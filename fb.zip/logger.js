const fs = require('fs');
const path = require('path');

const ENABLE_LOGGING = true;
const LOG_DIR = path.join(__dirname, 'logs');
const MAX_FILE_SIZE = 50 * 1024; // 50KB

let fileIndex = 1;
let currentLogFilePath;
let currentLogStream;
let failedLogStream;

// Helper to get timestamp for filenames
function getFileTimestamp() {
    return new Date().toISOString().replace(/:/g, '-'); // Replace ":" so filename is valid
}

// Helper to get timestamp for inside logs
function getTimeStamp() {
    return new Date().toISOString();
}

if (ENABLE_LOGGING) {
    if (!fs.existsSync(LOG_DIR)) {
        fs.mkdirSync(LOG_DIR);
    }

    // Create log file names with date & time
    const timestamp = getFileTimestamp();
    currentLogFilePath = path.join(LOG_DIR, `[${timestamp}]_text`);
    currentLogStream = fs.createWriteStream(currentLogFilePath, { flags: 'a' });

    failedLogStream = fs.createWriteStream(
        path.join(LOG_DIR, `[${timestamp}]_failed.txt`),
        { flags: 'a' }
    );

    function createNewStream() {
        fileIndex++;
        const newTimestamp = getFileTimestamp();
        currentLogFilePath = path.join(LOG_DIR, `[${newTimestamp}]_text`);
        return fs.createWriteStream(currentLogFilePath, { flags: 'a' });
    }

    function logToFile(message, type = 'success') {
        const logMessage = `[${getTimeStamp()}] ${message}\n`;

        if (type === 'fail') {
            failedLogStream.write(logMessage);
            return;
        }

        currentLogStream.write(logMessage, () => {
            if (!fs.existsSync(currentLogFilePath)) {
                fs.writeFileSync(currentLogFilePath, ''); // create empty file
            }

            const { size } = fs.statSync(currentLogFilePath);
            if (size > MAX_FILE_SIZE) {
                currentLogStream.end();
                currentLogStream = createNewStream();
            }
        });
    }

    function shouldBeFailLog(text) {
        return (
            text.includes('❌') ||
            text.toLowerCase().includes('failed') ||
            text.toLowerCase().includes('error')
        );
    }

    const originalLog = console.log;
    const originalError = console.error;
    const originalWarn = console.warn;

    console.log = function (...args) {
        const combined = args.map(String).join(' ');
        originalLog(...args);
        logToFile(combined, shouldBeFailLog(combined) ? 'fail' : 'success');
    };

    console.error = function (...args) {
        const combined = args.map(String).join(' ');
        originalError(...args);
        logToFile(combined, 'fail');
    };

    console.warn = function (...args) {
        const combined = args.map(String).join(' ');
        originalWarn(...args);
        logToFile(combined, shouldBeFailLog(combined) ? 'fail' : 'success');
    };

    console.fail = function (...args) {
        const combined = args.map(String).join(' ');
        originalLog(...args);
        logToFile(combined, 'fail');
    };
}
