


// === Updated Reporting Backend (reporting.js) ===
const express = require('express');
const router = express.Router();
const db = require('../config/db');
const ExcelJS = require('exceljs');

// Helper function to handle database queries with promises
const queryAsync = (query, params = []) => {
  return new Promise((resolve, reject) => {
    db.query(query, params, (err, results) => {
      if (err) {
        reject(err);
      } else {
        resolve(results);
      }
    });
  });
};

// Check if table exists in given schema
const tableExists = async (schema, table) => {
  const query = `
    SELECT COUNT(*) AS count
    FROM information_schema.tables
    WHERE table_schema = ? AND table_name = ?
  `;
  const [result] = await queryAsync(query, [schema, table]);
  return result.count > 0;
};

// Get available schemas
router.get('/schemas', async (req, res) => {
  try {
    const results = await queryAsync('SHOW SCHEMAS');
    const schemas = results
      .map(row => Object.values(row)[0])
      .filter(s => !['information_schema', 'performance_schema', 'mysql', 'sys'].includes(s));
    res.json({ success: true, schemas });
  } catch (err) {
    console.error('Error loading schemas:', err);
    res.status(500).json({ error: 'Failed to load schemas' });
  }
});

// ✅ Get only available tables in selected schema
router.get('/available-tables', async (req, res) => {
  const { schema } = req.query;
  if (!schema) return res.status(400).json({ error: 'Missing schema' });

  const tablesToCheck = ['releases', 'requirement', 'tests', 'parameters', 'alm_testcase_steps', 'testsetfolder', 'testlogs', 'defects', 'testcasemodules_releases', 'testset', 'testinstance', 'reqtotestlink', 'releasetoreqlink', 'defectslinks'];
  const availableTables = [];

  try {
    for (const table of tablesToCheck) {
      const exists = await tableExists(schema, table);
      if (exists) availableTables.push(table);
    }
    res.json({ success: true, tables: availableTables });
  } catch (err) {
    console.error('Error checking tables:', err);
    res.status(500).json({ error: 'Error checking available tables' });
  }
})

// NEW ENDPOINT - Get list of tables from a selected schema
router.get('/tables', async (req, res) => {
  const schema = req.query.schema;
  if (!schema) return res.status(400).json({ error: 'Missing schema parameter' });

  try {
    const query = `
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = ? 
      AND table_type = 'BASE TABLE'
      ORDER BY table_name
    `;
    const results = await queryAsync(query, [schema]);
    const tables = results.map(row => row.table_name);
    res.json({ success: true, tables });
  } catch (err) {
    console.error('Error fetching tables:', err);
    res.status(500).json({ error: 'Error fetching tables list' });
  }
});

// Summary for releases with schema param
router.get('/summary', async (req, res) => {
  const schema = req.query.schema;
  if (!schema) return res.status(400).json({ error: 'Missing schema' });
  if (!await tableExists(schema, 'releases')) return res.json({ success: false });

  try {
    const query = `
      SELECT 
        COUNT(*) as total_releases,
        SUM(CASE WHEN qtest_releases_id IS NOT NULL AND qtest_releases_id != '' THEN 1 ELSE 0 END) as has_qtest_id,
        SUM(CASE WHEN upload_status = 'completed' THEN 1 ELSE 0 END) as completed_status,
        SUM(CASE WHEN qtest_releases_id IS NOT NULL AND qtest_releases_id != '' AND upload_status = 'completed' THEN 1 ELSE 0 END) as success_records,
        ROUND(
          (SUM(CASE WHEN qtest_releases_id IS NOT NULL AND qtest_releases_id != '' AND upload_status = 'completed' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0)) * 100, 2
        ) as success_percentage
      FROM \`${schema}\`.releases
    `;
    const results = await queryAsync(query);
    res.json({ success: true, summary: results[0] });
  } catch (err) {
    res.status(500).json({ error: 'Database error' });
  }
});

// Status breakdown for releases
router.get('/status-breakdown', async (req, res) => {
  const schema = req.query.schema;
  if (!schema || !await tableExists(schema, 'releases')) return res.json({ success: false });
  try {
    const query = `
      SELECT 
        CASE 
          WHEN qtest_releases_id IS NOT NULL AND qtest_releases_id != '' AND upload_status = 'completed' THEN 'Success'
          WHEN qtest_releases_id IS NULL OR qtest_releases_id = '' THEN 'Failed - Missing qTest ID'
          WHEN upload_status != 'completed' THEN 'Failed - Not Completed'
          ELSE 'Other'
        END as status_category,
        COUNT(*) as count
      FROM \`${schema}\`.releases
      GROUP BY status_category
    `;
    const results = await queryAsync(query);
    res.json({ success: true, data: results });
  } catch (err) {
    res.status(500).json({ error: 'Database error' });
  }
});

// Paginated releases
router.get('/all-releases', async (req, res) => {
  const schema = req.query.schema;
  if (!schema || !await tableExists(schema, 'releases')) return res.json({ success: false });
  const page = Math.max(1, parseInt(req.query.page) || 1);
  const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 10));
  const offset = (page - 1) * limit;
  try {
    const query = `
      SELECT 
      id,
        qtest_releases_id,
        upload_status,
        CASE 
          WHEN qtest_releases_id IS NOT NULL AND qtest_releases_id != '' AND upload_status = 'completed' THEN 'Success'
          WHEN qtest_releases_id IS NULL OR qtest_releases_id = '' THEN 'Failed'
          WHEN upload_status != 'completed' THEN 'Failed'
          ELSE 'Other'
        END as result_status
      FROM \`${schema}\`.releases
      ORDER BY id DESC
      LIMIT ? OFFSET ?
    `;
    const [results, countResults] = await Promise.all([
      queryAsync(query, [limit, offset]),
      queryAsync(`SELECT COUNT(*) as total FROM \`${schema}\`.releases`)
    ]);
    res.json({
      success: true,
      data: results,
      pagination: {
        current_page: page,
        per_page: limit,
        total: countResults[0].total,
        total_pages: Math.ceil(countResults[0].total / limit)
      }
    });
  } catch (err) {
    res.status(500).json({ error: 'Database error' });
  }
});

//--------REQUIREMENT---------------

// Summary for requirements
router.get('/requirement/summary', async (req, res) => {
  const schema = req.query.schema;
  if (!schema || !(await tableExists(schema, 'requirement'))) return res.json({ success: false });

  const query = `
    SELECT 
      COUNT(*) as total_requirement,
      SUM(CASE WHEN qtest_requirement_id IS NOT NULL AND qtest_requirement_id != '' THEN 1 ELSE 0 END) as has_qtest_id,
      SUM(CASE WHEN upload_status = 'completed' THEN 1 ELSE 0 END) as completed_status,
      SUM(CASE WHEN qtest_requirement_id IS NOT NULL AND qtest_requirement_id != '' AND upload_status = 'completed' THEN 1 ELSE 0 END) as success_records,
      ROUND(
        (SUM(CASE WHEN qtest_requirement_id IS NOT NULL AND qtest_requirement_id != '' AND upload_status = 'completed' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0)) * 100, 2
      ) as success_percentage
    FROM \`${schema}\`.requirement
  `;
  const results = await queryAsync(query);
  res.json({ success: true, summary: results[0] });
});

// Status breakdown
router.get('/requirement/status-breakdown', async (req, res) => {
  const schema = req.query.schema;
  if (!schema || !(await tableExists(schema, 'requirement'))) return res.json({ success: false });

  const query = `
    SELECT 
      CASE 
        WHEN qtest_requirement_id IS NOT NULL AND qtest_requirement_id != '' AND upload_status = 'completed' THEN 'Success'
        WHEN qtest_requirement_id IS NULL OR qtest_requirement_id = '' THEN 'Failed - Missing qTest ID'
        WHEN upload_status != 'completed' THEN 'Failed - Not Completed'
        ELSE 'Other'
      END as status_category,
      COUNT(*) as count
    FROM \`${schema}\`.requirement
    GROUP BY status_category
  `;
  const results = await queryAsync(query);
  res.json({ success: true, data: results });
});

// Paginated data
router.get('/requirement/all-requirement', async (req, res) => {
  const schema = req.query.schema;
  if (!schema || !(await tableExists(schema, 'requirement'))) return res.json({ success: false });

  const page = Math.max(1, parseInt(req.query.page) || 1);
  const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 10));
  const offset = (page - 1) * limit;

  const query = `
    SELECT 
    id,
      qtest_requirement_id,
      upload_status,
      CASE 
        WHEN qtest_requirement_id IS NOT NULL AND qtest_requirement_id != '' AND upload_status = 'completed' THEN 'Success'
        WHEN qtest_requirement_id IS NULL OR qtest_requirement_id = '' THEN 'Failed'
        WHEN upload_status != 'completed' THEN 'Failed'
        ELSE 'Other'
      END as result_status
    FROM \`${schema}\`.requirement
    ORDER BY id DESC
    LIMIT ? OFFSET ?
  `;
  const [results, countResults] = await Promise.all([
    queryAsync(query, [limit, offset]),
    queryAsync(`SELECT COUNT(*) as total FROM \`${schema}\`.requirement`)
  ]);

  res.json({
    success: true,
    data: results,
    pagination: {
      current_page: page,
      per_page: limit,
      total: countResults[0].total,
      total_pages: Math.ceil(countResults[0].total / limit)
    }
  });
});


// ===== testcasemodules_releases ENDPOINTS =====

// Total count
router.get('/testcasemodules_releases/total-count', async (req, res) => {
  try {
    const query = 'SELECT COUNT(*) as total_count FROM testcasemodules_releases';
    const results = await queryAsync(query);
    res.json({ success: true, total_count: results[0].total_count });
  } catch (err) {
    console.error('Error fetching testcasemodules_releases count:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// Status breakdown
router.get('/testcasemodules_releases/status-breakdown', async (req, res) => {
  try {
    const query = `
      SELECT 
        CASE 
          WHEN qTest_TC_ID IS NOT NULL AND qTest_TC_ID != '' AND upload_status = 'completed' THEN 'Success'
          WHEN qTest_TC_ID IS NULL OR qTest_TC_ID = '' THEN 'Failed - Missing qTest ID'
          WHEN upload_status != 'completed' THEN 'Failed - Not Completed'
          ELSE 'Other'
        END as status_category,
        COUNT(*) as count
      FROM testcasemodules_releases
      GROUP BY status_category
    `;
    const results = await queryAsync(query);
    res.json({ success: true, data: results });
  } catch (err) {
    console.error('Error fetching testcasemodules_releases status breakdown:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// All testcasemodules_releases with pagination
router.get('/testcasemodules_releases/all-testcasemodules_releases', async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 10));
    const offset = (page - 1) * limit;

    const query = `
      SELECT 
      ALM_PID,
        qTest_TC_ID,
        upload_status,
        CASE 
          WHEN qTest_TC_ID IS NOT NULL AND qTest_TC_ID != '' AND upload_status = 'completed' THEN 'Success'
          WHEN qTest_TC_ID IS NULL OR qTest_TC_ID = '' THEN 'Failed'
          WHEN upload_status != 'completed' THEN 'Failed'
          ELSE 'Other'
        END as result_status
      FROM testcasemodules_releases
      ORDER BY ALM_PID DESC
      LIMIT ? OFFSET ?
    `;

    const [results, countResults] = await Promise.all([
      queryAsync(query, [limit, offset]),
      queryAsync('SELECT COUNT(*) as total FROM testcasemodules_releases')
    ]);

    res.json({
      success: true,
      data: results,
      pagination: {
        current_page: page,
        per_page: limit,
        total: countResults[0].total,
        total_pages: Math.ceil(countResults[0].total / limit)
      }
    });
  } catch (err) {
    console.error('Error fetching all testcasemodules_releases:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// Summary
router.get('/testcasemodules_releases/summary', async (req, res) => {
  try {
    const query = `
      SELECT 
        COUNT(*) as total_testcasemodules_releases,
        SUM(CASE WHEN qTest_TC_ID IS NOT NULL AND qTest_TC_ID != '' THEN 1 ELSE 0 END) as has_qtest_id,
        SUM(CASE WHEN upload_status = 'completed' THEN 1 ELSE 0 END) as completed_status,
        SUM(CASE WHEN qTest_TC_ID IS NOT NULL AND qTest_TC_ID != '' AND upload_status = 'completed' THEN 1 ELSE 0 END) as success_records,
        ROUND(
          (SUM(CASE WHEN qTest_TC_ID IS NOT NULL AND qTest_TC_ID != '' AND upload_status = 'completed' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0)) * 100, 2
        ) as success_percentage
      FROM testcasemodules_releases
    `;
    const results = await queryAsync(query);
    res.json({ success: true, summary: results[0] });
  } catch (err) {
    console.error('Error fetching testcasemodules_releases summary:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// ===== TESTS ENDPOINTS =====

// Total count
router.get('/tests/total-count', async (req, res) => {
  const schema = req.query.schema;
  if (!schema || !(await tableExists(schema, 'tests'))) return res.json({ success: false });

  try {
    const query = `SELECT COUNT(*) as total_count FROM \`${schema}\`.tests`;
    const results = await queryAsync(query);
    res.json({ success: true, total_count: results[0].total_count });
  } catch (err) {
    console.error('Error fetching tests count:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// Status breakdown
router.get('/tests/status-breakdown', async (req, res) => {
  const schema = req.query.schema;
  if (!schema || !(await tableExists(schema, 'tests'))) return res.json({ success: false });

  try {
    const query = `
      SELECT 
        CASE 
          WHEN qtest_testcase_id IS NOT NULL AND qtest_testcase_id != '' AND upload_status = 'completed' THEN 'Success'
          WHEN qtest_testcase_id IS NULL OR qtest_testcase_id = '' THEN 'Failed - Missing qTest ID'
          WHEN upload_status != 'completed' THEN 'Failed - Not Completed'
          ELSE 'Other'
        END as status_category,
        COUNT(*) as count
      FROM \`${schema}\`.tests
      GROUP BY status_category
    `;
    const results = await queryAsync(query);
    res.json({ success: true, data: results });
  } catch (err) {
    console.error('Error fetching tests status breakdown:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// All tests with pagination
router.get('/tests/all-tests', async (req, res) => {
  const schema = req.query.schema;
  if (!schema || !(await tableExists(schema, 'tests'))) return res.json({ success: false });

  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 10));
    const offset = (page - 1) * limit;

    const query = `
      SELECT 
      id,
        qtest_testcase_id,
        upload_status,
        CASE 
          WHEN qtest_testcase_id IS NOT NULL AND qtest_testcase_id != '' AND upload_status = 'completed' THEN 'Success'
          WHEN qtest_testcase_id IS NULL OR qtest_testcase_id = '' THEN 'Failed'
          WHEN upload_status != 'completed' THEN 'Failed'
          ELSE 'Other'
        END as result_status
      FROM \`${schema}\`.tests
      ORDER BY id DESC
      LIMIT ? OFFSET ?
    `;

    const [results, countResults] = await Promise.all([
      queryAsync(query, [limit, offset]),
      queryAsync(`SELECT COUNT(*) as total FROM \`${schema}\`.tests`)
    ]);

    res.json({
      success: true,
      data: results,
      pagination: {
        current_page: page,
        per_page: limit,
        total: countResults[0].total,
        total_pages: Math.ceil(countResults[0].total / limit)
      }
    });
  } catch (err) {
    console.error('Error fetching all tests:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// Summary
router.get('/tests/summary', async (req, res) => {
  const schema = req.query.schema;
  if (!schema || !(await tableExists(schema, 'tests'))) return res.json({ success: false });

  try {
    const query = `
      SELECT 
        COUNT(*) as total_tests,
        SUM(CASE WHEN qtest_testcase_id IS NOT NULL AND qtest_testcase_id != '' THEN 1 ELSE 0 END) as has_qtest_id,
        SUM(CASE WHEN upload_status = 'completed' THEN 1 ELSE 0 END) as completed_status,
        SUM(CASE WHEN qtest_testcase_id IS NOT NULL AND qtest_testcase_id != '' AND upload_status = 'completed' THEN 1 ELSE 0 END) as success_records,
        ROUND(
          (SUM(CASE WHEN qtest_testcase_id IS NOT NULL AND qtest_testcase_id != '' AND upload_status = 'completed' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0)) * 100, 2
        ) as success_percentage
      FROM \`${schema}\`.tests
    `;
    const results = await queryAsync(query);
    res.json({ success: true, summary: results[0] });
  } catch (err) {
    console.error('Error fetching tests summary:', err);
    res.status(500).json({ error: 'Database error' });
  }
});


// ===== PARAMETERS ENDPOINTS =====

// Total count
router.get('/parameters/total-count', async (req, res) => {
  const schema = req.query.schema;
  if (!schema || !(await tableExists(schema, 'parameters'))) return res.json({ success: false });

  try {
    const query = `SELECT COUNT(*) as total_count FROM \`${schema}\`.parameters`;
    const results = await queryAsync(query);
    res.json({ success: true, total_count: results[0].total_count });
  } catch (err) {
    console.error('Error fetching parameters count:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// Status breakdown
router.get('/parameters/status-breakdown', async (req, res) => {
  const schema = req.query.schema;
  if (!schema || !(await tableExists(schema, 'parameters'))) return res.json({ success: false });

  try {
    const query = `
      SELECT 
        CASE 
          WHEN  qTest_Params_id IS NOT NULL AND  qTest_Params_id != '' AND Status_Params = 'completed' THEN 'Success'
          WHEN  qTest_Params_id IS NULL OR  qTest_Params_id = '' THEN 'Failed - Missing qTest ID'
          WHEN Status_Params != 'completed' THEN 'Failed - Not Completed'
          ELSE 'Other'
        END as status_category,
        COUNT(*) as count
      FROM \`${schema}\`.parameters
      GROUP BY status_category
    `;
    const results = await queryAsync(query);
    res.json({ success: true, data: results });
  } catch (err) {
    console.error('Error fetching parameters status breakdown:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// All parameters with pagination
router.get('/parameters/all-parameters', async (req, res) => {
  const schema = req.query.schema;
  if (!schema || !(await tableExists(schema, 'parameters'))) return res.json({ success: false });

  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 10));
    const offset = (page - 1) * limit;

    const query = `
      SELECT 
      id,
         qTest_Params_id,
        Status_Params,
        CASE 
          WHEN  qTest_Params_id IS NOT NULL AND  qTest_Params_id != '' AND Status_Params = 'completed' THEN 'Success'
          WHEN  qTest_Params_id IS NULL OR  qTest_Params_id = '' THEN 'Failed'
          WHEN Status_Params != 'completed' THEN 'Failed'
          ELSE 'Other'
        END as result_status
      FROM \`${schema}\`.parameters
      ORDER BY id DESC
      LIMIT ? OFFSET ?
    `;

    const [results, countResults] = await Promise.all([
      queryAsync(query, [limit, offset]),
      queryAsync(`SELECT COUNT(*) as total FROM \`${schema}\`.parameters`)
    ]);

    res.json({
      success: true,
      data: results,
      pagination: {
        current_page: page,
        per_page: limit,
        total: countResults[0].total,
        total_pages: Math.ceil(countResults[0].total / limit)
      }
    });
  } catch (err) {
    console.error('Error fetching all parameters:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// Summary
router.get('/parameters/summary', async (req, res) => {
  const schema = req.query.schema;
  if (!schema || !(await tableExists(schema, 'parameters'))) return res.json({ success: false });

  try {
    const query = `
      SELECT 
        COUNT(*) as total_parameters,
        SUM(CASE WHEN  qTest_Params_id IS NOT NULL AND  qTest_Params_id != '' THEN 1 ELSE 0 END) as has_qtest_id,
        SUM(CASE WHEN Status_Params = 'completed' THEN 1 ELSE 0 END) as completed_status,
        SUM(CASE WHEN  qTest_Params_id IS NOT NULL AND  qTest_Params_id != '' AND Status_Params = 'completed' THEN 1 ELSE 0 END) as success_records,
        ROUND(
          (SUM(CASE WHEN  qTest_Params_id IS NOT NULL AND  qTest_Params_id != '' AND Status_Params = 'completed' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0)) * 100, 2
        ) as success_percentage
      FROM \`${schema}\`.parameters
    `;
    const results = await queryAsync(query);
    res.json({ success: true, summary: results[0] });
  } catch (err) {
    console.error('Error fetching parameters summary:', err);
    res.status(500).json({ error: 'Database error' });
  }
});


// ===== alm_testcase_steps ENDPOINTS =====

// Total count
router.get('/alm_testcase_steps/total-count', async (req, res) => {
  const schema = req.query.schema;
  if (!schema || !(await tableExists(schema, 'alm_testcase_steps'))) return res.json({ success: false });

  try {
    const query = `SELECT COUNT(*) as total_count FROM \`${schema}\`.alm_testcase_steps`;
    const results = await queryAsync(query);
    res.json({ success: true, total_count: results[0].total_count });
  } catch (err) {
    console.error('Error fetching alm_testcase_steps count:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// Status breakdown
router.get('/alm_testcase_steps/status-breakdown', async (req, res) => {
  const schema = req.query.schema;
  if (!schema || !(await tableExists(schema, 'alm_testcase_steps'))) return res.json({ success: false });

  try {
    const query = `
      SELECT 
        CASE 
          WHEN  qtest_tc_step_id IS NOT NULL AND  qtest_tc_step_id != '' AND upload_status = 'completed' THEN 'Success'
          WHEN  qtest_tc_step_id IS NULL OR  qtest_tc_step_id = '' THEN 'Failed - Missing qTest ID'
          WHEN upload_status != 'completed' THEN 'Failed - Not Completed'
          ELSE 'Other'
        END as status_category,
        COUNT(*) as count
      FROM \`${schema}\`.alm_testcase_steps
      GROUP BY status_category
    `;
    const results = await queryAsync(query);
    res.json({ success: true, data: results });
  } catch (err) {
    console.error('Error fetching alm_testcase_steps status breakdown:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// All alm_testcase_steps with pagination
router.get('/alm_testcase_steps/all-alm_testcase_steps', async (req, res) => {
  const schema = req.query.schema;
  if (!schema || !(await tableExists(schema, 'alm_testcase_steps'))) return res.json({ success: false });

  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 10));
    const offset = (page - 1) * limit;

    const query = `
      SELECT 
      id,
         qtest_tc_step_id,
        upload_status,
        CASE 
          WHEN  qtest_tc_step_id IS NOT NULL AND  qtest_tc_step_id != '' AND upload_status = 'completed' THEN 'Success'
          WHEN  qtest_tc_step_id IS NULL OR  qtest_tc_step_id = '' THEN 'Failed'
          WHEN upload_status != 'completed' THEN 'Failed'
          ELSE 'Other'
        END as result_status
      FROM \`${schema}\`.alm_testcase_steps
      ORDER BY id DESC
      LIMIT ? OFFSET ?
    `;

    const [results, countResults] = await Promise.all([
      queryAsync(query, [limit, offset]),
      queryAsync(`SELECT COUNT(*) as total FROM \`${schema}\`.alm_testcase_steps`)
    ]);

    res.json({
      success: true,
      data: results,
      pagination: {
        current_page: page,
        per_page: limit,
        total: countResults[0].total,
        total_pages: Math.ceil(countResults[0].total / limit)
      }
    });
  } catch (err) {
    console.error('Error fetching all alm_testcase_steps:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// Summary
router.get('/alm_testcase_steps/summary', async (req, res) => {
  const schema = req.query.schema;
  if (!schema || !(await tableExists(schema, 'alm_testcase_steps'))) return res.json({ success: false });

  try {
    const query = `
      SELECT 
        COUNT(*) as total_alm_testcase_steps,
        SUM(CASE WHEN  qtest_tc_step_id IS NOT NULL AND  qtest_tc_step_id != '' THEN 1 ELSE 0 END) as has_qtest_id,
        SUM(CASE WHEN upload_status = 'completed' THEN 1 ELSE 0 END) as completed_status,
        SUM(CASE WHEN  qtest_tc_step_id IS NOT NULL AND  qtest_tc_step_id != '' AND upload_status = 'completed' THEN 1 ELSE 0 END) as success_records,
        ROUND(
          (SUM(CASE WHEN  qtest_tc_step_id IS NOT NULL AND  qtest_tc_step_id != '' AND upload_status = 'completed' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0)) * 100, 2
        ) as success_percentage
      FROM \`${schema}\`.alm_testcase_steps
    `;
    const results = await queryAsync(query);
    res.json({ success: true, summary: results[0] });
  } catch (err) {
    console.error('Error fetching alm_testcase_steps summary:', err);
    res.status(500).json({ error: 'Database error' });
  }
});


// ===== testsetfolder ENDPOINTS =====

// Total count
router.get('/testsetfolder/total-count', async (req, res) => {
  const schema = req.query.schema;
  if (!schema || !(await tableExists(schema, 'testsetfolder'))) return res.json({ success: false });

  try {
    const query = `SELECT COUNT(*) as total_count FROM \`${schema}\`.testsetfolder`;
    const results = await queryAsync(query);
    res.json({ success: true, total_count: results[0].total_count });
  } catch (err) {
    console.error('Error fetching testsetfolder count:', err);
    res.status(500).json({ error: 'Database error' });
  }
});


// Status breakdown
router.get('/testsetfolder/status-breakdown', async (req, res) => {
  const schema = req.query.schema;
  if (!schema || !(await tableExists(schema, 'testsetfolder'))) return res.json({ success: false });

  try {
    const query = `
      SELECT 
        CASE 
          WHEN  qTest_id IS NOT NULL AND qTest_id != '' AND upload_status = 'completed' THEN 'Success'
          WHEN  qTest_id IS NULL OR qTest_id = '' THEN 'Failed - Missing qTest ID'
          WHEN upload_status != 'completed' THEN 'Failed - Not Completed'
          ELSE 'Other'
        END as status_category,
        COUNT(*) as count
      FROM \`${schema}\`.testsetfolder
      GROUP BY status_category
    `;
    const results = await queryAsync(query);
    res.json({ success: true, data: results });
  } catch (err) {
    console.error('Error fetching testsetfolder status breakdown:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// All testsetfolder with pagination
router.get('/testsetfolder/all-testsetfolder', async (req, res) => {
  const schema = req.query.schema;
  if (!schema || !(await tableExists(schema, 'testsetfolder'))) return res.json({ success: false });

  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 10));
    const offset = (page - 1) * limit;

    const query = `
      SELECT 
         id,
        qTest_id
        upload_status,
        CASE 
          WHEN  qTest_id IS NOT NULL AND  qTest_id != '' AND upload_status = 'completed' THEN 'Success'
          WHEN  qTest_id IS NULL OR  qTest_id = '' THEN 'Failed'
          WHEN upload_status != 'completed' THEN 'Failed'
          ELSE 'Other'
        END as result_status
      FROM \`${schema}\`.testsetfolder
      ORDER BY  id DESC
      LIMIT ? OFFSET ?
    `;

    const [results, countResults] = await Promise.all([
      queryAsync(query, [limit, offset]),
      queryAsync(`SELECT COUNT(*) as total FROM \`${schema}\`.testsetfolder`)
    ]);

    res.json({
      success: true,
      data: results,
      pagination: {
        current_page: page,
        per_page: limit,
        total: countResults[0].total,
        total_pages: Math.ceil(countResults[0].total / limit)
      }
    });
  } catch (err) {
    console.error('Error fetching all testsetfolder:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// Summary
router.get('/testsetfolder/summary', async (req, res) => {
  const schema = req.query.schema;
  if (!schema || !(await tableExists(schema, 'testsetfolder'))) return res.json({ success: false });

  try {
    const query = `
      SELECT 
        COUNT(*) as total_testsetfolder,
        SUM(CASE WHEN qTest_id IS NOT NULL AND qTest_id != '' THEN 1 ELSE 0 END) as has_qtest_id,
        SUM(CASE WHEN upload_status = 'completed' THEN 1 ELSE 0 END) as completed_status,
        SUM(CASE WHEN qTest_id IS NOT NULL AND qTest_id != '' AND upload_status = 'completed' THEN 1 ELSE 0 END) as success_records,
        ROUND(
          (SUM(CASE WHEN qTest_id IS NOT NULL AND qTest_id != '' AND upload_status = 'completed' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0)) * 100, 2
        ) as success_percentage
      FROM \`${schema}\`.testsetfolder
    `;
    const results = await queryAsync(query);
    res.json({ success: true, summary: results[0] });
  } catch (err) {
    console.error('Error fetching testsetfolder summary:', err);
    res.status(500).json({ error: 'Database error' });
  }
});


// ===== TESTSET ENDPOINTS =====

// Total count
router.get('/testset/total-count', async (req, res) => {
  try {
    const query = 'SELECT COUNT(*) as total_count FROM testset';
    const results = await queryAsync(query);
    res.json({ success: true, total_count: results[0].total_count });
  } catch (err) {
    console.error('Error fetching testset count:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// Status breakdown
router.get('/testset/status-breakdown', async (req, res) => {
  try {
    const query = `
      SELECT 
        CASE 
          WHEN qtest_testset_id IS NOT NULL AND qtest_testset_id != '' AND upload_status = 'completed' THEN 'Success'
          WHEN qtest_testset_id IS NULL OR qtest_testset_id = '' THEN 'Failed - Missing qTest ID'
          WHEN upload_status != 'completed' THEN 'Failed - Not Completed'
          ELSE 'Other'
        END as status_category,
        COUNT(*) as count
      FROM testset
      GROUP BY status_category
    `;
    const results = await queryAsync(query);
    res.json({ success: true, data: results });
  } catch (err) {
    console.error('Error fetching testset status breakdown:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// All testset with pagination
router.get('/testset/all-testset', async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 10));
    const offset = (page - 1) * limit;

    const query = `
      SELECT 
      id,
        qtest_testset_id,
        upload_status,
        CASE 
          WHEN qtest_testset_id IS NOT NULL AND qtest_testset_id != '' AND upload_status = 'completed' THEN 'Success'
          WHEN qtest_testset_id IS NULL OR qtest_testset_id = '' THEN 'Failed'
          WHEN upload_status != 'completed' THEN 'Failed'
          ELSE 'Other'
        END as result_status
      FROM testset
      ORDER BY id DESC
      LIMIT ? OFFSET ?
    `;

    const [results, countResults] = await Promise.all([
      queryAsync(query, [limit, offset]),
      queryAsync('SELECT COUNT(*) as total FROM testset')
    ]);

    res.json({
      success: true,
      data: results,
      pagination: {
        current_page: page,
        per_page: limit,
        total: countResults[0].total,
        total_pages: Math.ceil(countResults[0].total / limit)
      }
    });
  } catch (err) {
    console.error('Error fetching all testset:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// Summary
router.get('/testset/summary', async (req, res) => {
  try {
    const query = `
      SELECT 
        COUNT(*) as total_testset,
        SUM(CASE WHEN qtest_testset_id IS NOT NULL AND qtest_testset_id != '' THEN 1 ELSE 0 END) as has_qtest_id,
        SUM(CASE WHEN upload_status = 'completed' THEN 1 ELSE 0 END) as completed_status,
        SUM(CASE WHEN qtest_testset_id IS NOT NULL AND qtest_testset_id != '' AND upload_status = 'completed' THEN 1 ELSE 0 END) as success_records,
        ROUND(
          (SUM(CASE WHEN qtest_testset_id IS NOT NULL AND qtest_testset_id != '' AND upload_status = 'completed' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0)) * 100, 2
        ) as success_percentage
      FROM testset
    `;
    const results = await queryAsync(query);
    res.json({ success: true, summary: results[0] });
  } catch (err) {
    console.error('Error fetching testset summary:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// ===== testinstance ENDPOINTS =====

// Total count
router.get('/testinstance/total-count', async (req, res) => {
  try {
    const query = 'SELECT COUNT(*) as total_count FROM testinstance';
    const results = await queryAsync(query);
    res.json({ success: true, total_count: results[0].total_count });
  } catch (err) {
    console.error('Error fetching testinstance count:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// Status breakdown
router.get('/testinstance/status-breakdown', async (req, res) => {
  try {
    const query = `
      SELECT 
        CASE 
          WHEN qtest_testinstance_id IS NOT NULL AND qtest_testinstance_id != '' AND upload_status = 'completed' THEN 'Success'
          WHEN qtest_testinstance_id IS NULL OR qtest_testinstance_id = '' THEN 'Failed - Missing qTest ID'
          WHEN upload_status != 'completed' THEN 'Failed - Not Completed'
          ELSE 'Other'
        END as status_category,
        COUNT(*) as count
      FROM testinstance
      GROUP BY status_category
    `;
    const results = await queryAsync(query);
    res.json({ success: true, data: results });
  } catch (err) {
    console.error('Error fetching testinstance status breakdown:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// All testinstance with pagination
router.get('/testinstance/all-testinstance', async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 10));
    const offset = (page - 1) * limit;

    const query = `
      SELECT 
      id,
        qtest_testinstance_id,
        upload_status,
        CASE 
          WHEN qtest_testinstance_id IS NOT NULL AND qtest_testinstance_id != '' AND upload_status = 'completed' THEN 'Success'
          WHEN qtest_testinstance_id IS NULL OR qtest_testinstance_id = '' THEN 'Failed'
          WHEN upload_status != 'completed' THEN 'Failed'
          ELSE 'Other'
        END as result_status
      FROM testinstance
      ORDER BY id DESC
      LIMIT ? OFFSET ?
    `;

    const [results, countResults] = await Promise.all([
      queryAsync(query, [limit, offset]),
      queryAsync('SELECT COUNT(*) as total FROM testinstance')
    ]);

    res.json({
      success: true,
      data: results,
      pagination: {
        current_page: page,
        per_page: limit,
        total: countResults[0].total,
        total_pages: Math.ceil(countResults[0].total / limit)
      }
    });
  } catch (err) {
    console.error('Error fetching all testinstance:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// Summary
router.get('/testinstance/summary', async (req, res) => {
  try {
    const query = `
      SELECT 
        COUNT(*) as total_testinstance,
        SUM(CASE WHEN qtest_testinstance_id IS NOT NULL AND qtest_testinstance_id != '' THEN 1 ELSE 0 END) as has_qtest_id,
        SUM(CASE WHEN upload_status = 'completed' THEN 1 ELSE 0 END) as completed_status,
        SUM(CASE WHEN qtest_testinstance_id IS NOT NULL AND qtest_testinstance_id != '' AND upload_status = 'completed' THEN 1 ELSE 0 END) as success_records,
        ROUND(
          (SUM(CASE WHEN qtest_testinstance_id IS NOT NULL AND qtest_testinstance_id != '' AND upload_status = 'completed' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0)) * 100, 2
        ) as success_percentage
      FROM testinstance
    `;
    const results = await queryAsync(query);
    res.json({ success: true, summary: results[0] });
  } catch (err) {
    console.error('Error fetching testinstance summary:', err);
    res.status(500).json({ error: 'Database error' });
  }
});


// ===== testlogs ENDPOINTS =====

// Total count
router.get('/testlogs/total-count', async (req, res) => {
  try {
    const query = 'SELECT COUNT(*) as total_count FROM testlogs';
    const results = await queryAsync(query);
    res.json({ success: true, total_count: results[0].total_count });
  } catch (err) {
    console.error('Error fetching testlogs count:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// Status breakdown
router.get('/testlogs/status-breakdown', async (req, res) => {
  try {
    const query = `
      SELECT 
        CASE 
          WHEN qtest_testlog_id IS NOT NULL AND qtest_testlog_id != '' AND upload_status= 'completed' THEN 'Success'
          WHEN qtest_testlog_id IS NULL OR qtest_testlog_id = '' THEN 'Failed - Missing qTest ID'
          WHEN upload_status!= 'completed' THEN 'Failed - Not Completed'
          ELSE 'Other'
        END as status_category,
        COUNT(*) as count
      FROM testlogs
      GROUP BY status_category
    `;
    const results = await queryAsync(query);
    res.json({ success: true, data: results });
  } catch (err) {
    console.error('Error fetching testlogs status breakdown:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// All testlogs with pagination
router.get('/testlogs/all-testlogs', async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 10));
    const offset = (page - 1) * limit;

    const query = `
      SELECT 
         id,
         qtest_testlog_id ,
        upload_status,
        CASE 
          WHEN qtest_testlog_id IS NOT NULL AND qtest_testlog_id != '' AND upload_status = 'completed' THEN 'Success'
          WHEN qtest_testlog_id IS NULL OR qtest_testlog_id = '' THEN 'Failed'
          WHEN upload_status!= 'completed' THEN 'Failed'
          ELSE 'Other'
        END as result_status
      FROM testlogs
      ORDER BY id DESC
      LIMIT ? OFFSET ?
    `;

    const [results, countResults] = await Promise.all([
      queryAsync(query, [limit, offset]),
      queryAsync('SELECT COUNT(*) as total FROM testlogs')
    ]);

    res.json({
      success: true,
      data: results,
      pagination: {
        current_page: page,
        per_page: limit,
        total: countResults[0].total,
        total_pages: Math.ceil(countResults[0].total / limit)
      }
    });
  } catch (err) {
    console.error('Error fetching all testlogs:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// Summary
router.get('/testlogs/summary', async (req, res) => {
  try {
    const query = `
      SELECT 
        COUNT(*) as total_testlogs,
        SUM(CASE WHEN qtest_testlog_id IS NOT NULL AND qtest_testlog_id != '' THEN 1 ELSE 0 END) as has_qtest_id,
        SUM(CASE WHEN upload_status= 'completed' THEN 1 ELSE 0 END) as completed_status,
        SUM(CASE WHEN qtest_testlog_id IS NOT NULL AND qtest_testlog_id != '' AND upload_status= 'completed' THEN 1 ELSE 0 END) as success_records,
        ROUND(
          (SUM(CASE WHEN qtest_testlog_id IS NOT NULL AND qtest_testlog_id != '' AND upload_status= 'completed' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0)) * 100, 2
        ) as success_percentage
      FROM testlogs
    `;
    const results = await queryAsync(query);
    res.json({ success: true, summary: results[0] });
  } catch (err) {
    console.error('Error fetching testlogs summary:', err);
    res.status(500).json({ error: 'Database error' });
  }
});



// ===== DEFECTS ENDPOINTS =====

// Total count
router.get('/defects/total-count', async (req, res) => {
  try {
    const query = 'SELECT COUNT(*) as total_count FROM defects';
    const results = await queryAsync(query);
    res.json({ success: true, total_count: results[0].total_count });
  } catch (err) {
    console.error('Error fetching defects count:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// Status breakdown
router.get('/defects/status-breakdown', async (req, res) => {
  try {
    const query = `
      SELECT 
        CASE 
          WHEN qtest_defects_id IS NOT NULL AND qtest_defects_id != '' AND upload_status = 'completed' THEN 'Success'
          WHEN qtest_defects_id IS NULL OR qtest_defects_id = '' THEN 'Failed - Missing qTest ID'
          WHEN upload_status != 'completed' THEN 'Failed - Not Completed'
          ELSE 'Other'
        END as status_category,
        COUNT(*) as count
      FROM defects
      GROUP BY status_category
    `;
    const results = await queryAsync(query);
    res.json({ success: true, data: results });
  } catch (err) {
    console.error('Error fetching defects status breakdown:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// All defects with pagination
router.get('/defects/all-defects', async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 10));
    const offset = (page - 1) * limit;

    const query = `
SELECT 
  id,
  qtest_defects_id,
  upload_status,
  CASE 
    WHEN qtest_defects_id IS NOT NULL AND qtest_defects_id != '' AND upload_status = 'completed' THEN 'Success'
    WHEN qtest_defects_id IS NULL OR qtest_defects_id = '' THEN 'Failed'
    WHEN upload_status != 'completed' THEN 'Failed'
    ELSE 'Other'
  END as result_status
FROM defects
ORDER BY id DESC
LIMIT ? OFFSET ?

    `;

    const [results, countResults] = await Promise.all([
      queryAsync(query, [limit, offset]),
      queryAsync('SELECT COUNT(*) as total FROM defects')
    ]);

    res.json({
      success: true,
      data: results,
      pagination: {
        current_page: page,
        per_page: limit,
        total: countResults[0].total,
        total_pages: Math.ceil(countResults[0].total / limit)
      }
    });
  } catch (err) {
    console.error('Error fetching all defects:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// Summary
router.get('/defects/summary', async (req, res) => {
  try {
    const query = `
      SELECT 
        COUNT(*) as total_defects,
        SUM(CASE WHEN qtest_defects_id IS NOT NULL AND qtest_defects_id != '' THEN 1 ELSE 0 END) as has_qtest_id,
        SUM(CASE WHEN upload_status = 'completed' THEN 1 ELSE 0 END) as completed_status,
        SUM(CASE WHEN qtest_defects_id IS NOT NULL AND qtest_defects_id != '' AND upload_status = 'completed' THEN 1 ELSE 0 END) as success_records,
        ROUND(
          (SUM(CASE WHEN qtest_defects_id IS NOT NULL AND qtest_defects_id != '' AND upload_status = 'completed' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0)) * 100, 2
        ) as success_percentage
      FROM defects
    `;
    const results = await queryAsync(query);
    res.json({ success: true, summary: results[0] });
  } catch (err) {
    console.error('Error fetching defects summary:', err);
    res.status(500).json({ error: 'Database error' });
  }
});


//----------Link---------------

///RELEASESTOLINK---------

// Total count
router.get('/releasetoreqlink/total-count', async (req, res) => {
  try {
    const query = 'SELECT COUNT(*) as total_count FROM  releasetoreqlink';
    const results = await queryAsync(query);
    res.json({ success: true, total_count: results[0].total_count });
  } catch (err) {
    console.error('Error fetching  releasetoreqlink count:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// Status breakdown
router.get('/releasetoreqlink/status-breakdown', async (req, res) => {
  try {
    const query = `
      SELECT 
        CASE 
          WHEN id IS NOT NULL AND id != '' AND link_status = 'linked' THEN 'Success'
          WHEN id IS NULL OR id = '' THEN 'Failed - Missing qTest ID'
          WHEN link_status != 'linked' THEN 'Failed - Not linked'
          ELSE 'Other'
        END as status_category,
        COUNT(*) as count
      FROM  releasetoreqlink
      GROUP BY status_category
    `;
    const results = await queryAsync(query);
    res.json({ success: true, data: results });
  } catch (err) {
    console.error('Error fetching  releasetoreqlink status breakdown:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// All  releasetoreqlink with pagination
router.get('/releasetoreqlink/all-releasetoreqlink', async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 10));
    const offset = (page - 1) * limit;

    const query = `
      SELECT 
        id,
        link_status,
        CASE 
          WHEN id IS NOT NULL AND id != '' AND link_status = 'linked' THEN 'Success'
          WHEN id IS NULL OR id = '' THEN 'Failed'
          WHEN link_status != 'linked' THEN 'Failed'
          ELSE 'Other'
        END as result_status
      FROM  releasetoreqlink
      ORDER BY id DESC
      LIMIT ? OFFSET ?
    `;

    const [results, countResults] = await Promise.all([
      queryAsync(query, [limit, offset]),
      queryAsync('SELECT COUNT(*) as total FROM  releasetoreqlink')
    ]);

    res.json({
      success: true,
      data: results,
      pagination: {
        current_page: page,
        per_page: limit,
        total: countResults[0].total,
        total_pages: Math.ceil(countResults[0].total / limit)
      }
    });
  } catch (err) {
    console.error('Error fetching all  releasetoreqlink:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// Summary
router.get('/releasetoreqlink/summary', async (req, res) => {
  try {
    const query = `
      SELECT 
        COUNT(*) as total_releasetoreqlink,
        SUM(CASE WHEN id IS NOT NULL AND id != '' THEN 1 ELSE 0 END) as has_qtest_id,
        SUM(CASE WHEN link_status = 'linked' THEN 1 ELSE 0 END) as linked_status,
        SUM(CASE WHEN id IS NOT NULL AND id != '' AND link_status = 'linked' THEN 1 ELSE 0 END) as success_records,
        ROUND(
          (SUM(CASE WHEN id IS NOT NULL AND id != '' AND link_status = 'linked' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0)) * 100, 2
        ) as success_percentage
      FROM  releasetoreqlink
    `;
    const results = await queryAsync(query);
    res.json({ success: true, summary: results[0] });
  } catch (err) {
    console.error('Error fetching  releasetoreqlink summary:', err);
    res.status(500).json({ error: 'Database error' });
  }
});


//REQUIREMENTTOLINK--------------


// Total count
router.get('/reqtotestlink/total-count', async (req, res) => {
  try {
    const query = 'SELECT COUNT(*) as total_count FROM  reqtotestlink';
    const results = await queryAsync(query);
    res.json({ success: true, total_count: results[0].total_count });
  } catch (err) {
    console.error('Error fetching  reqtotestlink count:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// Status breakdown
router.get('/reqtotestlink/status-breakdown', async (req, res) => {
  try {
    const query = `
      SELECT 
        CASE 
          WHEN id IS NOT NULL AND id != '' AND link_status = 'linked' THEN 'Success'
          WHEN id IS NULL OR id = '' THEN 'Failed - Missing qTest ID'
          WHEN link_status != 'linked' THEN 'Failed - Not linked'
          ELSE 'Other'
        END as status_category,
        COUNT(*) as count
      FROM  reqtotestlink
      GROUP BY status_category
    `;
    const results = await queryAsync(query);
    res.json({ success: true, data: results });
  } catch (err) {
    console.error('Error fetching  reqtotestlink status breakdown:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// All  reqtotestlink with pagination
router.get('/reqtotestlink/all-reqtotestlink', async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 10));
    const offset = (page - 1) * limit;

    const query = `
      SELECT 
        id,
        link_status,
        CASE 
          WHEN id IS NOT NULL AND id != '' AND link_status = 'linked' THEN 'Success'
          WHEN id IS NULL OR id = '' THEN 'Failed'
          WHEN link_status != 'linked' THEN 'Failed'
          ELSE 'Other'
        END as result_status
      FROM  reqtotestlink
      ORDER BY id DESC
      LIMIT ? OFFSET ?
    `;

    const [results, countResults] = await Promise.all([
      queryAsync(query, [limit, offset]),
      queryAsync('SELECT COUNT(*) as total FROM  reqtotestlink')
    ]);

    res.json({
      success: true,
      data: results,
      pagination: {
        current_page: page,
        per_page: limit,
        total: countResults[0].total,
        total_pages: Math.ceil(countResults[0].total / limit)
      }
    });
  } catch (err) {
    console.error('Error fetching all  reqtotestlink:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// Summary
router.get('/reqtotestlink/summary', async (req, res) => {
  try {
    const query = `
      SELECT 
        COUNT(*) as total_reqtotestlink,
        SUM(CASE WHEN id IS NOT NULL AND id != '' THEN 1 ELSE 0 END) as has_qtest_id,
        SUM(CASE WHEN link_status = 'linked' THEN 1 ELSE 0 END) as linked_status,
        SUM(CASE WHEN id IS NOT NULL AND id != '' AND link_status = 'linked' THEN 1 ELSE 0 END) as success_records,
        ROUND(
          (SUM(CASE WHEN id IS NOT NULL AND id != '' AND link_status = 'linked' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0)) * 100, 2
        ) as success_percentage
      FROM  reqtotestlink
    `;
    const results = await queryAsync(query);
    res.json({ success: true, summary: results[0] });
  } catch (err) {
    console.error('Error fetching  reqtotestlink summary:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

//DEFECTSLINK-------------------------

// Total count
router.get('/defectslinks/total-count', async (req, res) => {
  try {
    const query = 'SELECT COUNT(*) as total_count FROM  defectslinks';
    const results = await queryAsync(query);
    res.json({ success: true, total_count: results[0].total_count });
  } catch (err) {
    console.error('Error fetching  defectslinks count:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// Status breakdown
router.get('/defectslinks/status-breakdown', async (req, res) => {
  try {
    const query = `
      SELECT 
        CASE 
          WHEN id IS NOT NULL AND id != '' AND link_status = 'linked' THEN 'Success'
          WHEN id IS NULL OR id = '' THEN 'Failed - Missing qTest ID'
          WHEN link_status != 'linked' THEN 'Failed - Not linked'
          ELSE 'Other'
        END as status_category,
        COUNT(*) as count
      FROM  defectslinks
      GROUP BY status_category
    `;
    const results = await queryAsync(query);
    res.json({ success: true, data: results });
  } catch (err) {
    console.error('Error fetching  defectslinks status breakdown:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// All  defectslinks with pagination
router.get('/defectslinks/all-defectslinks', async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 10));
    const offset = (page - 1) * limit;

    const query = `
      SELECT 
        id,
        link_status,
        CASE 
          WHEN id IS NOT NULL AND id != '' AND link_status = 'linked' THEN 'Success'
          WHEN id IS NULL OR id = '' THEN 'Failed'
          WHEN link_status != 'linked' THEN 'Failed'
          ELSE 'Other'
        END as result_status
      FROM  defectslinks
      ORDER BY id DESC
      LIMIT ? OFFSET ?
    `;

    const [results, countResults] = await Promise.all([
      queryAsync(query, [limit, offset]),
      queryAsync('SELECT COUNT(*) as total FROM  defectslinks')
    ]);

    res.json({
      success: true,
      data: results,
      pagination: {
        current_page: page,
        per_page: limit,
        total: countResults[0].total,
        total_pages: Math.ceil(countResults[0].total / limit)
      }
    });
  } catch (err) {
    console.error('Error fetching all  defectslinks:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

// Summary
router.get('/defectslinks/summary', async (req, res) => {
  try {
    const query = `
      SELECT 
        COUNT(*) as total_defectslinks,
        SUM(CASE WHEN id IS NOT NULL AND id != '' THEN 1 ELSE 0 END) as has_qtest_id,
        SUM(CASE WHEN link_status = 'linked' THEN 1 ELSE 0 END) as linked_status,
        SUM(CASE WHEN id IS NOT NULL AND id != '' AND link_status = 'linked' THEN 1 ELSE 0 END) as success_records,
        ROUND(
          (SUM(CASE WHEN id IS NOT NULL AND id != '' AND link_status = 'linked' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0)) * 100, 2
        ) as success_percentage
      FROM  defectslinks
    `;
    const results = await queryAsync(query);
    res.json({ success: true, summary: results[0] });
  } catch (err) {
    console.error('Error fetching  defectslinks summary:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

//---------------------------

// Export endpoint
const allowedTables = ['requirement', 'releases', 'testcasemodules_releases', 'testsetfolder', 'tests', 'parameters', 'alm_testcase_steps', 'defects', 'testset', 'testinstance', 'testlogs', 'reqtotestlink', 'releasetoreqlink', 'defectslinks'];

router.get('/export/:tableName', async (req, res) => {
  const { tableName } = req.params;
  const schema = req.query.schema;
  if (!allowedTables.includes(tableName) || !schema) {
    return res.status(400).json({ error: 'Invalid request' });
  }
  try {
    const query = `SELECT * FROM \`${schema}\`.${tableName}`;
    const rows = await queryAsync(query);
    if (rows.length === 0) return res.status(404).json({ error: `No data found in ${tableName}` });
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet(tableName);
    worksheet.columns = Object.keys(rows[0]).map((key) => ({ header: key, key: key, width: 20 }));
    rows.forEach(row => worksheet.addRow(row));
    const headerRow = worksheet.getRow(1);
    headerRow.font = { bold: true };
    headerRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE0E0E0' } };
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename=${tableName}_export_${new Date().toISOString().split('T')[0]}.xlsx`);
    await workbook.xlsx.write(res);
    res.end();
  } catch (err) {
    console.error('Export error:', err);
    res.status(500).json({ error: 'Internal server error during export.' });
  }
});

router.get('/export-errors/:tableName', async (req, res) => {
  const { tableName } = req.params;
  const schema = req.query.schema;
  if (!allowedTables.includes(tableName) || !schema) {
    return res.status(400).json({ error: 'Invalid request' });
  }
  try {
    const query = `
      SELECT *
      FROM \`${schema}\`.${tableName}
      WHERE upload_status IS NULL OR upload_status != 'completed'
    `;
    const rows = await queryAsync(query);
    if (rows.length === 0) return res.status(404).json({ error: `No error data found in ${tableName}` });
 
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet(tableName + "_errors");
    worksheet.columns = Object.keys(rows[0]).map((key) => ({ header: key, key: key, width: 20 }));
    rows.forEach(row => worksheet.addRow(row));
 
    const headerRow = worksheet.getRow(1);
    headerRow.font = { bold: true };
    headerRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFCCCC' } };
 
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename=${tableName}_errors_export_${new Date().toISOString().split('T')[0]}.xlsx`);
    await workbook.xlsx.write(res);
    res.end();
  } catch (err) {
    console.error('Export error (errors only):', err);
    res.status(500).json({ error: 'Internal server error during error export.' });
  }
});

module.exports = router;