// almRoutes.js
const express = require("express");
const router = express.Router();
const {
  getAllTestCases,
  createTestCases,
  getAlmFieldByPhysicalName,
  createAlmJsonFile,
  uploadAlmJsonFile,
  getListValues
} = require("../../controllers/ReleaseControllerfile/ALMReleasesFieldsController");

// Update the routes to include "alm" in the path where needed
router.get("/get-releases", getAllTestCases);
router.post("/post-releases", createTestCases);
router.post('/create-alm-field', createAlmJsonFile);
router.get('/alm/field/:physicalName', getAlmFieldByPhysicalName);
router.post("/upload-json-to-qtest", uploadAlmJsonFile);
router.get('/list-values/:listId', getListValues);

module.exports = router;

