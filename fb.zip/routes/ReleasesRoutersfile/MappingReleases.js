


// routes/releasesUploadRoutes.js
const express = require('express');
const router = express.Router();
const {insertSampleData, processAndUploadAllReleases, getMigrationStatus, getReleasesCount}= require('../../controllers/ReleaseControllerfile/MappingReleases');

// Route to insert sample data from ALM to local DB
router.post('/releases', insertSampleData);

// Route to process and upload all releases to qTest
router.post('/releasesupload', processAndUploadAllReleases);

// Route to get releases count
router.get('/releases/count', getReleasesCount);

// Route to get migration status
router.get('/migration-status', getMigrationStatus);

module.exports = router;