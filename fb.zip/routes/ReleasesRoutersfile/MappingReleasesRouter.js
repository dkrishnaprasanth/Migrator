const express = require("express");
const router = express.Router();
const { 
  saveMappings, 
  fetchAllTableNames, 
  getMappingsForTable, 
  getAlmFieldData,
  saveValueMappings,
  setCurrentTable,
  fetchCurrentTableName,
  fetchStoredTableName,
  getMappingData,
  insertSampleMappingData
} = require("../../controllers/ReleaseControllerfile/MappingReleasesController");
 
// Field Mapping Routes
router.post("/mappings", saveMappings);
 
// Value Mapping Routes
router.post("/valuemappings", saveValueMappings);
 
// Get all table names (supports both field and value mappings)

router.get("/fetch-all-table-names", fetchAllTableNames);
 
// Get current table name
router.get('/current-table-name', fetchCurrentTableName);
 
// Get stored table name
router.get('/stored-table-name', fetchStoredTableName);
 
// Set current table
router.post('/set-current-table', setCurrentTable);
 
// For individual field mapping lookup
router.get('/mappings/:tableName', getMappingsForTable);
 
// ALM field data lookup
router.get('/alm-field/:ep1_physical_name', getAlmFieldData);
 
// Sample data and mapping data routes
router.post('/insert-sample-data', insertSampleMappingData);

router.get('/mapping-data', getMappingData);
 
module.exports = router;


