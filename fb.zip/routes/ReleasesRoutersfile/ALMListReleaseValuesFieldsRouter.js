const express = require("express");
const router = express.Router();
const { 
  getAllListTestCases, 
  createListTestCases, 
  refreshListData
} = require("../../controllers/ReleaseControllerfile/ALMListReleasesValuesFieldsController");

// Get all test cases
router.get("/get-alm-list-db", getAllListTestCases);

// Insert new test cases
router.post("/post-alm-list-db", createListTestCases);

// Refresh ALM data (fetches new JSON and updates database)
router.post("/refresh-alm-list-value", refreshListData);

module.exports = router;