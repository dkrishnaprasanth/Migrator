const express = require("express");
const {  getAllData, insertData} = require("../../controllers/ReleaseControllerfile/qTestReleasesFieldsController");

const router = express.Router();

router.get("/qtest_data",  getAllData);

router.post("/qtest_data", insertData);

// router.post("/qtest/refresh-qtest-data", refreshQTestData);

module.exports = router;