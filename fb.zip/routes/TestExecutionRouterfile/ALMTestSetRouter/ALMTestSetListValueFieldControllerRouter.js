const express = require("express");
const router = express.Router();
const { 
   getAllListTestSet, 
   createListTestSet, 
  refreshTestSetListData
} = require("../../../controllers/TestExecutionControllerfile/ALMTestSetfile/AlmTestSetListValueFieldController");

// Get all test cases
router.get("/get-almtestset-list-db",  getAllListTestSet);

// Insert new test cases
router.post("/post-almtestset-list-db",  createListTestSet);

// Refresh ALM data (fetches new JSON and updates database)
router.post("/refresh-almtestset-list-value",  refreshTestSetListData);

module.exports = router;