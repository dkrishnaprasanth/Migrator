// // almRoutes.js
// const express = require("express");
// const router = express.Router();
// const {
//   getAllAlmTestSetFields,
//   insertTestSetFields,
//    getAlmTestSetFieldByPhysicalName,
//    createAlmTestSetFieldsListJsonFile,
//   uploadAlmTestSetFields,
//   gettestsetListValues
// } = require("../../../controllers/TestExecutionControllerfile/ALMTestSetfile/AlmTestSetFieldsController");

// // Update the routes to include "alm" in the path where needed
// router.get("/get-testset", getAllAlmTestSetFields);
// router.post("/post-testset", insertTestSetFields);
// router.post('/create-testset-field',  createAlmTestSetFieldsListJsonFile);
// router.get('/almtestset/field/:physicalName',  getAlmTestSetFieldByPhysicalName);
// router.post("/upload-json-to-qtesttestset",uploadAlmTestSetFields);

// router.get('/testset-list-values/:listId', gettestsetListValues);

// module.exports = router;




// almRoutes.js
const express = require("express");
const router = express.Router();
const {
  getAllAlmTestSetFields,
  insertTestSetFields,
  getAlmTestSetFieldByPhysicalName,
  createAlmTestSetFieldsListJsonFile,
  uploadAlmTestSetFields,
  gettestsetListValues
} = require("../../../controllers/TestExecutionControllerfile/ALMTestSetfile/AlmTestSetFieldsController");

// Routes - all these will be prefixed with '/api/alm' from app.js
router.get("/get-testset", getAllAlmTestSetFields);
router.post("/post-testset", insertTestSetFields);
router.post('/create-testset-field', createAlmTestSetFieldsListJsonFile);
router.get('/almtestset/field/:physicalName', getAlmTestSetFieldByPhysicalName);
router.post("/upload-json-to-qtesttestset", uploadAlmTestSetFields);

// Fixed route - this matches your frontend call
router.get('/testset-list-values/:listId', gettestsetListValues);

module.exports = router;