const express = require('express');
const router = express.Router();
const { fetchAlmTestSet } = require('../../../controllers/TestExecutionControllerfile/ALMTestSetfile/AlmTestSet');

// GET route using default ALM release URL
router.get('/testset', async (req, res) => {
    try {
        await fetchAlmTestSet(); // Default URL from config
        res.status(200).json({ message: 'Default ALM release data fetched and saved.' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// POST route with optional custom URL
router.post('/testset/custom', async (req, res) => {
    try {
        const { customReleaseUrl } = req.body;
        await fetchAlmTestSet(customReleaseUrl || '');
        res.status(200).json({ message: 'Custom ALM release data fetched and saved.' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;



