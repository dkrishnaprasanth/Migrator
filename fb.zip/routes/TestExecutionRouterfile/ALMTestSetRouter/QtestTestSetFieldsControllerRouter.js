const express = require("express");
const {  getqtestTestSetAllFields, insertqtestTestSetFields } = require("../../../controllers/TestExecutionControllerfile/ALMTestSetfile/QtestTestSuiteFieldsController");

const router = express.Router();

router.get("/qtest_testset_data",  getqtestTestSetAllFields);

router.post("/qtest_testset_data", insertqtestTestSetFields);

// router.post("/qtest/refresh-qtesttestset-data", refreshQTestTestSetFields);

module.exports = router;