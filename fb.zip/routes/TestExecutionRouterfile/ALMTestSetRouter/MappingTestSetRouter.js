


// routes/releasesUploadRoutes.js
const express = require('express');
const router = express.Router();
const {insertSampleData, processAndUploadAllTestset, getMigrationStatus, getTestSetCount}= require('../../../controllers/TestExecutionControllerfile/ALMTestSetfile/MappingTestSet');

// Route to insert sample data from ALM to local DB
router.post('/testset', insertSampleData);

// Route to process and upload all releases to qTest
router.post('/testsetupload', processAndUploadAllTestset);


// Route to get test sets count
router.get("/testset/count", getTestSetCount);

// Route to get migration status
router.get('/migrationtestset-status', getMigrationStatus);

module.exports = router;