const express = require("express");
const router = express.Router();
const { saveMappings, fetchAllTableNames, getMappingsForTable, getAlmFieldData , savetestsetValueMappings} = require("../../../controllers/TestExecutionControllerfile/ALMTestSetfile/MappingTestSetController");

// Save mappings (POST)
router.post("/mappingstestset", saveMappings);

router.post("/testset-valuemappings",  savetestsetValueMappings);

// Make sure this endpoint exists and is properly defined
router.get('/fetch-alltestset-table-names',fetchAllTableNames);

// For the individual mapping lookup
router.get('/mappingstestset/:tableName', getMappingsForTable);


router.get('/alm-fieldtestset/:alm_physical_name', getAlmFieldData);


module.exports = router;