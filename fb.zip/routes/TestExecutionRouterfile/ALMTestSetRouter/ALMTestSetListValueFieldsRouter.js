const express = require('express');
const router = express.Router();
const { fetchListTestSetFields } = require('../../../controllers/TestExecutionControllerfile/ALMTestSetfile/AlmTestSetListValueFields');
const { createListTestSetTables, insertListTestSetDataJson} = require ('../../../controllers/TestExecutionControllerfile/ALMTestSetfile/AlmTestSetListValueFieldController')

router.get('/listtestsetvalue', async (req, res) => {
    try {
        // First fetch the ALM data and save to JSON file
         await fetchListTestSetFields();

         await  createListTestSetTables();

         const insertResult = insertListTestSetDataJson();

        if (insertResult) {
            res.status(200).json({ message: 'ALM Listtestset data fetched and inserted into database successfully' });
        } else {
            res.status(200).json({ message: 'ALM Listtestset data fetched and saved to JSON file. No new data inserted into database.' });
        }
    } catch (err) {
        console.error('Error in ALM Listtestset fetch and insert process:', err);
        res.status(500).json({ error: err.message || 'Failed to process ALM data' });
    }
});

module.exports = router;
