const express = require('express');
const router = express.Router();
const { fetchAlmTestSetFields } = require('../../../controllers/TestExecutionControllerfile/ALMTestSetfile/AlmTestSetFields');
const {  createAlmTestSetTables , insertTestSetFieldsJson} = require('../../../controllers/TestExecutionControllerfile/ALMTestSetfile/AlmTestSetFieldsController');

router.get('/testsetfield', async (req, res) => {
    try {
        // First fetch the ALM data and save to JSON file
        await fetchAlmTestSetFields();
        
        // Create the table if it doesn't exist
        await  createAlmTestSetTables();
        
        // Then insert the data from the JSON file into the database
        const insertResult = await insertTestSetFieldsJson();
        
        if (insertResult) {
            res.status(200).json({ message: 'ALM Testset data fetched and inserted into database successfully' });
        } else {
            res.status(200).json({ message: 'ALM testset data fetched and saved to JSON file. No new data inserted into database.' });
        }
    } catch (err) {
        console.error('Error in ALM testset fetch and insert process:', err);
        res.status(500).json({ error: err.message || 'Failed to process ALM testset data' });
    }
});

module.exports = router;