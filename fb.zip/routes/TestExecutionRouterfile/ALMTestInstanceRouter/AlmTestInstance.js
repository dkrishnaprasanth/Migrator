const express = require('express');
const router = express.Router();
const { fetchAlmTestInstances } = require('../../../controllers/TestExecutionControllerfile/ALMTestInstancefile/AlmTestInstance');

// GET route using default ALM release URL
router.get('/testinstance', async (req, res) => {
    try {
        await fetchAlmTestInstances(); // Default URL from config
        res.status(200).json({ message: 'Default ALM testinstance data fetched and saved.' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// POST route with optional custom URL
router.post('/testinstance/custom', async (req, res) => {
    try {
        const { customReleaseUrl } = req.body;
        await fetchAlmTestInstances(customReleaseUrl || '');
        res.status(200).json({ message: 'Custom ALM testinstance data fetched and saved.' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;



