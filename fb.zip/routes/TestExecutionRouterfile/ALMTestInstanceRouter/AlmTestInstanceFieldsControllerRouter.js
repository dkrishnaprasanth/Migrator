// almRoutes.js
const express = require("express");
const router = express.Router();
const {
  getAllAlmTestSetFields,
  insertTestSetFields,
   getAlmTestSetFieldByPhysicalName,
   createAlmTestSetFieldsListJsonFile,
  uploadAlmTestSetFields,
  getInstanceListValues
} = require("../../../controllers/TestExecutionControllerfile/ALMTestInstancefile/AlmTestInstanceFieldsController");

// Update the routes to include "alm" in the path where needed
router.get("/get-testinstance", getAllAlmTestSetFields);
router.post("/post-testinstance", insertTestSetFields);
router.post('/create-testinstance-field',  createAlmTestSetFieldsListJsonFile);
router.get('/almtestinstance/field/:physicalName',  getAlmTestSetFieldByPhysicalName);
router.post("/upload-json-to-qtesttestinstance",uploadAlmTestSetFields);

router.get('/testinstance-list-values/:listId',  getInstanceListValues);


module.exports = router;

