const express = require("express");
const router = express.Router();
const { saveMappings, fetchAllTableNames, getMappingsForTable, getAlmFieldData, saverequirementValueMappings, } = require("../../../controllers/TestExecutionControllerfile/ALMTestInstancefile/MappingTestInstanceController");

// Save mappings (POST)
router.post("/mappingstestinstance", saveMappings);


router.post("/testinstance-valuemappings", saverequirementValueMappings);


// Make sure this endpoint exists and is properly defined
router.get('/fetch-alltestinstance-table-names',fetchAllTableNames);

// For the individual mapping lookup
router.get('/mappingstestinstance/:tableName', getMappingsForTable);


router.get('/alm-fieldtestinstance/:alm_physical_name', getAlmFieldData);


module.exports = router;