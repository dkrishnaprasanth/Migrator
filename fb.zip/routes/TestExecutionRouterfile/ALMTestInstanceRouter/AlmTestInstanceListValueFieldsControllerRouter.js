const express = require("express");
const router = express.Router();
const { 
   getAllListTestSet, 
   createListTestSet, 
  refreshTestSetListData
} = require("../../../controllers/TestExecutionControllerfile/ALMTestInstancefile/AlmTestInstanceListvalueFieldsController");

// Get all test cases
router.get("/get-almtestinstance-list-db",  getAllListTestSet);

// Insert new test cases
router.post("/post-almtestinstance-list-db",  createListTestSet);

// Refresh ALM data (fetches new JSON and updates database)
router.post("/refresh-almtestinstance-list-value",  refreshTestSetListData);

module.exports = router;