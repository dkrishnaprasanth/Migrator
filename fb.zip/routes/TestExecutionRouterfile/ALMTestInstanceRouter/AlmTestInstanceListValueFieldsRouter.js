const express = require('express');
const router = express.Router();
const { fetchListTestInstanceFields } = require('../../../controllers/TestExecutionControllerfile/ALMTestInstancefile/AlmTestInstanceListValueFields');
const { createListTestSetTables, insertListTestSetDataJson} = require ('../../../controllers/TestExecutionControllerfile/ALMTestInstancefile/AlmTestInstanceListvalueFieldsController')

router.get('/listtestinstancevalue', async (req, res) => {
    try {
        console.log('Starting ALM Listtestinstance fetch and insert process...');
        
        // First fetch the ALM data and save to JSON file
        await fetchListTestInstanceFields();
        console.log('✅ ALM data fetched successfully');
        
        // Create tables if they don't exist
        await createListTestSetTables();
        console.log('✅ Tables created/verified successfully');
        
        // Insert data from JSON to database
        const insertResult = await insertListTestSetDataJson();
        
        if (insertResult) {
            res.status(200).json({ 
                message: 'ALM Listtestinstance data fetched and inserted into database successfully',
                success: true 
            });
        } else {
            res.status(200).json({ 
                message: 'ALM Listtestinstance data fetched and saved to JSON file. No new data inserted into database (data already exists).',
                success: true 
            });
        }
    } catch (err) {
        console.error('Error in ALM Listtestinstance fetch and insert process:', err);
        res.status(500).json({ 
            error: err.message || 'Failed to process ALM data',
            success: false 
        });
    }
});

module.exports = router;

// router.get('/listtestinstancevalue', async (req, res) => {
//     try {
//         // First fetch the ALM data and save to JSON file
//          await fetchListTestInstanceFields();

//          await  createListTestSetTables();

//          const insertResult = insertListTestSetDataJson();

//         if (insertResult) {
//             res.status(200).json({ message: 'ALM Listtestinstance data fetched and inserted into database successfully' });
//         } else {
//             res.status(200).json({ message: 'ALM Listtestinstance data fetched and saved to JSON file. No new data inserted into database.' });
//         }
//     } catch (err) {
//         console.error('Error in ALM Listtestinstance fetch and insert process:', err);
//         res.status(500).json({ error: err.message || 'Failed to process ALM data' });
//     }
// });

// module.exports = router;
