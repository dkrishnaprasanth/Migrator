const express = require('express');
const router = express.Router();
const { fetchAlmTestInstanceFields  } = require('../../../controllers/TestExecutionControllerfile/ALMTestInstancefile/AlmTestInstanceFields');
const {  createAlmTestSetTables , insertTestSetFieldsJson} = require('../../../controllers/TestExecutionControllerfile/ALMTestInstancefile/AlmTestInstanceFieldsController');

router.get('/testinstancefield', async (req, res) => {
    try {
        // First fetch the ALM data and save to JSON file
        await fetchAlmTestInstanceFields ();
        
        // Create the table if it doesn't exist
        await  createAlmTestSetTables();
        
        // Then insert the data from the JSON file into the database
        const insertResult = await insertTestSetFieldsJson();
        
        if (insertResult) {
            res.status(200).json({ message: 'ALM Testinstance data fetched and inserted into database successfully' });
        } else {
            res.status(200).json({ message: 'ALM testinstance data fetched and saved to JSON file. No new data inserted into database.' });
        }
    } catch (err) {
        console.error('Error in ALM testset fetch and insert process:', err);
        res.status(500).json({ error: err.message || 'Failed to process ALM testset data' });
    }
});

module.exports = router;