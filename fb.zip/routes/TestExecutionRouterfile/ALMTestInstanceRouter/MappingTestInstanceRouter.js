// // routes/releasesUploadRoutes.js
// const express = require('express');
// const router = express.Router();
// const {insertSampleData, processAndUploadAllReleases, getMigrationStatus}= require('../../../controllers/TestExecutionControllerfile/ALMTestInstancefile/MappingTestInstance');

// // Route to insert sample data from ALM to local DB
// router.post('/testinstance', insertSampleData);

// // Route to process and upload all releases to qTest
// router.post('/testinstanceupload', processAndUploadAllReleases);

// // Route to get migration status
// router.get('/migrationtestinstance-status', getMigrationStatus);

// module.exports = router;



const express = require('express');
const router = express.Router();
const {insertSampleData, processAndUploadAllTestInstance, getMigrationStatus, getTestRunsCount}= require('../../../controllers/TestExecutionControllerfile/ALMTestInstancefile/MappingTestInstance');
const { synctest } = require('../../../controllers/TestDesignControllerfile/syncController')
const { runReqToTestSync } = require('../../../controllers/TestDesignControllerfile/runReqToTestSync');
const { syncRequirements} = require('../../../controllers/TestDesignControllerfile/syncRequirement');

// Route to insert sample data from ALM to local DB
router.post('/testinstance', insertSampleData);

router.post('/synctests', synctest);
 
router.post('/forsyncreq', runReqToTestSync);

router.post('/syncreq', syncRequirements);

// Route to process and upload all releases to qTest
router.post('/testrunupload', processAndUploadAllTestInstance);

// New route to get test runs count
router.get("/testruns/count", getTestRunsCount);

// Route to get migration status
router.get('/migrationtestinstance-status', getMigrationStatus);

module.exports = router;