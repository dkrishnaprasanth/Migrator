const express = require("express");
const {  getqtestTestSetAllFields, insertqtestTestSetFields,refreshQTestTestSetFields } = require("../../../controllers/TestExecutionControllerfile/ALMTestInstancefile/QtestTestInstanceFieldsController");

const router = express.Router();

router.get("/qtest_testinstance_data",  getqtestTestSetAllFields);

router.post("/qtest_testinstance_data", insertqtestTestSetFields);

router.post("/qtest/refresh-qtesttestinstance-data", refreshQTestTestSetFields);

module.exports = router;