 const express = require('express');
const router = express.Router();
const db = require('../../../config/db'); 
 

const {
  fetchAlmtestlog,           
  insertrunAlmTestLog,
  uploadrunAlmTestLog, 
  getTestLogCount
} = require('../../../controllers/TestExecutionControllerfile/ALMtestLogFolder/ALMTestLogConnection');
 
// Routes
router.get('/alm-insert-testlog', insertrunAlmTestLog);

router.post('/alm-upload-testlog', uploadrunAlmTestLog);
 

 
router.post('/alm-testlog/custom', async (req, res) => {
  try {
    const { customReleaseUrl } = req.body || {};
    console.log('[route] POST /alm-testlog/custom called - customReleaseUrl:', customReleaseUrl);
    await fetchAlmtestlog(customReleaseUrl || '');
    return res.status(200).json({ message: '✅ Custom ALM test log data fetched and saved.' });
  } catch (err) {
   
    console.error('❌ Error in /alm-testlog/custom handler:', {
      message: err.message,
      stack: err.stack,
      isAxiosError: err.isAxiosError,
      axiosResponseData: err.response ? err.response.data : undefined,
      axiosResponseStatus: err.response ? err.response.status : undefined
    });
 
  
    const clientMessage = err.response?.data ?? err.message ?? 'Unknown server error';
 
    return res.status(500).json({
      error: 'Failed to fetch custom test logs',
      details: clientMessage
    });
  }
});
 
router.get('/testlog/count', getTestLogCount);
 
router.get('/alm-testlog/status', async (req, res) => {
  try {
    const [total] = await db.promise().query("SELECT COUNT(*) as count FROM TestLogs");
    const [success] = await db.promise().query("SELECT COUNT(*) as count FROM TestLogs WHERE upload_status = 'completed'");
    const [failed] = await db.promise().query("SELECT COUNT(*) as count FROM TestLogs WHERE upload_status = 'failed'");
    const [pending] = await db.promise().query("SELECT COUNT(*) as count FROM TestLogs WHERE upload_status IS NULL OR upload_status = ''");
 
    res.status(200).json({
      total: total[0].count,
      success: success[0].count,
      failed: failed[0].count,
      pending: pending[0].count
    });
  } catch (err) {
    console.error('❌ Error fetching test log status:', err);
    res.status(500).json({ error: "Failed to fetch test log migration status", details: err.message });
  }
});
 
module.exports = router;
 
 