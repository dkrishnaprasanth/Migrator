const express = require('express');
const router = express.Router();
const db = require('../../../config/db');
 
// Controller imports
const {
  insertTestSetupToDB,
  uploadTestSetupToDB,
  getTestSetFolderCount
} = require('../../../controllers/TestExecutionControllerfile/ALMTestSetFolder/ALMTestSetConnection');
 
const {
  insertreleaselinkingTestSetupToDB,
  uploadreleaselinkingTestSetupToDB,
} = require('../../../controllers/TestExecutionControllerfile/ALMTestSetFolder/ReleaselinkingTestSetFolder/MainDBConnection');
 
// Routes for ALM Test Set Folder
router.get('/inserttestsetfolder', insertTestSetupToDB);
router.post('/uploadtestsetfolder', uploadTestSetupToDB);
 
// Routes for Release Linking Cycle
router.get('/insertreleaselinking-cyc', insertreleaselinkingTestSetupToDB);
router.post('/uploadreleaselinking-cyc', uploadreleaselinkingTestSetupToDB);
 

// Route to get count of Test Set Folders
router.get('/testsetfolder/count', getTestSetFolderCount);

// Status Route: Test Cycle Status Summary
router.get('/status', async (req, res) => {
  try {
    const [[{ count: total }]] = await db.promise().query(`
      SELECT COUNT(*) as count FROM TestSetFolder
    `);
 
    const [[{ count: success }]] = await db.promise().query(`
      SELECT COUNT(*) as count FROM TestSetFolder WHERE qTest_id IS NOT NULL AND qTest_id != ''
    `);
 
    const [[{ count: pending }]] = await db.promise().query(`
      SELECT COUNT(*) as count FROM TestSetFolder WHERE qTest_id IS NULL OR qTest_id = ''
    `);
 
    const failed = 0; // Optional: You can add logic here if failure data is tracked
 
    res.status(200).json({
      total,
      success,
      failed,
      pending,
    });
  } catch (err) {
    console.error('❌ Error fetching test set folder status:', err);
    res.status(500).json({
      error: 'Failed to fetch test set folder status',
      details: err.message,
    });
  }
});
 
module.exports = router;
 