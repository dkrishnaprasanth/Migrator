

const express = require('express');
const router = express.Router();
const db = require('../../config/db'); // ✅ Make sure this is at the top or already imported

const { fetchTestCaseSteps } = require('../../controllers/TestDesignControllerfile/ALMTestCaseSteps');
const { createTestCaseStepsTable,insertDataTestCaseStepsFromJson,uploadTestStepsToQTest } = require('../../controllers/TestDesignControllerfile/ALMTestCaseStepsController');
 

router.get('/step-migration-status', async (req, res) => {
  try {
    const [total] = await db.promise().query("SELECT COUNT(*) as count FROM alm_testcase_steps");
    const [success] = await db.promise().query("SELECT COUNT(*) as count FROM alm_testcase_steps WHERE upload_status = 'completed'");
    const [failed] = await db.promise().query("SELECT COUNT(*) as count FROM alm_testcase_steps WHERE upload_status LIKE 'failed%'");
    const [pending] = await db.promise().query("SELECT COUNT(*) as count FROM alm_testcase_steps WHERE upload_status IS NULL OR upload_status = 'pending'");

    res.json({
      total: total[0].count,
      success: success[0].count,
      failed: failed[0].count,
      pending: pending[0].count
    });
  } catch (err) {
    console.error("❌ Error fetching step migration status:", err.message);
    res.status(500).json({
      message: "Error fetching test step migration status",
      error: err.message
    });
  }
});

router.get('/testcasestepsfield', async (req, res) => {
    try {
        // First fetch the ALM data and save to JSON file
        await fetchTestCaseSteps();
 
        // Create the table if it doesn't exist
        await createTestCaseStepsTable();
 
        // Then insert the data from the JSON file into the database
        const insertResult = await insertDataTestCaseStepsFromJson();
 
        await uploadTestStepsToQTest();
 
        if (insertResult) {
            res.status(200).json({ message: 'TestCaseModules data fetched and inserted into database successfully' });
        } else {
            res.status(200).json({ message: 'TestCaseModules data fetched and saved to JSON file. No new data inserted into database.' });
        }
 
    } catch (err) {
        console.error('Error in ALMTestCaseSteps fetch and insert process:', err);
        res.status(500).json({ error: err.message || 'Failed to process ALM data' });
    }
});
 
module.exports = router;
 