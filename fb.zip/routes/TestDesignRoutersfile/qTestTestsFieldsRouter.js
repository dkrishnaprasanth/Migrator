const express = require("express");
const {  getqtestTestcaseAllData, insertData,refreshQTestData } = require("../../controllers/TestDesignControllerfile/qTestTestsFieldsController");

const router = express.Router();

router.get("/qtest-testcasedata",  getqtestTestcaseAllData);

router.post("/qtest-testcasedata", insertData);

router.post("/refresh-qtesttestcase-data", refreshQTestData);

module.exports = router;