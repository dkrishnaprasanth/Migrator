
// routes/releasesUploadRoutes.js
 
const express = require('express');
const router = express.Router();
const {insertSampleData, processAndUploadAlltestcase, getMigrationStatus, getTestCasesCount}= require('../../controllers/TestDesignControllerfile/MappingTests');
const { uploadtestComments } = require('../../controllers/TestDesignControllerfile/TestcaseComments');
 
// Route to insert sample data from ALM to local DB
router.post('/tests', insertSampleData);
 
// Route to process and upload all releases to qTest
//router.post('/testsupload', processAndUploadAlltestcase);
 
router.post('/testsupload', async (req, res) => {
  try {
    await processAndUploadAlltestcase(req, res); // Pass both req and res
    await uploadtestComments(req, res);
 
    // ✅ BUT THEN: DON'T send another response here if controller already did
    if (!res.headersSent) {
      res.status(200).json({
        success: true,
        message: 'Upload completed successfully'
      });
    }
  } catch (error) {
    if (!res.headersSent) {
      res.status(500).json({ error: 'Upload failed', details: error.message });
    }
  }
});
 
// New route to get test cases count
router.get("/testcase/count", getTestCasesCount);
 
// Route to get migration status
 router.get('/migrationtestcase-status', getMigrationStatus);
 
module.exports = router;