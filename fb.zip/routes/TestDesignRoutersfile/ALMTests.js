const express = require('express');
const router = express.Router();
const { fetchAlmReleases } = require('../../controllers/TestDesignControllerfile/ALMTests');

// GET route using default ALM release URL
router.get('/tests', async (req, res) => {
    try {
        await fetchAlmReleases(); // Default URL from config
        res.status(200).json({ message: 'Default ALM test data fetched and saved.' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// POST route with optional custom URL
router.post('/tests/custom', async (req, res) => {
    try {
        const { customReleaseUrl } = req.body;
        await fetchAlmReleases(customReleaseUrl || '');
        res.status(200).json({ message: 'Custom ALM test data fetched and saved.' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;



