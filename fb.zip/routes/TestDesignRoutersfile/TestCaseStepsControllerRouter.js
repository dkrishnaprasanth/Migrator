const express = require("express");
const router = express.Router();

const {
  createTestCaseStepsTable,
  insertDataTestCaseStepsFromJson,
  uploadTestStepsToQTest
} = require("../../controllers/TestDesignControllerfile/ALMTestCaseStepsController");


router.get("/create-table", async (req, res) => {
  try {
    await createTestCaseStepsTable();
    res.status(200).json({ message: "✅ Table created successfully." });
  } catch (err) {
    console.error("❌ Error creating table:", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
});


router.post("/insert", async (req, res) => {
  try {
    const inserted = await insertDataTestCaseStepsFromJson();
    if (inserted) {
      res.status(200).json({ message: "✅ Data inserted successfully." });
    } else {
      res.status(409).json({ message: "⚠️ Data already exists or insert failed." });
    }
  } catch (err) {
    console.error("❌ Error inserting data:", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.post("/upload-testcase-steps", uploadTestStepsToQTest);

module.exports = router;
