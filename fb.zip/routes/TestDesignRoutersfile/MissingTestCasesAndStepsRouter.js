

 
const express = require("express");
const router = express.Router();
const { fetchTestCaseSteps } = require('../../controllers/TestDesignControllerfile/ALMTestCaseSteps');
 
const {
  createTestCaseStepsTable,
  insertDataTestCaseStepsFromJson,
  getTestCaseStepsCount,
  uploadTestStepsToQTest
} = require("../../controllers/TestDesignControllerfile/ALMTestCaseStepsController");
 
const {
  syncMissingTestsAndStepsRecursive
} = require("../../controllers/TestDesignControllerfile/MissingTestcases");

 
router.post("/insert-test-steps-and-resolve", async (req, res) => {
  try {
    console.log("🚀 Step 1: Creating alm_testcase_steps table if not exists...");
    await createTestCaseStepsTable();
 
    console.log("📥 Step 1.5: Fetching steps for already existing test cases...");
    await fetchTestCaseSteps(); // <-- 🔥 Add this line
 
    console.log("📥 Step 2: Inserting fetched steps from ALM JSON into database...");
    await insertDataTestCaseStepsFromJson();
 
    console.log("🔄 Step 3: Starting recursive sync of missing test cases and steps...");
    await syncMissingTestsAndStepsRecursive(req, res);
    
  } catch (error) {
    console.error("❌ Error in insert-test-steps-and-resolve route:", error);
    res.status(500).json({
      message: "❌ Failed to insert and resolve missing test cases and steps.",
      error: error.message
    });
  }
});

// ✅ Count Route: Get total number of test case steps in alm_testcase_steps
router.get("/testcasesteps/count", getTestCaseStepsCount);


// ✅ Status Route: Test Step Migration Status Summary
router.get('/step-migration-status', async (req, res) => {
  try {
    // Total steps
    const [[{ total }]] = await db.promise().query(`
      SELECT COUNT(*) AS total FROM alm_testcase_steps
    `);

    // Successfully uploaded steps (qtest_tc_step_id exists)
    const [[{ success }]] = await db.promise().query(`
      SELECT COUNT(*) AS success 
      FROM alm_testcase_steps 
      WHERE qtest_tc_step_id IS NOT NULL AND qtest_tc_step_id != ''
    `);

    // Pending steps (qtest_tc_step_id missing)
    const [[{ pending }]] = await db.promise().query(`
      SELECT COUNT(*) AS pending 
      FROM alm_testcase_steps 
      WHERE qtest_tc_step_id IS NULL OR qtest_tc_step_id = ''
    `);

    // Failed steps (optional: adjust logic based on your failure tracking)
    const [[{ failed }]] = await db.promise().query(`
      SELECT COUNT(*) AS failed
      FROM alm_testcase_steps 
      WHERE upload_status LIKE 'failed%' 
    `);

    res.status(200).json({
      total,
      success,
      failed,
      pending
    });

  } catch (err) {
    console.error('❌ Error fetching step migration status:', err);
    res.status(500).json({
      error: 'Failed to fetch test step migration status',
      details: err.message
    });
  }
});



router.post("/upload-testcase-steps", uploadTestStepsToQTest);



 
module.exports = router;
 
 