const express = require("express");
const router = express.Router();
const { 
  getAllListTestCases, 
  createListTestCases, 
  refreshListData
} = require("../../controllers/TestDesignControllerfile/ALMListTestsValuesFieldsController");

// Get all test cases
router.get("/get-alm-listtestcase-db", getAllListTestCases);

// Insert new test cases
router.post("/post-alm-listtestcase-db", createListTestCases);

// Refresh ALM data (fetches new JSON and updates database)
router.post("/refresh-alm-listtestcase-value", refreshListData);

module.exports = router;