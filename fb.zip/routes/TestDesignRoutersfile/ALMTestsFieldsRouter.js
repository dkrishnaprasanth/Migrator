// // almRoutes.js
// const express = require("express");
// const router = express.Router();
// const {
//   getAllTestCases,
//   createTestCases,
//   refreshAlmData,
//   getAlmFieldByPhysicalName,
//   createAlmJsonFile,
//   uploadAlmJsonFile
// } = require("../../controllers/TestDesignControllerfile/ALMTestsFieldsController");

// // Update the routes to include "alm" in the path where needed
// router.get("/get-test-cases", getAllTestCases);
// router.post("/post-test-cases", createTestCases);
// router.post("/alm/refresh-alm-data", refreshAlmData); // This matches your frontend request
// router.post('/create-almtestcase-field', createAlmJsonFile);
// router.get('/testcasefield/:physicalName', getAlmFieldByPhysicalName);
// router.post("/upload-to-qtesttestcase", uploadAlmJsonFile);

// module.exports = router;




// almRoutes.js
const express = require("express");
const router = express.Router();
const {
  getAllTestCases,
  createTestCases,
  refreshAlmData,
  getAlmFieldByPhysicalName,
  createAlmJsonFile,
  uploadAlmJsonFile,
  getTestCaseListValues
} = require("../../controllers/TestDesignControllerfile/ALMTestsFieldsController");
 
// Update the routes to include "alm" in the path where needed
router.get("/get-test-cases", getAllTestCases);
router.post("/post-test-cases", createTestCases);
router.post("/alm/refresh-alm-data", refreshAlmData); // This matches your frontend request
router.post('/create-almtestcase-field', createAlmJsonFile);
router.get('/testcasefield/:physicalName', getAlmFieldByPhysicalName);
router.post("/upload-to-qtesttestcase", uploadAlmJsonFile);
router.get("/testcase-list-values/:listId", getTestCaseListValues);
module.exports = router;
 
 
 