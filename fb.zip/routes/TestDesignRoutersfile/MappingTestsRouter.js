



const express = require("express");
const router = express.Router();
const { saveMappings, fetchAllTableNames, getMappingsForTable, getAlmFieldData, saveTestCaseValueMappings} = require("../../controllers/TestDesignControllerfile/MappingTestsController");
 
// Save mappings (POST)
router.post("/mappingstestcase", saveMappings);
 
router.post("/valuetestcasmappings",  saveTestCaseValueMappings);
 
// Make sure this endpoint exists and is properly defined
router.get('/fetch-all-tabletestcase-names',fetchAllTableNames);
 
// For the individual mapping lookup
router.get('/mappingstestcase/:tableName', getMappingsForTable);
 
 
router.get('/almtestcase/:alm_physical_name', getAlmFieldData);
 
 
module.exports = router;
 
 