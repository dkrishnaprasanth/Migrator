const express = require('express');
const router = express.Router();

// Import controllers
const { 
  getReleasesTestCaseModulesData,
  createTestCaseModulesTable, 
  insertReleasesTestCaseModulesData
} = require('../../controllers/TestDesignControllerfile/TestCaseModulesController');

// Standard API endpoints
router.get("/testcasemodules-data", getReleasesTestCaseModulesData);
router.post("/testcasemodules-data", createTestCaseModulesTable);
router.post("/testcasemodules-data", insertReleasesTestCaseModulesData);

module.exports = router;