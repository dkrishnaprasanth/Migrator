

const express = require('express');
const router = express.Router();
const db = require('../../config/db'); // Ensure the path is correct to your db.js
const { fetchTestCaseModulesReleases } = require('../../controllers/TestDesignControllerfile/TestCaseModulesFields');
const { createTestCaseModulesTable, insertDataTestCaseModulesFromJson, uploadTestCaseModulesToQTest, getModulesWithQTestIds, getTestCaseModulesCount } = require('../../controllers/TestDesignControllerfile/TestCaseModulesController');

// router.get('/FetchAndinAertTestCaseModules', async (req, res) => {
//     try {
//         // First fetch the qTest data and save to JSON file
//         await fetchTestCaseModulesReleases();
       
//         // Create the table if it doesn't exist
//         await createTestCaseModulesTable();
       
//         // Then insert the data from the JSON file into the database
//         const insertResult = await insertDataTestCaseModulesFromJson();
       
//         if (insertResult) {
//             res.status(200).json({ message: 'TestCaseModules data fetched and inserted into database successfully' });
//         } else {
//             res.status(200).json({ message: 'TestCaseModules data fetched and saved to JSON file. No new data inserted into database.' });
//         }
//     } catch (err) {
//         console.error('Error in TestCaseModules fetch and insert process:', err);
//         res.status(500).json({ error: err.message || 'Failed to process TestCaseModules data' });
//     }
// });

// Fixed route - directly pass req and res to the controller function

router.get('/FetchAndinAertTestCaseModules', async (req, res) => {
    try {
        await fetchTestCaseModulesReleases();
        await createTestCaseModulesTable();
 
        const result = await insertDataTestCaseModulesFromJson();
 
        res.status(200).json({
            success: true,
            message: 'TestCaseModules data processed successfully.',
            stats: result
        });
 
    } catch (err) {
        console.error('Error in TestCaseModules fetch and insert process:', err);
        res.status(500).json({
            success: false,
            error: err.message || 'Failed to process TestCaseModules data'
        });
    }
});
 

router.get('/UplodeTestCaseModules', uploadTestCaseModulesToQTest);

// Alternative route to get modules with qTest IDs
router.get('/GetModulesWithQTestIds', getModulesWithQTestIds);
// Route to get migration status of TestCaseModules
router.get('/TestCaseModulesreleasesfield/status', async (req, res) => {
    try {
        const [totalCount] = await db.promise().query("SELECT COUNT(*) as count FROM Testcasemodules_releases");
        const [completedCount] = await db.promise().query("SELECT COUNT(*) as count FROM Testcasemodules_releases WHERE upload_status = 'completed'");
        const [failedCount] = await db.promise().query("SELECT COUNT(*) as count FROM Testcasemodules_releases WHERE upload_status LIKE 'failed%'");
        const [pendingCount] = await db.promise().query("SELECT COUNT(*) as count FROM Testcasemodules_releases WHERE upload_status IS NULL OR upload_status = 'pending'");

        res.json({
            total: totalCount[0].count,
            success: completedCount[0].count,
            failed: failedCount[0].count,
            pending: pendingCount[0].count
        });
    } catch (error) {
        console.error("❌ Error fetching TestCaseModules status:", error.message);
        res.status(500).json({
            message: "Error getting test case module migration status",
            error: error.message
        });
    }
});


// New route to get test case modules count
router.get('/testcasemodules/count', getTestCaseModulesCount);

module.exports = router;