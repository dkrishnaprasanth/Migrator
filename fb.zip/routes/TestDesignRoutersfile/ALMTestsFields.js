const express = require('express');
const router = express.Router();
const { fetchAlmReleasesFields } = require('../../controllers/TestDesignControllerfile/ALMTestsFields');
const { createTables, insertDataJson } = require('../../controllers/TestDesignControllerfile/ALMTestsFieldsController');

router.get('/testcasefield', async (req, res) => {
    try {
        // First fetch the ALM data and save to JSON file
        await fetchAlmReleasesFields();
        
        // Create the table if it doesn't exist
        await createTables();
        
        // Then insert the data from the JSON file into the database
        const insertResult = await insertDataJson();
        
        if (insertResult) {
            res.status(200).json({ message: 'ALM data fetched and inserted into database successfully' });
        } else {
            res.status(200).json({ message: 'ALM data fetched and saved to JSON file. No new data inserted into database.' });
        }
    } catch (err) {
        console.error('Error in ALM fetch and insert process:', err);
        res.status(500).json({ error: err.message || 'Failed to process ALM data' });
    }
});

module.exports = router;