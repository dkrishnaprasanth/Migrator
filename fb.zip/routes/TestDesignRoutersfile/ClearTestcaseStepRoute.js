const express = require('express');
const router = express.Router();
const { run } = require('../../controllers/TestDesignControllerfile/ClearTestSteps');

router.get('/alm-clearteststeps', async (req, res) => {
  try {
    await run(); // ✅ perform the step-clearing logic
    res.json({ message: '✅ Cleared old Test Case Steps' }); // ✅ send success response
  } catch (err) {
    console.error('❌ Error during clear:', err);
    res.status(500).json({ message: '❌ Failed to clear Test Case Steps' });
  }
});

module.exports = router;
