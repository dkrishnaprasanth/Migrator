const express = require('express');
const router = express.Router();
const { fetchApproveTestCase } = require('../../controllers/TestDesignControllerfile/ApproveTestCase');

router.get('/approval-status', async (req, res) => {
    try {
        // Fetch and process the approval data
        await fetchApproveTestCase();
        
        // Send success response
        res.status(200).json({ 
            success: true, 
            message: 'Test cases approval process completed successfully' 
        });
        
    } catch (err) {
        console.error('Error in ALMApproveTestCase fetch and insert process:', err);
        res.status(500).json({ 
            success: false,
            error: err.message || 'Failed to process ALM data' 
        });
    }
});

module.exports = router;