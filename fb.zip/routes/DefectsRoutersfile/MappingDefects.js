


// routes/releasesUploadRoutes.js
const express = require('express');
const router = express.Router();
const { insertSampleDataInDefects, processAndUploadAllDefects, getMigrationStatusInDefects, getDefectsCount}= require('../../controllers/DefectsControllerfile/MappingDefects');
const { uploadDefectComments } = require('../../controllers/DefectsControllerfile/DefectComments');
// Route to insert sample data from ALM to local DB
router.post('/defects',  insertSampleDataInDefects);

// Route to process and upload all releases to qTest
//router.post('/defectsupload', processAndUploadAllDefects);

router.post('/defectsupload', async (req, res) => {
  try {
    await processAndUploadAllDefects(req, res);
    await uploadDefectComments(req, res);
    //res.status(200).json({ success: true, message: 'Upload completed successfully' });
  } catch (error) {
    //res.status(500).json({ error: 'Upload failed', details: error.message });
  }
});

router.post('/defectsupload', async (req, res) => {
  try {
    const result1 = await processAndUploadAllDefects(req);
    console.log("✅ processAndUploadAllDefects completed");

    if (!result1.success) {
      return res.status(result1.status || 500).json(result1);
    }

    const result2 = await uploadDefectComments(req); // assumes this also returns a result
    console.log("✅ uploadDefectComments completed");

    return res.status(200).json({
      message: 'All defect data uploaded successfully',
      defectUpload: result1,
      commentUpload: result2
    });
  } catch (error) {
    console.error("❌ Error in /defectsupload:", error.message);
    return res.status(500).json({ error: 'Upload failed', details: error.message });
  }
});


// New route to get defects count
router.get("/defects/count", getDefectsCount);


// Route to get migration status
router.get('/migrationdefects-status', getMigrationStatusInDefects);

module.exports = router;