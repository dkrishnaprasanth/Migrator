const express = require("express");
const {  getAllData, insertData,refreshQTestData } = require("../../controllers/DefectsControllerfile/qTestDefectsFieldsController");

const router = express.Router();

router.get("/qtestdefects_data",  getAllData);

router.post("/qtestdefects_data", insertData);

router.post("/qtestdefects/refresh-qtest-data", refreshQTestData);

module.exports = router;