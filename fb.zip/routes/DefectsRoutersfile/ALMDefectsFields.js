const express = require('express');
const router = express.Router();
const { fetchAlmReleasesFieldsnew } = require('../../controllers/DefectsControllerfile/ALMDefectsFields');
const {createTables,insertDataJson} = require("../../controllers/DefectsControllerfile/ALMDefectsFieldsController");

router.get('/defectsfielddata', async (req, res) => {
    try {
        // First fetch the ALM data and save to JSON file
        await fetchAlmReleasesFieldsnew();
         await  createTables();

        const insertResult =   insertDataJson();
        if (insertResult) {
            res.status(200).json({ message: 'ALM List data fetched and inserted into database successfully' });
        } else {
            res.status(200).json({ message: 'ALM List data fetched and saved to JSON file. No new data inserted into database.' });
        }
    } catch (err) {
        console.error('Error in ALM fetch and insert process:', err);
        res.status(500).json({ error: err.message || 'Failed to process ALM data' });
    }
});

module.exports = router;