const express = require("express");
const router = express.Router();
const { 
  getAllListTestCases, 
  createListTestCases, 
  refreshListData
} = require("../../controllers/DefectsControllerfile/ALMListDefectsValuesFieldsController");

// Get all test cases
router.get("/get-almedfects-list-db", getAllListTestCases);

// Insert new test cases
router.post("/post-almdefects-list-db", createListTestCases);

// Refresh ALM data (fetches new JSON and updates database)
router.post("/refresh-almefects-list-value", refreshListData);

module.exports = router;