const express = require("express");
const router = express.Router();
const { saveMappings, fetchAllTableNames, getMappingsForTable, getAlmFieldData ,  savedefectsValueMappings} = require("../../controllers/DefectsControllerfile/MappingDefectsController");

// Save mappings (POST)
router.post("/mappingsdefects", saveMappings);


router.post("/defects-valuemappings",  savedefectsValueMappings);

// Make sure this endpoint exists and is properly defined
router.get('/fetch-all-tabledefects-names',fetchAllTableNames);

// For the individual mapping lookup
router.get('/mappingsdefects/:tableName', getMappingsForTable);


router.get('/alm-defectsfield/:alm_physical_name', getAlmFieldData);


module.exports = router;

