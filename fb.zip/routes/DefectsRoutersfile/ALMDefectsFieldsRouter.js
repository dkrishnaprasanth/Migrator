// almRoutes.js
const express = require("express");
const router = express.Router();
const {
  getAllTestCases,
  createTestCases,
  refreshAlmData,
  getAlmFieldByPhysicalName,
  createAlmJsonFile,
  uploadAlmJsonFile,
  getdefectsListValues
} = require("../../controllers/DefectsControllerfile/ALMDefectsFieldsController");

// Update the routes to include "alm" in the path where needed
router.get("/get-defectsfields", getAllTestCases);
router.post("/defectsfields", createTestCases);
router.post("/alm/refresh-defectsfields", refreshAlmData); // This matches your frontend request
router.post('/alm/create-defectsfields', createAlmJsonFile);
router.get('/defects/field/:physicalName', getAlmFieldByPhysicalName);
router.post("/alm/upload-json-to-defectsfields", uploadAlmJsonFile);

router.get('/defects-list-values/:listId',getdefectsListValues);

module.exports = router;

