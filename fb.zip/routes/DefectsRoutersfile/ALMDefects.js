const express = require('express');
const router = express.Router();
const { fetchAlmReleases } = require('../../controllers/DefectsControllerfile/ALMDefects');

// GET route using default ALM release URL
router.get('/defects', async (req, res) => {
    try {
        await fetchAlmReleases(); // Default URL from config
        res.status(200).json({ message: 'Default ALM Defect data fetched and saved.' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// POST route with optional custom URL
router.post('/defects/custom', async (req, res) => {
    try {
        const { customReleaseUrl } = req.body;
        await fetchAlmReleases(customReleaseUrl || '');
        res.status(200).json({ message: 'Custom ALM defect data fetched and saved.' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;



