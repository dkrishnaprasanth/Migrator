const express = require('express');
const router = express.Router();
const settingsController = require('../controllers/settingsController');
 
// Routes for combined settings
router.post('/settings', settingsController.saveSystemSettings);
router.get('/settings', settingsController.getSystemSettings);
router.get('/settings/:id', settingsController.getSingleSystemSetting);
router.put('/settings/:id', settingsController.updateSystemSetting);
router.delete('/settings/:id', settingsController.deleteSystemSetting);

// Add this route in your routes file
router.get('/check-name/:name', settingsController.checkNameExists);
 
// New routes for temporary saving credentials for validation
router.post('/save-temp-alm', settingsController.saveTempAlmCredentials);
router.post('/save-temp-qtest', settingsController.saveTempQtestCredentials);
 
// Validation routes
router.post('/validate-alm', settingsController.validateAlmConnection);
router.post('/validate-qtest', settingsController.validateQtestConnection);

router.put('/set-current/:link_name', settingsController.setCurrentLink);

// Optional: Add route for getting settings with current status
router.get('/settings-with-current', settingsController.getSystemSettingsWithCurrent);
 

module.exports = router;