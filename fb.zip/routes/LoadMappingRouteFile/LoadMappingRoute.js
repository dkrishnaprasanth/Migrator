const express = require('express');
const router = express.Router();
const {
  getLinkNames,
  getArtifactTypesByLink,
  getMappedFieldsByArtifacts
} = require('../../controllers/LoadMappingControllerFile/LoadMapping');
 
router.get('/link-names', getLinkNames);
router.get('/artifact-types/:linkName', getArtifactTypesByLink);
router.post('/mapped-fields', getMappedFieldsByArtifacts);
 
module.exports = router;
