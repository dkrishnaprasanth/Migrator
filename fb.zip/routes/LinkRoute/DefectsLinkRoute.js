// const express = require('express');
// const router = express.Router();
// const { linkDefects } = require('../../controllers/LinkControllerFile/DefectsLinking');

// router.post('/link-defects', linkDefects);

// module.exports = router;




const express = require('express');
const router = express.Router();
const { linkDefects } = require('../../controllers/LinkControllerFile/DefectsLinking');

router.post('/link-defects', linkDefects);

module.exports = router;