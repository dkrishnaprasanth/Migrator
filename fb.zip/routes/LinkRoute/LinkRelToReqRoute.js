// const express = require('express');
// const router = express.Router();
// const linkController = require('../../controllers/LinkControllerFile/LinkReleaseToRequirement');

// // POST: /api/link-release-to-req
// router.post('/link-release-to-req', linkController.linkReleaseToRequirement);

// module.exports = router;



const express = require('express');
const router = express.Router();
const linkController = require('../../controllers/LinkControllerFile/LinkReleaseToRequirement');

// POST: /api/link-release-to-req
router.post('/link-release-to-req', linkController.linkReleaseToRequirement);

module.exports = router;
