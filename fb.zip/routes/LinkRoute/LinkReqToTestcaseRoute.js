// const express = require('express');
// const router = express.Router();
// const testLinkController = require('../../controllers/LinkControllerFile/LinkRequirementToTestCase');

// // POST: /api/link-req-to-test
// router.post('/link-req-to-test', testLinkController.linkRequirementToTest);

// module.exports = router;




const express = require('express');
const router = express.Router();
const testLinkController = require('../../controllers/LinkControllerFile/LinkRequirementToTestCase');

// POST: /api/link-req-to-test
router.post('/link-req-to-test', testLinkController.linkRequirementToTest);

module.exports = router;
