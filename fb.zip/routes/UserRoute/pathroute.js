const express = require("express");
const multer = require("multer");
const { updateUsersFromCSV } = require("../../controllers/usersmig/csvchecker");
const { insertUsers } = require("../../controllers/usersmig/pushqtestuserToDB");
const { fetchalmusers } = require("../../controllers/usersmig/getalmusers");
const { fetchQTestUsers} = require("../../controllers/usersmig/getqTestusers");
const { main } = require("../../controllers/usersmig/pushalmuserToDB");



const router = express.Router();
const storage = multer.memoryStorage();
const upload = multer({ storage });

router.post("/upload-csv", upload.single("csvFile"), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: "No file uploaded!" });
    }

    const csvContent = req.file.buffer.toString("utf-8");
    
    await fetchalmusers();
    await fetchQTestUsers();
    await main();
    await updateUsersFromCSV(csvContent);
    await insertUsers();

    res.json({ message: "CSV uploaded and processed successfully!" });
  } catch (error) {
    console.error("Error processing CSV:", error);
    res.status(500).json({ message: "Error processing CSV", details: error.message });
  }
});

module.exports = router;
