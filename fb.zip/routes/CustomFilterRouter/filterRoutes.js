// routes/filterRoutes.js
const express = require('express');
const router = express.Router();
const {
  saveFilter,
  getAllFilters,
  getFiltersByLink
} = require('../../controllers/CustomFilter/Filter');

// Save filter
router.post('/filter/save', saveFilter);

// Get all filters
router.get('/filter/all', getAllFilters);

// Get filters by link_name
router.get('/filter/:link_name', getFiltersByLink);

module.exports = router;
