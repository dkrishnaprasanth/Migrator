const express = require('express');
const router = express.Router();
const db = require('../../config/db');  // ✅ You forgot this
 
router.get('/alm/status', async (req, res) => {
  try {
    const [total] = await db.promise().query("SELECT COUNT(*) as count FROM parameters");
    const [success] = await db.promise().query("SELECT COUNT(*) as count FROM parameters WHERE Status_Params = 'completed'");
    const [failed] = await db.promise().query("SELECT COUNT(*) as count FROM parameters WHERE Status_Params = 'failed'");
    const [pending] = await db.promise().query("SELECT COUNT(*) as count FROM parameters WHERE Status_Params IS NULL OR Status_Params = ''");
 
    res.json({
      total: total[0].count,
      success: success[0].count,
      failed: failed[0].count,
      pending: pending[0].count
    });
  } catch (err) {
    res.status(500).json({
      message: "Error fetching parameter migration status",
      error: err.message
    });
  }
});
 
const { insertparameters, uploadparameters, getParameterCount} = require('../../controllers/ParametersControllerfile/AlmparameterConnection');
 
router.get('/insertparameters', insertparameters);
 
router.get('/uploadparameters', uploadparameters);

router.get('/parameter/count', getParameterCount);

module.exports = router;