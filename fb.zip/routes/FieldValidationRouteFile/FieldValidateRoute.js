// const express = require('express');
// const router = express.Router();
// const validateFieldMappings = require('../../controllers/FieldValidationController/FieldValidation');

// router.get('/validate-fields', async (req, res) => {
//   try {
//     console.log('Starting field validation...');
//     const result = await validateFieldMappings();

//     if (result.status === 'completed') {
//       res.status(200).json({
//         success: true,
//         message: result.message,
//         report: result.result
//       });
//     } else if (result.status === 'error') {
//       res.status(500).json({
//         success: false,
//         message: result.message,
//         report: [],
//         error_type: 'database_connection'
//       });
//     } else {
//       res.status(500).json({
//         success: false,
//         message: result.message || 'Validation failed',
//         report: []
//       });
//     }
//   } catch (error) {
//     console.error('Route error:', error);
//     res.status(500).json({
//       success: false,
//       message: 'Internal Server Error: ' + error.message,
//       report: [],
//       error_type: 'server_error'
//     });
//   }
// });

// module.exports = router;


const express = require('express');
const router = express.Router();
const validateFieldMappings = require('../../controllers/FieldValidationController/FieldValidation');

router.get('/validate-fields', async (req, res) => {
  try {
    console.log('Starting field validation...');
    console.log('Request received at:', new Date().toISOString());
    
    const result = await validateFieldMappings();
    console.log('Validation result status:', result.status);

    if (result.status === 'completed') {
      const responseData = {
        success: true,
        message: result.message,
        report: result.result,
        timestamp: new Date().toISOString(),
        total_links: result.result.length
      };
      
      console.log(`Validation completed successfully. Found ${result.result.length} links.`);
      res.status(200).json(responseData);
      
    } else if (result.status === 'error') {
      console.error('Database error during validation:', result.message);
      res.status(500).json({
        success: false,
        message: result.message,
        report: [],
        error_type: 'database_connection',
        timestamp: new Date().toISOString()
      });
      
    } else {
      console.error('Unknown validation status:', result.status);
      res.status(500).json({
        success: false,
        message: result.message || 'Validation failed with unknown status',
        report: [],
        error_type: 'unknown_error',
        timestamp: new Date().toISOString()
      });
    }
    
  } catch (error) {
    console.error('Route error:', error);
    console.error('Error stack:', error.stack);
    
    res.status(500).json({
      success: false,
      message: 'Internal Server Error: ' + error.message,
      report: [],
      error_type: 'server_error',
      timestamp: new Date().toISOString()
    });
  }
});

// Additional route to get the latest validation report
router.get('/validation-report', (req, res) => {
  try {
    const fs = require('fs');
    const path = require('path');
    
    const filePath = path.join('C:', 'Users', 'ElitteBook', 'Pictures', 'Build project', 'backend', 'data', 'fieldvalidationreport.json');
    
    if (fs.existsSync(filePath)) {
      const reportData = fs.readFileSync(filePath, 'utf8');
      const report = JSON.parse(reportData);
      
      res.status(200).json({
        success: true,
        message: 'Report retrieved successfully',
        report: report,
        file_path: filePath
      });
    } else {
      res.status(404).json({
        success: false,
        message: 'No validation report found. Please run validation first.',
        report: []
      });
    }
  } catch (error) {
    console.error('Error reading report file:', error);
    res.status(500).json({
      success: false,
      message: 'Error reading validation report: ' + error.message,
      report: []
    });
  }
});

module.exports = router;