
const express = require('express');
const router = express.Router();
const { fetchqTestRequirementFields  } = require('../../controllers/RequirementControllersfile/qTestRequirementFields');
const {  createTableqtestrequirement,   insertqtestrequirementDataFromJson } = require('../../controllers/RequirementControllersfile/qTestRequirementFieldsController');

router.get('/qtestrequirementfield', async (req, res) => {
    try {
        // First fetch the qTest data and save to JSON file
        await fetchqTestRequirementFields ();
        
        // Create the table if it doesn't exist
        await  createTableqtestrequirement();
        
        // Then insert the data from the JSON file into the database
        const insertResult = await  insertqtestrequirementDataFromJson();
        
        if (insertResult) {
            res.status(200).json({ message: 'qTest data fetched and inserted into database successfully' });
        } else {
            res.status(200).json({ message: 'qTest data fetched and saved to JSON file. No new data inserted into database.' });
        }
    } catch (err) {
        console.error('Error in qTest fetch and insert process:', err);
        res.status(500).json({ error: err.message || 'Failed to process qTest data' });
    }
});

module.exports = router;