

const express = require('express');
const router = express.Router();
const { fetchAlmRequirement } = require('../../controllers/RequirementControllersfile/ALMRequirement');

// GET: Fetch default ALM releases
router.get('/requirement', async (req, res) => {
    try {
        await fetchAlmRequirement();
        res.status(200).json({ message: '✅ Default ALM release data fetched and saved.' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// POST: Fetch custom URL if provided
router.post('/requirement/custom', async (req, res) => {
    try {
        const { customReleaseUrl } = req.body;
        await fetchAlmRequirement(customReleaseUrl || '');
        res.status(200).json({ message: '✅ Custom ALM release data fetched and saved.' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;
