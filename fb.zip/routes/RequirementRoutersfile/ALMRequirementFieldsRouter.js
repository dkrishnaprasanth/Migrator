// almRoutes.js
const express = require("express");
const router = express.Router();
const {
  getAllRequirementTestCases,
  createRequirementTestCases,
  getAlmRequirementFieldByPhysicalName,
  createAlmRequirementJsonFile,
  uploadAlmRequirementJsonFile,
  getRequirementListValues
} = require("../../controllers/RequirementControllersfile/ALMRequirementFieldsController");

// Update the routes to include "alm" in the path where needed
router.get("/rquirement-test-cases",  getAllRequirementTestCases);
router.post("/requirement-test-cases",  createRequirementTestCases);
router.post('/alm/create-requirement-field', createAlmRequirementJsonFile);
router.get('/requirement/field/:physicalName', getAlmRequirementFieldByPhysicalName);
router.post("/alm/upload-requirement", uploadAlmRequirementJsonFile);

router.get('/req/list-values/:listId', getRequirementListValues);

module.exports = router;

