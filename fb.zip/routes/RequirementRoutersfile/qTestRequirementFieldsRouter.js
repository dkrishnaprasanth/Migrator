const express = require("express");
const {  getqtestrequirementAllData, insertRequirementData  } = require("../../controllers/RequirementControllersfile/qTestRequirementFieldsController");

const router = express.Router();

router.get("/qtest-requirement_data",  getqtestrequirementAllData);

router.post("/qtest-requirement_data", insertRequirementData);

// router.post("/requirement/refresh-qtest-data",  refreshQTestrequirementData);

module.exports = router;