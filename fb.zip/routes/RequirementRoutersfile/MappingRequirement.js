
// routes/releasesUploadRoutes.js
const express = require('express');
const router = express.Router();
const {RequirementinsertSampleData, processAndRequirementUploadAll,  getRequirementMigrationStatus, getRequirementsCount}= require('../../controllers/RequirementControllersfile/MappingRequirement');
const {uploadRequirementComments} = require('../../controllers/RequirementControllersfile/RequirementComments');
// Route to insert sample data from ALM to local DB
router.post('/requirement', RequirementinsertSampleData);

// Route to process and upload all releases to qTest
//router.post('/requirementupload',  processAndRequirementUploadAll);

router.post('/requirementupload', async (req, res) => {
  try {
    await processAndRequirementUploadAll(req, res);
    await uploadRequirementComments(req, res);
    //res.status(200).json({ success: true, message: 'Upload completed successfully' });
  } catch (error) {
    //res.status(500).json({ error: 'Upload failed', details: error.message });
  }
});

// Route to get requirements count
router.get("/requirement/count", getRequirementsCount);

// Route to get migration status
router.get('/migration-requirement-status',  getRequirementMigrationStatus);

module.exports = router;



