const express = require("express");
const router = express.Router();
const { 
  getAllListRequirementTestCases, 
  createListRequirementTestCases, 
  refreshRequirementListData
} = require("../../controllers/RequirementControllersfile/ALMListRequirementValueFielsController");

// Get all test cases
router.get("/get-alm-requirement-list-db",  getAllListRequirementTestCases);

// Insert new test cases
router.post("/post-alm-requirement-list-db", createListRequirementTestCases);

// Refresh ALM data (fetches new JSON and updates database)
router.post("/refresh-alm-list-requirement-value", refreshRequirementListData);

module.exports = router;