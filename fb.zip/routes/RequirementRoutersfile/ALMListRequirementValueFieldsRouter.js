const express = require('express');
const router = express.Router();
const {  fetchListRequirementFields } = require('../../controllers/RequirementControllersfile/AlmListRequirementValuesFields');
const { createListRequirementTables,  insertListRequirementDataJson} = require ('../../controllers/RequirementControllersfile/ALMListRequirementValueFielsController');

router.get('/listrequirementfield', async (req, res) => {
    try {
        // First fetch the ALM data and save to JSON file
    await  fetchListRequirementFields();

        await  createListRequirementTables();

        const insertResult =  insertListRequirementDataJson();
        if (insertResult) {
            res.status(200).json({ message: 'ALM List data fetched and inserted into database successfully' });
        } else {
            res.status(200).json({ message: 'ALM List data fetched and saved to JSON file. No new data inserted into database.' });
        }
    } catch (err) {
        console.error('Error in ALM List fetch and insert process:', err);
        res.status(500).json({ error: err.message || 'Failed to process ALM data' });
    }
});

module.exports = router;
