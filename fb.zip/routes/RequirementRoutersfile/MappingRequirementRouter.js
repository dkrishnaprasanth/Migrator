const express = require("express");
const router = express.Router();
const {RequirementsaveMappings, fetchAllRequirementTableNames,  getRequirementMappingsForTable,  getAlmRequirementFieldData ,  saverequirementValueMappings} = require("../../controllers/RequirementControllersfile/MappingRequirementController");

// Save mappings (POST)
router.post("/requirementmappings", RequirementsaveMappings);


router.post("/requirement-valuemappings", saverequirementValueMappings);


// Make sure this endpoint exists and is properly defined
router.get('/fetch-all-requirementtable-names',fetchAllRequirementTableNames);

// For the individual mapping lookup
router.get('/requirementmappings/:tableName',  getRequirementMappingsForTable);


router.get('/alm-requirementfield/:alm_physical_name',  getAlmRequirementFieldData);


module.exports = router;

