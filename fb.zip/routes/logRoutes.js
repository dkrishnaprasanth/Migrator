const express = require('express');
const router = express.Router();
const { runProcess } = require('../controllers/logController');

router.get('/run-process', runProcess);

module.exports = router;
