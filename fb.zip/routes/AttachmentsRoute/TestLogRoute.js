const express = require('express');
const router = express.Router();
const { TestLogAttachments } = require('../../controllers/AttachmentsControllerFile/TestLogAttachment');

router.post('/TestLogAttachments',  TestLogAttachments);

module.exports = router;