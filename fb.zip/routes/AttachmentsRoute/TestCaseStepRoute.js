const express = require('express');
const router = express.Router();
const { TestCaseStepAttachments } = require('../../controllers/AttachmentsControllerFile/TestCaseStepAttachment');

router.post('/TestCaseStepAttachments',  TestCaseStepAttachments);

module.exports = router;