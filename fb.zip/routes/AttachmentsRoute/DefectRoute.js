const express = require('express');
const router = express.Router();
const { DefectAttachments } = require('../../controllers/AttachmentsControllerFile/DefectAttachment');

router.post('/DefectAttachments', DefectAttachments);

module.exports = router;