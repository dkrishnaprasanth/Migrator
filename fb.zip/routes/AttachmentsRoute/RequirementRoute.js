const express = require('express');
const router = express.Router();
const { RequirementAttachments } = require('../../controllers/AttachmentsControllerFile/RequirementAttachment');

router.post('/RequirementAttachments', RequirementAttachments);

module.exports = router;