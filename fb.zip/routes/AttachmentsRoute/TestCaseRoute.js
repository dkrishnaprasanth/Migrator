const express = require('express');
const router = express.Router();
const { TestCaseAttachments } = require('../../controllers/AttachmentsControllerFile/TestCaseAttachment');

router.post('/TestCaseAttachments', TestCaseAttachments);

module.exports = router;