const express = require('express');
const router = express.Router();
const { TestLogStepAttachments } = require('../../controllers/AttachmentsControllerFile/TestLogStepAttachment');

router.post('/TestLogStepAttachments',  TestLogStepAttachments);

module.exports = router;