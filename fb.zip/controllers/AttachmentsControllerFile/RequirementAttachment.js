

const fs = require("fs");
const path = require("path");
const axios = require("axios");
const https = require("https");
const db = require("../../config/db");
const FormData = require("form-data");

// Load credentials
const almConfig = JSON.parse(fs.readFileSync(path.join(__dirname, '../../data/AlmCredentials.json')));
const qtestConfig = JSON.parse(fs.readFileSync(path.join(__dirname, '../../data/qTestCredentials.json')));

const {
  almServerUrl,
  username: almUsername,
  password: almPassword,
  domain,
  project
} = almConfig;

const {
  qTestDomain: qtestUrl,
  projectId: qtestProjectId,
  apiToken: qtestToken
} = qtestConfig;

let almCookies = null;

// Authenticate to ALM
async function authenticate(authUrl, username, password) {
  const auth = Buffer.from(`${username}:${password}`).toString("base64");
  const response = await axios.post(authUrl, {}, {
    headers: {
      "Content-Type": "application/json",
      Authorization: `Basic ${auth}`,
    },
    withCredentials: true,
    httpsAgent: new https.Agent({ rejectUnauthorized: false }),
  });

  const cookies = {};
  const rawCookies = response.headers["set-cookie"];
  if (rawCookies) {
    for (const cookie of rawCookies) {
      const parts = cookie.split(";")[0].split("=");
      cookies[parts[0]] = parts[1];
    }
  }

  return cookies;
}

// Build ALM headers
function buildHeaders(cookies, acceptType = "application/json") {
  const cookieHeader = Object.entries(cookies).map(([k, v]) => `${k}=${v}`).join("; ");
  return {
    Accept: acceptType,
    "X-XSRF-TOKEN": cookies["XSRF-TOKEN"],
    Cookie: cookieHeader,
  };
}

// Make ALM request with retry on 401
async function makeAlmRequestWithRetry(configFn) {
  try {
    return await configFn(almCookies);
  } catch (err) {
    if (err.response && err.response.status === 401) {
      console.warn("🔁 Session expired. Re-authenticating...");
      almCookies = await authenticate(`${almServerUrl}/api/authentication/sign-in`, almUsername, almPassword);
      return await configFn(almCookies);
    }
    throw err;
  }
}

// Update DB
async function updateAttachStatus(relId, status) {
  await db.promise().query("UPDATE requirement SET attach_status = ? WHERE id = ?", [status, relId]);
}

// Main controller
const RequirementAttachments = async (req, res) => {
  try {
    almCookies = await authenticate(`${almServerUrl}/api/authentication/sign-in`, almUsername, almPassword);
    if (!almCookies["XSRF-TOKEN"] || !almCookies["JSESSIONID"]) {
      return res.status(401).json({ message: "Authentication with ALM failed" });
    }

    const [rows] = await db.promise().query(
      "SELECT id, qtest_requirement_id FROM requirement WHERE qtest_requirement_id is not NULL AND (attach_status IS NULL OR attach_status = 'failed')"
    );

    for (const row of rows) {
      const relId = row.id;
      const qtestId = row.qtest_requirement_id;

      console.log("📂 Processing requirement:", relId);

      // 🔁 Retry wrapper for ALM GET request
      const attachResp = await makeAlmRequestWithRetry(cookies =>
        axios.get(`${almServerUrl}/rest/domains/${domain}/projects/${project}/requirements/${relId}/attachments`, {
          headers: buildHeaders(cookies),
          httpsAgent: new https.Agent({ rejectUnauthorized: false }),
        })
      );

      const entities = attachResp.data.entities;
      if (!Array.isArray(entities) || entities.length === 0) {
        console.log(`⚠️ No attachments for id: ${relId}`);
        await updateAttachStatus(relId, "no_attachments");
        continue;
      }

      let allSuccess = true;

      for (const entity of entities) {
        let attachId = null, fileName = null;
        for (const field of entity.Fields) {
          if (field.Name === "id") attachId = field.values[0].value;
          else if (field.Name === "name") fileName = field.values[0].value;
        }

        if (!attachId || !fileName) {
          console.error("❌ Missing attachment ID or filename");
          continue;
        }

        console.log(`⬇️ Downloading attachment ${attachId} (${fileName})`);

        const contentUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/attachments/${attachId}`;
        const tempPath = path.join(__dirname, `temp_${attachId}_${fileName}`);

        const contentResp = await makeAlmRequestWithRetry(cookies =>
          axios.get(contentUrl, {
            responseType: "stream",
            headers: buildHeaders(cookies, "application/octet-stream"),
            httpsAgent: new https.Agent({ rejectUnauthorized: false }),
          })
        );

        const writer = fs.createWriteStream(tempPath);
        await new Promise((resolve, reject) => {
          contentResp.data.pipe(writer);
          writer.on("finish", resolve);
          writer.on("error", reject);
        });

        try {
          const form = new FormData();
          form.append("file", fs.createReadStream(tempPath), fileName);

          const qtestResp = await axios.post(
            `${qtestUrl}/api/v3/projects/${qtestProjectId}/requirements/${qtestId}/attachments`,
            form,
            {
              headers: {
                Authorization: `Bearer ${qtestToken}`,
                ...form.getHeaders(),
              },
              httpsAgent: new https.Agent({ rejectUnauthorized: false }),
            }
          );

          if (qtestResp.status === 200 || qtestResp.status === 201) {
            console.log(`✅ Uploaded to qTest: ${fileName}`);
          } else {
            console.error(`❌ Failed to upload ${fileName}, Status: ${qtestResp.status}`);
            allSuccess = false;
          }
        } catch (uploadErr) {
          console.error("❌ Upload error:", uploadErr.message);
          allSuccess = false;
        } finally {
          fs.unlinkSync(tempPath);
        }
      }

      await updateAttachStatus(relId, allSuccess ? "success" : "failed");
    }

    return res.status(200).json({ message: "Requirement attachment sync completed" });
  } catch (err) {
    console.error("❌ Sync failed:", err);
    return res.status(500).json({ message: "Internal server error", error: err.message });
  }
};

module.exports = { RequirementAttachments };
