// const fs = require("fs");
// const path = require("path");
// const axios = require("axios");
// const https = require("https");
// const db = require("../../config/db"); 
// const FormData = require("form-data");


// const almConfig = JSON.parse(fs.readFileSync(path.join(__dirname, '../../data/AlmCredentials.json')));
// const qtestConfig = JSON.parse(fs.readFileSync(path.join(__dirname, '../../data/qTestCredentials.json')));

// const {
//   almServerUrl,
//   username: almUsername,
//   password: almPassword,
//   domain,
//   project
// } = almConfig;

// const {
//   qTestDomain: qtestUrl,
//   projectId: qtestProjectId,
//   apiToken: qtestToken
// } = qtestConfig;


// // Authentication
// async function authenticate(url, username, password) {
//   const auth = Buffer.from(`${username}:${password}`).toString("base64");
//   const response = await axios.post(
//     url,
//     {},
//     {
//       headers: {
//         "Content-Type": "application/json",
//         Authorization: `Basic ${auth}`,
//       },
//       withCredentials: true,
//       httpsAgent: new https.Agent({ rejectUnauthorized: false }),
//     }
//   );

//   const cookies = {};
//   const rawCookies = response.headers["set-cookie"];
//   if (rawCookies) {
//     for (const cookie of rawCookies) {
//       const parts = cookie.split(";")[0].split("=");
//       cookies[parts[0]] = parts[1];
//     }
//   }
//   return cookies;
// }

// // Build ALM cookie headers
// function buildHeaders(cookies, acceptType = "application/json") {
//   const cookieHeader = Object.entries(cookies).map(([k, v]) => `${k}=${v}`).join("; ");
//   return {
//     Accept: acceptType,
//     "X-XSRF-TOKEN": cookies["XSRF-TOKEN"],
//     Cookie: cookieHeader,
//   };
// }

// // Update attach_status in DB
// async function updateAttachStatus(relId, status) {
//   await db.promise().query("UPDATE testlogsteps SET attach_status = ? WHERE id = ?", [status, relId]);
// }

// // ✅ Main Controller Function
// const TestLogStepAttachments = async (req, res) => {
//   try {
//     const cookies = await authenticate(`${almServerUrl}/api/authentication/sign-in`, almUsername, almPassword);
//     if (!cookies["XSRF-TOKEN"] || !cookies["JSESSIONID"]) {
//       return res.status(401).json({ message: "Authentication with ALM failed" });
//     }

//     const [rows] = await db.promise().query(
//       "SELECT id, qtest_testlogstep_id FROM testlogsteps WHERE attach_status IS NULL OR attach_status = 'failed'"
//     );

//     for (const row of rows) {
//       const relId = row.id;
//       const qtestId = row.qtest_testlogstep_id;

//       console.log("📂 Processing testlogsteps:", relId);

//       const attachUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/run-steps/${relId}/attachments`;
//       const attachResp = await axios.get(attachUrl, {
//         headers: buildHeaders(cookies),
//         httpsAgent: new https.Agent({ rejectUnauthorized: false }),
//       });

//       const entities = attachResp.data.entities;
//       if (!Array.isArray(entities) || entities.length === 0) {
//         console.log(`⚠️ No attachments for id: ${relId}`);
//         await updateAttachStatus(relId, "no_attachments");
//         continue;
//       }

//       let allSuccess = true;

//       for (const entity of entities) {
//         let attachId = null, fileName = null;
//         for (const field of entity.Fields) {
//           if (field.Name === "id") attachId = field.values[0].value;
//           else if (field.Name === "name") fileName = field.values[0].value;
//         }

//         if (!attachId || !fileName) {
//           console.error("❌ Missing attachment ID or filename");
//           continue;
//         }

//         console.log(`⬇️ Downloading attachment ${attachId} (${fileName})`);

//         const contentUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/attachments/${attachId}`;
//         const tempPath = path.join(__dirname, `temp_${attachId}_${fileName}`);

//         const contentResp = await axios.get(contentUrl, {
//           responseType: "stream",
//           headers: buildHeaders(cookies, "application/octet-stream"),
//           httpsAgent: new https.Agent({ rejectUnauthorized: false }),
//         });

//         const writer = fs.createWriteStream(tempPath);
//         await new Promise((resolve, reject) => {
//           contentResp.data.pipe(writer);
//           writer.on("finish", resolve);
//           writer.on("error", reject);
//         });

//         try {
//           const form = new FormData();
//           form.append("file", fs.createReadStream(tempPath), fileName);

//           const qtestResp = await axios.post(
//             `${qtestUrl}/api/v3/projects/${qtestProjectId}/test-step-logs/${qtestId}/attachments`,
//             form,
//             {
//               headers: {
//                 Authorization: `Bearer ${qtestToken}`,
//                 ...form.getHeaders(),
//               },
//               httpsAgent: new https.Agent({ rejectUnauthorized: false }),
//             }
//           );

//           if (qtestResp.status === 200 || qtestResp.status === 201) {
//             console.log(`✅ Uploaded to qTest: ${fileName}`);
//           } else {
//             console.error(`❌ Failed to upload ${fileName}, Status: ${qtestResp.status}`);
//             allSuccess = false;
//           }
//         } catch (uploadErr) {
//           console.error("❌ Upload error:", uploadErr.message);
//           allSuccess = false;
//         } finally {
//           fs.unlinkSync(tempPath);
//         }
//       }

//       await updateAttachStatus(relId, allSuccess ? "success" : "failed");
//     }

//     return res.status(200).json({ message: "Attachment sync completed" });
//   } catch (err) {
//     console.error("❌ Sync failed:", err);
//     return res.status(500).json({ message: "Internal server error", error: err.message });
//   }
// };

// module.exports = { TestLogStepAttachments };


// const fs = require("fs");
// const path = require("path");
// const axios = require("axios");
// const https = require("https");
// const db = require("../../config/db"); 
// const FormData = require("form-data");


// const almConfig = JSON.parse(fs.readFileSync(path.join(__dirname, '../../data/AlmCredentials.json')));
// const qtestConfig = JSON.parse(fs.readFileSync(path.join(__dirname, '../../data/qTestCredentials.json')));

// const {
//   almServerUrl,
//   username: almUsername,
//   password: almPassword,
//   domain,
//   project
// } = almConfig;

// const {
//   qTestDomain: qtestUrl,
//   projectId: qtestProjectId,
//   apiToken: qtestToken
// } = qtestConfig;


// // Authentication
// async function authenticate(url, username, password) {
//   const auth = Buffer.from(`${username}:${password}`).toString("base64");
//   const response = await axios.post(
//     url,
//     {},
//     {
//       headers: {
//         "Content-Type": "application/json",
//         Authorization: `Basic ${auth}`,
//       },
//       withCredentials: true,
//       httpsAgent: new https.Agent({ rejectUnauthorized: false }),
//     }
//   );

//   const cookies = {};
//   const rawCookies = response.headers["set-cookie"];
//   if (rawCookies) {
//     for (const cookie of rawCookies) {
//       const parts = cookie.split(";")[0].split("=");
//       cookies[parts[0]] = parts[1];
//     }
//   }
//   return cookies;
// }

// // Build ALM cookie headers
// function buildHeaders(cookies, acceptType = "application/json") {
//   const cookieHeader = Object.entries(cookies).map(([k, v]) => `${k}=${v}`).join("; ");
//   return {
//     Accept: acceptType,
//     "X-XSRF-TOKEN": cookies["XSRF-TOKEN"],
//     Cookie: cookieHeader,
//   };
// }

// // Update attach_status in DB
// async function updateAttachStatus(relId, status) {
//   await db.promise().query("UPDATE testlogsteps SET attach_status = ? WHERE id = ?", [status, relId]);
// }

// // ✅ Main Controller Function
// const TestLogStepAttachments = async (req, res) => {
//   try {
//     const cookies = await authenticate(`${almServerUrl}/api/authentication/sign-in`, almUsername, almPassword);
//     if (!cookies["XSRF-TOKEN"] || !cookies["JSESSIONID"]) {
//       return res.status(401).json({ message: "Authentication with ALM failed" });
//     }

//     const [rows] = await db.promise().query(
//       "SELECT id, qtest_testlogstep_id FROM testlogsteps WHERE attach_status IS NULL OR attach_status = 'failed'"
//     );

//     for (const row of rows) {
//       const relId = row.id;
//       const qtestId = row.qtest_testlogstep_id;

//       console.log("📂 Processing testlogsteps:", relId);

//       const attachUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/run-steps/${relId}/attachments`;
//       const attachResp = await axios.get(attachUrl, {
//         headers: buildHeaders(cookies),
//         httpsAgent: new https.Agent({ rejectUnauthorized: false }),
//       });

//       const entities = attachResp.data.entities;
//       if (!Array.isArray(entities) || entities.length === 0) {
//         console.log(`⚠️ No attachments for id: ${relId}`);
//         await updateAttachStatus(relId, "no_attachments");
//         continue;
//       }

//       let allSuccess = true;

//       for (const entity of entities) {
//         let attachId = null, fileName = null;
//         for (const field of entity.Fields) {
//           if (field.Name === "id") attachId = field.values[0].value;
//           else if (field.Name === "name") fileName = field.values[0].value;
//         }

//         if (!attachId || !fileName) {
//           console.error("❌ Missing attachment ID or filename");
//           continue;
//         }

//         console.log(`⬇️ Downloading attachment ${attachId} (${fileName})`);

//         const contentUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/attachments/${attachId}`;
//         const tempPath = path.join(__dirname, `temp_${attachId}_${fileName}`);

//         const contentResp = await axios.get(contentUrl, {
//           responseType: "stream",
//           headers: buildHeaders(cookies, "application/octet-stream"),
//           httpsAgent: new https.Agent({ rejectUnauthorized: false }),
//         });

//         const writer = fs.createWriteStream(tempPath);
//         await new Promise((resolve, reject) => {
//           contentResp.data.pipe(writer);
//           writer.on("finish", resolve);
//           writer.on("error", reject);
//         });

//         try {
//           const form = new FormData();
//           form.append("file", fs.createReadStream(tempPath), fileName);

//           const qtestResp = await axios.post(
//             `${qtestUrl}/api/v3/projects/${qtestProjectId}/test-step-logs/${qtestId}/attachments`,
//             form,
//             {
//               headers: {
//                 Authorization: `Bearer ${qtestToken}`,
//                 ...form.getHeaders(),
//               },
//               httpsAgent: new https.Agent({ rejectUnauthorized: false }),
//             }
//           );

//           if (qtestResp.status === 200 || qtestResp.status === 201) {
//             console.log(`✅ Uploaded to qTest: ${fileName}`);
//           } else {
//             console.error(`❌ Failed to upload ${fileName}, Status: ${qtestResp.status}`);
//             allSuccess = false;
//           }
//         } catch (uploadErr) {
//           console.error("❌ Upload error:", uploadErr.message);
//           allSuccess = false;
//         } finally {
//           fs.unlinkSync(tempPath);
//         }
//       }

//       await updateAttachStatus(relId, allSuccess ? "success" : "failed");
//     }

//     return res.status(200).json({ message: "Attachment sync completed" });
//   } catch (err) {
//     console.error("❌ Sync failed:", err);
//     return res.status(500).json({ message: "Internal server error", error: err.message });
//   }
// };

// module.exports = { TestLogStepAttachments };








// const fs = require("fs");
// const path = require("path");
// const axios = require("axios");
// const https = require("https");
// const db = require("../../config/db");
// const FormData = require("form-data");

// const almConfig = JSON.parse(fs.readFileSync(path.join(__dirname, '../../data/AlmCredentials.json')));
// const qtestConfig = JSON.parse(fs.readFileSync(path.join(__dirname, '../../data/qTestCredentials.json')));

// const {
//   almServerUrl,
//   username: almUsername,
//   password: almPassword,
//   domain,
//   project
// } = almConfig;

// const {
//   qTestDomain: qtestUrl,
//   projectId: qtestProjectId,
//   apiToken: qtestToken
// } = qtestConfig;

// let cookies = {}; // Shared cookies

// async function authenticate() {
//   const auth = Buffer.from(`${almUsername}:${almPassword}`).toString("base64");
//   const response = await axios.post(
//     `${almServerUrl}/api/authentication/sign-in`,
//     {},
//     {
//       headers: {
//         "Content-Type": "application/json",
//         Authorization: `Basic ${auth}`,
//       },
//       withCredentials: true,
//       httpsAgent: new https.Agent({ rejectUnauthorized: false }),
//     }
//   );

//   const rawCookies = response.headers["set-cookie"];
//   const newCookies = {};
//   if (rawCookies) {
//     for (const cookie of rawCookies) {
//       const parts = cookie.split(";")[0].split("=");
//       newCookies[parts[0]] = parts[1];
//     }
//   }
//   cookies = newCookies;
// }

// function buildHeaders(acceptType = "application/json") {
//   const cookieHeader = Object.entries(cookies).map(([k, v]) => `${k}=${v}`).join("; ");
//   return {
//     Accept: acceptType,
//     "X-XSRF-TOKEN": cookies["XSRF-TOKEN"],
//     Cookie: cookieHeader,
//   };
// }

// async function fetchWithRetry(url, options, retry = true) {
//   try {
//     return await axios.get(url, {
//       ...options,
//       headers: buildHeaders(options.acceptType || "application/json"),
//       httpsAgent: new https.Agent({ rejectUnauthorized: false }),
//     });
//   } catch (err) {
//     if (err.response && err.response.status === 401 && retry) {
//       console.warn("🔄 Session expired. Re-authenticating...");
//       await authenticate();
//       return fetchWithRetry(url, options, false);
//     }
//     throw err;
//   }
// }

// async function updateAttachStatus(relId, status) {
//   await db.promise().query("UPDATE testlogsteps SET attach_status = ? WHERE id = ?", [status, relId]);
// }

// const TestLogStepAttachments = async (req, res) => {
//   try {
//     await authenticate();

//     if (!cookies["XSRF-TOKEN"] || !cookies["JSESSIONID"]) {
//       return res.status(401).json({ message: "Authentication with ALM failed" });
//     }

//     const [rows] = await db.promise().query(
//       "SELECT id, qtest_testlogstep_id FROM testlogsteps WHERE qtest_testlogstep_id is not NULL AND (attach_status IS NULL OR attach_status = 'failed')"
//     );

//     for (const row of rows) {
//       const relId = row.id;
//       const qtestId = row.qtest_testlogstep_id;
//       console.log("📂 Processing testlogsteps:", relId);

//       const attachUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/run-steps/${relId}/attachments`;
//       let attachResp;

//       try {
//         attachResp = await fetchWithRetry(attachUrl, {});
//       } catch (err) {
//         console.error(`❌ Failed to fetch attachments for ${relId}:`, err.message);
//         await updateAttachStatus(relId, "failed");
//         continue;
//       }

//       const entities = attachResp.data.entities;
//       if (!Array.isArray(entities) || entities.length === 0) {
//         console.log(`⚠️ No attachments for id: ${relId}`);
//         await updateAttachStatus(relId, "no_attachments");
//         continue;
//       }

//       let allSuccess = true;

//       for (const entity of entities) {
//         let attachId = null, fileName = null;
//         for (const field of entity.Fields) {
//           if (field.Name === "id") attachId = field.values[0].value;
//           else if (field.Name === "name") fileName = field.values[0].value;
//         }

//         if (!attachId || !fileName) {
//           console.error("❌ Missing attachment ID or filename");
//           continue;
//         }

//         console.log(`⬇️ Downloading attachment ${attachId} (${fileName})`);
//         const contentUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/attachments/${attachId}`;
//         const tempPath = path.join(__dirname, `temp_${attachId}_${fileName}`);

//         let contentResp;
//         try {
//           contentResp = await fetchWithRetry(contentUrl, { acceptType: "application/octet-stream" });
//         } catch (err) {
//           console.error(`❌ Failed to download attachment ${attachId}:`, err.message);
//           allSuccess = false;
//           continue;
//         }

//         const writer = fs.createWriteStream(tempPath);
//         await new Promise((resolve, reject) => {
//           contentResp.data.pipe(writer);
//           writer.on("finish", resolve);
//           writer.on("error", reject);
//         });

//         try {
//           const form = new FormData();
//           form.append("file", fs.createReadStream(tempPath), fileName);

//           const qtestResp = await axios.post(
//             `${qtestUrl}/api/v3/projects/${qtestProjectId}/test-step-logs/${qtestId}/attachments`,
//             form,
//             {
//               headers: {
//                 Authorization: `Bearer ${qtestToken}`,
//                 ...form.getHeaders(),
//               },
//               httpsAgent: new https.Agent({ rejectUnauthorized: false }),
//             }
//           );

//           if (qtestResp.status === 200 || qtestResp.status === 201) {
//             console.log(`✅ Uploaded to qTest: ${fileName}`);
//           } else {
//             console.error(`❌ Failed to upload ${fileName}, Status: ${qtestResp.status}`);
//             allSuccess = false;
//           }
//         } catch (uploadErr) {
//           console.error("❌ Upload error:", uploadErr.message);
//           allSuccess = false;
//         } finally {
//           fs.unlinkSync(tempPath);
//         }
//       }

//       await updateAttachStatus(relId, allSuccess ? "success" : "failed");
//     }

//     return res.status(200).json({ message: "Attachment sync completed" });
//   } catch (err) {
//     console.error("❌ Sync failed:", err);
//     return res.status(500).json({ message: "Internal server error", error: err.message });
//   }
// };

// module.exports = { TestLogStepAttachments };




const fs = require("fs");
const path = require("path");
const axios = require("axios");
const https = require("https");
const db = require("../../config/db");
const FormData = require("form-data");
 
const almConfig = JSON.parse(fs.readFileSync(path.join(__dirname, '../../data/AlmCredentials.json')));
const qtestConfig = JSON.parse(fs.readFileSync(path.join(__dirname, '../../data/qTestCredentials.json')));
 
const {
  almServerUrl,
  username: almUsername,
  password: almPassword,
  domain,
  project
} = almConfig;
 
const {
  qTestDomain: qtestUrl,
  projectId: qtestProjectId,
  apiToken: qtestToken
} = qtestConfig;
 
let cookies = {}; // Shared cookies
 
async function authenticate() {
  const auth = Buffer.from(`${almUsername}:${almPassword}`).toString("base64");
  const response = await axios.post(
    `${almServerUrl}/api/authentication/sign-in`,
    {},
    {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Basic ${auth}`,
      },
      withCredentials: true,
      httpsAgent: new https.Agent({ rejectUnauthorized: false }),
    }
  );
 
  const rawCookies = response.headers["set-cookie"];
  const newCookies = {};
  if (rawCookies) {
    for (const cookie of rawCookies) {
      const parts = cookie.split(";")[0].split("=");
      newCookies[parts[0]] = parts[1];
    }
  }
  cookies = newCookies;
}
 
function buildHeaders(acceptType = "application/json") {
  const cookieHeader = Object.entries(cookies).map(([k, v]) => `${k}=${v}`).join("; ");
  return {
    Accept: acceptType,
    "X-XSRF-TOKEN": cookies["XSRF-TOKEN"],
    Cookie: cookieHeader,
  };
}
 
async function fetchWithRetry(url, options, retry = true) {
  try {
    return await axios.get(url, {
      ...options,
      headers: buildHeaders(options.acceptType || "application/json"),
      httpsAgent: new https.Agent({ rejectUnauthorized: false }),
      // Add responseType for binary data
      responseType: options.acceptType === "application/octet-stream" ? "stream" : "json"
    });
  } catch (err) {
    if (err.response && err.response.status === 401 && retry) {
      console.warn("🔄 Session expired. Re-authenticating...");
      await authenticate();
      return fetchWithRetry(url, options, false);
    }
    throw err;
  }
}
 
async function updateAttachStatus(relId, status) {
  await db.promise().query("UPDATE testlogsteps SET attach_status = ? WHERE id = ?", [status, relId]);
}
 
const TestLogStepAttachments = async (req, res) => {
  try {
    await authenticate();
 
    if (!cookies["XSRF-TOKEN"] || !cookies["JSESSIONID"]) {
      return res.status(401).json({ message: "Authentication with ALM failed" });
    }
 
    const [rows] = await db.promise().query(
      "SELECT id, qtest_testlogstep_id FROM testlogsteps WHERE qtest_testlogstep_id is not NULL AND (attach_status IS NULL OR attach_status = 'failed')"
    );
 
    for (const row of rows) {
      const relId = row.id;
      const qtestId = row.qtest_testlogstep_id;
      console.log("📂 Processing testlogsteps:", relId);
 
      const attachUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/run-steps/${relId}/attachments`;
      let attachResp;
 
      try {
        attachResp = await fetchWithRetry(attachUrl, {});
      } catch (err) {
        console.error(`❌ Failed to fetch attachments for ${relId}:`, err.message);
        await updateAttachStatus(relId, "failed");
        continue;
      }
 
      const entities = attachResp.data.entities;
      if (!Array.isArray(entities) || entities.length === 0) {
        console.log(`⚠️ No attachments for id: ${relId}`);
        await updateAttachStatus(relId, "no_attachments");
        continue;
      }
 
      let allSuccess = true;
 
      for (const entity of entities) {
        let attachId = null, fileName = null;
        for (const field of entity.Fields) {
          if (field.Name === "id") attachId = field.values[0].value;
          else if (field.Name === "name") fileName = field.values[0].value;
        }
 
        if (!attachId || !fileName) {
          console.error("❌ Missing attachment ID or filename");
          continue;
        }
 
        console.log(`⬇️ Downloading attachment ${attachId} (${fileName})`);
        const contentUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/attachments/${attachId}`;
        const tempPath = path.join(__dirname, `temp_${attachId}_${fileName}`);
 
        let contentResp;
        try {
          contentResp = await fetchWithRetry(contentUrl, { acceptType: "application/octet-stream" });
        } catch (err) {
          console.error(`❌ Failed to download attachment ${attachId}:`, err.message);
          allSuccess = false;
          continue;
        }
 
        // Create write stream and pipe the response stream to it
        const writer = fs.createWriteStream(tempPath);
        await new Promise((resolve, reject) => {
          contentResp.data.pipe(writer);
          writer.on("finish", resolve);
          writer.on("error", reject);
          contentResp.data.on("error", reject);
        });
 
        try {
          const form = new FormData();
          form.append("file", fs.createReadStream(tempPath), fileName);
 
          const qtestResp = await axios.post(
            `${qtestUrl}/api/v3/projects/${qtestProjectId}/test-step-logs/${qtestId}/attachments`,
            form,
            {
              headers: {
                Authorization: `Bearer ${qtestToken}`,
                ...form.getHeaders(),
              },
              httpsAgent: new https.Agent({ rejectUnauthorized: false }),
            }
          );
 
          if (qtestResp.status === 200 || qtestResp.status === 201) {
            console.log(`✅ Uploaded to qTest: ${fileName}`);
          } else {
            console.error(`❌ Failed to upload ${fileName}, Status: ${qtestResp.status}`);
            allSuccess = false;
          }
        } catch (uploadErr) {
          console.error("❌ Upload error:", uploadErr.message);
          allSuccess = false;
        } finally {
          // Clean up temporary file
          if (fs.existsSync(tempPath)) {
            fs.unlinkSync(tempPath);
          }
        }
      }
 
      await updateAttachStatus(relId, allSuccess ? "success" : "failed");
    }
 
    return res.status(200).json({ message: "Attachment sync completed" });
  } catch (err) {
    console.error("❌ Sync failed:", err);
    return res.status(500).json({ message: "Internal server error", error: err.message });
  }
};
 
module.exports = { TestLogStepAttachments };