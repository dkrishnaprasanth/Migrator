

const fs = require("fs");
const path = require("path");
const db = require("../../config/db"); // import shared DB connection

// Load JSON file
const jsonFile = path.join(__dirname, '../../data/userdatafile/qtestusers.json');
// const rawData = fs.readFileSync(jsonFile, "utf-8");
// const userData = JSON.parse(rawData).items;

async function insertUsers() {
  const rawData = fs.readFileSync(jsonFile, "utf-8");
const userData = JSON.parse(rawData).items;
  try {
    for (const user of userData) {
      const id = user.id ?? null;
      const username = user.username ?? null;
      const email = user.email ?? null;
      const first_name = user.first_name ?? null;
      const last_name = user.last_name ?? null;
      const status = user.status ?? null;

      // 🚫 Skip if username is null/empty
      if (!username || username.trim() === "") {
        console.log(`⚠️ Skipping user with empty username (id: ${id})`);
        continue;
      }

      // Query wrapped in Promise to use async/await
      const [rows] = await new Promise((resolve, reject) => {
        db.query(
          "SELECT * FROM users WHERE LOWER(csv_email) LIKE LOWER(?)",
          [`%${username}%`],
          (err, results) => {
            if (err) return reject(err);
            resolve([results]);
          }
        );
      });

      if (rows.length > 0) {
        for (const row of rows) {
          console.log(`✅ Found partial match for DB csv_email: ${row.csv_email}, updating...`);

          await new Promise((resolve, reject) => {
            db.query(
              `UPDATE users SET 
                qtest_id = ?, 
                username = ?, 
                qtest_email = ?, 
                first_name = ?, 
                last_name = ?, 
                status = ?
              WHERE csv_email = ?`,
              [id, username, email, first_name, last_name, status, row.csv_email],
              (err) => {
                if (err) return reject(err);
                resolve();
              }
            );
          });
        }
      } else {
        console.log(`❌ No partial match for csv_email: ${username}, skipping...`);
      }
    }
  } catch (err) {
    console.error("❌ Error:", err);
  }
}

// Export function so you can call from index.js or elsewhere
module.exports = { insertUsers };



