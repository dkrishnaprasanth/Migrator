

const fs = require("fs");
const path = require("path");
const db = require("../../config/db"); // uses your db.js connection

async function main() {

  try {
    // Step 1: Load data from external JSON
    const filePath = path.join(__dirname, '../../data/userdatafile/almusers.json'); // keep your JSON file here
    const rawData = fs.readFileSync(filePath, "utf-8");
    const jsonData = JSON.parse(rawData);
    const users = jsonData[0]?.users || [];
   // const users = jsonData.users || [];

    if (users.length === 0) {
      console.log("No users found in JSON file.");
      return;
    }

    // Step 2: Create table if not exists
    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        phone VARCHAR(50),
        email VARCHAR(100),
        description TEXT,
        Name VARCHAR(100),
        FullName VARCHAR(100),
        UserActive BOOLEAN,
        userAvatarCache INT,
        userGroups VARCHAR(255),
        csv_email VARCHAR(100),
        qtest_id VARCHAR(50),
        username VARCHAR(100),
        qtest_email VARCHAR(100),
        first_name VARCHAR(100),
        last_name VARCHAR(100),
        status INT
      )
    `;
    await db.promise().query(createTableQuery);
    console.log("✅ Users table readyy");

    // Step 3: Insert users into DB
    const insertQuery = `
      INSERT INTO users 
        (phone, email, description, Name, FullName, UserActive, userAvatarCache, userGroups)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;

    for (const user of users) {
      await db.promise().query(insertQuery, [
        user.phone,
        user.email,
        user.description,
        user.Name,
        user.FullName,
        user.UserActive ? 1 : 0,
        user.userAvatarCache,
        user.userGroups,
      ]);
    }

    console.log("✅ Users inserted into database successfully");
  } catch (error) {
    console.error("❌ Error:", error);
  }
}


module.exports = {main};
