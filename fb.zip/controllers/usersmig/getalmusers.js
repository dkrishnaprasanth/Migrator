

const axios = require('axios');
const fs = require('fs');
const path = require('path');

const CONFIG_PATH = path.join(__dirname, '../../data/AlmCredentials.json');
const OUTPUT_PATH = path.join(__dirname, '../../data/userdatafile/almusers.json');

const loadConfigFromFile = (filePath) => {
    const rawData = fs.readFileSync(filePath);
    return JSON.parse(rawData);
};

const parseCookies = (cookieArray) => {
    const cookieMap = {};
    cookieArray.forEach(cookie => {
        const [cookiePair] = cookie.split(';');
        const [name, value] = cookiePair.split('=');
        cookieMap[name.trim()] = value;
    });
    return cookieMap;
};

const buildCookieHeader = ({ xsrfToken, sessionCookie, lwssoCookie, almUser, qcSession }) => {
    return `XSRF-TOKEN=${xsrfToken}; JSESSIONID=${sessionCookie}; LWSSO_COOKIE_KEY=${lwssoCookie}; ALM_USER=${almUser}; QCSession=${qcSession}`;
};

const fetchalmusers = async (customReleaseUrl = '') => {
    try {
        const config = loadConfigFromFile(CONFIG_PATH);
        const { almServerUrl, username, password, domain, project } = config;

        const loginUrl = `${almServerUrl}/api/authentication/sign-in`;
        const baseUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/customization/users`;

        const targetUrl = customReleaseUrl && customReleaseUrl.trim().length > 0
            ? `${baseUrl}${customReleaseUrl}`
            : baseUrl;

        const useAmpersand = customReleaseUrl && customReleaseUrl.trim().length > 0;
        const queryPrefix = useAmpersand ? '&' : '?';

        const authHeader = 'Basic ' + Buffer.from(`${username}:${password}`).toString('base64');

        const loginResponse = await axios.post(loginUrl, {}, {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': authHeader
            },
            withCredentials: true
        });

        const cookies = loginResponse.headers['set-cookie'] || [];
        const cookieMap = parseCookies(cookies);

        const {
            'XSRF-TOKEN': xsrfToken,
            'JSESSIONID': sessionCookie,
            'LWSSO_COOKIE_KEY': lwssoCookie,
            'ALM_USER': almUser,
            'QCSession': qcSession
        } = cookieMap;

        const cookieHeader = buildCookieHeader({ xsrfToken, sessionCookie, lwssoCookie, almUser, qcSession });

        if (!xsrfToken || !sessionCookie) {
            console.error("❌ Missing authentication tokens from ALM.");
            return;
        }

        const pageSize = 100;
        let startIndex = 1;
        let allResponses = [];

        while (true) {
            const pagedUrl = `${targetUrl}${queryPrefix}start-index=${startIndex}&page-size=${pageSize}`;
            console.log("➡️ Fetching:", pagedUrl);

            const response = await axios.get(pagedUrl, {
                headers: {
                    'Accept': 'application/json',
                    'Cookie': cookieHeader
                }
            });

            allResponses.push(response.data);

            // stop if no more entities
            const currentEntities = response.data.entities || response.data.users || [];
            if (!currentEntities || currentEntities.length === 0) break;
            if (currentEntities.length < pageSize) break;

            startIndex += pageSize;
        }

        // save everything we got (raw)
        fs.writeFileSync(OUTPUT_PATH, JSON.stringify(allResponses, null, 2), 'utf8');
        console.log(`✅ Full raw ALM users response saved to ${OUTPUT_PATH}`);

    } catch (error) {
        console.error("❌ Failed to fetch ALM users:", error.message);
        if (error.response) {
            console.error("Status:", error.response.status);
            console.error("Response:", error.response.data);
        }
        throw error;
    }
};



module.exports = { fetchalmusers };