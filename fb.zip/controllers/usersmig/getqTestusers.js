const fs = require("fs");
const path = require("path");
const axios = require("axios");

// Path to your credentials JSON file
const configPath = path.join(__dirname, '../../data/qTestCredentials.json');

// Load credentials
const config = JSON.parse(fs.readFileSync(configPath, "utf-8"));

const { qTestDomain, apiToken } = config;

// Output file
const outputPath = path.join(__dirname, '../../data/userdatafile/qtestusers.json');

async function fetchQTestUsers() {
  try {
    const url = `${qTestDomain}/api/v3/users/search`;
    const response = await axios.get(url, {
      headers: {
       // "Authorization": apiToken,
        "Authorization": `Bearer ${apiToken}`,
        "Content-Type": "application/json",
      },
    });

    // Save full response data into file
    fs.writeFileSync(outputPath, JSON.stringify(response.data, null, 2));
    console.log(`✅ Users saved to ${outputPath}`);
  } catch (err) {
    console.error("❌ Error fetching users from qTest:", err.response?.data || err.message);
  }
}



module.exports = { fetchQTestUsers };
