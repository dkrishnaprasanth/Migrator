

const fs = require("fs");
const csv = require("csv-parser");
const db = require("../../config/db");
const { Readable } = require("stream");

async function updateUsersFromCSV(csvInput) {
  try {
    const rows = [];

    // Decide if input is a file path or CSV string
    let stream;
    if (fs.existsSync(csvInput)) {
      // Input is a file path
      stream = fs.createReadStream(csvInput);
    } else {
      // Input is CSV string (buffer-based so csv-parser reads properly)
      stream = Readable.from([csvInput]);
    }

    // 1. Read CSV (from file or string)
    await new Promise((resolve, reject) => {
      stream
        .pipe(csv())
        .on("data", (row) => rows.push(row))
        .on("end", resolve)
        .on("error", reject);
    });

    console.log("📄 Parsed CSV rows:", rows);

    // 2. Loop through CSV rows
    for (const row of rows) {
      const { name, qtest_email } = row;
      if (!name || !qtest_email) {
        console.log("⚠️ Skipping invalid row:", row);
        continue;
      }

      // 3. Check if name exists
      const [results] = await new Promise((resolve, reject) => {
        db.query("SELECT id FROM users WHERE name = ?", [name], (err, results) => {
          if (err) return reject(err);
          resolve([results]);
        });
      });

      if (results.length > 0) {
        const userId = results[0].id;

        // 4. Update csv_email
        await new Promise((resolve, reject) => {
          db.query(
            "UPDATE users SET csv_email = ? WHERE id = ?",
            [qtest_email, userId],
            (err) => {
              if (err) return reject(err);
              resolve();
            }
          );
        });

        console.log(`✅ Updated user '${name}' with csv_email = '${qtest_email}'`);
      } else {
        console.log(`⚠️ No match found in DB for name: ${name}`);
      }
    }
  } catch (err) {
    console.error("❌ Error:", err);
  }
}

module.exports = { updateUsersFromCSV };
