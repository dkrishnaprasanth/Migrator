const fs = require('fs');
const path = require('path');
const axios = require('axios');

// Load config from qTestCredentials.json
const loadConfigFromFile = (filePath) => {
  try {
    if (!fs.existsSync(filePath)) {
      throw new Error(`Configuration file not found at ${filePath}`);
    }
    const rawData = fs.readFileSync(filePath, 'utf8');
    return JSON.parse(rawData);
  } catch (error) {
    console.error(`❌ Error loading config from ${filePath}:`, error.message);
    throw error;
  }
};

// Save API response to file (using promises)
const saveToFile = (fileName, data) => {
  return new Promise((resolve, reject) => {
    // Ensure directory exists
    const dir = path.dirname(fileName);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    
    fs.writeFile(fileName, data, 'utf8', (err) => {
      if (err) {
        console.error(`❌ Error writing to file: ${fileName}`, err);
        reject(err);
      } else {
        console.log(`✅ Data successfully saved to ${fileName}`);
        resolve(true);
      }
    });
  });
};

// Main function with proper async/await and error handling
const fetchqTestReleasesFields = async () => {
  const configPath = path.join(__dirname, '../../data/qTestCredentials.json');
  const outputPath = path.join(__dirname, '../../data/Defectsdatafile/qTestDefectsFields.json');
  
  try {
    // Load configuration
    const config = loadConfigFromFile(configPath);
    const { qTestDomain, apiToken, projectId } = config;
    
    if (!qTestDomain || !apiToken || !projectId) {
      throw new Error("Missing required configuration values");
    }
    
    const url = `${qTestDomain}/api/v3/projects/${projectId}/settings/defects/fields`;
    
    // Make API request
    console.log(`📡 Fetching data from ${url}`);
    const response = await axios.get(url, {
      headers: {
        Authorization: `Bearer ${apiToken}`
      }
    });
    
    // Validate response
    if (response.status !== 200) {
      throw new Error(`Failed to retrieve data. HTTP Status: ${response.status}`);
    }
    
    const data = response.data;
    if (!data || (Array.isArray(data) && data.length === 0)) {
      console.warn("⚠️ API returned empty data");
    }
    
    // Save data to file
    await saveToFile(outputPath, JSON.stringify(data, null, 2));
    
    return { 
      success: true, 
      message: "qTest data fetched and saved to JSON file.",
      data: data 
    };
  } catch (error) {
    console.error("❌ Error occurred while fetching qTest defects fields:", error.message);
    return {
      success: false,
      message: `Failed to fetch qTest data: ${error.message}`
    };
  }
};

// API endpoint handler
const qtestReleasesField = async (req, res) => {
  try {
    const result = await fetchqTestReleasesFields();
    return res.status(result.success ? 200 : 400).json(result);
  } catch (error) {
    console.error("❌ Error in qtestdefectField endpoint:", error.message);
    return res.status(500).json({ 
      success: false, 
      message: `Server error: ${error.message}` 
    });
  }
};

module.exports = {
  fetchqTestReleasesFields,
  qtestReleasesField
};