
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const db = require("../../config/db");

const formatDateForQTest = (date) => {
  if (!date || isNaN(date.getTime())) return null;

  const year = date.getUTCFullYear();
  const month = String(date.getUTCMonth() + 1).padStart(2, '0');
  const day = String(date.getUTCDate()).padStart(2, '0');

  return `${year}-${month}-${day}T00:00:00+00:00`;
};

const insertSampleDataInDefects = async (req, res) => {
  try {
    console.log("🚀 Starting insertSampleDataInDefects function");

    const [columns] = await db.promise().query(
      "SELECT ep1_name, ep1_type, ep2_field_id FROM Field_mappings WHERE artifact_type='Defects' "
    );

    if (!columns || columns.length === 0) {
      console.log("❌ No mapping columns found");
      return res.status(400).json({
        success: false,
        message: "No mapping columns found. Please create mappings first."
      });
    }

    const jsonFilePath = path.join(__dirname, '../../data/Defectsdatafile/ALMDefects.json');
    console.log("📁 JSON file path:", jsonFilePath);

    if (!fs.existsSync(jsonFilePath)) {
      console.log("❌ JSON file not found");
      return res.status(404).json({
        success: false,
        message: `JSON file not found at: ${jsonFilePath}`
      });
    }

    const jsonData = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'));
    console.log("📊 JSON data loaded, entities count:", jsonData.entities?.length || 0);

    const [tableInfo] = await db.promise().query("DESCRIBE defects");
    const tableColumns = tableInfo.map(column => column.Field);
    console.log("🗂️ Table columns:", tableColumns);

    const mappingColumns = columns.map(col =>
      col.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase()
    );

    const requiredColumns = ['has_link', 'has_attachment', 'parent_id', 'last_modified', 'qtest_defects_id', 'upload_status', 'attach_status', 'comments', 'comment_Id '];

    const allColumns = [...new Set([...mappingColumns, ...requiredColumns])].filter(
      col => tableColumns.includes(col)
    );

    console.log("📋 Columns for insertion:", allColumns);

    const [existingRows] = await db.promise().query("SELECT id, last_modified, upload_status FROM defects");
    const existingMap = new Map();
    for (const row of existingRows) {
      existingMap.set(String(row.id), row);
    }

    let insertCount = 0;
    let updateCount = 0;
    let skipCount = 0;

    for (const entity of jsonData.entities) {
      const rowData = {};

      const id = entity.Fields.find(f => f.Name === 'id')?.values?.[0]?.value;
      const lastModified = entity.Fields.find(f => f.Name === 'last-modified')?.values?.[0]?.value;

      if (!id) continue;

      // Process mapped fields
      for (const column of columns) {
        const columnName = column.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
        if (!tableColumns.includes(columnName)) continue;

        const matchingField = entity.Fields.find(field =>
          field.Name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase() === columnName
        );

        if (!matchingField || !matchingField.values?.length) {
          rowData[columnName] = null;
        } else {
          const combinedValue = matchingField.values.map(v => v.value).join(',');

          switch (column.ep1_type) {
            case 'Number':
              rowData[columnName] = isNaN(Number(combinedValue)) ? null : Number(combinedValue);
              break;
            case 'Date':
              rowData[columnName] = formatDateForQTest(new Date(combinedValue));
              break;
            default:
              rowData[columnName] = combinedValue;
          }
        }
      }

      // Required fields
      if (tableColumns.includes('has_link')) {
        rowData['has_link'] = entity.Fields.find(f => f.Name === 'has-linkage')?.values?.[0]?.value || null;
      }
      if (tableColumns.includes('has_attachment')) {
        rowData['has_attachment'] = entity.Fields.find(f => f.Name === 'attachment')?.values?.[0]?.value || null;
      }
      if (tableColumns.includes('parent_id')) {
        rowData['parent_id'] = entity.Fields.find(f => f.Name === 'parent-id')?.values?.[0]?.value || null;
      }
      if (tableColumns.includes('last_modified')) {
        rowData['last_modified'] = lastModified || null;
      }
      if (tableColumns.includes('comments')) {
        rowData['comments'] = entity.Fields.find(f => f.Name === 'dev-comments')?.values?.[0]?.value || null;
      }
      if (tableColumns.includes('comment_Id ')) {
        rowData['comment_Id '] = 'null';
      }

      const [existingDefectRows] = await db.promise().query("SELECT * FROM defects WHERE id = ?", [id]);
      const existing = existingDefectRows[0];

      if (!existing) {
        // INSERT
        rowData['qtest_defects_id'] = null;
        rowData['upload_status'] = 'pending';

        const insertColumns = Object.keys(rowData).filter(col => tableColumns.includes(col));
        const insertValues = insertColumns.map(col => rowData[col] ?? null);
        const insertSQL = `INSERT INTO defects (${insertColumns.map(col => `\`${col}\``).join(', ')}) VALUES (${insertColumns.map(() => '?').join(', ')})`;
        await db.promise().query(insertSQL, insertValues);
        insertCount++;
      } else {
        const existingTime = new Date(existing.last_modified).getTime();
        const incomingTime = new Date(lastModified).getTime();

        if (existingTime !== incomingTime) {
          // UPDATE
          const updateColumns = Object.keys(rowData).filter(col => col !== 'qtest_defects_id');
          const updateValues = updateColumns.map(col => rowData[col] ?? null);
          updateValues.push(id);

          const updateSQL = `UPDATE defects SET ${updateColumns.map(col => `\`${col}\` = ?`).join(', ')} WHERE id = ?`;
          await db.promise().query(updateSQL, updateValues);
          updateCount++;

          if (['completed', 'uploaded'].includes(existing.upload_status)) {
            const newStatus = existing.qtest_defects_id ? 'modified' : 'changed';
            await db.promise().query("UPDATE defects SET upload_status = ? WHERE id = ?", [newStatus, id]);
          }
        } else {
          skipCount++;
        }
      }
    }

    const totalProcessed = insertCount + updateCount + skipCount;

    console.log(`🎉 Data insertion completed. Inserted: ${insertCount}, Updated: ${updateCount}, Skipped: ${skipCount}`);

    res.status(200).json({
      success: true,
      message: "Releases processed successfully",
      details: {
        inserted: insertCount,
        updated: updateCount,
        skipped: skipCount,
        totalProcessed: totalProcessed
      },
      totalCount: totalProcessed
    });

  } catch (error) {
    console.error('❌ Error inserting data:', error);
    res.status(500).json({
      success: false,
      message: `Error inserting data: ${error.message}`,
      error: error.stack
    });
  }
};


let credentials;
try {
  credentials = require("../../data/qTestCredentials.json");
} catch (error) {
  credentials = null;
}

// Global variable to store migration statistics
let uploadStats = {
  total: 0,
  success: 0,
  failed: 0,
  skipped: 0,
  updated: 0,
  pending: 0,
  inProgress: false,
  startTime: null,
  endTime: null
};

const uploadDefectsToQTest = async (payload, defectId, defectName, qtestDefectId = null, status = null) => {
  try {
    if (!credentials) {
      throw new Error("qTest credentials not loaded");
    }

    // ✅ Skip if already completed
    if (status === 'completed') {
      console.log(`⏭️ Skipping defect ${defectName} (ID: ${defectId}) - Already completed`);
      uploadStats.skipped++;
      uploadStats.pending--;
      return { success: true, skipped: true };
    }

    // ✅ Determine method
    const method = (status === 'modified' && qtestDefectId)
      ? 'PUT'
      : 'POST';

    const url = method === 'POST'
      ? `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/defects`
      : `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/defects/${qtestDefectId}`;

    console.log(`${method === 'POST' ? '📤 Creating' : '✏️ Updating'} defect: ${defectName} (ID: ${defectId})`);

    const response = await axios({
      method,
      url,
      data: payload,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${credentials.apiToken}`,
      },
    });

    // if (response.status === 200 || response.status === 201) {
    //   await db
    //     .promise()
    //     .query(
    //       "UPDATE defects SET upload_status = ?, qtest_defects_id = ? WHERE id = ?",
    //       ["completed", response.data.id, defectId]
    //     );

    //   uploadStats.success++;
    //   uploadStats.pending--;

    // if(isUpdate){
    //   uploadStats.updated++;
    // }else{
    //   uploadStats.success++;
    // }
    // uploadStats.pending--;

    //   console.log(`✅ ${method === 'POST' ? 'Created' : 'Updated'}: ${defectName} → qTest ID: ${response.data.id}`);
    //   return { success: true, qTestId: response.data.id };
    // }
    if (response.status === 200 || response.status === 201) {
      await db.promise().query(
        "UPDATE defects SET upload_status = ?, qtest_defects_id = ? WHERE id = ?",
        ["completed", response.data.id, defectId]
      );

      if (method === 'PUT') {
        uploadStats.updated++;
      } else {
        uploadStats.success++;
      }
      uploadStats.pending--;

      console.log(`✅ ${method === 'POST' ? 'Created' : 'Updated'}: ${defectName} → qTest ID: ${response.data.id}`);
      return { success: true, qTestId: response.data.id };
    }
    else {
      const errorStatus = `failed_${response.status}`;
      await db
        .promise()
        .query("UPDATE defects SET upload_status = ? WHERE id = ?", [
          errorStatus,
          defectId,
        ]);

      uploadStats.failed++;
      uploadStats.pending--;

      console.log(`❌ Upload failed for ${defectName}: HTTP ${response.status}`);
      return { success: false, error: `HTTP Status: ${response.status}` };
    }

  } catch (error) {
    const statusCode = error.response?.status || "network_error";
    const errorMessage = error.response?.data?.message || error.message || "Unknown error";

    const errorStatus = `failed_${statusCode}`;
    try {
      await db
        .promise()
        .query("UPDATE defects SET upload_status = ? WHERE id = ?", [
          errorStatus,
          defectId,
        ]);
    } catch (dbError) {
      console.error(`❌ DB error while marking failed: ${defectName} →`, dbError.message);
    }

    uploadStats.failed++;
    uploadStats.pending--;

    console.log(`❌ Upload error for ${defectName}: ${errorMessage}`);
    return { success: false, error: errorMessage };
  }
};



const getRequiredFieldsFromQTest = async () => {
  try {
    if (!credentials) {
      throw new Error("qTest credentials not loaded");
    }

    const response = await axios.get(
      `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/settings/defects/fields`,
      {
        headers: {
          Authorization: `Bearer ${credentials.apiToken}`,
        },
      }
    );

    if (response.status === 200) {
      const requiredFields = response.data.filter(field => field.required === true);
      console.log(`🔍 Found ${requiredFields.length} required fields in qTest`);
      return requiredFields;
    }
    return [];
  } catch (error) {
    console.error("❌ Error fetching required fields:", error.message);
    return [];
  }
};

// **FIXED: Improved handling of required fields with proper value mapping**
const processDefectsAsync = async (defectRows, mappings, qtestDefects) => {
  let counter = 1;

  try {
    // **FIXED: Get required fields from qTest**
    const requiredFields = await getRequiredFieldsFromQTest();
    console.log("📋 Required fields from qTest:", requiredFields.map(f => `${f.label} (${f.id})`));

    for (let row of defectRows) {
      console.log(`🔄 Processing Defect ${counter}/${uploadStats.total}: ${row.name}`);


      // Pre-check: Get existing defect info from DB
      const [existingDefect] = await db.promise().query(
        "SELECT id, last_modified, qtest_defects_id FROM defects WHERE id = ?",
        [row.id]
      );

      if (existingDefect.length > 0) {
        const existing = existingDefect[0];

        if (existing.last_modified === row.last_modified) {
          console.log(`⏭️ Skipping defect ${row.name} (ID: ${row.id}) - No changes detected`);
          uploadStats.skipped++;
          uploadStats.pending--;
          continue; // Skip processing
        }

        // If last_modified changed
        // let newStatus = 'changed';
        // if (existing.qtest_defects_id) {
        //   newStatus = 'modified';
        // }

        // // Update record without modifying id, qtest_defects_id, comment_id
        // const updateFields = { ...row };
        // delete updateFields.id;
        // delete updateFields.qtest_defects_id;
        // delete updateFields.comment_id;

        // const setClause = Object.keys(updateFields)
        //   .map(col => `${col} = ?`)
        //   .join(", ");
        // const values = Object.values(updateFields);

        // await db.promise().query(
        //   `UPDATE defects SET ${setClause}, upload_status = ? WHERE id = ?`,
        //   [...values, newStatus, row.id]
        // );

        // console.log(`🔄 Updated defect ${row.name} (ID: ${row.id}) - Status: ${newStatus}`);


        // If last_modified changed
        let newStatus = existing.qtest_defects_id ? 'modified' : 'changed';

        // Update record without modifying id, qtest_defects_id, comment_id
        const updateFields = { ...row };
        delete updateFields.id;
        delete updateFields.qtest_defects_id;
        delete updateFields.comment_id;

        const setClause = Object.keys(updateFields)
          .map(col => `${col} = ?`)
          .join(", ");
        const values = Object.values(updateFields);

        await db.promise().query(
          `UPDATE defects SET ${setClause}, upload_status = ? WHERE id = ?`,
          [...values, newStatus, row.id]
        );

        console.log(`🔄 Updated defect ${row.name} (ID: ${row.id}) - Status: ${newStatus}`);



      } else {
        // Insert new record (don't insert id, let it be auto)
        const insertFields = { ...row };
        delete insertFields.id;

        const columns = Object.keys(insertFields).join(", ");
        const placeholders = Object.keys(insertFields).map(() => "?").join(", ");
        const values = Object.values(insertFields);

        await db.promise().query(
          `INSERT INTO defects (${columns}) VALUES (${placeholders})`,
          values
        );

        console.log(`🆕 Inserted new defect ${row.name} (ID: ${row.id})`);
      }



      const properties = [];
      const addedFieldIds = new Set(); // Track which fields we've already added

      // **FIXED: First process all mapped fields (including required ones)**
      for (let mapping of mappings) {
        const columnName = mapping.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
        const rawValue = row[columnName];

        console.log(`🔍 Processing field: ${mapping.ep1_name} (${columnName}) = ${rawValue} (type: ${mapping.ep1_type})`);

        let fieldValue = null;
        let fieldValueName = null;

        // Handle non-empty values
        if (rawValue !== null && rawValue !== undefined && rawValue !== '') {
          // Handle LookupList fields (including Priority, Status, Severity)
          if (mapping.ep1_type === "LookupList") {
            const valuesToCheck = typeof rawValue === 'string' ? rawValue.split(',').map(v => v.trim()) : [rawValue];

            const [valueMappings] = await db.promise().query(`
              SELECT ep1_value, ep2_value_id, ep2_value
              FROM value_mappings
              WHERE ep1_name = ? AND ep2_field_id = ?
            `, [mapping.ep1_name, mapping.ep2_field_id]);

            console.log(`🔎 Found ${valueMappings.length} value mappings for ${mapping.ep1_name}`);

            valuesToCheck.forEach(value => {
              const match = valueMappings.find(vm => vm.ep1_value === value);
              if (match) {
                fieldValue = match.ep2_value_id;
                fieldValueName = match.ep2_value;
                console.log(`✅ Matched value: ${value} -> ${match.ep2_value_id} (${match.ep2_value})`);
              } else {
                console.log(`❌ No match found for value: ${value}`);
              }
            });
          }
          // Handle UsersList
          // else if (mapping.ep1_type === "UsersList") {
          //   const valuesToCheck = typeof rawValue === 'string' ? rawValue.split(',').map(v => v.trim()) : [rawValue];

          //   const [valueMappings] = await db.promise().query(`
          //     SELECT ep1_value, ep2_value_id, ep2_value
          //     FROM value_mappings
          //     WHERE ep1_name = ? AND ep2_field_id = ?
          //   `, [mapping.ep1_name, mapping.ep2_field_id]);

          //   const matchedEp2Ids = [];
          //   const matchedEp2Names = [];

          //   valuesToCheck.forEach(value => {
          //     const match = valueMappings.find(vm => vm.ep1_value === value);
          //     if (match) {
          //       matchedEp2Ids.push(match.ep2_value_id);
          //       matchedEp2Names.push(match.ep2_value);
          //     }
          //   });

          //   if (matchedEp2Ids.length > 0) {
          //     fieldValue = JSON.stringify(matchedEp2Ids);
          //     fieldValueName = JSON.stringify(matchedEp2Names);
          //   }
          // }

          else if (mapping.ep1_type === "UsersList") {
            const valuesToCheck = typeof rawValue === 'string'
              ? rawValue.split(',').map(v => v.trim())
              : [rawValue];

            for (const value of valuesToCheck) {
              // Query users table to match the Name column
              const [userMatch] = await db.promise().query(`
      SELECT qtest_id, first_name 
      FROM users 
      WHERE Name = ?
      LIMIT 1
    `, [value]);

              if (userMatch.length > 0) {
                const { qtest_id, first_name } = userMatch[0];

                properties.push({
                  field_id: mapping.ep2_field_id,
                  field_name: mapping.ep2_label,
                  field_value: qtest_id,
                  field_value_name: first_name
                });

                console.log(`✅ Matched user: ${value} -> ${qtest_id} (${first_name})`);
              } else {
                console.log(`❌ No match found in users table for: ${value}`);
              }
            }
          }

          // Handle other field types
          else {
            if (mapping.ep1_type === 'Number') {
              fieldValue = isNaN(Number(rawValue)) ? null : Number(rawValue);
            } else if (mapping.ep1_type === 'Date') {
              const parsedDate = new Date(rawValue);
              fieldValue = formatDateForQTest(parsedDate);
            } else if (mapping.ep1_type === 'String') {
              fieldValue = String(rawValue).trim();
            } else {
              fieldValue = rawValue;
            }
          }
        }

        // **FIXED: For required fields, provide proper defaults if no value found**
        const isRequiredField = requiredFields.find(rf => rf.id === mapping.ep2_field_id);
        if (isRequiredField && (fieldValue === null || fieldValue === undefined || fieldValue === '')) {
          console.log(`⚠️ Setting default value for required field: ${mapping.ep2_label}`);

          // **FIXED: For LookupList fields, use the first available mapping as default**
          if (mapping.ep1_type === "LookupList") {
            const [firstMapping] = await db.promise().query(`
              SELECT ep2_value_id, ep2_value
              FROM value_mappings
              WHERE ep2_field_id = ?
              LIMIT 1
            `, [mapping.ep2_field_id]);

            if (firstMapping.length > 0) {
              fieldValue = firstMapping[0].ep2_value_id;
              fieldValueName = firstMapping[0].ep2_value;
              console.log(`🔧 Using first mapped value for ${mapping.ep2_label}: ${fieldValue} (${fieldValueName})`);
            } else if (isRequiredField.allowed_values && isRequiredField.allowed_values.length > 0) {
              // Fallback to qTest's allowed values
              fieldValue = isRequiredField.allowed_values[0].value;
              fieldValueName = isRequiredField.allowed_values[0].label;
              console.log(`🔧 Using first qTest allowed value for ${mapping.ep2_label}: ${fieldValue} (${fieldValueName})`);
            }
          } else if (mapping.ep1_type === 'UsersList') {
            if (isRequiredField.allowed_values && isRequiredField.allowed_values.length > 0) {
              fieldValue = JSON.stringify([isRequiredField.allowed_values[0].value]);
              fieldValueName = JSON.stringify([isRequiredField.allowed_values[0].label]);
            }
          } else if (mapping.ep1_type === 'TextBox' || mapping.ep1_type === 'RichTextBox') {
            fieldValue = `Default ${mapping.ep2_label}`;
          } else if (mapping.ep1_type === 'Date') {
            fieldValue = formatDateForQTest(new Date());
          } else if (mapping.ep1_type === 'Number') {
            fieldValue = 0;
          } else {
            fieldValue = `Default ${mapping.ep2_label}`;
          }
        }

        // Add field if we have a value
        if (fieldValue !== null && fieldValue !== undefined && fieldValue !== '') {
          const propertyToAdd = {
            field_id: mapping.ep2_field_id,
            field_name: mapping.ep2_label,
            field_value: fieldValue
          };

          if (fieldValueName) {
            propertyToAdd.field_value_name = fieldValueName;
          }

          properties.push(propertyToAdd);
          addedFieldIds.add(mapping.ep2_field_id);
          console.log(`✅ Added field: ${mapping.ep2_label} = ${fieldValue}`);
        }
      }

      // **FIXED: Handle remaining required fields that weren't mapped**
      // for (let requiredField of requiredFields) {
      //   if (!addedFieldIds.has(requiredField.id)) {
      //     console.log(`⚠️ Adding unmapped required field: ${requiredField.label}`);

      //     let fieldValue = null;
      //     let fieldValueName = null;

      //     if (requiredField.field_type === 'LookupList' && requiredField.allowed_values && requiredField.allowed_values.length > 0) {
      //       fieldValue = requiredField.allowed_values[0].value;
      //       fieldValueName = requiredField.allowed_values[0].label;
      //     } else if (requiredField.field_type === 'UsersList' && requiredField.allowed_values && requiredField.allowed_values.length > 0) {
      //       fieldValue = JSON.stringify([requiredField.allowed_values[0].value]);
      //       fieldValueName = JSON.stringify([requiredField.allowed_values[0].label]);
      //     } else if (requiredField.field_type === 'TextBox' || requiredField.field_type === 'RichTextBox') {
      //       fieldValue = `Default ${requiredField.label}`;
      //     } else if (requiredField.field_type === 'Date') {
      //       fieldValue = formatDateForQTest(new Date());
      //     } else if (requiredField.field_type === 'Number') {
      //       fieldValue = 0;
      //     } else {
      //       fieldValue = `Default ${requiredField.label}`;
      //     }

      //     const propertyToAdd = {
      //       field_id: requiredField.id,
      //       field_name: requiredField.label,
      //       field_value: fieldValue
      //     };

      //     if (fieldValueName) {
      //       propertyToAdd.field_value_name = fieldValueName;
      //     }

      //     properties.push(propertyToAdd);
      //     console.log(`✅ Added unmapped required field: ${requiredField.label} = ${fieldValue}`);
      //   }
      // }

      console.log(`📊 Total properties created: ${properties.length}`);

      // **FIXED: Include name and ensure all required fields are present**
      const singlePayload = {
        name: row.name,
        properties: properties
      };

      console.log(`📋 Final payload:`, JSON.stringify(singlePayload, null, 2));

      // Save payload for debugging
      const outputPath = path.join(__dirname, `../../data/Defectsdatafile/DefectsfinalPayload.json`);
      fs.writeFileSync(outputPath, JSON.stringify(singlePayload, null, 2), "utf8");

      //const uploadResult = await uploadDefectsToQTest(singlePayload, row.id, row.name);

      const uploadResult = await uploadDefectsToQTest(
        singlePayload,
        row.id,
        row.name,
        row.qtest_defects_id,
        row.upload_status
      );


      if (!uploadResult.success) {
        console.error(`❌ Upload failed for Defect ${row.name}: ${uploadResult.error}`);
      } else {
        console.log(`✅ Successfully uploaded Defect ${row.name} with ID ${uploadResult.qTestId}`);
      }

      counter++;

      // Add small delay to prevent overwhelming the API
      await new Promise(resolve => setTimeout(resolve, 1000));
    }

  } catch (error) {
    console.error("❌ Error in async processing:", error.message);
  } finally {
    uploadStats.inProgress = false;
    uploadStats.endTime = new Date();
  }
};




const processAndUploadAllDefects = async (req) => {
  try {
    console.log("🚀 Starting processAndUploadAllDefects function");

    if (uploadStats.inProgress) {
      return {
        success: false,
        status: 409,
        message: "Migration is already in progress",
        counts: uploadStats
      };
    }

    uploadStats = {
      total: 0,
      success: 0,
      failed: 0,
      skipped: 0,
      updated: 0,
      pending: 0,
      inProgress: true,
      startTime: new Date(),
      endTime: null
    };

    if (!credentials) {
      uploadStats.inProgress = false;
      return {
        success: false,
        status: 500,
        message: "qTest credentials not available",
        counts: uploadStats
      };
    }

    const [mappingRow] = await db
      .promise()
      .query("SELECT DISTINCT link_name FROM Field_mappings WHERE artifact_type='Defects'");

    const currentTable = mappingRow.length > 0 ? mappingRow[0].link_name : null;
    if (!currentTable) {
      uploadStats.inProgress = false;
      throw new Error("No active mapping table found.");
    }

    const [mappings] = await db
      .promise()
      .query(
        "SELECT ep1_name, ep1_type, ep2_label, ep2_field_id FROM Field_mappings WHERE artifact_type = 'Defects' AND link_name = ?",
        [currentTable]
      );

    const [qtestDefects] = await db.promise().query("SELECT * FROM qtest_defects");
    // const [defectRows] = await db.promise().query(
    //   "SELECT * FROM defects WHERE upload_status IS NULL OR upload_status = 'pending' OR upload_status LIKE 'failed%'"
    // );/
    const [defectRows] = await db.promise().query(
      "SELECT * FROM defects WHERE upload_status IS NULL OR upload_status = 'pending' OR upload_status LIKE 'failed%' OR upload_status = 'modified' OR upload_status = 'completed' OR upload_status = 'changed'"
    );


    uploadStats.total = defectRows.length;
    uploadStats.pending = defectRows.length;

    if (uploadStats.total === 0) {
      uploadStats.inProgress = false;
      uploadStats.endTime = new Date();
      return {
        success: true,
        status: 200,
        message: "No defects found to upload",
        counts: uploadStats
      };
    }

    // Start async processing
    await processDefectsAsync(defectRows, mappings, qtestDefects);

    return {
      success: true,
      status: 202,
      message: "Migration started successfully",
      counts: uploadStats
    };

  } catch (error) {
    console.error("❌ Error starting defect processing:", error.message);
    uploadStats.inProgress = false;
    uploadStats.endTime = new Date();
    return {
      success: false,
      status: 500,
      message: "Migration failed to start",
      error: error.message,
      counts: uploadStats
    };
  }
};

// const processAndUploadAllDefects = async (req, res) => {
//   try {
//     console.log("🚀 Starting processAndUploadAllDefects function");

//     if (uploadStats.inProgress) {
//       return res.status(409).json({
//         success: false,
//         message: "Migration is already in progress",
//         counts: uploadStats
//       });
//     }

//     uploadStats = {
//       total: 0,
//       success: 0,
//       failed: 0,
//       skipped: 0,
//       pending: 0,
//       inProgress: true,
//       startTime: new Date(),
//       endTime: null
//     };

//     if (!credentials) {
//       uploadStats.inProgress = false;
//       return res.status(500).json({
//         success: false,
//         message: "qTest credentials not available",
//         counts: uploadStats
//       });
//     }

//     // **UPDATED: Get mappings similar to requirements**
//     const [mappingRow] = await db
//       .promise()
//       .query("SELECT DISTINCT link_name FROM Field_mappings WHERE artifact_type='Defects'");

//     const currentTable = mappingRow.length > 0 ? mappingRow[0].link_name : null;
//     if (!currentTable) {
//       uploadStats.inProgress = false;
//       throw new Error("No active mapping table found.");
//     }

//     console.log("📋 Current mapping table:", currentTable);

//     // **UPDATED: Use artifact_type = 'Defects' (not 'Defect')**
//     const [mappings] = await db
//       .promise()
//       .query(
//         "SELECT ep1_name, ep1_type, ep2_label, ep2_field_id FROM Field_mappings WHERE artifact_type = 'Defects' AND link_name = ?",
//         [currentTable]
//       );

//     console.log(`Found ${mappings.length} field mappings for Defects`);

//     const [qtestDefects] = await db.promise().query("SELECT * FROM qtest_defects");
//     console.log("🔍 qTest defects lookup data:", qtestDefects.length);

//     const [defectRows] = await db.promise().query(
//       "SELECT * FROM defects WHERE upload_status IS NULL OR upload_status = 'pending' OR upload_status LIKE 'failed%'"
//     );

//     uploadStats.total = defectRows.length;
//     uploadStats.pending = defectRows.length;

//     console.log(`📊 Found ${uploadStats.total} defects to process`);

//     if (uploadStats.total === 0) {
//       uploadStats.inProgress = false;
//       uploadStats.endTime = new Date();
//       return res.status(200).json({
//         success: true,
//         message: "No defects found to upload",
//         counts: uploadStats,
//       });
//     }

//     // Start async processing
//     processDefectsAsync(defectRows, mappings, qtestDefects);

//     res.status(202).json({
//       success: true,
//       message: "Migration started successfully",
//       counts: uploadStats,
//     });

//   } catch (error) {
//     console.error("❌ Error starting defect processing:", error.message);
//     uploadStats.inProgress = false;
//     uploadStats.endTime = new Date();

//     if (!res.headersSent) {
//       res.status(500).json({
//         success: false,
//         message: "Migration failed to start",
//         error: error.message,
//         counts: uploadStats
//       });
//     }
//   }
// };

// const getMigrationStatusInDefects = async (req, res) => {
//   try {
//     const [totalCount] = await db.promise().query("SELECT COUNT(*) as count FROM defects");
//     const [completedCount] = await db.promise().query("SELECT COUNT(*) as count FROM defects WHERE upload_status = 'completed'");
//     const [failedCount] = await db.promise().query("SELECT COUNT(*) as count FROM defects WHERE upload_status LIKE 'failed%'");
//     const [pendingCount] = await db.promise().query("SELECT COUNT(*) as count FROM defects WHERE upload_status IS NULL OR upload_status = 'pending'");

//     const dbStats = {
//       total: totalCount[0].count,
//       success: completedCount[0].count,
//       failed: failedCount[0].count,
//       pending: pendingCount[0].count
//     };

//     res.json({
//       counts: {
//         total: dbStats.total,
//         success: dbStats.success,
//         failed: dbStats.failed,
//         pending: dbStats.pending
//       },
//       inProgress: uploadStats.inProgress,
//       duration: uploadStats.startTime && uploadStats.endTime ?
//         Math.round((uploadStats.endTime - uploadStats.startTime) / 1000) : null
//     });

//   } catch (error) {
//     console.error("❌ Error getting migration status:", error);
//     res.status(500).json({
//       error: "Failed to get migration status",
//       counts: uploadStats
//     });
//   }
// };

const getMigrationStatusInDefects = async (req, res) => {
  try {
    res.json({
      counts: {
        total: uploadStats.total,
        success: uploadStats.success,
        failed: uploadStats.failed,
        pending: uploadStats.pending,
        skipped: uploadStats.skipped,
        updated: uploadStats.updated
      },
      inProgress: uploadStats.inProgress,
      duration: uploadStats.startTime && uploadStats.endTime
        ? Math.round((uploadStats.endTime - uploadStats.startTime) / 1000)
        : null
    });
  } catch (error) {
    console.error("❌ Error getting migration status:", error);
    res.status(500).json({
      error: "Failed to get migration status",
      counts: uploadStats
    });
  }
};

const getDefectsCount = async (req, res) => {
  try {
    const jsonFilePath = path.join(__dirname, "../../data/Defectsdatafile/ALMDefects.json");

    if (!fs.existsSync(jsonFilePath)) {
      return res.status(404).json({ success: false, message: "Defects JSON not found" });
    }

    const jsonData = JSON.parse(fs.readFileSync(jsonFilePath, "utf8"));
    const totalCount = jsonData.entities?.length || 0;

    res.json({ totalCount });
  } catch (error) {
    console.error("❌ Error in getDefectsCount:", error);
    res.status(500).json({ error: "Failed to fetch defects count" });
  }
};

module.exports = {
  insertSampleDataInDefects,
  processAndUploadAllDefects,
  getMigrationStatusInDefects,
  getDefectsCount
};
