// controllers/Filter.js
const fs = require("fs");
const path = require("path");
const db = require('../../config/db');

// ✅ Create Filter table automatically
const createFilterTable = async () => {
  try {
    const createQuery = `
      CREATE TABLE IF NOT EXISTS Filter (
        id INT AUTO_INCREMENT PRIMARY KEY,
        filter TEXT NOT NULL,
        artifact_type VARCHAR(100) NOT NULL,
        link_name VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `;
    await db.promise().query(createQuery);
    console.log("✅ Filter table verified/created.");
  } catch (err) {
    console.error("❌ Error creating Filter table:", err);
  }
};

// ✅ Save Filter (POST)
const saveFilter = async (req, res) => {
  const { filter, artifact_type, link_name } = req.body;

  if (!filter || !artifact_type || !link_name) {
    return res.status(400).json({ error: "All fields are required" });
  }

  try {
    // ✅ Automatically create table when user sends filter input
    await createFilterTable();

    await db.promise().query(
      "INSERT INTO Filter (filter, artifact_type, link_name) VALUES (?, ?, ?)",
      [filter, artifact_type, link_name]
    );

    res.status(200).json({ message: "Filter saved successfully" });
  } catch (err) {
    console.error("❌ Error saving filter:", err);
    res.status(500).json({ error: "Failed to save filter" });
  }
};


// ✅ Get all filters (GET)
const getAllFilters = async (req, res) => {
  try {
    const [filters] = await db.promise().query("SELECT * FROM Filter");
    res.status(200).json(filters);
  } catch (err) {
    console.error("❌ Error fetching filters:", err);
    res.status(500).json({ error: "Failed to fetch filters" });
  }
};

// ✅ Get filters by link name (GET)
const getFiltersByLink = async (req, res) => {
  const { link_name } = req.params;

  try {
    const [filters] = await db.promise().query(
      "SELECT * FROM Filter WHERE link_name = ?",
      [link_name]
    );
    res.status(200).json(filters);
  } catch (err) {
    console.error("❌ Error fetching filters for link:", err);
    res.status(500).json({ error: "Failed to fetch filters" });
  }
};


module.exports = {
createFilterTable,
  saveFilter,
  getAllFilters,
  getFiltersByLink
};


