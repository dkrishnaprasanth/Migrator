const axios = require('axios');
const fs = require('fs');
const path = require('path');

// Paths
const CONFIG_PATH = path.join(__dirname, '../../data/AlmCredentials.json');
const OUTPUT_PATH = path.join(__dirname, '../../data/Requirementdatafile/ALMRequirementFields.json'); 

// Load ALM config
const loadConfigFromFile = (filePath) => {
    const rawData = fs.readFileSync(filePath);
    return JSON.parse(rawData);
};

// Parse cookies
const parseCookies = (cookieArray) => {
    const cookieMap = {};
    cookieArray.forEach(cookie => {
        const [cookiePair] = cookie.split(';');
        const [name, value] = cookiePair.split('=');
        cookieMap[name.trim()] = value;
    });
    return cookieMap;
};

// Build cookie header
const buildCookieHeader = ({ xsrfToken, sessionCookie, lwssoCookie, almUser, qcSession }) => {
    return `XSRF-TOKEN=${xsrfToken}; JSESSIONID=${sessionCookie}; LWSSO_COOKIE_KEY=${lwssoCookie}; ALM_USER=${almUser}; QCSession=${qcSession}`;
};

// Main fetch function
const fetchAlmRequirementFields = async () => {
    try {
        const config = loadConfigFromFile(CONFIG_PATH);
        const { almServerUrl, username, password, domain, project } = config;

        const loginUrl = `${almServerUrl}/api/authentication/sign-in`;
        const releaseDataUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/customization/entities/requirement/fields`;

        const authHeader = 'Basic ' + Buffer.from(`${username}:${password}`).toString('base64');

        // Step 1: Login
        const loginResponse = await axios.post(loginUrl, {}, {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': authHeader
            },
            withCredentials: true
        });

        const cookies = loginResponse.headers['set-cookie'] || [];
        const cookieMap = parseCookies(cookies);

        const {
            'XSRF-TOKEN': xsrfToken,
            'JSESSIONID': sessionCookie,
            'LWSSO_COOKIE_KEY': lwssoCookie,
            'ALM_USER': almUser,
            'QCSession': qcSession
        } = cookieMap;

        // Step 2: Get release data
        if (xsrfToken && sessionCookie) {
            const releaseDataResponse = await axios.get(releaseDataUrl, {
                headers: {
                    'Accept': 'application/json',
                    'Cookie': buildCookieHeader({ xsrfToken, sessionCookie, lwssoCookie, almUser, qcSession })
                }
            });

            console.log("📥 Writing to:", OUTPUT_PATH);
            fs.writeFileSync(OUTPUT_PATH, JSON.stringify(releaseDataResponse.data, null, 2), 'utf8');
            console.log("✅ ALM release data saved to AlmReleases.json");

        } else {
            console.error("❌ Missing authentication tokens from ALM.");
        }
    } catch (error) {
        console.error("❌ Failed to fetch ALM releases:", error.message);
    }
};

module.exports = {
    fetchAlmRequirementFields 
};



// const axios = require('axios');
// const fs = require('fs');
// const path = require('path');

// // Paths
// const CONFIG_PATH = path.join(__dirname, '../data/AlmCredentials.json');
// const OUTPUT_PATH = path.join(__dirname, '../data/AlmReleaseFields.json');

// // Load ALM config
// const loadConfigFromFile = (filePath) => {
//     const rawData = fs.readFileSync(filePath);
//     return JSON.parse(rawData);
// };

// // Parse cookies
// const parseCookies = (cookieArray) => {
//     const cookieMap = {};
//     cookieArray.forEach(cookie => {
//         const [cookiePair] = cookie.split(';');
//         const [name, value] = cookiePair.split('=');
//         cookieMap[name.trim()] = value;
//     });
//     return cookieMap;
// };

// // Build cookie header
// const buildCookieHeader = ({ xsrfToken, sessionCookie, lwssoCookie, almUser, qcSession }) => {
//     return `XSRF-TOKEN=${xsrfToken}; JSESSIONID=${sessionCookie}; LWSSO_COOKIE_KEY=${lwssoCookie}; ALM_USER=${almUser}; QCSession=${qcSession}`;
// };

// // Main fetch function
// const fetchAlmReleasesFields = async () => {
//     try {
//         const config = loadConfigFromFile(CONFIG_PATH);
//         const { almServerUrl, username, password, domain, project } = config;

//         const loginUrl = `${almServerUrl}/api/authentication/sign-in`;
//         const releaseDataUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/customization/entities/release/fields`;

//         const authHeader = 'Basic ' + Buffer.from(`${username}:${password}`).toString('base64');

//         // Step 1: Login
//         const loginResponse = await axios.post(loginUrl, {}, {
//             headers: {
//                 'Content-Type': 'application/json',
//                 'Authorization': authHeader
//             },
//             withCredentials: true
//         });

//         const cookies = loginResponse.headers['set-cookie'] || [];
//         const cookieMap = parseCookies(cookies);

//         const {
//             'XSRF-TOKEN': xsrfToken,
//             'JSESSIONID': sessionCookie,
//             'LWSSO_COOKIE_KEY': lwssoCookie,
//             'ALM_USER': almUser,
//             'QCSession': qcSession
//         } = cookieMap;

//         // Step 2: Get release data
//         if (xsrfToken && sessionCookie) {
//             const releaseDataResponse = await axios.get(releaseDataUrl, {
//                 headers: {
//                     'Accept': 'application/json',
//                     'Cookie': buildCookieHeader({ xsrfToken, sessionCookie, lwssoCookie, almUser, qcSession })
//                 }
//             });

//             console.log("📥 Writing to:", OUTPUT_PATH);
//             fs.writeFileSync(OUTPUT_PATH, JSON.stringify(releaseDataResponse.data, null, 2), 'utf8');
//             console.log("✅ ALM release data saved to AlmReleaseFields.json");

//         } else {
//             console.error("❌ Missing authentication tokens from ALM.");
//         }
//     } catch (error) {
//         console.error("❌ Failed to fetch ALM releases:", error.message);
//     }
// };

// module.exports = {
//     fetchAlmReleasesFields 
// };


// const axios = require('axios');
// const fs = require('fs');
// const path = require('path');

// // Ensure data directory exists
// const DATA_DIR = path.join(__dirname, '../data');
// if (!fs.existsSync(DATA_DIR)) {
//     console.log(`📁 Creating data directory: ${DATA_DIR}`);
//     fs.mkdirSync(DATA_DIR, { recursive: true });
// }

// // Paths
// const CONFIG_PATH = path.join(__dirname, '../data/AlmCredentials.json');
// const OUTPUT_PATH = path.join(__dirname, '../data/AlmReleaseFields.json');

// // Load ALM config
// const loadConfigFromFile = (filePath) => {
//     try {
//         if (fs.existsSync(filePath)) {
//             const rawData = fs.readFileSync(filePath);
//             return JSON.parse(rawData);
//         } else {
//             console.error(`❌ Config file not found: ${filePath}`);
//             // If you want to provide a default config when file doesn't exist
//             return {
//                 "almServerUrl": "http://122.165.58.206:8080/qcbin",
//                 "username": "apikey-gjcasbfmiiigeormmrbl",
//                 "password": "bmbdojjihkhpnian",
//                 "domain": "DEFAULT",
//                 "project": "ALM17_Demo"
//             };
//         }
//     } catch (error) {
//         console.error(`❌ Error loading config: ${error.message}`);
//         throw error;
//     }
// };

// // Parse cookies
// const parseCookies = (cookieArray) => {
//     const cookieMap = {};
//     if (!cookieArray || !Array.isArray(cookieArray)) {
//         console.warn("⚠️ No cookies received from server");
//         return cookieMap;
//     }
    
//     cookieArray.forEach(cookie => {
//         const [cookiePair] = cookie.split(';');
//         const [name, value] = cookiePair.split('=');
//         cookieMap[name.trim()] = value;
//     });
//     return cookieMap;
// };

// // Build cookie header
// const buildCookieHeader = ({ xsrfToken, sessionCookie, lwssoCookie, almUser, qcSession }) => {
//     return `XSRF-TOKEN=${xsrfToken}; JSESSIONID=${sessionCookie}; LWSSO_COOKIE_KEY=${lwssoCookie}; ALM_USER=${almUser}; QCSession=${qcSession}`;
// };

// // Main fetch function
// const fetchAlmReleasesFields = async () => {
//     try {
//         const config = loadConfigFromFile(CONFIG_PATH);
        
//         // Save config if it doesn't exist
//         if (!fs.existsSync(CONFIG_PATH)) {
//             fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2), 'utf8');
//             console.log(`✅ Created config file: ${CONFIG_PATH}`);
//         }
        
//         const { almServerUrl, username, password, domain, project } = config;
        
//         console.log(`🔄 Connecting to ALM server: ${almServerUrl}`);
//         console.log(`👤 Using credentials for: ${username}`);

//         const loginUrl = `${almServerUrl}/api/authentication/sign-in`;
//         const releaseDataUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/customization/entities/release/fields`;

//         const authHeader = 'Basic ' + Buffer.from(`${username}:${password}`).toString('base64');

//         // Step 1: Login
//         console.log("🔑 Attempting login to ALM...");
//         const loginResponse = await axios.post(loginUrl, {}, {
//             headers: {
//                 'Content-Type': 'application/json',
//                 'Authorization': authHeader
//             },
//             withCredentials: true
//         });

//         console.log("✅ Login successful");
        
//         const cookies = loginResponse.headers['set-cookie'] || [];
//         const cookieMap = parseCookies(cookies);

//         const {
//             'XSRF-TOKEN': xsrfToken,
//             'JSESSIONID': sessionCookie,
//             'LWSSO_COOKIE_KEY': lwssoCookie,
//             'ALM_USER': almUser,
//             'QCSession': qcSession
//         } = cookieMap;

//         // Step 2: Get release data
//         if (xsrfToken && sessionCookie) {
//             console.log("🔄 Fetching ALM release fields data...");
//             const releaseDataResponse = await axios.get(releaseDataUrl, {
//                 headers: {
//                     'Accept': 'application/json',
//                     'Cookie': buildCookieHeader({ xsrfToken, sessionCookie, lwssoCookie, almUser, qcSession })
//                 }
//             });

//             console.log("📥 Writing to:", OUTPUT_PATH);
//             fs.writeFileSync(OUTPUT_PATH, JSON.stringify(releaseDataResponse.data, null, 2), 'utf8');
//             console.log("✅ ALM release data saved to AlmReleaseFields.json");
            
//             return releaseDataResponse.data;
//         } else {
//             console.error("❌ Missing authentication tokens from ALM.");
//             return null;
//         }
//     } catch (error) {
//         console.error("❌ Failed to fetch ALM releases:", error.message);
//         if (error.response) {
//             console.error("Status:", error.response.status);
//             console.error("Response data:", error.response.data);
//         }
//         throw error;
//     }
// };

// // Create a credentials file if it doesn't exist
// const createCredentialsFile = () => {
//     const credentials = {
//         "almServerUrl": "http://122.165.58.206:8080/qcbin",
//         "username": "apikey-gjcasbfmiiigeormmrbl",
//         "password": "bmbdojjihkhpnian",
//         "domain": "DEFAULT",
//         "project": "ALM17_Demo"
//     };
    
//     if (!fs.existsSync(CONFIG_PATH)) {
//         try {
//             fs.writeFileSync(CONFIG_PATH, JSON.stringify(credentials, null, 2), 'utf8');
//             console.log(`✅ Created ALM credentials file: ${CONFIG_PATH}`);
//         } catch (error) {
//             console.error(`❌ Failed to create credentials file: ${error.message}`);
//         }
//     }
// };

// // Execute if running directly
// if (require.main === module) {
//     console.log("🚀 Starting ALM data fetch script");
//     createCredentialsFile();
//     fetchAlmReleasesFields()
//         .then(() => console.log("✅ Script completed successfully"))
//         .catch(err => console.error("❌ Script failed:", err.message));
// }

// module.exports = {
//     fetchAlmReleasesFields,
//     createCredentialsFile
// };