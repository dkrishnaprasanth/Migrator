const fs = require("fs");
const path = require("path");
const db = require("../../config/db");


// Field Mappings Table Creation
const createMappingTable = async () => {
  try {
    const createReleasesMappingQuery = `
      CREATE TABLE IF NOT EXISTS Field_mappings (
        id INT PRIMARY KEY AUTO_INCREMENT,
        ep1_label VARCHAR(255) NOT NULL,
        ep1_name VARCHAR(255) NOT NULL,
        ep1_physical_name VARCHAR(255),
        ep1_type VARCHAR(255),
        ep2_label VARCHAR(255) NOT NULL,
        ep2_field_id INT NOT NULL,
        ep2_type VARCHAR(255),
        artifact_type VARCHAR(255),          
        link_name VARCHAR(255),            
        is_current BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )`;

    await db.promise().query(createReleasesMappingQuery);
    console.log("Field Mappings Table Verified/Created");
  } catch (err) {
    console.error("Error Creating Field Mappings Table:", err);
  }
};


const createValueMappingTable = async () => {
  try {
    const createValueMappingsQuery = `
      CREATE TABLE IF NOT EXISTS value_mappings (
        id INT PRIMARY KEY AUTO_INCREMENT,
        ep1_label VARCHAR(255) NOT NULL,
        ep1_name VARCHAR(255) NOT NULL,
        ep1_value VARCHAR(255),
        ep1_type VARCHAR(255),
        ep2_label VARCHAR(255) NOT NULL,
        ep2_field_id INT NOT NULL,
        ep2_value VARCHAR(255),
        ep2_value_id VARCHAR(255),
        ep2_type VARCHAR(255),
        artifact_type VARCHAR(255),
        link_name VARCHAR(255),
        field_mapping_id INT,
        is_current BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (field_mapping_id) REFERENCES Field_mappings(id) ON DELETE CASCADE
      )`;

    await db.promise().query(createValueMappingsQuery);
    console.log("Value Mappings Table Verified/Created");
  } catch (err) {
    console.error("Error Creating Value Mappings Table:", err);
  }
};

const processLinkName = async (mappings) => {
  const [tableInfo] = await db.promise().query("DESCRIBE link_table");
  const columns = tableInfo.map(col => col.Field);

  let orderColumn = 'id';
  if (columns.includes('created_at')) {
    orderColumn = 'created_at';
  } else if (columns.includes('creation_date')) {
    orderColumn = 'creation_date';
  }

  console.log(`Using ${orderColumn} for ordering in link_table queries`);

  for (const mapping of mappings) {
    if (mapping.link_name && mapping.link_name.trim() !== '') {
      const [linkResult] = await db.promise().query(
        "SELECT link_name FROM link_table WHERE link_name = ? AND is_current = 1",
        [mapping.link_name]
      );

      if (linkResult.length === 0) {
        const [defaultLink] = await db.promise().query(
          `SELECT link_name FROM link_table WHERE is_current = 1 ORDER BY ${orderColumn} DESC LIMIT 1`
        );

        if (defaultLink.length === 0) {
          throw new Error(`No active link_name found in link_table. The provided value '${mapping.link_name}' cannot be used.`);
        }

        mapping.link_name = defaultLink[0].link_name;
        console.log(`Using default link_name: ${mapping.link_name}`);
      } else {
        mapping.link_name = linkResult[0].link_name;
        console.log(`Using validated link_name: ${mapping.link_name}`);
      }
    } else if (mapping.link_name === '') {
      mapping.link_name = null;
    } else {
      const [defaultLink] = await db.promise().query(
        `SELECT link_name FROM link_table WHERE is_current = 1 ORDER BY ${orderColumn} DESC LIMIT 1`
      );

      if (defaultLink.length > 0) {
        mapping.link_name = defaultLink[0].link_name;
        console.log(`Using default link_name: ${mapping.link_name}`);
      } else {
        mapping.link_name = null;
        console.log("No default link_name available, setting to null");
      }
    }
  }

  console.log(`Processed ${mappings.length} mappings with link_name validation`);
};

const RequirementsaveMappings = async (req, res) => {
  try {
    await createMappingTable();

    const { mappings, tableName } = req.body;

    // Step 1: Get the current link_name
    const [rows] = await db.promise().query(
      `SELECT link_name FROM link_table WHERE is_current = TRUE LIMIT 1`
    );

    const linkName = rows.length > 0 ? rows[0].link_name : null;

    if (!linkName) {
      throw new Error("No current link_name found in link_table");
    }

    // Step 2: Delete old mappings for this artifact_type and link_name
    await db.promise().query(
      `DELETE FROM Field_mappings WHERE link_name = ? AND artifact_type = ?`,
      [linkName, 'Requirement']
    );

    if (!Array.isArray(mappings) || mappings.length === 0 || !tableName) {
      return res.status(400).json({ message: "Invalid data" });
    }

    const sanitizedTableName = tableName.replace(/[^a-zA-Z0-9_]/g, '_');

    // Check for existing table name
    const [existingTable] = await db.promise().query(
      "SELECT link_name FROM Field_mappings WHERE link_name = ? LIMIT 1",
      [sanitizedTableName]
    );

    if (existingTable.length > 0) {
      return res.status(400).json({
        message: `Table name '${sanitizedTableName}' already exists. Choose a different name.`
      });
    }

    await processLinkName(mappings);

    // Set all existing mappings as not current
    await db.promise().query("UPDATE Field_mappings SET is_current = FALSE");

    const insertedMappings = [];

    // Insert field mappings one by one
    for (const mapping of mappings) {
      const insertQuery = `
        INSERT INTO Field_mappings (
          ep1_label, ep1_name, ep1_physical_name,
          ep1_type, ep2_label, ep2_field_id, ep2_type,
          artifact_type, link_name, is_current
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;

      const values = [
        mapping.ep1_label,
        mapping.ep1_name,
        mapping.ep1_physical_name,
        mapping.ep1_type,
        mapping.ep2_label,
        mapping.ep2_field_id,
        mapping.ep2_type,
        mapping.artifact_type || null,
        mapping.link_name || null,
        true
      ];

      const [result] = await db.promise().query(insertQuery, values);

      insertedMappings.push({
        ...mapping,
        field_mapping_id: result.insertId
      });

      console.log(`✅ Inserted field mapping: ${mapping.ep1_name} with ID: ${result.insertId}`);
    }

    console.log("✅ All field mappings saved successfully");


    // await updateValueMappingsWithFieldIds(insertedMappings, sanitizedTableName);


    // Check if there are any lookuplist or userlist fields
    const hasLookupFields = insertedMappings.some(
      m => m.ep1_type === 'lookuplist' || m.ep1_type === 'userlist'
    );

    if (hasLookupFields) {
      await updateValueMappingsWithFieldIds(insertedMappings, sanitizedTableName);
    }



    await RequirementrecreateNewTable();

    return res.status(201).json({
      message: `${insertedMappings.length} field mappings saved successfully`,
      mappingsAdded: insertedMappings.length,
      tableName: sanitizedTableName,
      fieldMappingIds: insertedMappings.map(m => m.field_mapping_id)
    });
  } catch (error) {
    console.error("❌ Error saving mappings:", error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};


const updateValueMappingsWithFieldIds = async (fieldMappings, tableName) => {
  try {
    console.log("🔄 Starting to update value_mappings with field_mapping_ids...");

    const [tables] = await db.promise().query("SHOW TABLES LIKE 'value_mappings'");
    if (tables.length === 0) {
      console.log("⚠️ value_mappings table does not exist. Skipping update.");
      return;
    }


    for (const fieldMapping of fieldMappings) {
      console.log(`🔍 Processing field: ${fieldMapping.ep1_name}`);


      const findQuery = `
        SELECT id, ep1_name, ep2_field_id, field_mapping_id
        FROM value_mappings
        WHERE ep1_name = ? AND link_name = ?
      `;

      const [valueMappings] = await db.promise().query(findQuery, [
        fieldMapping.ep1_name,
        tableName
      ]);

      console.log(`📋 Found ${valueMappings.length} value mappings for ${fieldMapping.ep1_name}`);

      if (valueMappings.length > 0) {
        // Update all matching value mappings
        const updateQuery = `
          UPDATE value_mappings
          SET field_mapping_id = ?
          WHERE ep1_name = ? AND link_name = ?
        `;

        const [updateResult] = await db.promise().query(updateQuery, [
          fieldMapping.field_mapping_id,
          fieldMapping.ep1_name,
          tableName
        ]);

        console.log(`✅ Updated ${updateResult.affectedRows} value mappings with field_mapping_id: ${fieldMapping.field_mapping_id}`);
      } else {
        console.log(`⚠️  No value mappings found for ${fieldMapping.ep1_name}`);
      }
    }

    console.log("✅ Successfully updated all value mappings with field_mapping_ids");
  } catch (error) {
    console.error("❌ Error updating value mappings:", error);
    throw error;
  }
};


const saverequirementValueMappings = async (req, res) => {
  try {

    await createValueMappingTable();

    const { mappings, tableName } = req.body;

    // Step 1: Get the current link_name
    const [rows] = await db.promise().query(
      `SELECT link_name FROM link_table WHERE is_current = TRUE LIMIT 1`
    );

    const linkName = rows.length > 0 ? rows[0].link_name : null;

    if (!linkName) {
      throw new Error("No current link_name found in link_table");
    }

    // Step 2: Delete old mappings for this artifact_type and link_name
    await db.promise().query(
      `DELETE FROM value_mappings WHERE link_name = ? AND artifact_type = ?`,
      [linkName, 'Requirement']
    );

    if (!Array.isArray(mappings) || mappings.length === 0 || !tableName) {
      return res.status(400).json({ message: "Invalid data" });
    }

    const sanitizedTableName = tableName.replace(/[^a-zA-Z0-9_]/g, '_');

    // Check existing table
    const [existingTable] = await db.promise().query(
      "SELECT link_name FROM value_mappings WHERE link_name = ? LIMIT 1",
      [sanitizedTableName]
    );

    if (existingTable.length > 0) {
      return res.status(400).json({
        message: `Table name '${sanitizedTableName}' already exists. Choose a different name.`
      });
    }

    await processLinkName(mappings);

    // Set all existing mappings as not current
    await db.promise().query("UPDATE value_mappings SET is_current = FALSE");

    const enrichedMappings = [];


    for (const mapping of mappings) {
      let fieldMappingId = null;


      const [fieldMapping] = await db.promise().query(
        `SELECT id FROM Field_mappings
         WHERE ep1_name = ? AND link_name = ? AND is_current = TRUE`,
        [mapping.ep1_name, mapping.link_name]
      );

      if (fieldMapping.length > 0) {
        fieldMappingId = fieldMapping[0].id;
        console.log(`✅ Found field_mapping_id: ${fieldMappingId} for ${mapping.ep1_name}`);
      } else {
        console.log(`⚠️  No field_mapping_id found for ${mapping.ep1_name}`);
      }

      enrichedMappings.push({
        ...mapping,
        field_mapping_id: fieldMappingId
      });
    }

    // Bulk insert with field_mapping_id
    const values = enrichedMappings.map(mapping => [
      mapping.ep1_label,
      mapping.ep1_name,
      mapping.ep1_value,
      mapping.ep1_type,
      mapping.ep2_label,
      mapping.ep2_field_id,
      mapping.ep2_value,
      mapping.ep2_value_id,
      mapping.ep2_type,
      mapping.artifact_type || null,
      mapping.link_name || null,
      mapping.field_mapping_id || null,
      true
    ]);

    const insertQuery = `
      INSERT INTO value_mappings (
        ep1_label, ep1_name, ep1_value,
        ep1_type, ep2_label, ep2_field_id,
        ep2_value, ep2_value_id, ep2_type,
        artifact_type, link_name, field_mapping_id, is_current
      ) VALUES ?
    `;

    await db.promise().query(insertQuery, [values]);

    console.log("✅ Value Mappings saved successfully with field_mapping_ids");

    return res.status(201).json({
      message: `${values.length} value mappings saved successfully`,
      mappingsAdded: values.length,
      tableName: sanitizedTableName,
      fieldMappingIds: enrichedMappings.map(m => m.field_mapping_id).filter(id => id !== null)
    });

  } catch (error) {
    console.error("❌ Error saving value mappings:", error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

const getAlmRequirementFieldData = async (req, res) => {
  try {
    const { ep1_physical_name } = req.params;

    if (!ep1_physical_name) {
      return res.status(400).json({ message: "ALM physical name is required" });
    }

    const query = `
      SELECT
        ep1_label, ep1_name, ep1_physical_name, ep1_type,
        ep2_label, ep2_field_id, ep2_type, link_name, is_current
      FROM Field_mappings
      WHERE ep1_physical_name = ?
    `;

    const [rows] = await db.promise().query(query, [ep1_physical_name]);

    if (rows.length === 0) {
      return res.status(404).json({ message: "No data found for this ALM physical name" });
    }

    res.status(200).json(rows[0]);
  } catch (error) {
    console.error("Error fetching ALM field data:", error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

const getRequirementCurrentTableName = async () => {
  try {
    const [rows] = await db.promise().query(
      'SELECT DISTINCT link_name FROM Field_mappings WHERE is_current = TRUE LIMIT 1'
    );
    return rows.length > 0 ? rows[0].link_name : null;
  } catch (error) {
    console.error("Error retrieving current table name:", error);
    return null;
  }
};

const getAllRequirementTableNames = async () => {
  const allRows = [];

  try {
    const [fieldRows] = await db.promise().query(`
      SELECT
        link_name,
        MAX(created_at) as created_date,
        MAX(is_current) as is_current
      FROM Field_mappings
      GROUP BY link_name
      ORDER BY created_date DESC
    `);
    allRows.push(...fieldRows);

  } catch (error) {
    console.error("❌ Field_mappings query failed:", error.message);
  }

  try {
    const [valueRows] = await db.promise().query(`
      SELECT
        link_name,
        MAX(created_at) as created_date,
        MAX(is_current) as is_current,
        'value_mapping' as mapping_type
      FROM value_mappings
      GROUP BY link_name
      ORDER BY created_date DESC
    `);
    allRows.push(...valueRows);
  } catch (err) {
    console.error("❌ value_mappings query failed:", err.message);
  }

  return allRows.map(row => ({
    tableName: row.link_name,
    createdAt: row.created_date,
    isCurrent: Boolean(row.is_current),
    mappingType: row.mapping_type
  }));
};

const fetchCurrentRequirementTableName = async (req, res) => {
  try {
    const tableName = await getRequirementCurrentTableName();
    if (tableName) {
      res.status(200).json({ tableName, isCurrent: true });
    } else {
      res.status(404).json({ message: "No current table name found" });
    }
  } catch (error) {
    console.error("Error in fetchCurrentTableName:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const fetchAllRequirementTableNames = async (req, res) => {
  try {
    const tableNames = await getAllRequirementTableNames();
    if (tableNames && tableNames.length > 0) {
      res.status(200).json({ tables: tableNames });
    } else {
      res.status(404).json({ message: "No table names found" });
    }
  } catch (error) {
    console.error("Error in fetchAllRequirementTableNames:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const setCurrentRequirementTable = async (req, res) => {
  try {
    const { tableName, mappingType } = req.body;

    if (!tableName) {
      return res.status(400).json({ message: "Table name is required" });
    }

    const tableToCheck = mappingType === 'value_mapping' ? 'value_mappings' : 'Field_mappings';

    const [tableExists] = await db.promise().query(
      `SELECT COUNT(*) as count FROM ${tableToCheck} WHERE link_name = ?`,
      [tableName]
    );

    if (tableExists[0].count === 0) {
      return res.status(404).json({ message: "Table not found in records" });
    }

    await db.promise().query(`UPDATE ${tableToCheck} SET is_current = FALSE`);

    await db.promise().query(
      `UPDATE ${tableToCheck} SET is_current = TRUE WHERE link_name = ?`,
      [tableName]
    );

    res.status(200).json({ message: `Table ${tableName} set as current` });
  } catch (error) {
    console.error("Error in setCurrentRequirementTable:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const getStoredRequirementTableName = async () => {
  try {
    const [rows] = await db.promise().query(
      'SELECT DISTINCT link_name FROM Field_mappings LIMIT 1'
    );
    return rows.length > 0 ? rows[0].link_name : null;
  } catch (error) {
    console.error("Error retrieving stored table name:", error);
    return null;
  }
};

const fetchStoredRequirementTableName = async (req, res) => {
  try {
    const tableName = await getStoredRequirementTableName();
    if (tableName) {
      res.status(200).json({ tableName });
    } else {
      res.status(404).json({ message: "No table name found" });
    }
  } catch (error) {
    console.error("Error in fetchStoredTableName:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const getRequirementMappingsForTable = async (req, res) => {
  try {
    const { tableName } = req.params;
    const { artifactType, mappingType } = req.query;

    if (!tableName) {
      return res.status(400).json({ message: "Table name is required" });
    }

    console.log(`🔍 Fetching mappings for table: ${tableName}, artifact: ${artifactType}, type: ${mappingType}`);

    let fieldQuery = `
      SELECT
        id, ep1_label, ep1_name, ep1_physical_name, ep1_type,
        ep2_label, ep2_field_id, ep2_type, artifact_type, link_name
      FROM Field_mappings
      WHERE link_name = ?
    `;

    const fieldParams = [tableName];

    if (artifactType) {
      fieldQuery += ' AND artifact_type = ?';
      fieldParams.push(artifactType);
    }

    const [fieldMappings] = await db.promise().query(fieldQuery, fieldParams);

     if (!fieldMappings || fieldMappings.length === 0) {
      console.warn(`⚠️ No field mappings found for table: ${tableName}`);
      return res.status(200).json([]); // ✅ return empty array instead of 500
    }

    console.log(`✅ Found ${fieldMappings.length} field mappings`);

    const enhancedMappings = [];

    for (const fieldMapping of fieldMappings) {
      const valueQuery = `
        SELECT
          ep1_label, ep1_name, ep1_value, ep1_type,
          ep2_label, ep2_field_id, ep2_value, ep2_value_id, ep2_type,
          artifact_type, link_name, field_mapping_id
        FROM value_mappings
        WHERE field_mapping_id = ? AND link_name = ?
      `;

  let valueMappings = [];
      try {
        const [rows] = await db.promise().query(valueQuery, [fieldMapping.id, tableName]);
        valueMappings = rows || [];
        console.log(` Found ${valueMappings.length} value mappings for field: ${fieldMapping.ep1_name}`);
      } catch (err) {
        console.error(`❌ Error fetching value mappings for fieldMapping ${fieldMapping.id}:`, err.message);
        valueMappings = [];
      }

      let processedValueMappings = {};

      if (valueMappings.length > 0) {
        valueMappings.forEach(valueMapping => {
          if (valueMapping.ep1_value && valueMapping.ep2_value_id) {
            processedValueMappings[valueMapping.ep1_value] = {
              value: valueMapping.ep2_value_id,
              label_value: valueMapping.ep2_value
            };
          }
        });
      }

      const enhancedMapping = {
        id: fieldMapping.id,
        ep1_label: fieldMapping.ep1_label,
        ep1_name: fieldMapping.ep1_name,
        ep1_physical_name: fieldMapping.ep1_physical_name,
        ep1_type: fieldMapping.ep1_type,
        ep2_label: fieldMapping.ep2_label,
        ep2_field_id: fieldMapping.ep2_field_id,
        ep2_type: fieldMapping.ep2_type,
        artifact_type: fieldMapping.artifact_type,
        link_name: fieldMapping.link_name,

        value_mappings: Object.keys(processedValueMappings).length > 0 ? processedValueMappings : null,
        has_value_mappings: Object.keys(processedValueMappings).length > 0,
        value_mapping_count: Object.keys(processedValueMappings).length
      };

      enhancedMappings.push(enhancedMapping);
    }

    console.log(`✅ Returning ${enhancedMappings.length} enhanced mappings with value mappings`);

    return res.status(200).json(enhancedMappings);

  } catch (error) {
    console.error("❌ Error getting mappings for table:", error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

const RequirementrecreateNewTable = async () => {
  try {
    const [rows] = await db.promise().query(`SELECT ep1_name, ep1_type FROM Field_mappings WHERE artifact_type = 'Requirement' AND link_name = (SELECT link_name FROM link_table WHERE is_current = 1 LIMIT 1)`);

    if (rows.length === 0) {
      console.log('No current requirement mappings found to create table.');
      return;
    }

    console.log('Dropping existing `requirement` table...');
    await db.promise().query('DROP TABLE IF EXISTS requirement');

    let createRequirementTableSQL = `CREATE TABLE requirement (
      id INT PRIMARY KEY`;

    const reservedColumns = ['id', 'parent_id', 'type_id', 'name', 'has_link', 'has_attachment', 'last_modified', 'qtest_requirement_id', 'upload_status', 'attach_status'];

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const columnName = row.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();

      if (reservedColumns.includes(columnName)) {
        console.log(`Skipping reserved column: ${columnName}`);
        continue;
      }

      let columnType = 'TEXT';
      if (row.ep1_type === 'String') columnType = 'VARCHAR(255)';
      if (row.ep1_type === 'Number') columnType = 'INT';
      if (row.ep1_type === 'Date') columnType = 'DATE';

      createRequirementTableSQL += `,
      \`${columnName}\` ${columnType}`;
    }

    createRequirementTableSQL += `,
      parent_id INT,
      type_id INT,
      name TEXT,
      has_link VARCHAR(500),
      has_attachment VARCHAR(500),
      last_modified TIMESTAMP,
      qtest_requirement_id INT,
      upload_status TEXT,
      attach_status TEXT,
      comments TEXT,
      comment_Id INT
    )`;

    console.log('Creating new `requirement` table...');
    await db.promise().query(createRequirementTableSQL);

    console.log('✅ `requirement` table created successfully.');
    return true;
  } catch (error) {
    console.error('❌ Error Creating requirement table:', error);
    throw error;
  }
};

const { RequirementinsertSampleData, processAndRequirementUploadAll } = require("../RequirementControllersfile/MappingRequirement");

const RequirementinsertSampleMappingData = async (req, res) => {
  try {
    await RequirementinsertSampleData();
    res.status(201).json({ success: true, message: "Sample data inserted successfully" });
  } catch (error) {
    console.error("Error inserting sample data:", error);
    res.status(500).json({ success: false, message: "Error inserting sample data" });
  }
};

const getRequirementMappingData = async (req, res) => {
  try {
    const data = await processAndRequirementUploadAll();
    res.status(200).json({ success: true, data });
  } catch (error) {
    console.error("Error getting mapping data:", error);
    res.status(500).json({ success: false, message: "Error getting mapping data" });
  }
};

module.exports = {
  RequirementsaveMappings,
  createMappingTable,
  fetchCurrentRequirementTableName,
  fetchAllRequirementTableNames,
  setCurrentRequirementTable,
  fetchStoredRequirementTableName,
  getRequirementMappingData,
  RequirementinsertSampleMappingData,
  getRequirementMappingsForTable,
  getAlmRequirementFieldData,
  saverequirementValueMappings,
  createValueMappingTable,
  processLinkName,
  updateValueMappingsWithFieldIds
};

