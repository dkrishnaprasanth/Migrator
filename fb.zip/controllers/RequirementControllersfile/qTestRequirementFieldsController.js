const db = require("../../config/db");
const fs = require("fs");
const path = require("path");
const { fetchqTestRequirementFields  } = require("../RequirementControllersfile/qTestRequirementFields");

// ------------------------------
// Read and Validate JSON
// ------------------------------
const loadJsonAndValidateqtestrequirement = async () => {
  const jsonFilePath = path.join(__dirname, '../../data/Requirementdatafile/qTestRequirementFields.json');

  try {
    const rawData = fs.readFileSync(jsonFilePath, "utf-8");
    if (!rawData) {
      console.error("❌ JSON file is empty.");
      return [];
    }

    const parsedData = JSON.parse(rawData);
    if (
      !Array.isArray(parsedData) &&
      (!parsedData.Fields || !Array.isArray(parsedData.Fields.Field))
    ) {
      console.error("❌ Unexpected JSON structure:", parsedData);
      return [];
    }

    return Array.isArray(parsedData) ? parsedData : parsedData.Fields.Field;
  } catch (err) {
    console.error("❌ Error reading/parsing JSON file:", err);
    return [];
  }
};

// ------------------------------
// Create Tables
// ------------------------------
const createTableqtestrequirement = async () => {
  return new Promise((resolve, reject) => {
    const dropQtestFieldsTable = `DROP TABLE IF EXISTS qtest_requirement_data;`;
    const createQtestDataTable = `
      CREATE TABLE IF NOT EXISTS qtest_requirement_data (
        id INT PRIMARY KEY,
        attribute_type VARCHAR(255),
        label TEXT, 
        required TINYINT(1)
       
      ) `;

        const dropComboValuesTable = `DROP TABLE IF EXISTS  qtest_requirement;`;
    const createQtestReleasesTable = `
      CREATE TABLE IF NOT EXISTS qtest_requirement (
        id INT,
        attribute_type VARCHAR(255),
        label TEXT,
        value INT,
        label_value TEXT
      )
    `;

      db.query(dropQtestFieldsTable, (dropErr1) => {
      if (dropErr1) {
        console.error("Error dropping qtest_requirement_data:", dropErr1.message);
        return reject(dropErr1);
      }

      db.query(dropComboValuesTable, (dropErr2) => {
        if (dropErr2) {
          console.error("Error dropping qtest_requirement:", dropErr2.message);
          return reject(dropErr2);
        }

        db.query(createQtestDataTable, (createErr1) => {
          if (createErr1) {
            console.error("Error creating qtest_requirement_data:", createErr1.message);
            return reject(createErr1);
          }

          db.query( createQtestReleasesTable, (createErr2) => {
            if (createErr2) {
              console.error("Error creating qtest_requirement:", createErr2.message);
              return reject(createErr2);
            }

            resolve(); // All done successfully
          });
        });
      });
    });
  });
};

// ------------------------------
// Insert Data From JSON
// ------------------------------
const insertqtestrequirementDataFromJson = async () => {
  try {
    const jsonData = await  loadJsonAndValidateqtestrequirement();
    if (!jsonData || jsonData.length === 0) return;

    const [dataResult] = await db.promise().query("SELECT COUNT(*) AS count FROM qtest_requirement_data");
    if (dataResult[0].count > 0) {
      console.log("⚠️ Data already exists in qtest_requirement_data.");
      return;
    }

    // Insert into qtest_requirement_data table
    const qtestDataValues = jsonData.map(item => [
      item.id || null,
      item.attribute_type || null,
      item.label || null,
      item.required || null,
    ]);

    await db.promise().query(
      `INSERT INTO qtest_requirement_data (id, attribute_type, label, required) VALUES ?`,
      [qtestDataValues]
    );
    console.log("✅ qtest_requirement_data inserted.");

    // Insert into qtest_requirement (includes all entries, with or without allowed_values)
    let qtestReleasesValues = [];

    jsonData.forEach(item => {
      if (item.allowed_values && Array.isArray(item.allowed_values) && item.allowed_values.length > 0) {
        // insert each allowed value
        item.allowed_values.forEach(val => {
          if (val.value != null && val.label != null) {
            qtestReleasesValues.push([
              item.id,
              item.attribute_type,
              item.label,
              val.value,
              val.label
            ]);
          }
        });
      } else {
        // FIXED: Remove extra item.required value - only 5 columns in qtest_requirement table
        qtestReleasesValues.push([
          item.id,
          item.attribute_type,
          item.label,
          null, // value
          null  // label_value
        ]);
      }
    });

    await db.promise().query(
      `INSERT INTO qtest_requirement (id, attribute_type, label, value, label_value) VALUES ?`,
      [qtestReleasesValues]
    );
    console.log("✅ qtest_requirement data inserted.");

  } catch (err) {
    console.error("❌ Error in insertDataFromJson:", err);
  }
};


// ------------------------------
// Main Init
// ------------------------------
const qtestrequirementinit = async () => {
  try {
    console.log("🚀 Fetching fields...");
    await fetchqTestRequirementFields ();
    console.log("✅ Fetch done.");
    await createTableqtestrequirement();
    await insertqtestrequirementDataFromJson ();
  } catch (err) {
    console.error("❌ Initialization failed:", err);
    process.exit(1);
  }
};



const getqtestrequirementAllData =  async (req, res) => {
 
  try {
    // Get all fields from qtest_data
    const [fields] = await db.promise().query("SELECT * FROM qtest_requirement_data");
    
    // For each field, get its allowed values from qtest_releases
    const fieldsWithValues = await Promise.all(fields.map(async (field) => {
      const [values] = await db.promise().query(
        "SELECT value, label_value FROM qtest_requirement WHERE id = ? AND value IS NOT NULL",
        [field.id]
      );
      return {
        ...field,
        allowed_values: values
      };
    }));

    res.json(fieldsWithValues);
  } catch (err) {
    console.error("❌ Error fetching data:", err);
    res.status(500).json({ error: err.message });
  }
};

// ------------------------------
// Get Releases Data
// ------------------------------
const getRequirementData = (req, res) => {
  db.query("SELECT * FROM qtest_requirement", (err, results) => {
    if (err) {
      console.error("❌ Error fetching releases data:", err);
      return res.status(500).json({ error: err.message });
    }
    res.json(results);
  });
};

// ------------------------------
// Insert qtest_requirement_data via API
// ------------------------------
const insertqtestrequirementData = (req, res) => {
  const testCases = req.body;

  if (!Array.isArray(testCases) || testCases.length === 0) {
    return res.status(400).json({ message: "Invalid input: expected an array of test cases." });
  }

  const values = testCases.map(item => [
    item.id || null,
    item.attribute_type || null,
    item.label || null,
    item.required || null
  ]);

  const sql = `
    INSERT INTO qtest_requirement_data (id, attribute_type, label, required)
    VALUES ?
  `;

  db.query(sql, [values], (err, result) => {
    if (err) {
      console.error("❌ Error inserting via API:", err);
      return res.status(500).json({ error: err.message });
    }
    res.status(201).json({ message: `${result.affectedRows} records added.` });
  });
};

// ------------------------------
// Insert qtest_requirement via API
// ------------------------------
const insertRequirementData = (req, res) => {
  const releaseData = req.body;

  if (!Array.isArray(releaseData) || releaseData.length === 0) {
    return res.status(400).json({ message: "Invalid input: expected an array of release data." });
  }

  const values = releaseData.map(item => [
    item.id || null,
    item.attribute_type || null,
    item.label || null,
    item.value || null,
    item.label_value || null
  ]);

  const sql = `
    INSERT INTO qtest_requirement (id, attribute_type, label, value, label_value)
    VALUES ?
  `;

  db.query(sql, [values], (err, result) => {
    if (err) {
      console.error("❌ Error inserting releases via API:", err);
      return res.status(500).json({ error: err.message });
    }
    res.status(201).json({ message: `${result.affectedRows} release records added.` });
  });
};

// ------------------------------
// Export Functions
// ------------------------------
module.exports = {
  qtestrequirementinit,
  createTableqtestrequirement,
  insertqtestrequirementDataFromJson ,
  getqtestrequirementAllData,
  getRequirementData,
  insertqtestrequirementData,
  insertRequirementData 
  
};