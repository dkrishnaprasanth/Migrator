
// const fs = require("fs");
// const path = require("path");
// const axios = require("axios");
// const db = require("../../config/db");


// const parseCookies = (cookieArray) => {
//   const cookieMap = {};
//   cookieArray.forEach(cookie => {
//     const [cookiePair] = cookie.split(';');
//     const [name, value] = cookiePair.split('=');
//     cookieMap[name.trim()] = value;
//   });
//   return cookieMap;
// };

// const buildCookieHeader = ({ xsrfToken, sessionCookie, lwssoCookie, almUser, qcSession }) => {
//   return `XSRF-TOKEN=${xsrfToken}; JSESSIONID=${sessionCookie}; LWSSO_COOKIE_KEY=${lwssoCookie}; ALM_USER=${almUser}; QCSession=${qcSession}`;
// };


// // 👇 Paste this right below the require(...) statements
// async function fetchParentChainFromALM(startId, cookieHeader, columns, seen = new Set()) {
//   const parentEntities = [];
//   let currentId = startId;

//   while (currentId !== null && !seen.has(currentId)) {
//     if (parseInt(currentId) < 0) break;

//     seen.add(currentId);
//     console.log(`🌐 Trying to fetch ALM requirement ID: ${currentId}`);

//     const url = `${almCredentials.almServerUrl}/rest/domains/${almCredentials.domain}/projects/${almCredentials.project}/requirements/${currentId}`;

//     try {
//       const { data } = await axios.get(url, {
//         headers: {
//           Accept: 'application/json',
//           Cookie: cookieHeader
//         }
//       });

//       if (!data?.Fields || !Array.isArray(data.Fields)) {
//         console.warn(`⚠️ Unexpected or empty data for ID: ${currentId}`);
//         break;
//       }

//       parentEntities.push({ Fields: data.Fields }); // keep structure consistent
//       console.log(`✅ Fetched entity ID: ${currentId}`);

//       const parentIdField = data.Fields.find(f => f.Name === 'parent-id');

//       currentId = parentIdField?.values?.[0]?.value ?? null;

//       if (parseInt(currentId) === 0) {
//         seen.add(currentId);
//         console.log(`🌐 Fetching root ID: 0`);

//         const rootUrl = `${almCredentials.almServerUrl}/rest/domains/${almCredentials.domain}/projects/${almCredentials.project}/requirements/0`;
//         const rootData = await axios.get(rootUrl, {
//           headers: { Accept: 'application/json', Cookie: cookieHeader }
//         });

//         if (rootData?.data?.Fields) {
//           parentEntities.push({ Fields: rootData.data.Fields });
//           console.log(`✅ Fetched root entity ID: 0`);
//         }
//         break;
//       }


//     } catch (err) {
//       console.error(`❌ Failed to fetch parent ID ${currentId}:`, err.response?.status, err.response?.data || err.message);
//       break;
//     }
//   }

//   return parentEntities;
// }
// const RequirementinsertSampleData = async (req, res) => {
//   try {
//     const [columns] = await db.promise().query(
//       "SELECT ep1_name, ep1_type, ep2_field_id FROM Field_mappings WHERE artifact_type='Requirement'"
//     );
 
//     if (!columns || columns.length === 0) {
//       return res.status(400).json({
//         success: false,
//         message: "No mapping columns found. Please create mappings first."
//       });
//     }
 
//     const jsonFilePath = path.join(__dirname, '../../data/Requirementdatafile/ALMRequirement.json');
//     if (!fs.existsSync(jsonFilePath)) {
//       return res.status(404).json({
//         success: false,
//         message: `JSON file not found at: ${jsonFilePath}`
//       });
//     }
 
//     const jsonData = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'));
 
//     //const [existingRows] = await db.promise().query("SELECT id, last_modified, upload_status FROM requirement");
 
 
//     const [existingRows] = await db.promise().query("SELECT id, last_modified, upload_status, qtest_requirement_id FROM requirement");
 
 
//     const existingMap = new Map();
//     existingRows.forEach(row => {
//       existingMap.set(row.id, {
//         last_modified: row.last_modified ? new Date(row.last_modified).toISOString() : null,
//         upload_status: row.upload_status,
//         qtest_requirement_id: row.qtest_requirement_id
//       });
//     });
 
 
//     // Truncate the 'requirement' table before inserting
//     // await db.promise().query("TRUNCATE TABLE requirement");
 
//     const allRowsToInsert = [];
 
//     let insertCount = 0;
//     let updateCount = 0;
//     let skipCount = 0;
 
//     const insertRows = [];
//     const updateRows = [];
 
//     for (const entity of jsonData.entities) {
//       const rowValues = processEntityFields(entity, columns);
//       if (!rowValues) continue;
 
//       const entityId = parseInt(entity.Fields.find(f => f.Name === 'id')?.values?.[0]?.value);
//       const entityModified = entity.Fields.find(f => f.Name === 'last-modified')?.values?.[0]?.value;
//       const entityModifiedISO = entityModified ? new Date(entityModified).toISOString() : null;
 
//       const existing = existingMap.get(entityId);
 
//       if (!existing) {
//         insertRows.push({ id: entityId, values: rowValues });
//         insertCount++;
//       } else if (existing.last_modified !== entityModifiedISO) {
//         if (['completed', 'uploaded'].includes(existing.upload_status)) {
//           rowValues[rowValues.length - 1] = 'changed'; // set upload_status
//         }
//         updateRows.push({ id: entityId, values: rowValues, existingStatus: existing.upload_status });
//         updateCount++;
//       } else {
//         skipCount++;
//       }
//     }
 
//    if (insertRows.length === 0 && updateRows.length === 0) {
//   // 🔹 Get the latest total count in 'requirement' table
//   const [[{ totalCount }]] = await db.promise().query(
//     "SELECT COUNT(*) AS totalCount FROM requirement"
//   );
 
//   return res.status(200).json({
//     success: true,
//     message: '✅ All requirements are already up-to-date. No insert/update needed.',
//     stats: {
//       inserted: 0,
//       updated: 0,
//       skipped: jsonData.entities.length,
//       totalCount
//     }
//   });
// }
//     // Get actual table columns to verify they exist
//     const [tableColumns] = await db.promise().query(
//       "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'requirement' AND TABLE_SCHEMA = DATABASE()"
//     );
 
//     const existingColumns = tableColumns.map(col => col.COLUMN_NAME.toLowerCase());
 
//     // Filter out reserved columns and prepare column names
//     const reservedColumns = ['parent_id', 'type_id', 'name', 'has_link', 'has_attachment', 'last_modified', 'qtest_requirement_id', 'upload_status', 'comments', 'comment_Id'];
 
//     // Only include columns that actually exist in the database
//     const columnNamesArray = columns
//       .filter(col => !reservedColumns.includes(col.ep1_name.toLowerCase()))
//       .map(col => col.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase())
//       .filter(colName => existingColumns.includes(colName))
//       .map(colName => `\`${colName}\``);
 
//     // Also verify reserved columns exist before including them
//     const validReservedColumns = reservedColumns.filter(col => existingColumns.includes(col));
 
//     const allColumnNames = [
//       ...columnNamesArray,
//       ...validReservedColumns
//     ].join(', ');
 
//     const BATCH_SIZE = 100;
//     let insertedCount = 0;
 
 
//     for (const entity of jsonData.entities) {
//       const rowValues = processEntityFields(entity, columns);
//       if (!rowValues) continue;
 
//       const entityId = parseInt(entity.Fields.find(f => f.Name === 'id')?.values?.[0]?.value);
//       const entityModified = entity.Fields.find(f => f.Name === 'last-modified')?.values?.[0]?.value;
//       const entityModifiedISO = entityModified ? new Date(entityModified).toISOString() : null;
 
//       const existing = existingMap.get(entityId);
 
//       if (!existing) {
//         // Insert new row
//         const insertObj = buildRowObjectFromValues(rowValues, columns);
//         insertObj.id = entityId;
 
//         await db.promise().query("INSERT INTO requirement SET ?", [insertObj]);
//         insertCount++;
 
//       }
 
 
//       else if (existing.last_modified !== entityModifiedISO) {
//         // Update only if last_modified differs
//         const fullUpdateObj = buildRowObjectFromValues(rowValues, columns);
//         fullUpdateObj.id = entityId;
 
//         // Determine new status (based only on qtest_requirement_id)
//         fullUpdateObj.upload_status = existing.qtest_requirement_id ? 'modified' : 'changed';
 
//         // Do NOT overwrite qtest_requirement_id
//         delete fullUpdateObj.qtest_requirement_id;
//         delete fullUpdateObj.comment_Id;
//         await db.promise().query("UPDATE requirement SET ? WHERE id = ?", [fullUpdateObj, entityId]);
//         updateCount++;
//       }
//       else {
//         skipCount++;
//       }
//     }
 
 
 
//     // --- Detect and Handle Missing Parent Requirements ---
 
//     // 🔁 Recursively fetch and insert missing parents
//     await insertMissingParentsRecursively(columns);
//     const jsonPath = path.join(__dirname, '../../data/Requirementdatafile/MissingParentRequirements.json');
//     if (fs.existsSync(jsonPath)) {
//       await insertRequirementsFromJsonFile(jsonPath, columns);
//     }
//     else {
//       console.log("⚠️ Skipping insert from MissingParentRequirements.json because file does not exist.");
//     }
//   console.log(`✅ Requirement Normal Data - Inserted: ${insertCount}, Updated: ${updateCount}, Skipped: ${skipCount}`);
 
// // 🔹 Get the latest total count in 'requirement' table
// const [[{ totalCount }]] = await db.promise().query(
//   "SELECT COUNT(*) AS totalCount FROM requirement"
// );
 
// res.status(200).json({
//   success: true,
//   message: `Requirement data insert/update complete`,
//   stats: {
//     inserted: insertCount,
//     updated: updateCount,
//     skipped: skipCount,
//     totalCount
//   }
// });
 
 
//   } catch (error) {
//     console.error('Error inserting data:', error);
//     res.status(500).json({
//       success: false,
//       message: `Error inserting data: ${error.message}`
//     });
//   }
// };
 
 

// function processEntityFields(entity, columns) {
//   const reservedColumns = ['parent_id', 'type_id', 'name', 'has_link', 'has_attachment', 'last_modified', 'qtest_requirement_id', 'upload_status', 'comments', 'comment_Id'];

//   // Filter out reserved columns from mappings
//   const nonReservedColumns = columns.filter(col => !reservedColumns.includes(col.ep1_name.toLowerCase()));

//   const rowValues = nonReservedColumns.map(column => {
//     const columnName = column.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
//     const matchingField = entity.Fields.find(field =>
//       field.Name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase() === columnName
//     );

//     if (!matchingField || !matchingField.values || matchingField.values.length === 0) return null;

//     const combinedValue = matchingField.values.map(v => v.value).join(',');

//     switch (column.ep1_type) {
//       case 'Number':
//         return isNaN(Number(combinedValue)) ? null : Number(combinedValue);
//       case 'Date': {
//         const parsedDate = new Date(combinedValue);
//         return isNaN(parsedDate.getTime()) ? null : parsedDate.toISOString().split('T')[0];
//       }
//       case 'String':
//       default:
//         return combinedValue;
//     }
//   });

//   // Add metadata fields
//   const parentId = entity.Fields.find(f => f.Name === 'parent-id')?.values?.[0]?.value || null;
//   const typeId = entity.Fields.find(f => f.Name === 'type-id')?.values?.[0]?.value || null;
//   const name = entity.Fields.find(f => f.Name === 'name')?.values?.[0]?.value || null;
//   const has_link = entity.Fields.find(f => f.Name === 'has-linkage')?.values?.[0]?.value || null;
//   const has_attachment = entity.Fields.find(f => f.Name === 'attachment')?.values?.[0]?.value || null;
//   const last_modified = entity.Fields.find(f => f.Name === 'last-modified')?.values?.[0]?.value || null;
//   const upload_status = null; // keeps track of parse/validation failures
//   const attach_status = null; // keeps track of parse/validation failures
//   const comments = entity.Fields.find(f => f.Name === 'comments')?.values?.[0]?.value || null;
//   const comment_id = null;



//   rowValues.push(parentId, typeId, name, has_link, has_attachment, last_modified, upload_status, attach_status, comments, comment_id);

//   return rowValues;
// }

// function buildRowObjectFromValues(rowValues, columns) {
//   const reservedColumns = ['parent_id', 'type_id', 'name', 'has_link', 'has_attachment', 'last_modified', 'qtest_requirement_id', 'upload_status', 'comments', 'comment_Id'];
//   const nonReserved = columns.filter(col => !reservedColumns.includes(col.ep1_name.toLowerCase()));

//   const obj = {};

//   let index = 0;
//   for (const col of nonReserved) {
//     const dbCol = col.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
//     obj[dbCol] = rowValues[index++];
//   }

//   // Add reserved columns
//   reservedColumns.forEach((col, i) => {
//     obj[col] = rowValues[index + i];
//   });

//   return obj;
// }

// async function insertMissingParentsRecursively(columns) {
//   const authHeader = 'Basic ' + Buffer.from(`${almCredentials.username}:${almCredentials.password}`).toString('base64');
//   const login = await axios.post(`${almCredentials.almServerUrl}/api/authentication/sign-in`, {}, {
//     headers: { Authorization: authHeader },
//     withCredentials: true
//   });
//   const cookiesRawArray = login.headers['set-cookie'] || [];
//   const cookieMap = parseCookies(cookiesRawArray);
//   const cookieHeader = buildCookieHeader({
//     xsrfToken: cookieMap['XSRF-TOKEN'],
//     sessionCookie: cookieMap['JSESSIONID'],
//     lwssoCookie: cookieMap['LWSSO_COOKIE_KEY'],
//     almUser: cookieMap['ALM_USER'],
//     qcSession: cookieMap['QCSession']
//   });


//   const jsonPath = path.join(__dirname, '../../data/Requirementdatafile/MissingParentRequirements.json');
//   fs.writeFileSync(jsonPath, JSON.stringify({ entities: [] }, null, 2)); // clear file

//   const seenParents = new Set(); // ✅ track only what was successfully fetched

//   let round = 1;
//   let allFetchedEntities = [];

//   while (true) {
//     console.log(`🔁 Round ${round++}: Checking for missing parent requirements...`);

//     const [rows] = await db.promise().query("SELECT id, parent_id FROM requirement");
//     const existingIds = new Set(rows.map(r => r.id));
//     const parentIds = rows.map(r => r.parent_id).filter(pid => pid !== null && pid !== -1);

//     const missingParentIds = [...new Set(parentIds.filter(pid => !existingIds.has(pid)))];

//     const toFetch = missingParentIds.filter(pid => !seenParents.has(pid));

//     if (toFetch.length === 0) {
//       console.log("✅ No more parent IDs to fetch.");
//       break;
//     }

//     console.log(`🧩 Missing Parent IDs:`, toFetch);

//     let newEntitiesFetched = 0;

//     for (const parentId of toFetch) {
//       const chain = await fetchParentChainFromALM(parentId, cookieHeader, columns, seenParents);
//       ;



//       if (chain && chain.length > 0) {
//         seenParents.add(parentId);

//         // De-duplicate by requirement ID
//         const existingData = JSON.parse(fs.readFileSync(jsonPath, 'utf8'));
//         const existingIds = new Set(existingData.entities.map(e =>
//           e.Fields.find(f => f.Name === 'id')?.values?.[0]?.value
//         ));

//         const newEntities = chain.filter(entity => {
//           const entityId = entity.Fields.find(f => f.Name === 'id')?.values?.[0]?.value;
//           return !existingIds.has(entityId);
//         });

//         if (newEntities.length > 0) {
//           allFetchedEntities.push(...newEntities);
//           existingData.entities.push(...newEntities);
//           fs.writeFileSync(jsonPath, JSON.stringify(existingData, null, 2));
//         }
//       }

//     }



//     if (newEntitiesFetched === 0) {
//       console.warn(`⚠️ No new parent entities fetched. Breaking to avoid infinite loop.`);
//       break;
//     }
//   }
// }


// async function insertRequirementsFromJsonFile(jsonFilePath, columns) {
//   let jsonData;
//   try {
//     const fileContent = fs.readFileSync(jsonFilePath, 'utf8');
//     jsonData = JSON.parse(fileContent);
//   } catch (err) {
//     console.error(`❌ Failed to parse ${jsonFilePath}:`, err.message);
//     return;
//   }

//   if (!jsonData.entities || jsonData.entities.length === 0) {
//     console.log("⚠️ No entities found in JSON.");
//     return;
//   }

//   // Get existing requirement records from DB
//   // const [existingRows] = await db.promise().query(
//   //   "SELECT id, last_modified, upload_status FROM requirement"
//   // );
//   const [existingRows] = await db.promise().query("SELECT id, last_modified, upload_status, qtest_requirement_id FROM requirement");

//   const existingMap = new Map();
//   existingRows.forEach(row => {
//     existingMap.set(row.id, {
//       last_modified: row.last_modified ? new Date(row.last_modified).toISOString() : null,
//       upload_status: row.upload_status,
//       qtest_requirement_id: row.qtest_requirement_id
//     });
//   });

//   const insertRows = [];
//   const updateRows = [];

//   for (const entity of jsonData.entities) {
//     const rowValues = processEntityFields(entity, columns);
//     if (!rowValues) continue;

//     const entityId = parseInt(entity.Fields.find(f => f.Name === 'id')?.values?.[0]?.value);
//     const entityModified = entity.Fields.find(f => f.Name === 'last-modified')?.values?.[0]?.value;
//     const entityModifiedISO = entityModified ? new Date(entityModified).toISOString() : null;

//     const existing = existingMap.get(entityId);

//     if (!existing) {
//       insertRows.push({ id: entityId, values: rowValues });
//     }
//     // else if (existing.last_modified !== entityModifiedISO) {
//     //   if (['completed', 'uploaded'].includes(existing.upload_status)) {
//     //     rowValues[rowValues.length - 1] = 'changed'; // last column is upload_status
//     //   }
//     //   updateRows.push({ id: entityId, values: rowValues });
//     // }

//     else if (existing.last_modified !== entityModifiedISO) {
//       const qtestId = existing.qtest_requirement_id;
//       if (qtestId) {
//         rowValues[rowValues.length - 1] = 'modified';  // set status to modified
//         // Do NOT overwrite qtest_requirement_id
//       } else {
//         rowValues[rowValues.length - 1] = 'changed';   // set status to changed
//       }
//       updateRows.push({ id: entityId, values: rowValues });
//     }

//     else {
//       // Unchanged → skip
//       continue;
//     }
//   }

//   // Get valid column list
//   const [tableColumns] = await db.promise().query(
//     "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'requirement' AND TABLE_SCHEMA = DATABASE()"
//   );
//   const existingColumns = tableColumns.map(col => col.COLUMN_NAME.toLowerCase());
//   const reservedColumns = ['parent_id', 'type_id', 'name', 'has_link', 'has_attachment', 'last_modified', 'qtest_requirement_id', 'upload_status', 'comments', 'comment_Id'];

//   const columnNamesArray = columns
//     .filter(col => !reservedColumns.includes(col.ep1_name.toLowerCase()))
//     .map(col => col.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase())
//     .filter(colName => existingColumns.includes(colName))
//     .map(colName => `\`${colName}\``);

//   const validReservedColumns = reservedColumns.filter(col => existingColumns.includes(col));
//   const allColumnNames = [...columnNamesArray, ...validReservedColumns];
//   const totalColumns = allColumnNames.length;

//   const BATCH_SIZE = 100;

//   const runBatchInsert = async (batch) => {
//     const placeholders = batch.map(() => `(${new Array(totalColumns).fill('?').join(', ')})`).join(', ');
//     const adjustedBatch = batch.map(rowObj => {
//       const row = rowObj.values;
//       const adjustedRow = row.slice(0, columnNamesArray.length);
//       const reservedValues = row.slice(-7); // last 7 are reserved
//       validReservedColumns.forEach(col => {
//         const index = reservedColumns.indexOf(col);
//         adjustedRow.push(reservedValues[index]);
//       });
//       return adjustedRow;
//     });

//     const flatValues = adjustedBatch.flat();
//     const insertSQL = `
//       INSERT INTO requirement (${allColumnNames.join(', ')}) VALUES ${placeholders}
//       ON DUPLICATE KEY UPDATE
//       ${allColumnNames
//         .filter(col => col !== '`id`' && col !== '`qtest_requirement_id`' && col !== '`comment_Id`')
//         .map(col => `${col} = VALUES(${col})`)
//         .join(', ')}
//     `;
//     await db.promise().query(insertSQL, flatValues);
//   };

//   for (let i = 0; i < insertRows.length; i += BATCH_SIZE) {
//     const batch = insertRows.slice(i, i + BATCH_SIZE);
//     await runBatchInsert(batch);
//     console.log(`✅ Inserted ${batch.length} new parent requirements`);
//   }

//   for (let i = 0; i < updateRows.length; i += BATCH_SIZE) {
//     const batch = updateRows.slice(i, i + BATCH_SIZE);
//     await runBatchInsert(batch);
//     console.log(`✏️ Updated ${batch.length} modified parent requirements`);
//   }

//   console.log(`📦 Total missing parents processed: Inserted ${insertRows.length}, Updated ${updateRows.length}`);
// }

// const credentials = require("../../data/qTestCredentials.json");
// const almCredentials = require("../../data/AlmCredentials.json");



// let uploadStats = {
//   total: 0,
//   success: 0,
//   failed: 0,
//   skipped: 0,
//   updated: 0,
//   pending: 0
// };


// // const uploadRequirementToQTest = async (url, payload, requirementId) => {
// const uploadRequirementToQTest = async (url, payload, requirementId, uploadStatus, qTestId) => {

  

//   try {
//     let response;

    

//     const isUpdate = uploadStatus === 'modified' && qTestId;

//     if (isUpdate) {
//       const updateUrl = `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/requirements/${qTestId}`;
//       console.log(`🔁 Updating requirement ${requirementId} (qTest ID: ${qTestId})`);
//       response = await axios.put(updateUrl, payload, {
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${credentials.apiToken}`,
//         },
//       });
//     } else {
//       console.log(`➕ Creating requirement ${requirementId}`);
//       response = await axios.post(url, payload, {
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${credentials.apiToken}`,
//         },
//       });
//     }

//     await db.promise().query(
//       "UPDATE requirement SET upload_status = ?, qtest_requirement_id = ? WHERE id = ?",
//       ["completed", response.data.id, requirementId]
//     );

//     // uploadStats.success++;
//     // uploadStats.pending--;


//     if (isUpdate) {
//       uploadStats.updated++;
//     } else {
//       uploadStats.success++;
//     }
//     uploadStats.pending--;


     

//     return { success: true, qTestId: response.data.id };
//   } catch (error) {
//     const status = error.response?.status || "unknown_error";
//     const errorMessage = error.response?.data?.message || error.message;

//     await db.promise().query("UPDATE requirement SET upload_status = ? WHERE id = ?", [
//       `failed_${status}`,
//       requirementId,
//     ]);

//     uploadStats.failed++;
//     uploadStats.pending--;

//     return { success: false, error: errorMessage };
//   }
// };



// const processAndRequirementUploadAll = async (req, res) => {
//   try {
//     uploadStats = {
//       total: 0,
//       success: 0,
//       failed: 0,
//       skipped: 0,
//       updated: 0,
//       pending: 0
//     };

//     // ✅ Fetch mapping columns
//     const [mappingRow] = await db.promise().query("SELECT DISTINCT link_name FROM Field_mappings WHERE artifact_type = 'Requirement'");
//     const currentTable = mappingRow.length > 0 ? mappingRow[0].link_name : null;

//     if (!currentTable) throw new Error("No active mapping table found.");

//     const [mappings] = await db.promise().query(
//       "SELECT ep1_name, ep1_type, ep2_label, ep2_field_id FROM Field_mappings WHERE artifact_type = 'Requirement' AND link_name = ?",
//       [currentTable]
//     );

//     // console.log(`Found ${mappings.length} field mappings for Requirements`);

//     //const [rows] = await db.promise().query("SELECT * FROM requirement WHERE upload_status IS NULL OR upload_status LIKE 'failed%' OR upload_status = 'pending'");

//     const [rows] = await db.promise().query(
//       "SELECT * FROM requirement WHERE upload_status IS NULL OR upload_status LIKE 'failed%' OR upload_status = 'pending' OR upload_status = 'modified' OR upload_status = 'changed' OR upload_status = 'completed'"
//     );



//     uploadStats.total = rows.length;
//     uploadStats.pending = rows.length;

//     const idToQtestIdMap = {};
//     const allParentIds = new Set(rows.map(r => r.parent_id).filter(pid => pid !== null));

//     const outputPayloadPath = path.join(__dirname, '../../data/Requirementdatafile/RequirementfinalPayload.json');

//     let counter = 1;

//     for (let row of rows) {

//      if (row.upload_status === 'completed' && row.qtest_requirements_id) {
//         console.log(`⏭️ Skipping Requirement ID ${row.id} - already completed`);
//         uploadStats.skipped++;
//         uploadStats.pending--;
//         continue;
//       }


//       console.log(`🔄 Processing Requirement ${counter}/${rows.length} (ID: ${row.id})`);

//       let requirementName = `Requirement_${row.id}`;

//       if (row.name && row.name.trim() !== '') {
//         requirementName = row.name.trim();
//       }

//       // console.log(`📝 Requirement name: ${requirementName}`);

//       const properties = [];

//       // Process field mappings similar to releases
//       for (let mapping of mappings) {
//         const columnName = mapping.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
//         const rawValue = row[columnName];

//         // console.log(`🔍 Processing field: ${mapping.ep1_name} (${columnName}) = ${rawValue} (type: ${mapping.ep1_type})`);

//         if (rawValue === null || rawValue === undefined || rawValue === '') {
//           // console.log(`⚠️ Skipping empty value for ${columnName}`);
//           continue;
//         }

//         if (mapping.ep1_type === "LookupList") {
//           const valuesToCheck = typeof rawValue === 'string' ? rawValue.split(',').map(v => v.trim()) : [rawValue];

//           const [valueMappings] = await db.promise().query(`
//             SELECT ep1_value, ep2_value_id, ep2_value 
//             FROM value_mappings 
//             WHERE ep1_name = ? AND ep2_field_id = ?
//           `, [mapping.ep1_name, mapping.ep2_field_id]);

//           console.log(`🔎 Found ${valueMappings.length} value mappings for ${mapping.ep1_name}`);
//           const matchedEp2Ids = [];
//           const matchedEp2Names = [];

//           valuesToCheck.forEach(value => {
//             const match = valueMappings.find(vm => vm.ep1_value === value);
//             if (match) {
//               matchedEp2Ids.push(match.ep2_value_id);
//               matchedEp2Names.push(match.ep2_value);
//               console.log(`✅ Matched value: ${value} -> ${match.ep2_value_id} (${match.ep2_value})`);
//             } else {
//               console.log(`❌ No match found for value: ${value}`);
//             }
//           });

//           if (matchedEp2Ids.length > 0) {
//             const fieldValue = matchedEp2Ids.length === 1 ? matchedEp2Ids[0] : matchedEp2Ids;
//             const fieldValueName = matchedEp2Names.length === 1 ? matchedEp2Names[0] : matchedEp2Names;

//             properties.push({
//               field_id: mapping.ep2_field_id,
//               field_name: mapping.ep2_label,
//               field_value: Array.isArray(fieldValue) ? JSON.stringify(fieldValue) : fieldValue,
//               field_value_name: Array.isArray(fieldValueName) ? JSON.stringify(fieldValueName) : fieldValueName
//             });
//             // console.log(`✅ Added LookupList property: ${mapping.ep2_label} = ${fieldValue}`);
//           }
//         } else if (mapping.ep1_type === "UsersList") {
//           const valuesToCheck = typeof rawValue === 'string' ? rawValue.split(',').map(v => v.trim()) : [rawValue];

//           const [valueMappings] = await db.promise().query(`
//             SELECT ep1_value, ep2_value_id, ep2_value 
//             FROM value_mappings 
//             WHERE ep1_name = ? AND ep2_field_id = ?
//           `, [mapping.ep1_name, mapping.ep2_field_id]);

//           console.log(`🔎 Found ${valueMappings.length} user mappings for ${mapping.ep1_name}`);
//           const matchedEp2Ids = [];
//           const matchedEp2Names = [];

//           valuesToCheck.forEach(value => {
//             const match = valueMappings.find(vm => vm.ep1_value === value);
//             if (match) {
//               matchedEp2Ids.push(match.ep2_value_id);
//               matchedEp2Names.push(match.ep2_value);
//               console.log(`✅ Matched user: ${value} -> ${match.ep2_value_id} (${match.ep2_value})`);
//             } else {
//               console.log(`❌ No match found for user: ${value}`);
//             }
//           });

//           if (matchedEp2Ids.length > 0) {
//             properties.push({
//               field_id: mapping.ep2_field_id,
//               field_name: mapping.ep2_label,
//               field_value: JSON.stringify(matchedEp2Ids),
//               field_value_name: JSON.stringify(matchedEp2Names)
//             });
//             // console.log(`✅ Added UsersList property: ${mapping.ep2_label} = ${matchedEp2Ids}`);
//           }
//         } else {
//           // Handle other field types (String, Number, Date, etc.)
//           let processedValue = rawValue;

//           if (mapping.ep1_type === 'Number') {
//             processedValue = isNaN(Number(rawValue)) ? null : Number(rawValue);
//           } else if (mapping.ep1_type === 'Date') {
//             const parsedDate = new Date(rawValue);
//             processedValue = formatDateForQTest(parsedDate);
//           } else if (mapping.ep1_type === 'String') {
//             processedValue = String(rawValue).trim();
//           }

//           if (processedValue !== null && processedValue !== '') {
//             properties.push({
//               field_id: mapping.ep2_field_id,
//               field_name: mapping.ep2_label,
//               field_value: processedValue
//             });
//             // console.log(`✅ Added ${mapping.ep1_type} property: ${mapping.ep2_label} = ${processedValue}`);
//           }
//         }
//       }

//       // console.log(`📊 Total properties created: ${properties.length}`);

//       // Validate requirement name
//       if (!requirementName || requirementName.trim() === '' || requirementName === 'Requirement_') {
//         console.error(`❌ Skipping requirement with invalid name: ${row.id}`);
//         await db.promise().query("UPDATE requirement SET upload_status = ? WHERE id = ?", ['failed_no_name', row.id]);
//         uploadStats.skipped++;
//         uploadStats.pending--;
//         continue;
//       }

//       const parentId = row.parent_id;
//       const qtestParentId = idToQtestIdMap[parentId];

//       let url = "";
//       let payload = {};

//       const rowId = row.id;
//       const rowParentId = row.parent_id;

//       if (rowId === 0 && rowParentId === -1) {
//         // Root-level module
//         url = `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/modules`;
//         payload = {
//           name: requirementName,
//           description: row.description || ""
//         };
//       } else if (allParentIds.has(rowId)) {
//         // Module under module
//         if (!qtestParentId) {
//           console.warn(`⚠️ Skipping module ${requirementName} due to missing parent qTest ID`);
//           uploadStats.skipped++;
//           uploadStats.pending--;
//           continue;
//         }
//         url = `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/modules?parentId=${qtestParentId}`;
//         payload = {
//           name: requirementName,
//           description: row.description || ""
//         };
//       } else {
//         // Regular requirement with properties
//         url = `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/requirements`;
//         payload = {
//           name: requirementName.trim(),
//           properties: properties,
//           ...(row.description ? { description: row.description } : {}),
//           ...(qtestParentId ? { parent_id: qtestParentId } : {})
//         };
//       }

//       // console.log(`📋 Final payload:`, JSON.stringify(payload, null, 2));

//       // Write payload to file
//       fs.writeFileSync(outputPayloadPath, JSON.stringify(payload, null, 2), 'utf8');

//       //const result = await uploadRequirementToQTest(url, payload, row.id);

//       const result = await uploadRequirementToQTest(url, payload, row.id, row.upload_status, row.qtest_requirement_id);


//       if (result.success) {
//         idToQtestIdMap[row.id] = result.qTestId;
//         // console.log(`✅ Uploaded ${row.name}`);
//       } else {
//         console.error(`❌ Failed to upload ${row.name}: ${result.error}`);
//       }
//     }
//     res.json({ message: "Migration completed", counts: uploadStats });

//   } catch (err) {
//     console.error("❌ Error during requirement upload:", err.message);
//     res.status(500).json({ error: err.message });
//   }
// };



// const getRequirementMigrationStatus = async (req, res) => {

//   try {

//     res.json({ counts: uploadStats });

//   } catch (error) {

//     console.error("❌ Error getting requirement migration status:", error.message);

//     res.status(500).json({

//       message: "Error getting requirement migration status",

//       error: error.message

//     });

//   }

// };

// module.exports = {
//   RequirementinsertSampleData,
//   processAndRequirementUploadAll,
//   getRequirementMigrationStatus,
// };



 
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const db = require("../../config/db");
 
 
const parseCookies = (cookieArray) => {
  const cookieMap = {};
  cookieArray.forEach(cookie => {
    const [cookiePair] = cookie.split(';');
    const [name, value] = cookiePair.split('=');
    cookieMap[name.trim()] = value;
  });
  return cookieMap;
};
 
const buildCookieHeader = ({ xsrfToken, sessionCookie, lwssoCookie, almUser, qcSession }) => {
  return `XSRF-TOKEN=${xsrfToken}; JSESSIONID=${sessionCookie}; LWSSO_COOKIE_KEY=${lwssoCookie}; ALM_USER=${almUser}; QCSession=${qcSession}`;
};
 
 
// 👇 Paste this right below the require(...) statements
async function fetchParentChainFromALM(startId, cookieHeader, columns, seen = new Set()) {
  const parentEntities = [];
  let currentId = startId;
 
  while (currentId !== null && !seen.has(currentId)) {
    if (parseInt(currentId) < 0) break;
 
    seen.add(currentId);
    console.log(`🌐 Trying to fetch ALM requirement ID: ${currentId}`);
 
    const url = `${almCredentials.almServerUrl}/rest/domains/${almCredentials.domain}/projects/${almCredentials.project}/requirements/${currentId}`;
 
    try {
      const { data } = await axios.get(url, {
        headers: {
          Accept: 'application/json',
          Cookie: cookieHeader
        }
      });
 
      if (!data?.Fields || !Array.isArray(data.Fields)) {
        console.warn(`⚠️ Unexpected or empty data for ID: ${currentId}`);
        break;
      }
 
      parentEntities.push({ Fields: data.Fields }); // keep structure consistent
      console.log(`✅ Fetched entity ID: ${currentId}`);
 
      const parentIdField = data.Fields.find(f => f.Name === 'parent-id');
 
      currentId = parentIdField?.values?.[0]?.value ?? null;
 
      if (parseInt(currentId) === 0) {
        seen.add(currentId);
        console.log(`🌐 Fetching root ID: 0`);
 
        const rootUrl = `${almCredentials.almServerUrl}/rest/domains/${almCredentials.domain}/projects/${almCredentials.project}/requirements/0`;
        const rootData = await axios.get(rootUrl, {
          headers: { Accept: 'application/json', Cookie: cookieHeader }
        });
 
        if (rootData?.data?.Fields) {
          parentEntities.push({ Fields: rootData.data.Fields });
          console.log(`✅ Fetched root entity ID: 0`);
        }
        break;
      }
 
 
    } catch (err) {
      console.error(`❌ Failed to fetch parent ID ${currentId}:`, err.response?.status, err.response?.data || err.message);
      break;
    }
  }
 
  return parentEntities;
}
 
// const RequirementinsertSampleData = async (req, res) => {
//   try {
//     const [columns] = await db.promise().query(
//       "SELECT ep1_name, ep1_type, ep2_field_id FROM Field_mappings WHERE artifact_type='Requirement'"
//     );
 
//     if (!columns || columns.length === 0) {
//       return res.status(400).json({
//         success: false,
//         message: "No mapping columns found. Please create mappings first."
//       });
//     }
 
//     const jsonFilePath = path.join(__dirname, '../../data/Requirementdatafile/ALMRequirement.json');
//     if (!fs.existsSync(jsonFilePath)) {
//       return res.status(404).json({
//         success: false,
//         message: `JSON file not found at: ${jsonFilePath}`
//       });
//     }
 
//     const jsonData = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'));
 
//     //const [existingRows] = await db.promise().query("SELECT id, last_modified, upload_status FROM requirement");
 
 
//     const [existingRows] = await db.promise().query("SELECT id, last_modified, upload_status, qtest_requirement_id FROM requirement");
 
 
//     const existingMap = new Map();
//     existingRows.forEach(row => {
//       existingMap.set(row.id, {
//         last_modified: row.last_modified ? new Date(row.last_modified).toISOString() : null,
//         upload_status: row.upload_status,
//         qtest_requirement_id: row.qtest_requirement_id
//       });
//     });
 
 
//     // Truncate the 'requirement' table before inserting
//     // await db.promise().query("TRUNCATE TABLE requirement");
 
//     const allRowsToInsert = [];
 
//     let insertCount = 0;
//     let updateCount = 0;
//     let skipCount = 0;
 
//     const insertRows = [];
//     const updateRows = [];
 
//     for (const entity of jsonData.entities) {
//       const rowValues = processEntityFields(entity, columns);
//       if (!rowValues) continue;
 
//       const entityId = parseInt(entity.Fields.find(f => f.Name === 'id')?.values?.[0]?.value);
//       const entityModified = entity.Fields.find(f => f.Name === 'last-modified')?.values?.[0]?.value;
//       const entityModifiedISO = entityModified ? new Date(entityModified).toISOString() : null;
 
//       const existing = existingMap.get(entityId);
 
//       if (!existing) {
//         insertRows.push({ id: entityId, values: rowValues });
//         insertCount++;
//       } else if (existing.last_modified !== entityModifiedISO) {
//         if (['completed', 'uploaded'].includes(existing.upload_status)) {
//           rowValues[rowValues.length - 1] = 'changed'; // set upload_status
//         }
//         updateRows.push({ id: entityId, values: rowValues, existingStatus: existing.upload_status });
//         updateCount++;
//       } else {
//         skipCount++;
//       }
//     }
 
 
 
 
//     if (insertRows.length === 0 && updateRows.length === 0) {
//       return res.status(200).json({
//         success: true,
//         message: '✅ All requirements are already up-to-date. No insert/update needed.',
//         stats: {
//           inserted: 0,
//           updated: 0,
//           skipped: jsonData.entities.length
//         }
//       });
//     }
 
//     // Get actual table columns to verify they exist
//     const [tableColumns] = await db.promise().query(
//       "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'requirement' AND TABLE_SCHEMA = DATABASE()"
//     );
 
//     const existingColumns = tableColumns.map(col => col.COLUMN_NAME.toLowerCase());
 
//     // Filter out reserved columns and prepare column names
//     const reservedColumns = ['parent_id', 'type_id', 'name', 'has_link', 'has_attachment', 'last_modified', 'qtest_requirement_id', 'upload_status', 'comments', 'comment_Id'];
 
//     // Only include columns that actually exist in the database
//     const columnNamesArray = columns
//       .filter(col => !reservedColumns.includes(col.ep1_name.toLowerCase()))
//       .map(col => col.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase())
//       .filter(colName => existingColumns.includes(colName))
//       .map(colName => `\`${colName}\``);
 
//     // Also verify reserved columns exist before including them
//     const validReservedColumns = reservedColumns.filter(col => existingColumns.includes(col));
 
//     const allColumnNames = [
//       ...columnNamesArray,
//       ...validReservedColumns
//     ].join(', ');
 
//     const BATCH_SIZE = 100;
//     let insertedCount = 0;
 
 
//     for (const entity of jsonData.entities) {
//       const rowValues = processEntityFields(entity, columns);
//       if (!rowValues) continue;
 
//       const entityId = parseInt(entity.Fields.find(f => f.Name === 'id')?.values?.[0]?.value);
//       const entityModified = entity.Fields.find(f => f.Name === 'last-modified')?.values?.[0]?.value;
//       const entityModifiedISO = entityModified ? new Date(entityModified).toISOString() : null;
 
//       const existing = existingMap.get(entityId);
 
//       if (!existing) {
//         // Insert new row
//         const insertObj = buildRowObjectFromValues(rowValues, columns);
//         insertObj.id = entityId;
 
//         await db.promise().query("INSERT INTO requirement SET ?", [insertObj]);
//         insertCount++;
 
//       }
 
//      else if (existing.last_modified !== entityModifiedISO) {
//         // Update only if last_modified differs
//         const fullUpdateObj = buildRowObjectFromValues(rowValues, columns);
//         fullUpdateObj.id = entityId;
 
//         // Determine new status (based only on qtest_requirement_id)
//         fullUpdateObj.upload_status = existing.qtest_requirement_id ? 'modified' : 'changed';
 
//         // Do NOT overwrite qtest_requirement_id
//         delete fullUpdateObj.qtest_requirement_id;
//         delete fullUpdateObj.comment_Id;
//         await db.promise().query("UPDATE requirement SET ? WHERE id = ?", [fullUpdateObj, entityId]);
//         updateCount++;
//       }
//       else {
//         skipCount++;
//       }
//     }
 
 
 
//     // --- Detect and Handle Missing Parent Requirements ---
 
//     // 🔁 Recursively fetch and insert missing parents
//     await insertMissingParentsRecursively(columns);
//     const jsonPath = path.join(__dirname, '../../data/Requirementdatafile/MissingParentRequirements.json');
//     if (fs.existsSync(jsonPath)) {
//       await insertRequirementsFromJsonFile(jsonPath, columns);
//     }
//     else {
//       console.log("⚠️ Skipping insert from MissingParentRequirements.json because file does not exist.");
//     }
 
 
//     console.log(`✅ Requirement Normal Data - Inserted: ${insertCount}, Updated: ${updateCount}, Skipped: ${skipCount}`);
 
//     const [[{ totalCount }]] = await db.promise().query(
//       "SELECT COUNT(*) AS totalCount FROM requirement"
//     );
 
//     res.status(200).json({
//       success: true,
//       message: `Requirement data insert/update complete`,
//       stats: {
//         inserted: insertCount,
//         updated: updateCount,
//         skipped: skipCount,
//         totalCount
//       }
//     });
 
 
//   } catch (error) {
//     console.error('Error inserting data:', error);
//     res.status(500).json({
//       success: false,
//       message: `Error inserting data: ${error.message}`
//     });
//   }
// };
 
const RequirementinsertSampleData = async (req, res) => {
  try {
    const [columns] = await db.promise().query(
      "SELECT ep1_name, ep1_type, ep2_field_id FROM Field_mappings WHERE artifact_type='Requirement'"
    );
 
    if (!columns || columns.length === 0) {
      return res.status(400).json({
        success: false,
        message: "No mapping columns found. Please create mappings first."
      });
    }
 
    const jsonFilePath = path.join(__dirname, '../../data/Requirementdatafile/ALMRequirement.json');
    if (!fs.existsSync(jsonFilePath)) {
      return res.status(404).json({
        success: false,
        message: `JSON file not found at: ${jsonFilePath}`
      });
    }
 
    const jsonData = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'));
 
    //const [existingRows] = await db.promise().query("SELECT id, last_modified, upload_status FROM requirement");
 
 
    const [existingRows] = await db.promise().query("SELECT id, last_modified, upload_status, qtest_requirement_id FROM requirement");
 
 
    const existingMap = new Map();
    existingRows.forEach(row => {
      existingMap.set(row.id, {
        last_modified: row.last_modified ? new Date(row.last_modified).toISOString() : null,
        upload_status: row.upload_status,
        qtest_requirement_id: row.qtest_requirement_id
      });
    });
 
 
    // Truncate the 'requirement' table before inserting
    // await db.promise().query("TRUNCATE TABLE requirement");
 
    const allRowsToInsert = [];
 
    let insertCount = 0;
    let updateCount = 0;
    let skipCount = 0;
 
    const insertRows = [];
    const updateRows = [];
 
    for (const entity of jsonData.entities) {
      const rowValues = processEntityFields(entity, columns);
      if (!rowValues) continue;
 
      const entityId = parseInt(entity.Fields.find(f => f.Name === 'id')?.values?.[0]?.value);
      const entityModified = entity.Fields.find(f => f.Name === 'last-modified')?.values?.[0]?.value;
      const entityModifiedISO = entityModified ? new Date(entityModified).toISOString() : null;
 
      const existing = existingMap.get(entityId);
 
      if (!existing) {
        insertRows.push({ id: entityId, values: rowValues });
        insertCount++;
      } else if (existing.last_modified !== entityModifiedISO) {
        if (['completed', 'uploaded'].includes(existing.upload_status)) {
          rowValues[rowValues.length - 1] = 'changed'; // set upload_status
        }
        updateRows.push({ id: entityId, values: rowValues, existingStatus: existing.upload_status });
        updateCount++;
      } else {
        skipCount++;
      }
    }
 
    if (insertRows.length === 0 && updateRows.length === 0) {
      // 🔹 Get the latest total count in 'requirement' table
      const [[{ totalCount }]] = await db.promise().query(
        "SELECT COUNT(*) AS totalCount FROM requirement"
      );
 
      return res.status(200).json({
        success: true,
        message: '✅ All requirements are already up-to-date. No insert/update needed.',
        stats: {
          inserted: 0,
          updated: 0,
          skipped: jsonData.entities.length,
          totalCount
        }
      });
    }
    // Get actual table columns to verify they exist
    const [tableColumns] = await db.promise().query(
      "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'requirement' AND TABLE_SCHEMA = DATABASE()"
    );
 
    const existingColumns = tableColumns.map(col => col.COLUMN_NAME.toLowerCase());
 
    // Filter out reserved columns and prepare column names
    const reservedColumns = ['parent_id', 'type_id', 'name', 'has_link', 'has_attachment', 'last_modified', 'qtest_requirement_id', 'upload_status', 'comments', 'comment_Id'];
 
    // Only include columns that actually exist in the database
    const columnNamesArray = columns
      .filter(col => !reservedColumns.includes(col.ep1_name.toLowerCase()))
      .map(col => col.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase())
      .filter(colName => existingColumns.includes(colName))
      .map(colName => `\`${colName}\``);
 
    // Also verify reserved columns exist before including them
    const validReservedColumns = reservedColumns.filter(col => existingColumns.includes(col));
 
    const allColumnNames = [
      ...columnNamesArray,
      ...validReservedColumns
    ].join(', ');
 
    const BATCH_SIZE = 100;
    let insertedCount = 0;
 
 
    for (const entity of jsonData.entities) {
      const rowValues = processEntityFields(entity, columns);
      if (!rowValues) continue;
 
      const entityId = parseInt(entity.Fields.find(f => f.Name === 'id')?.values?.[0]?.value);
      const entityModified = entity.Fields.find(f => f.Name === 'last-modified')?.values?.[0]?.value;
      const entityModifiedISO = entityModified ? new Date(entityModified).toISOString() : null;
 
      const existing = existingMap.get(entityId);
 
      if (!existing) {
        // Insert new row
        const insertObj = buildRowObjectFromValues(rowValues, columns);
        insertObj.id = entityId;
 
        await db.promise().query("INSERT INTO requirement SET ?", [insertObj]);
        insertCount++;
 
      }
 
 
      else if (existing.last_modified !== entityModifiedISO) {
        // Update only if last_modified differs
        const fullUpdateObj = buildRowObjectFromValues(rowValues, columns);
        fullUpdateObj.id = entityId;
 
        // Determine new status (based only on qtest_requirement_id)
        fullUpdateObj.upload_status = existing.qtest_requirement_id ? 'modified' : 'changed';
 
        // Do NOT overwrite qtest_requirement_id
        delete fullUpdateObj.qtest_requirement_id;
        delete fullUpdateObj.comment_Id;
        await db.promise().query("UPDATE requirement SET ? WHERE id = ?", [fullUpdateObj, entityId]);
        updateCount++;
      }
      else {
        skipCount++;
      }
    }
 
 
 
    // --- Detect and Handle Missing Parent Requirements ---
 
    // 🔁 Recursively fetch and insert missing parents
    await insertMissingParentsRecursively(columns);
    const jsonPath = path.join(__dirname, '../../data/Requirementdatafile/MissingParentRequirements.json');
    if (fs.existsSync(jsonPath)) {
      await insertRequirementsFromJsonFile(jsonPath, columns);
    }
    else {
      console.log("⚠️ Skipping insert from MissingParentRequirements.json because file does not exist.");
    }
    console.log(`✅ Requirement Normal Data - Inserted: ${insertCount}, Updated: ${updateCount}, Skipped: ${skipCount}`);
 
    // 🔹 Get the latest total count in 'requirement' table
    const [[{ totalCount }]] = await db.promise().query(
      "SELECT COUNT(*) AS totalCount FROM requirement"
    );
 
    res.status(200).json({
      success: true,
      message: `Requirement data insert/update complete`,
      stats: {
        inserted: insertCount,
        updated: updateCount,
        skipped: skipCount,
        totalCount
      }
    });
 
 
  } catch (error) {
    console.error('Error inserting data:', error);
    res.status(500).json({
      success: false,
      message: `Error inserting data: ${error.message}`
    });
  }
};
 
 
 
function processEntityFields(entity, columns) {
  const reservedColumns = ['parent_id', 'type_id', 'name', 'has_link', 'has_attachment', 'last_modified', 'qtest_requirement_id', 'upload_status', 'comments', 'comment_Id'];
 
  // Filter out reserved columns from mappings
  const nonReservedColumns = columns.filter(col => !reservedColumns.includes(col.ep1_name.toLowerCase()));
 
  const rowValues = nonReservedColumns.map(column => {
    const columnName = column.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
    const matchingField = entity.Fields.find(field =>
      field.Name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase() === columnName
    );
 
    if (!matchingField || !matchingField.values || matchingField.values.length === 0) return null;
 
    const combinedValue = matchingField.values.map(v => v.value).join(',');
 
    switch (column.ep1_type) {
      case 'Number':
        return isNaN(Number(combinedValue)) ? null : Number(combinedValue);
      case 'Date': {
        const parsedDate = new Date(combinedValue);
        return isNaN(parsedDate.getTime()) ? null : parsedDate.toISOString().split('T')[0];
      }
      case 'String':
      default:
        return combinedValue;
    }
  });
 
  // Add metadata fields
  const parentId = entity.Fields.find(f => f.Name === 'parent-id')?.values?.[0]?.value || null;
  const typeId = entity.Fields.find(f => f.Name === 'type-id')?.values?.[0]?.value || null;
  const name = entity.Fields.find(f => f.Name === 'name')?.values?.[0]?.value || null;
  const has_link = entity.Fields.find(f => f.Name === 'has-linkage')?.values?.[0]?.value || null;
  const has_attachment = entity.Fields.find(f => f.Name === 'attachment')?.values?.[0]?.value || null;
  const last_modified = entity.Fields.find(f => f.Name === 'last-modified')?.values?.[0]?.value || null;
  const upload_status = null; // keeps track of parse/validation failures
  const attach_status = null; // keeps track of parse/validation failures
  const comments = entity.Fields.find(f => f.Name === 'comments')?.values?.[0]?.value || null;
  const comment_id = null;
 
 
 
  rowValues.push(parentId, typeId, name, has_link, has_attachment, last_modified, upload_status, attach_status, comments, comment_id);
 
  return rowValues;
}
 
function buildRowObjectFromValues(rowValues, columns) {
  const reservedColumns = ['parent_id', 'type_id', 'name', 'has_link', 'has_attachment', 'last_modified', 'qtest_requirement_id', 'upload_status', 'comments', 'comment_Id'];
  const nonReserved = columns.filter(col => !reservedColumns.includes(col.ep1_name.toLowerCase()));
 
  const obj = {};
 
  let index = 0;
  for (const col of nonReserved) {
    const dbCol = col.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
    obj[dbCol] = rowValues[index++];
  }
 
  // Add reserved columns
  reservedColumns.forEach((col, i) => {
    obj[col] = rowValues[index + i];
  });
 
  return obj;
}
 
async function insertMissingParentsRecursively(columns) {
  const authHeader = 'Basic ' + Buffer.from(`${almCredentials.username}:${almCredentials.password}`).toString('base64');
  const login = await axios.post(`${almCredentials.almServerUrl}/api/authentication/sign-in`, {}, {
    headers: { Authorization: authHeader },
    withCredentials: true
  });
  const cookiesRawArray = login.headers['set-cookie'] || [];
  const cookieMap = parseCookies(cookiesRawArray);
  const cookieHeader = buildCookieHeader({
    xsrfToken: cookieMap['XSRF-TOKEN'],
    sessionCookie: cookieMap['JSESSIONID'],
    lwssoCookie: cookieMap['LWSSO_COOKIE_KEY'],
    almUser: cookieMap['ALM_USER'],
    qcSession: cookieMap['QCSession']
  });
 
 
  const jsonPath = path.join(__dirname, '../../data/Requirementdatafile/MissingParentRequirements.json');
  fs.writeFileSync(jsonPath, JSON.stringify({ entities: [] }, null, 2)); // clear file
 
  const seenParents = new Set(); // ✅ track only what was successfully fetched
 
  let round = 1;
  let allFetchedEntities = [];
 
  while (true) {
    console.log(`🔁 Round ${round++}: Checking for missing parent requirements...`);
 
    const [rows] = await db.promise().query("SELECT id, parent_id FROM requirement");
    const existingIds = new Set(rows.map(r => r.id));
    const parentIds = rows.map(r => r.parent_id).filter(pid => pid !== null && pid !== -1);
 
    const missingParentIds = [...new Set(parentIds.filter(pid => !existingIds.has(pid)))];
 
    const toFetch = missingParentIds.filter(pid => !seenParents.has(pid));
 
    if (toFetch.length === 0) {
      console.log("✅ No more parent IDs to fetch.");
      break;
    }
 
    console.log(`🧩 Missing Parent IDs:`, toFetch);
 
    let newEntitiesFetched = 0;
 
    for (const parentId of toFetch) {
      const chain = await fetchParentChainFromALM(parentId, cookieHeader, columns, seenParents);
      ;
 
 
 
      if (chain && chain.length > 0) {
        seenParents.add(parentId);
 
        // De-duplicate by requirement ID
        const existingData = JSON.parse(fs.readFileSync(jsonPath, 'utf8'));
        const existingIds = new Set(existingData.entities.map(e =>
          e.Fields.find(f => f.Name === 'id')?.values?.[0]?.value
        ));
 
        const newEntities = chain.filter(entity => {
          const entityId = entity.Fields.find(f => f.Name === 'id')?.values?.[0]?.value;
          return !existingIds.has(entityId);
        });
 
        if (newEntities.length > 0) {
          allFetchedEntities.push(...newEntities);
          existingData.entities.push(...newEntities);
          fs.writeFileSync(jsonPath, JSON.stringify(existingData, null, 2));
        }
      }
 
    }
 
 
 
    if (newEntitiesFetched === 0) {
      console.warn(`⚠️ No new parent entities fetched. Breaking to avoid infinite loop.`);
      break;
    }
  }
}
 
 
async function insertRequirementsFromJsonFile(jsonFilePath, columns) {
  let jsonData;
  try {
    const fileContent = fs.readFileSync(jsonFilePath, 'utf8');
    jsonData = JSON.parse(fileContent);
  } catch (err) {
    console.error(`❌ Failed to parse ${jsonFilePath}:`, err.message);
    return;
  }
 
  if (!jsonData.entities || jsonData.entities.length === 0) {
    console.log("⚠️ No entities found in JSON.");
    return;
  }
 
  // Get existing requirement records from DB
  // const [existingRows] = await db.promise().query(
  //   "SELECT id, last_modified, upload_status FROM requirement"
  // );
  const [existingRows] = await db.promise().query("SELECT id, last_modified, upload_status, qtest_requirement_id FROM requirement");
 
  const existingMap = new Map();
  existingRows.forEach(row => {
    existingMap.set(row.id, {
      last_modified: row.last_modified ? new Date(row.last_modified).toISOString() : null,
      upload_status: row.upload_status,
      qtest_requirement_id: row.qtest_requirement_id
    });
  });
 
  const insertRows = [];
  const updateRows = [];
 
  for (const entity of jsonData.entities) {
    const rowValues = processEntityFields(entity, columns);
    if (!rowValues) continue;
 
    const entityId = parseInt(entity.Fields.find(f => f.Name === 'id')?.values?.[0]?.value);
    const entityModified = entity.Fields.find(f => f.Name === 'last-modified')?.values?.[0]?.value;
    const entityModifiedISO = entityModified ? new Date(entityModified).toISOString() : null;
 
    const existing = existingMap.get(entityId);
 
    if (!existing) {
      insertRows.push({ id: entityId, values: rowValues });
    }
    // else if (existing.last_modified !== entityModifiedISO) {
    //   if (['completed', 'uploaded'].includes(existing.upload_status)) {
    //     rowValues[rowValues.length - 1] = 'changed'; // last column is upload_status
    //   }
    //   updateRows.push({ id: entityId, values: rowValues });
    // }
 
    else if (existing.last_modified !== entityModifiedISO) {
      const qtestId = existing.qtest_requirement_id;
      if (qtestId) {
        rowValues[rowValues.length - 1] = 'modified';  // set status to modified
        // Do NOT overwrite qtest_requirement_id
      } else {
        rowValues[rowValues.length - 1] = 'changed';   // set status to changed
      }
      updateRows.push({ id: entityId, values: rowValues });
    }
 
    else {
      // Unchanged → skip
      continue;
    }
  }
 
  // Get valid column list
  const [tableColumns] = await db.promise().query(
    "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'requirement' AND TABLE_SCHEMA = DATABASE()"
  );
  const existingColumns = tableColumns.map(col => col.COLUMN_NAME.toLowerCase());
  const reservedColumns = ['parent_id', 'type_id', 'name', 'has_link', 'has_attachment', 'last_modified', 'qtest_requirement_id', 'upload_status', 'comments', 'comment_Id'];
 
  const columnNamesArray = columns
    .filter(col => !reservedColumns.includes(col.ep1_name.toLowerCase()))
    .map(col => col.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase())
    .filter(colName => existingColumns.includes(colName))
    .map(colName => `\`${colName}\``);
 
  const validReservedColumns = reservedColumns.filter(col => existingColumns.includes(col));
  const allColumnNames = [...columnNamesArray, ...validReservedColumns];
  const totalColumns = allColumnNames.length;
 
  const BATCH_SIZE = 100;
 
  const runBatchInsert = async (batch) => {
    const placeholders = batch.map(() => `(${new Array(totalColumns).fill('?').join(', ')})`).join(', ');
    const adjustedBatch = batch.map(rowObj => {
      const row = rowObj.values;
      const adjustedRow = row.slice(0, columnNamesArray.length);
      const reservedValues = row.slice(-7); // last 7 are reserved
      validReservedColumns.forEach(col => {
        const index = reservedColumns.indexOf(col);
        adjustedRow.push(reservedValues[index]);
      });
      return adjustedRow;
    });
 
    const flatValues = adjustedBatch.flat();
    const insertSQL = `
      INSERT INTO requirement (${allColumnNames.join(', ')}) VALUES ${placeholders}
      ON DUPLICATE KEY UPDATE
      ${allColumnNames
        .filter(col => col !== '`id`' && col !== '`qtest_requirement_id`' && col !== '`comment_Id`')
        .map(col => `${col} = VALUES(${col})`)
        .join(', ')}
    `;
    await db.promise().query(insertSQL, flatValues);
  };
 
  for (let i = 0; i < insertRows.length; i += BATCH_SIZE) {
    const batch = insertRows.slice(i, i + BATCH_SIZE);
    await runBatchInsert(batch);
    console.log(`✅ Inserted ${batch.length} new parent requirements`);
  }
 
  for (let i = 0; i < updateRows.length; i += BATCH_SIZE) {
    const batch = updateRows.slice(i, i + BATCH_SIZE);
    await runBatchInsert(batch);
    console.log(`✏️ Updated ${batch.length} modified parent requirements`);
  }
 
  console.log(`📦 Total missing parents processed: Inserted ${insertRows.length}, Updated ${updateRows.length}`);
}
 
const credentials = require("../../data/qTestCredentials.json");
const almCredentials = require("../../data/AlmCredentials.json");
 
 
 
let uploadStats = {
  total: 0,
  success: 0,
  failed: 0,
  skipped: 0,
  updated: 0,
  pending: 0
};
 
 
// const uploadRequirementToQTest = async (url, payload, requirementId) => {
// const uploadRequirementToQTest = async (url, payload, requirementId, uploadStatus, qTestId) => {
 
 
 
//   try {
//     let response;
 
 
 
//     const isUpdate = uploadStatus === 'modified' && qTestId;
 
//     if (isUpdate) {
//       const updateUrl = `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/requirements/${qTestId}`;
//       console.log(`🔁 Updating requirement ${requirementId} (qTest ID: ${qTestId})`);
//       response = await axios.put(updateUrl, payload, {
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${credentials.apiToken}`,
//         },
//       });
//     } else {
//       console.log(`➕ Creating requirement ${requirementId}`);
//       response = await axios.post(url, payload, {
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${credentials.apiToken}`,
//         },
//       });
//     }
 
//     await db.promise().query(
//       "UPDATE requirement SET upload_status = ?, qtest_requirement_id = ? WHERE id = ?",
//       ["completed", response.data.id, requirementId]
//     );
 
//     // uploadStats.success++;
//     // uploadStats.pending--;
 
 
//     if (isUpdate) {
//       uploadStats.updated++;
//     } else {
//       uploadStats.success++;
//     }
//     uploadStats.pending--;
 
 
 
 
//     return { success: true, qTestId: response.data.id };
//   } catch (error) {
//     const status = error.response?.status || "unknown_error";
//     const errorMessage = error.response?.data?.message || error.message;
 
//     await db.promise().query("UPDATE requirement SET upload_status = ? WHERE id = ?", [
//       `failed_${status}`,
//       requirementId,
//     ]);
 
//     uploadStats.failed++;
//     uploadStats.pending--;
 
//     return { success: false, error: errorMessage };
//   }
// };
 
const uploadRequirementToQTest = async (url, payload, requirementId, uploadStatus, qTestId, isModule) => {
  try {
    let response;
    const isUpdate = uploadStatus === 'modified' && qTestId;
 
    if (isUpdate) {
      // 🔄 Update existing
      let updateUrl;
      if (isModule) {
        updateUrl = `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/modules/${qTestId}`;
        console.log(`🔁 Updating module ${requirementId} (qTest ID: ${qTestId})`);
      } else {
        updateUrl = `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/requirements/${qTestId}`;
        console.log(`🔁 Updating requirement ${requirementId} (qTest ID: ${qTestId})`);
      }
 
      response = await axios.put(updateUrl, payload, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${credentials.apiToken}`,
        },
      });
    } else {
      // ➕ Create new
      if (isModule) {
        console.log(`➕ Creating module ${requirementId}`);
      } else {
        console.log(`➕ Creating requirement ${requirementId}`);
      }
 
      response = await axios.post(url, payload, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${credentials.apiToken}`,
        },
      });
    }
 
    // ✅ Save status in DB
    await db.promise().query(
      "UPDATE requirement SET upload_status = ?, qtest_requirement_id = ? WHERE id = ?",
      ["completed", response.data.id, requirementId]
    );
 
    if (isUpdate) {
      uploadStats.updated++;
    } else {
      uploadStats.success++;
    }
    uploadStats.pending--;
 
    return { success: true, qTestId: response.data.id };
  } catch (error) {
    const status = error.response?.status || "unknown_error";
    const errorMessage = error.response?.data?.message || error.message;
 
    await db.promise().query("UPDATE requirement SET upload_status = ? WHERE id = ?", [
      `failed_${status}`,
      requirementId,
    ]);
 
    uploadStats.failed++;
    uploadStats.pending--;
 
    return { success: false, error: errorMessage };
  }
};
 
function getQTestUrl(row, isUpdate, qtestParentId, isModule) {
  if (isModule) {
    return isUpdate
      ? `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/modules/${row.qtest_requirement_id}`
      : `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/modules${qtestParentId ? `?parentId=${qtestParentId}` : ''}`;
  } else {
    return isUpdate
      ? `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/requirements/${row.qtest_requirement_id}`
      : `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/requirements`;
  }
}
 
 
 
const processAndRequirementUploadAll = async (req, res) => {
  try {
    uploadStats = {
      total: 0,
      success: 0,
      failed: 0,
      skipped: 0,
      updated: 0,
      pending: 0
    };
 
    // ✅ Fetch mapping columns
    const [link_name] = await db.promise().query("SELECT link_name from link_table where is_current = '1' LIMIT 1")
    const [mappingRow] = await db.promise().query("SELECT DISTINCT link_name FROM Field_mappings WHERE artifact_type = 'Requirement'");
    const currentTable = mappingRow.length > 0 ? mappingRow[0].link_name : null;
 
    if (!currentTable) throw new Error("No active mapping table found.");
 
    const [mappings] = await db.promise().query(
      "SELECT ep1_name, ep1_type, ep2_label, ep2_field_id FROM Field_mappings WHERE artifact_type = 'Requirement' AND link_name = ?",
      [link_name]
    );
 
    // console.log(`Found ${mappings.length} field mappings for Requirements`);
 
    //const [rows] = await db.promise().query("SELECT * FROM requirement WHERE upload_status IS NULL OR upload_status LIKE 'failed%' OR upload_status = 'pending'");
 
    const [rows] = await db.promise().query(
      "SELECT * FROM requirement WHERE upload_status IS NULL OR upload_status LIKE 'failed%' OR upload_status = 'pending' OR upload_status = 'modified' OR upload_status = 'changed' OR upload_status = 'completed'"
    );
 
 
 
    uploadStats.total = rows.length;
    uploadStats.pending = rows.length;
 
    const idToQtestIdMap = {};
    const allParentIds = new Set(rows.map(r => r.parent_id).filter(pid => pid !== null));
 
    const outputPayloadPath = path.join(__dirname, '../../data/Requirementdatafile/RequirementfinalPayload.json');
 
    let counter = 1;
 
    for (let row of rows) {
 
      console.log(`🔄 Processing Requirement ${counter}/${rows.length} (ID: ${row.id})`);
 
      if (row.upload_status === 'completed' && row.qtest_requirement_id) {
        console.log(`⏭️ Skipping Requirement ID ${row.id} - already completed`);
        uploadStats.skipped++;
        uploadStats.pending--;
        continue;
      }
 
 
 
      let requirementName = `Requirement_${row.id}`;
 
      if (row.name && row.name.trim() !== '') {
        requirementName = row.name.trim();
      }
 
      // console.log(`📝 Requirement name: ${requirementName}`);
 
      const properties = [];
 
      // Process field mappings similar to releases
      for (let mapping of mappings) {
        const columnName = mapping.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
        const rawValue = row[columnName];
 
        // console.log(`🔍 Processing field: ${mapping.ep1_name} (${columnName}) = ${rawValue} (type: ${mapping.ep1_type})`);
 
        if (rawValue === null || rawValue === undefined || rawValue === '') {
          // console.log(`⚠️ Skipping empty value for ${columnName}`);
          continue;
        }
 
        if (mapping.ep1_type === "LookupList") {
          const valuesToCheck = typeof rawValue === 'string' ? rawValue.split(',').map(v => v.trim()) : [rawValue];
 
          const [valueMappings] = await db.promise().query(`
            SELECT ep1_value, ep2_value_id, ep2_value
            FROM value_mappings
            WHERE ep1_name = ? AND ep2_field_id = ?
          `, [mapping.ep1_name, mapping.ep2_field_id]);
 
          console.log(`🔎 Found ${valueMappings.length} value mappings for ${mapping.ep1_name}`);
          const matchedEp2Ids = [];
          const matchedEp2Names = [];
 
          valuesToCheck.forEach(value => {
            const match = valueMappings.find(vm => vm.ep1_value === value);
            if (match) {
              matchedEp2Ids.push(match.ep2_value_id);
              matchedEp2Names.push(match.ep2_value);
              console.log(`✅ Matched value: ${value} -> ${match.ep2_value_id} (${match.ep2_value})`);
            } else {
              console.log(`❌ No match found for value: ${value}`);
            }
          });
 
          if (matchedEp2Ids.length > 0) {
            const fieldValue = matchedEp2Ids.length === 1 ? matchedEp2Ids[0] : matchedEp2Ids;
            const fieldValueName = matchedEp2Names.length === 1 ? matchedEp2Names[0] : matchedEp2Names;
 
            properties.push({
              field_id: mapping.ep2_field_id,
              field_name: mapping.ep2_label,
              field_value: Array.isArray(fieldValue) ? JSON.stringify(fieldValue) : fieldValue,
              field_value_name: Array.isArray(fieldValueName) ? JSON.stringify(fieldValueName) : fieldValueName
            });
            // console.log(`✅ Added LookupList property: ${mapping.ep2_label} = ${fieldValue}`);
          }
        } 
        // else if (mapping.ep1_type === "UsersList") {
        //   const valuesToCheck = typeof rawValue === 'string' ? rawValue.split(',').map(v => v.trim()) : [rawValue];
 
        //   const [valueMappings] = await db.promise().query(`
        //     SELECT ep1_value, ep2_value_id, ep2_value
        //     FROM value_mappings
        //     WHERE ep1_name = ? AND ep2_field_id = ?
        //   `, [mapping.ep1_name, mapping.ep2_field_id]);
 
        //   console.log(`🔎 Found ${valueMappings.length} user mappings for ${mapping.ep1_name}`);
        //   const matchedEp2Ids = [];
        //   const matchedEp2Names = [];
 
        //   valuesToCheck.forEach(value => {
        //     const match = valueMappings.find(vm => vm.ep1_value === value);
        //     if (match) {
        //       matchedEp2Ids.push(match.ep2_value_id);
        //       matchedEp2Names.push(match.ep2_value);
        //       console.log(`✅ Matched user: ${value} -> ${match.ep2_value_id} (${match.ep2_value})`);
        //     } else {
        //       console.log(`❌ No match found for user: ${value}`);
        //     }
        //   });
 
        //   if (matchedEp2Ids.length > 0) {
        //     properties.push({
        //       field_id: mapping.ep2_field_id,
        //       field_name: mapping.ep2_label,
        //       field_value: JSON.stringify(matchedEp2Ids),
        //       field_value_name: JSON.stringify(matchedEp2Names)
        //     });
        //     // console.log(`✅ Added UsersList property: ${mapping.ep2_label} = ${matchedEp2Ids}`);
        //   }
        // } 
         else if (mapping.ep1_type === "UsersList") {
  const valuesToCheck = typeof rawValue === 'string' 
    ? rawValue.split(',').map(v => v.trim()) 
    : [rawValue];

  for (const value of valuesToCheck) {
    // Query users table to match the Name column
    const [userMatch] = await db.promise().query(`
      SELECT qtest_id, first_name 
      FROM users 
      WHERE Name = ?
      LIMIT 1
    `, [value]);

    if (userMatch.length > 0) {
      const { qtest_id, first_name } = userMatch[0];

      properties.push({
        field_id: mapping.ep2_field_id,
        field_name: mapping.ep2_label,
        field_value: qtest_id,
        field_value_name: first_name
      });

      console.log(`✅ Matched user: ${value} -> ${qtest_id} (${first_name})`);
    } else {
      console.log(`❌ No match found in users table for: ${value}`);
    }
  }
}

        else {
          // Handle other field types (String, Number, Date, etc.)
          let processedValue = rawValue;
 
          if (mapping.ep1_type === 'Number') {
            processedValue = isNaN(Number(rawValue)) ? null : Number(rawValue);
          } else if (mapping.ep1_type === 'Date') {
            const parsedDate = new Date(rawValue);
            processedValue = formatDateForQTest(parsedDate);
          } else if (mapping.ep1_type === 'String') {
            processedValue = String(rawValue).trim();
          }
 
          if (processedValue !== null && processedValue !== '') {
            properties.push({
              field_id: mapping.ep2_field_id,
              field_name: mapping.ep2_label,
              field_value: processedValue
            });
            // console.log(`✅ Added ${mapping.ep1_type} property: ${mapping.ep2_label} = ${processedValue}`);
          }
        }
      }
 
      // console.log(`📊 Total properties created: ${properties.length}`);
 
      // Validate requirement name
      if (!requirementName || requirementName.trim() === '' || requirementName === 'Requirement_') {
        console.error(`❌ Skipping requirement with invalid name: ${row.id}`);
        await db.promise().query("UPDATE requirement SET upload_status = ? WHERE id = ?", ['failed_no_name', row.id]);
        uploadStats.skipped++;
        uploadStats.pending--;
        continue;
      }
 
      const isModule = (row.id === 0 && row.parent_id === -1) || allParentIds.has(row.id);
      const parentId = row.parent_id;
      const qtestParentId = idToQtestIdMap[parentId];
      const isUpdate = row.upload_status === 'modified' && row.qtest_requirement_id;
 
      let url = getQTestUrl(row, isUpdate, qtestParentId, isModule);
 
      let payload = {};
 
      const rowId = row.id;
      const rowParentId = row.parent_id;
 
 
      if (rowId === 0 && rowParentId === -1) {
        // Root module
        url = isUpdate
          ? `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/modules/${row.qtest_requirement_id}`
          : `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/modules`;
        payload = { name: requirementName, description: row.description || "" };
      } else if (allParentIds.has(rowId)) {
        // Module under module
        if (!isUpdate && !qtestParentId) {
          console.warn(`⚠️ Skipping module ${requirementName} due to missing parent qTest ID`);
          uploadStats.skipped++;
          uploadStats.pending--;
          continue;
        }
 
        url = isUpdate
          ? `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/modules/${row.qtest_requirement_id}`
          : `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/modules?parentId=${qtestParentId}`;
 
        payload = { name: requirementName, description: row.description || "" };
      } else {
        // Regular requirement
        url = isUpdate
          ? `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/requirements/${row.qtest_requirement_id}`
          : `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/requirements`;
 
        //payload = { name: requirementName.trim(), properties, description: row.description, ...(qtestParentId && !isUpdate ? { parent_id: qtestParentId } : {}) };
 
        if (isModule) {
          // Module payload
          payload = { name: requirementName, description: row.description || "" };
        } else {
          // Requirement payload
          payload = { name: requirementName.trim(), properties, description: row.description || "" };
          if (!isUpdate && qtestParentId) {
            payload.parent_id = qtestParentId; // Only add parent ID when creating
          }
        }
 
 
      }
 
 
 
      // let url = "";
      // let payload = {};
 
      // const rowId = row.id;
      // const rowParentId = row.parent_id;
 
      // if (rowId === 0 && rowParentId === -1) {
      //   // Root-level module
      //   url = `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/modules`;
      //   payload = {
      //     name: requirementName,
      //     description: row.description || ""
      //   };
      // } else if (allParentIds.has(rowId)) {
      //   // Module under module
      //   if (!qtestParentId) {
      //     console.warn(`⚠️ Skipping module ${requirementName} due to missing parent qTest ID`);
      //     uploadStats.skipped++;
      //     uploadStats.pending--;
      //     continue;
      //   }
      //   url = `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/modules?parentId=${qtestParentId}`;
      //   payload = {
      //     name: requirementName,
      //     description: row.description || ""
      //   };
      // } else {
      //   // Regular requirement with properties
      //   url = `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/requirements`;
      //   payload = {
      //     name: requirementName.trim(),
      //     properties: properties,
      //     ...(row.description ? { description: row.description } : {}),
      //     ...(qtestParentId ? { parent_id: qtestParentId } : {})
      //   };
      // }
 
      // console.log(`📋 Final payload:`, JSON.stringify(payload, null, 2));
 
      // Write payload to file
      fs.writeFileSync(outputPayloadPath, JSON.stringify(payload, null, 2), 'utf8');
 
      //const result = await uploadRequirementToQTest(url, payload, row.id);
 
      // const result = await uploadRequirementToQTest(url, payload, row.id, row.upload_status, row.qtest_requirement_id);
 
      // let isModule = false;
 
      // if (rowId === 0 && rowParentId === -1) {
      //   isModule = true; // root module
      // } else if (allParentIds.has(rowId)) {
      //   isModule = true; // module under module
      // }
 
      const result = await uploadRequirementToQTest(
        url,
        payload,
        row.id,
        row.upload_status,
        row.qtest_requirement_id,
        isModule
      );
 
 
      if (result.success) {
        idToQtestIdMap[row.id] = result.qTestId;
        // console.log(`✅ Uploaded ${row.name}`);
      } else {
        console.error(`❌ Failed to upload ${row.name}: ${result.error}`);
      }
    }
    res.json({ message: "Migration completed", counts: uploadStats });
 
  } catch (err) {
    console.error("❌ Error during requirement upload:", err.message);
    res.status(500).json({ error: err.message });
  }
};
 
 
 
const getRequirementMigrationStatus = async (req, res) => {
 
  try {
 
    res.json({ counts: uploadStats });
 
  } catch (error) {
 
    console.error("❌ Error getting requirement migration status:", error.message);
 
    res.status(500).json({
 
      message: "Error getting requirement migration status",
 
      error: error.message
 
    });
 
  }
 
};
 
const getRequirementsCount = async (req, res) => {
  try {
    const jsonFilePath = path.join(__dirname, "../../data/Requirementdatafile/ALMRequirement.json");

    if (!fs.existsSync(jsonFilePath)) {
      return res.status(404).json({ success: false, message: "Requirements JSON not found" });
    }

    const jsonData = JSON.parse(fs.readFileSync(jsonFilePath, "utf8"));
    const totalCount = jsonData.entities?.length || 0;

    res.json({ totalCount });
  } catch (error) {
    console.error("❌ Error in getRequirementsCount:", error);
    res.status(500).json({ error: "Failed to fetch requirements count" });
  }
};

module.exports = {
  RequirementinsertSampleData,
  processAndRequirementUploadAll,
  getRequirementMigrationStatus,
  getRequirementsCount
  
};
 
 
 