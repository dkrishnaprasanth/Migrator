
// //this new coding


// const db = require("../../config/db");
// const fs = require("fs");
// const path = require("path");
// const axios = require("axios");
// const { fetchAlmRequirementFields } = require("../../controllers/RequirementControllersfile/ALMRequirementFields");

// const requiredFields = ["label", "name", "type", "physicalName", "required", "listId", "supportsMultivalue", "qtest_id"];

// const getrequirementTypeCode = (type, supportsMultivalue) => {
//   let v_datatype = 1;
  
//   if (!type) return v_datatype;
  
//   if (type === 'Number') {
//     v_datatype = 7;
//   } else if (type === 'String') {
//     v_datatype = 1;
//   } else if (type === 'LookupList') {
//     if (supportsMultivalue) {
//       v_datatype = 17;
//     } else {
//       v_datatype = 3;
//     }
//   } else if (type === 'UsersList') {
//     v_datatype = 5;
//   } else if (type === 'Date') {
//     v_datatype = 4;
//   } else if (type === 'DateTime') {
//     v_datatype = 9;
//   } else if (type === 'Memo') {
//     v_datatype = 2;
//   }
  
//   return v_datatype;
// };

// const getAlmRequirementFields = async (req, res) => {
//   db.query("SELECT * FROM alm_requirement_data", (err, results) => {
//     if (err) {
//       return res.status(500).json({ error: err.message });
//     }
    
//     const formattedResults = results.map(row => {
//       const isRequired = row.required === 1;
//       const supportsMultivalue = row.supportsMultivalue === 1;
      
//       return {
//         ...row,
//         required: isRequired,
//         supportsMultivalue: supportsMultivalue,
//         typeCode: getrequirementTypeCode(row.type, supportsMultivalue)
//       };
//     });
    
//     res.json(formattedResults);
//   });
// };

// const loadJsonAndValidateRequirement = async () => {
//   const jsonFilePath = path.join(__dirname, '../../data/Requirementdatafile/ALMRequirementFields.json');

//   try {
//     if (!fs.existsSync(jsonFilePath)) {
//       console.error(" JSON file does not exist:", jsonFilePath);
//       return [];
//     }

//     const rawData = fs.readFileSync(jsonFilePath, "utf-8");
//     const parsedData = JSON.parse(rawData);

//     if (
//       !Array.isArray(parsedData) &&
//       (!parsedData.Fields || !Array.isArray(parsedData.Fields.Field))
//     ) {
//       console.error(" Unexpected JSON structure:", parsedData);
//       return [];
//     }

//     const normalizedData = Array.isArray(parsedData)
//       ? parsedData
//       : parsedData.Fields.Field;

//     const validated = normalizedData.map((item) => {
//       const filtered = {};
//       requiredFields.forEach((field) => {
//         filtered[field] = item[field] !== undefined ? item[field] : null;
//       });
//       return filtered;
//     });

//     return validated;
//   } catch (err) {
//     console.error(" Error reading/parsing JSON file:", err.message);
//     return [];
//   }
// };

// const getAlmRequirementFieldByPhysicalName = async (req, res) => {
//   const { physicalName } = req.params;

//   if (!physicalName) {
//     return res.status(400).json({ error: "Physical name is required" });
//   }

//   db.query(
//     "SELECT * FROM alm_requirement_data WHERE physicalName = ?",
//     [physicalName],
//     (err, results) => {
//       if (err) {
//         return res.status(500).json({ error: err.message });
//       }

//       if (results.length === 0) {
//         return res.status(404).json({ error: "Field not found" });
//       }

//       const isRequired = results[0].required === 1;
//       const supportsMultivalue = results[0].supportsMultivalue === 1;

//       const formattedResult = {
//         ...results[0],
//         required: isRequired,
//         supportsMultivalue: supportsMultivalue,
//         typeCode: getrequirementTypeCode(results[0].type, supportsMultivalue)
//       };

//       res.json(formattedResult);
//     }
//   );
// };

// const createAlmRequirementJsonFile = async (req, res) => {
//   const { physicalName } = req.body;

//   if (!physicalName) {
//     return res.status(400).json({ error: "Physical name is required" });
//   }

//   try {
//     // Fetch field from alm_requirement_data table
//     const result = await new Promise((resolve, reject) => {
//       db.query(
//         "SELECT * FROM alm_requirement_data WHERE physicalName = ?",
//         [physicalName],
//         (err, results) => {
//           if (err) return reject(err);
//           if (!results.length) return reject(new Error("Field not found"));
//           resolve(results[0]);
//         }
//       );
//     });

//     const isRequired = result.required === 1;
//     const supportsMultivalue = result.supportsMultivalue === 1;
//     const typeCode = getrequirementTypeCode(result.type, supportsMultivalue);

//     let jsonData;

//     if (result.type === "LookupList") {
//       if (!result.listId) {
//         throw new Error("Missing listId in alm_requirement_data for LookupList");
//       }

//       // Fetch values from Requirement_Lists table using listId
//       const listValues = await new Promise((resolve, reject) => {
//         db.query(
//           "SELECT value FROM Requirement_Lists WHERE id = ?",
//           [result.listId],
//           (err, results) => {
//             if (err) return reject(err);
//             if (!results.length) return reject(new Error("No values found in Requirement_Lists table"));
//             resolve(results);
//           }
//         );
//       });

//       const allowedValues = listValues.map((item) => ({
//         label: item.value,
//         is_default: false,
//         is_active: true,
//       }));

//       jsonData = {
//         label: result.label,
//         field_name: result.physicalName, // Adding field_name which is required by qTest API
//         allowed_values: allowedValues,
//         data_type: typeCode,
//         multiple: supportsMultivalue ? true : false, // Ensure boolean, not 0/1
//         is_active: true,
//         required: isRequired ? true : false // Ensure boolean, not 0/1
//       };
//     } else {
//       // Non-lookup field
//       jsonData = {
//         label: result.label,
//         field_name: result.physicalName, // Adding field_name which is required by qTest API
//         data_type: typeCode,
//         required: isRequired ? true : false, // Ensure boolean, not 0/1
//         is_active: true
//       };
//     }

//     // Create directories if they don't exist
//     const dataDir = path.join(__dirname, "../../data");
//     const requirementDir = path.join(dataDir, "Requirementdatafile");
    
//     if (!fs.existsSync(dataDir)) {
//       fs.mkdirSync(dataDir, { recursive: true });
//     }
    
//     if (!fs.existsSync(requirementDir)) {
//       fs.mkdirSync(requirementDir, { recursive: true });
//     }

//     // Write to file
//     const filePath = path.join(requirementDir, "ALMListRequirement.json");
//     fs.writeFileSync(filePath, JSON.stringify(jsonData, null, 2), "utf-8");

//     console.log("✅ JSON file created:", filePath);

//     res.status(200).json({
//       message: "JSON file created successfully",
//       data: jsonData,
//       filePath,
//     });
//   } catch (error) {
//     console.error("❌ Error creating JSON file:", error.message);
//     res.status(error.message === "Field not found" ? 404 : 500).json({
//       error: error.message,
//     });
//   }
// };

// const initRequirement = async () => {
//   try {
//     console.log(" Fetching ALM release fields...");
//     await fetchAlmRequirementFields();
//     console.log("✅ Fetch complete.");
    
//     // Create tables if they don't exist
//     await createRequirementTables();
    
//     // Insert data from JSON
//     await insertRequirementDataJson();
    
//     console.log("✅ ALM initialization complete.");
//   } catch (err) {
//     console.error(" Failed to initialize ALM data:", err.message);
//     process.exit(1);
//   }
// };

// const createRequirementTables = async () => {
//   const droprequirementQuery = `DROP TABLE IF EXISTS alm_requirement_data`;
//   const createTableQuery = `
//     CREATE TABLE IF NOT EXISTS alm_requirement_data (
//       id INT AUTO_INCREMENT PRIMARY KEY,
//       label TEXT,
//       name TEXT,
//       type TEXT,
//       physicalName TEXT,
//       required TINYINT(1),
//       listId INT,
//       supportsMultivalue TINYINT(1),
//      qtest_id INT
//     )
//   `;

//   try {
//     await db.promise().query(droprequirementQuery);
//     await db.promise().query(createTableQuery);
//     console.log("✅ Table 'alm_requirement_data' created successfully.");
//     return true;
//   } catch (err) {
//     console.error("❌ Error:", err.message);
//     throw err;
//   }
// };


// const insertRequirementDataJson = async () => {
//   try {
//     const jsonData = await loadJsonAndValidateRequirement();

//     return new Promise((resolve, reject) => {
//       db.query("SELECT COUNT(*) AS count FROM alm_requirement_data", (err, results) => {
//         if (err) {
//           console.error(" Error checking existing data:", err.message);
//           return reject(err);
//         }

//         if (results[0].count > 0) {
//           console.log(" Data already exists. Skipping insertion.");
//           return resolve(false);
//         }

//         if (jsonData.length === 0) {
//           console.log(" No valid data to insert.");
//           return resolve(false);
//         }

//         const insertPromises = jsonData.map((item) => {
//           return new Promise((resolve, reject) => {
//             const sql = `
//               INSERT INTO alm_requirement_data (label, name, type, physicalName, required, listId, supportsMultivalue,qtest_id)
//               VALUES (?, ?, ?, ?, ?, ?, ?, ?)
//             `;
            
//             const values = [
//               item.label || null,
//               item.name || null,
//               item.type || null,
//               item.physicalName || null,
//               item.required === true ? 1 : 0, // Convert boolean to 0/1
//               item.listId,
//               item.supportsMultivalue === true ? 1 : 0, // Convert boolean to 0/1
//               item.qtest_id || null
//             ];
            
//             db.query(sql, values, (err, result) => {
//               if (err) {
//                 console.error(" Error inserting row:", err.message);
//                 return reject(err);
//               }
//               resolve(result);
//             });
//           });
//         });
        
//         Promise.all(insertPromises)
//           .then(() => {
//             console.log(`✅ ${jsonData.length} records inserted successfully.`);
//             resolve(true);
//           })
//           .catch(err => {
//             console.error(" Error in batch insertion:", err.message);
//             reject(err);
//           });
//       });
//     });
//   } catch (err) {
//     console.error(" Failed to insert data:", err.message);
//     throw err;
//   }
// };

// const getAllRequirementTestCases = (req, res) => {
//   db.query("SELECT * FROM alm_requirement_data", (err, results) => {
//     if (err) {
//       return res.status(500).json({ error: err.message });
//     }
    
//     const formattedResults = results.map(row => {
//       const isRequired = row.required === 1;
//       const supportsMultivalue = row.supportsMultivalue === 1;
      
//       return {
//         ...row,
//         required: isRequired,
//         supportsMultivalue: supportsMultivalue,
//         typeCode: getrequirementTypeCode(row.type, supportsMultivalue)
//       };
//     });
    
//     res.json(formattedResults);
//   });
// };

// const createRequirementTestCases = async (req, res) => {
//   const testCases = req.body;

//   if (!Array.isArray(testCases) || testCases.length === 0) {
//     return res
//       .status(400)
//       .json({ message: "Invalid input, expecting an array of test cases" });
//   }
//   const insertPromises = testCases.map((item) => {
//     return new Promise((resolve, reject) => {
//       const sql = `
//         INSERT INTO alm_requirement_data (label, name, type, physicalName, required, listId, supportsMultivalue,qtest_id)
//         VALUES (?, ?, ?, ?, ?, ?, ?, ?)
//       `;
      
//       const values = [
//         item.label || null,
//         item.name || null,
//         item.type || null,
//         item.physicalName || null,
//         item.required === true ? 1 : 0, 
//         item.listId,
//         item.supportsMultivalue === true ? 1 : 0,
//         item.qtest_id || null
//       ];
      
//       db.query(sql, values, (err, result) => {
//         if (err) {
//           console.error(" Error inserting row:", err.message);
//           return reject(err);
//         }
//         resolve(result);
//       });
//     });
//   });

//   try {
//     await Promise.all(insertPromises);
//     res.status(201).json({ 
//       message: `${testCases.length} new test cases added successfully` 
//     });
//   } catch (err) {
//     console.error(" Error inserting data:", err.message);
//     return res.status(500).json({ error: err.message });
//   }
// };

// const uploadAlmRequirementJsonFile = async (req, res) => {
//   try {
//     // Read credentials 
//     const credentialsPath = path.join(__dirname, "../../data/qTestCredentials.json");
//     if (!fs.existsSync(credentialsPath)) {
//       console.error("❌ Credentials file not found:", credentialsPath);
//       return res.status(500).json({ error: "qTest credentials file not found" });
//     }
    
//     const credentialsData = fs.readFileSync(credentialsPath, "utf-8");
//     const config = JSON.parse(credentialsData);

//     // Validate credentials
//     if (!config.qTestDomain || !config.apiToken || !config.projectId) {
//       console.error("❌ Invalid qTest credentials. Missing required fields.");
//       return res.status(500).json({ error: "Invalid qTest credentials. Check domain, token and projectId." });
//     }

//     const qTestDomain = config.qTestDomain;
//     const apiToken = config.apiToken;
//     const projectId = parseInt(config.projectId, 10); // Ensure projectId is a number

//     // Read payload file
//     const payloadPath = path.join(__dirname, "../../data/Requirementdatafile/ALMListRequirement.json");
//     if (!fs.existsSync(payloadPath)) {
//       console.error("❌ Payload file not found:", payloadPath);
//       return res.status(500).json({ error: "Requirement JSON file not found. Please create it first." });
//     }
    
//     const payload = JSON.parse(fs.readFileSync(payloadPath, "utf-8"));
    
//     // Ensure numeric values are properly formatted
//     if (payload.data_type) {
//       payload.data_type = parseInt(payload.data_type, 10);
//     }
    
//     // Log payload for debugging
//     console.log("Attempting to upload with payload:", JSON.stringify(payload, null, 2));
    
//     // Validate payload format
//     if (!payload.field_name || !payload.label || payload.data_type === undefined) {
//       console.error("❌ Invalid payload format. Missing required fields.");
//       return res.status(400).json({ 
//         error: "Invalid payload format. Required fields: field_name, label, data_type", 
//         payload: payload 
//       });
//     }

//     // Send request to qTest API
//     try {
//       const response = await axios.post(
//         `${qTestDomain}/api/v3/projects/${projectId}/settings/requirements/fields`,
//         payload,
//         {
//           headers: {
//             "Content-Type": "application/json",
//             Authorization: `Bearer ${apiToken}`,
//           },
//         }
//       );

//       console.log("✅ Uploaded to qTest successfully");
//       res.status(200).json({
//         message: "Uploaded to qTest successfully",
//         statusCode: response.status,
//         data: response.data,
//       });
//     } catch (apiError) {
//       // Handle API error with detailed response
//       console.error("❌ qTest API error:", apiError.message);
      
//       if (apiError.response) {
//         // The request was made and the server responded with a status code
//         // that falls out of the range of 2xx
//         console.error("Response data:", apiError.response.data);
//         console.error("Response status:", apiError.response.status);
//         console.error("Response headers:", apiError.response.headers);
        
//         return res.status(apiError.response.status).json({
//           error: "qTest API error",
//           status: apiError.response.status,
//           message: apiError.message,
//           details: apiError.response.data
//         });
//       } else if (apiError.request) {
//         // The request was made but no response was received
//         console.error("Request data:", apiError.request);
//         return res.status(500).json({
//           error: "No response received from qTest API",
//           message: apiError.message
//         });
//       } else {
//         // Something happened in setting up the request that triggered an Error
//         return res.status(500).json({
//           error: "Error setting up qTest API request",
//           message: apiError.message
//         });
//       }
//     }
//   } catch (error) {
//     console.error("❌ Upload error:", error.message);
//     res.status(500).json({
//       error: error.message,
//     });
//   }
// };

// const getListValues = async (req, res) => {
//   const { listId } = req.params;
  
//   if (!listId) {
//     return res.status(400).json({ error: "listId is required" });
//   }

//   db.query(
//     "SELECT value FROM Requirement_Lists WHERE id = ?",
//     [listId],
//     (err, results) => {
//       if (err) {
//         return res.status(500).json({ error: err.message });
//       }
//       res.json(results);
//     }
//   );
// };


// module.exports = {
//   initRequirement,
//   createRequirementTables,
//   insertRequirementDataJson,
//   getAllRequirementTestCases,
//   getAlmRequirementFields,
//   createRequirementTestCases,
//   createAlmRequirementJsonFile,
//   getAlmRequirementFieldByPhysicalName,
//   uploadAlmRequirementJsonFile,

//    getListValues
// };




// Fixed Controller Code - ALMRequirementFieldsController.js
const db = require("../../config/db");
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const { fetchAlmRequirementFields } = require("../../controllers/RequirementControllersfile/ALMRequirementFields");

const requiredFields = ["label", "name", "type", "physicalName", "required", "listId", "supportsMultivalue", "qtest_id"];

const getrequirementTypeCode = (type, supportsMultivalue) => {
  let v_datatype = 1;
  
  if (!type) return v_datatype;
  
  if (type === 'Number') {
    v_datatype = 7;
  } else if (type === 'String') {
    v_datatype = 1;
  } else if (type === 'LookupList') {
    if (supportsMultivalue) {
      v_datatype = 17;
    } else {
      v_datatype = 3;
    }
  } else if (type === 'UsersList') {
    v_datatype = 5;
  } else if (type === 'Date') {
    v_datatype = 4;
  } else if (type === 'DateTime') {
    v_datatype = 9;
  } else if (type === 'Memo') {
    v_datatype = 2;
  }
  
  return v_datatype;
};

const getAlmRequirementFields = async (req, res) => {
  db.query("SELECT * FROM alm_requirement_data", (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    
    const formattedResults = results.map(row => {
      const isRequired = row.required === 1;
      const supportsMultivalue = row.supportsMultivalue === 1;
      
      return {
        ...row,
        required: isRequired,
        supportsMultivalue: supportsMultivalue,
        typeCode: getrequirementTypeCode(row.type, supportsMultivalue)
      };
    });
    
    res.json(formattedResults);
  });
};

const loadJsonAndValidateRequirement = async () => {
  const jsonFilePath = path.join(__dirname, '../../data/Requirementdatafile/ALMRequirementFields.json');

  try {
    if (!fs.existsSync(jsonFilePath)) {
      console.error(" JSON file does not exist:", jsonFilePath);
      return [];
    }

    const rawData = fs.readFileSync(jsonFilePath, "utf-8");
    const parsedData = JSON.parse(rawData);

    if (
      !Array.isArray(parsedData) &&
      (!parsedData.Fields || !Array.isArray(parsedData.Fields.Field))
    ) {
      console.error(" Unexpected JSON structure:", parsedData);
      return [];
    }

    const normalizedData = Array.isArray(parsedData)
      ? parsedData
      : parsedData.Fields.Field;

    const validated = normalizedData.map((item) => {
      const filtered = {};
      requiredFields.forEach((field) => {
        filtered[field] = item[field] !== undefined ? item[field] : null;
      });
      return filtered;
    });

    return validated;
  } catch (err) {
    console.error(" Error reading/parsing JSON file:", err.message);
    return [];
  }
};

const getAlmRequirementFieldByPhysicalName = async (req, res) => {
  const { physicalName } = req.params;

  if (!physicalName) {
    return res.status(400).json({ error: "Physical name is required" });
  }

  db.query(
    "SELECT * FROM alm_requirement_data WHERE physicalName = ?",
    [physicalName],
    (err, results) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }

      if (results.length === 0) {
        return res.status(404).json({ error: "Field not found" });
      }

      const isRequired = results[0].required === 1;
      const supportsMultivalue = results[0].supportsMultivalue === 1;

      const formattedResult = {
        ...results[0],
        required: isRequired,
        supportsMultivalue: supportsMultivalue,
        typeCode: getrequirementTypeCode(results[0].type, supportsMultivalue)
      };

      res.json(formattedResult);
    }
  );
};

const createAlmRequirementJsonFile = async (req, res) => {
  const { physicalName } = req.body;

  if (!physicalName) {
    return res.status(400).json({ error: "Physical name is required" });
  }

  try {
    // Fetch field from alm_requirement_data table
    const result = await new Promise((resolve, reject) => {
      db.query(
        "SELECT * FROM alm_requirement_data WHERE physicalName = ?",
        [physicalName],
        (err, results) => {
          if (err) return reject(err);
          if (!results.length) return reject(new Error("Field not found"));
          resolve(results[0]);
        }
      );
    });

    const isRequired = result.required === 1;
    const supportsMultivalue = result.supportsMultivalue === 1;
    const typeCode = getrequirementTypeCode(result.type, supportsMultivalue);

    let jsonData;

    if (result.type === "LookupList") {
      if (!result.listId) {
        throw new Error("Missing listId in alm_requirement_data for LookupList");
      }

      // Fetch values from Requirement_Lists table using listId
      const listValues = await new Promise((resolve, reject) => {
        db.query(
          "SELECT value FROM Requirement_Lists WHERE id = ?",
          [result.listId],
          (err, results) => {
            if (err) return reject(err);
            if (!results.length) return reject(new Error("No values found in Requirement_Lists table"));
            resolve(results);
          }
        );
      });

      const allowedValues = listValues.map((item) => ({
        label: item.value,
        is_default: false,
        is_active: true,
      }));

      jsonData = {
        label: result.label,
        field_name: result.physicalName, // Adding field_name which is required by qTest API
        allowed_values: allowedValues,
        data_type: typeCode,
        multiple: supportsMultivalue ? true : false, // Ensure boolean, not 0/1
        is_active: true,
        required: isRequired ? true : false // Ensure boolean, not 0/1
      };
    } else {
      // Non-lookup field
      jsonData = {
        label: result.label,
        field_name: result.physicalName, // Adding field_name which is required by qTest API
        data_type: typeCode,
        required: isRequired ? true : false, // Ensure boolean, not 0/1
        is_active: true
      };
    }

    // Create directories if they don't exist
    const dataDir = path.join(__dirname, "../../data");
    const requirementDir = path.join(dataDir, "Requirementdatafile");
    
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    if (!fs.existsSync(requirementDir)) {
      fs.mkdirSync(requirementDir, { recursive: true });
    }

    // Write to file
    const filePath = path.join(requirementDir, "ALMListRequirement.json");
    fs.writeFileSync(filePath, JSON.stringify(jsonData, null, 2), "utf-8");

    console.log("✅ JSON file created:", filePath);

    res.status(200).json({
      message: "JSON file created successfully",
      data: jsonData,
      filePath,
    });
  } catch (error) {
    console.error("❌ Error creating JSON file:", error.message);
    res.status(error.message === "Field not found" ? 404 : 500).json({
      error: error.message,
    });
  }
};

const initRequirement = async () => {
  try {
    console.log(" Fetching ALM release fields...");
    await fetchAlmRequirementFields();
    console.log("✅ Fetch complete.");
    
    // Create tables if they don't exist
    await createRequirementTables();
    
    // Insert data from JSON
    await insertRequirementDataJson();
    
    console.log("✅ ALM initialization complete.");
  } catch (err) {
    console.error(" Failed to initialize ALM data:", err.message);
    process.exit(1);
  }
};

const createRequirementTables = async () => {
  const droprequirementQuery = `DROP TABLE IF EXISTS alm_requirement_data`;
  const createTableQuery = `
    CREATE TABLE IF NOT EXISTS alm_requirement_data (
      id INT AUTO_INCREMENT PRIMARY KEY,
      label TEXT,
      name TEXT,
      type TEXT,
      physicalName TEXT,
      required TINYINT(1),
      listId INT,
      supportsMultivalue TINYINT(1),
     qtest_id INT
    )
  `;

  try {
    await db.promise().query(droprequirementQuery);
    await db.promise().query(createTableQuery);
    console.log("✅ Table 'alm_requirement_data' created successfully.");
    return true;
  } catch (err) {
    console.error("❌ Error:", err.message);
    throw err;
  }
};

const insertRequirementDataJson = async () => {
  try {
    const jsonData = await loadJsonAndValidateRequirement();

    return new Promise((resolve, reject) => {
      db.query("SELECT COUNT(*) AS count FROM alm_requirement_data", (err, results) => {
        if (err) {
          console.error(" Error checking existing data:", err.message);
          return reject(err);
        }

        if (results[0].count > 0) {
          console.log(" Data already exists. Skipping insertion.");
          return resolve(false);
        }

        if (jsonData.length === 0) {
          console.log(" No valid data to insert.");
          return resolve(false);
        }

        const insertPromises = jsonData.map((item) => {
          return new Promise((resolve, reject) => {
            const sql = `
              INSERT INTO alm_requirement_data (label, name, type, physicalName, required, listId, supportsMultivalue,qtest_id)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            `;
            
            const values = [
              item.label || null,
              item.name || null,
              item.type || null,
              item.physicalName || null,
              item.required === true ? 1 : 0, // Convert boolean to 0/1
              item.listId,
              item.supportsMultivalue === true ? 1 : 0, // Convert boolean to 0/1
              item.qtest_id || null
            ];
            
            db.query(sql, values, (err, result) => {
              if (err) {
                console.error(" Error inserting row:", err.message);
                return reject(err);
              }
              resolve(result);
            });
          });
        });
        
        Promise.all(insertPromises)
          .then(() => {
            console.log(`✅ ${jsonData.length} records inserted successfully.`);
            resolve(true);
          })
          .catch(err => {
            console.error(" Error in batch insertion:", err.message);
            reject(err);
          });
      });
    });
  } catch (err) {
    console.error(" Failed to insert data:", err.message);
    throw err;
  }
};

const getAllRequirementTestCases = (req, res) => {
  db.query("SELECT * FROM alm_requirement_data", (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    
    const formattedResults = results.map(row => {
      const isRequired = row.required === 1;
      const supportsMultivalue = row.supportsMultivalue === 1;
      
      return {
        ...row,
        required: isRequired,
        supportsMultivalue: supportsMultivalue,
        typeCode: getrequirementTypeCode(row.type, supportsMultivalue)
      };
    });
    
    res.json(formattedResults);
  });
};

const createRequirementTestCases = async (req, res) => {
  const testCases = req.body;

  if (!Array.isArray(testCases) || testCases.length === 0) {
    return res
      .status(400)
      .json({ message: "Invalid input, expecting an array of test cases" });
  }
  const insertPromises = testCases.map((item) => {
    return new Promise((resolve, reject) => {
      const sql = `
        INSERT INTO alm_requirement_data (label, name, type, physicalName, required, listId, supportsMultivalue,qtest_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `;
      
      const values = [
        item.label || null,
        item.name || null,
        item.type || null,
        item.physicalName || null,
        item.required === true ? 1 : 0, 
        item.listId,
        item.supportsMultivalue === true ? 1 : 0,
        item.qtest_id || null
      ];
      
      db.query(sql, values, (err, result) => {
        if (err) {
          console.error(" Error inserting row:", err.message);
          return reject(err);
        }
        resolve(result);
      });
    });
  });

  try {
    await Promise.all(insertPromises);
    res.status(201).json({ 
      message: `${testCases.length} new test cases added successfully` 
    });
  } catch (err) {
    console.error(" Error inserting data:", err.message);
    return res.status(500).json({ error: err.message });
  }
};

const uploadAlmRequirementJsonFile = async (req, res) => {
  try {
    // Read credentials 
    const credentialsPath = path.join(__dirname, "../../data/qTestCredentials.json");
    if (!fs.existsSync(credentialsPath)) {
      console.error("❌ Credentials file not found:", credentialsPath);
      return res.status(500).json({ error: "qTest credentials file not found" });
    }
    
    const credentialsData = fs.readFileSync(credentialsPath, "utf-8");
    const config = JSON.parse(credentialsData);

    // Validate credentials
    if (!config.qTestDomain || !config.apiToken || !config.projectId) {
      console.error("❌ Invalid qTest credentials. Missing required fields.");
      return res.status(500).json({ error: "Invalid qTest credentials. Check domain, token and projectId." });
    }

    const qTestDomain = config.qTestDomain;
    const apiToken = config.apiToken;
    const projectId = parseInt(config.projectId, 10); // Ensure projectId is a number

    // Read payload file
    const payloadPath = path.join(__dirname, "../../data/Requirementdatafile/ALMListRequirement.json");
    if (!fs.existsSync(payloadPath)) {
      console.error("❌ Payload file not found:", payloadPath);
      return res.status(500).json({ error: "Requirement JSON file not found. Please create it first." });
    }
    
    const payload = JSON.parse(fs.readFileSync(payloadPath, "utf-8"));
    
    // Ensure numeric values are properly formatted
    if (payload.data_type) {
      payload.data_type = parseInt(payload.data_type, 10);
    }
    
    // Log payload for debugging
    console.log("Attempting to upload with payload:", JSON.stringify(payload, null, 2));
    
    // Validate payload format
    if (!payload.field_name || !payload.label || payload.data_type === undefined) {
      console.error("❌ Invalid payload format. Missing required fields.");
      return res.status(400).json({ 
        error: "Invalid payload format. Required fields: field_name, label, data_type", 
        payload: payload 
      });
    }

    // Send request to qTest API
    try {
      const response = await axios.post(
        `${qTestDomain}/api/v3/projects/${projectId}/settings/requirements/fields`,
        payload,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${apiToken}`,
          },
        }
      );

      console.log("✅ Uploaded to qTest successfully");
      res.status(200).json({
        message: "Uploaded to qTest successfully",
        statusCode: response.status,
        data: response.data,
      });
    } catch (apiError) {
      // Handle API error with detailed response
      console.error("❌ qTest API error:", apiError.message);
      
      if (apiError.response) {
        // The request was made and the server responded with a status code
        // that falls out of the range of 2xx
        console.error("Response data:", apiError.response.data);
        console.error("Response status:", apiError.response.status);
        console.error("Response headers:", apiError.response.headers);
        
        return res.status(apiError.response.status).json({
          error: "qTest API error",
          status: apiError.response.status,
          message: apiError.message,
          details: apiError.response.data
        });
      } else if (apiError.request) {
        // The request was made but no response was received
        console.error("Request data:", apiError.request);
        return res.status(500).json({
          error: "No response received from qTest API",
          message: apiError.message
        });
      } else {
        // Something happened in setting up the request that triggered an Error
        return res.status(500).json({
          error: "Error setting up qTest API request",
          message: apiError.message
        });
      }
    }
  } catch (error) {
    console.error("❌ Upload error:", error.message);
    res.status(500).json({
      error: error.message,
    });
  }
};



const getRequirementListValues = async (req, res) => {
  const { listId } = req.params;
  
  if (!listId) {
    return res.status(400).json({ error: "listId is required" });
  }

  db.query(
    "SELECT value FROM Requirement_Lists WHERE id = ?",
    [listId],
    (err, results) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      res.json(results);
    }
  );
};



module.exports = {
  initRequirement,
  createRequirementTables,
  insertRequirementDataJson,
  getAllRequirementTestCases,
  getAlmRequirementFields,
  createRequirementTestCases,
  createAlmRequirementJsonFile,
  getAlmRequirementFieldByPhysicalName,
  uploadAlmRequirementJsonFile,
  getRequirementListValues
};