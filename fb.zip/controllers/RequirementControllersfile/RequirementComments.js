const fs = require('fs');
const path = require('path');
const axios = require('axios');
const util = require('util');
const db = require('../../config/db'); // adjust path if needed
const query = util.promisify(db.query).bind(db);

// Load qTest credentials
const credsPath = path.join(__dirname, '../../data/qTestCredentials.json');
const { qTestDomain, projectId, apiToken } = JSON.parse(fs.readFileSync(credsPath, 'utf-8'));

// Function to strip HTML tags
function stripHtml(html) {
  const commentBlocks = html.match(/<div[^>]*>[\s\S]*?<\/div>/gi) || [];

  const results = commentBlocks.map(block => {
    // Extract image filename if any
    const imgMatch = block.match(/<img[^>]+src="[^"]*\/([^\/"]+\.png)"/i);
    const imgText = imgMatch ? ` img:${imgMatch[1]}` : '';

    // Remove image tag
    block = block.replace(/<img[^>]*>/gi, '');

    // Replace <br> with newlines
    block = block.replace(/<br\s*\/?>/gi, '\n');

    // Remove remaining HTML tags
    let clean = block.replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ').trim();

    // Append image text
    return clean + (imgText ? imgText : '');
  });

  return results.join('\n');
}

const uploadRequirementComments = async () => {
  try {
    // Step 1: Get requirement with comments but no comment_id
    const requirement = await query(`SELECT id, qtest_requirement_id, comments FROM requirement WHERE comment_id IS NULL AND comments IS NOT NULL`);

    for (const requirements of requirement) {
      const { id, qtest_requirement_id, comments } = requirements;

      const cleanedComment = stripHtml(comments);
      const payload = {
        content: cleanedComment,
      };

      const url = `${qTestDomain}/api/v3/projects/${projectId}/requirements/${qtest_requirement_id}/comments`;
      console.log(`📤 Uploading comment for requirements_id ${id} to ${url}`);


      try {
        const response = await axios.post(url, payload, {
          headers: {
            Authorization: `Bearer ${apiToken}`,
            'Content-Type': 'application/json',
          },
        });

        const commentId = response.data?.id;
        if (commentId) {
          await query(`UPDATE requirement SET comment_id = ? WHERE id = ?`, [commentId, id]);
          console.log(`✅ Comment uploaded and saved for requirements_id ${id}, qTest comment_id: ${commentId}`);
        } else {
          console.warn(`⚠️ No comment ID returned for requirements_id ${id}`);
        }
      } catch (err) {
        console.error(`❌ Error uploading comment for requirements_id ${id}:`, err.response?.data || err.message);
      }
    }
  } catch (err) {
    console.error('❌ Error during comment upload process:', err.message);
  }
};

module.exports = {uploadRequirementComments};
//uploadRequirementComments();
