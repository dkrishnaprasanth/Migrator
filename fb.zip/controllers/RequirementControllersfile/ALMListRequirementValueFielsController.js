const db = require("../../config/db");
const fs = require("fs");
const path = require("path");
const { fetchListRequirementFields } = require("../../controllers/RequirementControllersfile/AlmListRequirementValuesFields");

const requiredFields = ["name", "id", "value"];

const getListRequirementFields = async (req, res) => {
  db.query("SELECT * FROM Requirement_Lists", (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    const formattedResults = results.map(row => ({
      ...row,
      required: row.required === 1,
      supportsMultivalue: row.supportsMultivalue === 1
    }));

    res.json(formattedResults);
  });
};

const loadJsonAndRequirementValidate = async () => {
    const jsonFilePath = path.join(__dirname, "../../data/Requirementdatafile/ListRequirementValues.json");
  
    try {
      if (!fs.existsSync(jsonFilePath)) {
        console.error("JSON file does not exist:", jsonFilePath);
        return [];
      }
  
      const rawData = fs.readFileSync(jsonFilePath, "utf-8");
      const parsedData = JSON.parse(rawData);
  
      console.log("Raw data from JSON:", parsedData); // Log raw data for debugging
  
      // Adjust the parsing logic to handle 'lists' and 'Items'
      const normalizedData = Array.isArray(parsedData.lists) ? parsedData.lists : [];
  
      // Process each list
      const validated = normalizedData.map(listItem => {
        // Extract the name, id, and logicalName for the list
        const listData = {
          name: listItem.Name || null,
          id: listItem.Id || null,
          items: [] 
        };
  
        // If there are items, extract the 'logicalName' and 'value' from each item in the list
        if (Array.isArray(listItem.Items)) {
          listData.items = listItem.Items.map(item => ({
            value: item.value || null
          }));
        }
  
        return listData;
      });
  
      console.log("Validated data:", validated);  // Log validated data for debugging
      return validated;
  
    } catch (err) {
      console.error("Error reading/parsing JSON file:", err.message);
      return [];
    }
  };
  
  

const initlistRequirement = async () => {
  try {
    console.log("Fetching ALM release fields...");
    await fetchListRequirementFields();
    console.log("✅ Fetch complete.");

    await createListRequirementTables();
    await insertListRequirementDataJson();

    console.log("✅ ALM initialization complete.");
  } catch (err) {
    console.error("Failed to initialize ALM data:", err.message);
    process.exit(1);
  }
};

const createListRequirementTables = async () => {
  const droprequirementlistQuery = `DROP TABLE IF EXISTS Requirement_Lists`;
  const createRequirementTableQuery = `
    CREATE TABLE IF NOT EXISTS Requirement_Lists (
      name VARCHAR(255),
      id INT,
      value VARCHAR(255)
    )
  `;

  try {
    await db.promise().query(droprequirementlistQuery);
    await db.promise().query(createRequirementTableQuery);
    console.log("✅ Table 'Requirement_Lists' created successfully.");
    return true;
  } catch (error) {
    console.error("❌ Error creating Requirement_Lists table:", error.message);
    throw error;
  }
};


const insertListRequirementDataJson = async () => {
    try {
      const jsonData = await loadJsonAndRequirementValidate();
  
      if (jsonData.length === 0) {
        console.log("No valid data to insert.");
        return;
      }
  
      console.log("Inserting data into 'Requirement_Lists' table...");
  
      // Check if the table already has data
      return new Promise((resolve, reject) => {
        db.query("SELECT COUNT(*) AS count FROM Requirement_Lists", (err, results) => {
          if (err) {
            console.error("Error checking existing data:", err.message);
            return reject(err);
          }
  
          if (results[0].count > 0) {
            console.log("Data already exists. Skipping insertion.");
            return resolve(false);
          }
  
          // Create an array to hold all insertion promises
          const insertPromises = [];
  
          // Process each list and its items
          jsonData.forEach(listItem => {
            const listName = listItem.name || null;
            const listId = listItem.id || null;
            
            // For each item in the list, create an insert promise
            if (Array.isArray(listItem.items) && listItem.items.length > 0) {
              listItem.items.forEach(item => {
                const itemValue = item.value || null;
                
                // Create insert promise for this list-item combination
                const insertPromise = new Promise((resolve, reject) => {
                  const sql = `INSERT INTO Requirement_Lists (name, id, value) VALUES (?, ?, ?)`;
                  const values = [listName, listId, itemValue];
                  
                  console.log(`Inserting: name=${listName}, id=${listId}, value=${itemValue}`);
                  
                  db.query(sql, values, (err, result) => {
                    if (err) {
                      console.error("Error inserting row:", err.message);
                      return reject(err);
                    }
                    resolve(result);
                  });
                });
                
                insertPromises.push(insertPromise);
              });
            } else {
              console.log(`List ${listName} has no items or items array is invalid`);
            }
          });
  
          // Wait for all insertions to complete
          Promise.all(insertPromises)
            .then(() => {
              console.log(`✅ Inserted data for ${jsonData.length} lists successfully.`);
              resolve(true);
            })
            .catch(err => {
              console.error("Error in batch insertion:", err.message);
              reject(err);
            });
        });
      });
    } catch (err) {
      console.error("Failed to insert data:", err.message);
      throw err;
    }
  };

const refreshRequirementListData = async (req, res) => {
  try {
    await fetchListRequirementFields();
    const jsonData = await loadJsonAndRequirementValidate();

    if (jsonData.length === 0) {
      return res.status(400).json({ error: "No valid data to insert" });
    }

    await new Promise((resolve, reject) => {
      db.query("DELETE FROM Requirement_Lists", (err) => {
        if (err) {
          console.error("Error clearing table:", err.message);
          return reject(err);
        }
        console.log("✅ Table 'Requirement_Lists' cleared.");
        resolve();
      });
    });

    const insertPromises = jsonData.map((item, index) => {
      const values = [item.name || null, item.id || null, item.value || null];
      console.log(`Inserting record ${index + 1}:`, values);  // Log each record to be inserted

      return new Promise((resolve, reject) => {
        const sql = `INSERT INTO Requirement_Lists (name, id, value) VALUES (?, ?, ?)`;

        db.query(sql, values, (err, result) => {
          if (err) {
            console.error("Error inserting row:", err.message);
            return reject(err);
          }
          resolve(result);
        });
      });
    });

    await Promise.all(insertPromises);

    return res.status(200).json({ 
      message: "ALM List data refreshed successfully", 
      count: jsonData.length 
    });
  } catch (error) {
    console.error("Failed to refresh ALM List data:", error.message);
    return res.status(500).json({ error: error.message });
  }
};

const getAllListRequirementTestCases = (req, res) => {
  db.query("SELECT * FROM Requirement_Lists", (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    const formattedResults = results.map(row => ({
      ...row,
      required: row.required === 1,
      supportsMultivalue: row.supportsMultivalue === 1
    }));

    res.json(formattedResults);
  });
};

const createListRequirementTestCases = async (req, res) => {
  const testCases = req.body;

  if (!Array.isArray(testCases) || testCases.length === 0) {
    return res.status(400).json({ message: "Invalid input, expecting an array of test cases" });
  }

  const insertPromises = testCases.map((item, index) => {
    const values = [item.name || null, item.id || null, item.value || null];
    console.log(`Inserting new test case ${index + 1}:`, values);  // Log each record to be inserted

    return new Promise((resolve, reject) => {
      const sql = `INSERT INTO Requirement_Lists (name, id, value) VALUES (?, ?, ?)`;

      db.query(sql, values, (err, result) => {
        if (err) {
          console.error("Error inserting row:", err.message);
          return reject(err);
        }
        resolve(result);
      });
    });
  });

  try {
    await Promise.all(insertPromises);
    res.status(201).json({ message: `${testCases.length} new test cases added.` });
  } catch (err) {
    console.error("Error inserting data:", err.message);
    return res.status(500).json({ error: err.message });
  }
};

module.exports = {
  initlistRequirement ,
  createListRequirementTables,
  insertListRequirementDataJson,
  getAllListRequirementTestCases,
  getListRequirementFields,
  createListRequirementTestCases,
  refreshRequirementListData
};




