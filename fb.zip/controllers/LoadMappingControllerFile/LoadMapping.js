const db = require('../../config/db');
 
const getLinkNames = (req, res) => {
  db.query('SELECT DISTINCT link_name FROM link_table', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results.map(row => row.link_name));
  });
};
 
const getArtifactTypesByLink = (req, res) => {
  const linkName = req.params.linkName;
  db.query(
    'SELECT DISTINCT artifact_type FROM field_mappings WHERE link_name = ?',
    [linkName],
    (err, results) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(results.map(row => row.artifact_type));
    }
  );
};
 
const getMappedFieldsByArtifacts = (req, res) => {
  const { linkName, artifacts } = req.body;
 
  if (!linkName || !Array.isArray(artifacts) || artifacts.length === 0) {
    return res.status(400).json({ error: 'Invalid request' });
  }
 
  const placeholders = artifacts.map(() => '?').join(',');
  const query = `
    SELECT artifact_type, ep1_name, ep1_label, ep2_label
    FROM field_mappings
    WHERE link_name = ? AND artifact_type IN (${placeholders})
  `;
 
  db.query(query, [linkName, ...artifacts], (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
 
    // Group by artifact_type
    const grouped = {};
    results.forEach(({ artifact_type, ep1_name, ep1_label, ep2_label }) => {
      if (!grouped[artifact_type]) grouped[artifact_type] = [];
      grouped[artifact_type].push({
        ep1_name,
        ep1_label,
        ep2_label
      });
    });
 
    res.json(grouped);
  });
};
 
 
module.exports = {
  getLinkNames,
  getArtifactTypesByLink,
  getMappedFieldsByArtifacts
};
 
