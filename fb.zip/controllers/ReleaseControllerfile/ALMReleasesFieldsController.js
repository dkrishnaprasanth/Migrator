const db = require("../../config/db");
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const { fetchAlmReleasesFields } = require("../../controllers/ReleaseControllerfile/ALMReleasesFields");

const requiredFields = ["label", "name", "type", "physicalName", "required", "listId", "supportsMultivalue", "qtest_id"];

const getTypeCode = (type, supportsMultivalue) => {

  let v_datatype = 1;
  
  if (!type) return v_datatype;
  
  if (type === 'Number') {
    v_datatype = 7;
  } else if (type === 'String') {
    v_datatype = 1;
  } else if (type === 'LookupList') {
    if (supportsMultivalue) {
      v_datatype = 17;
    } else {
      v_datatype = 3;
    }
  } else if (type === 'UsersList') {
    v_datatype = 5;
  } else if (type === 'Date') {
    v_datatype = 4;
  } else if (type === 'DateTime') {
    v_datatype = 9;
  } else if (type === 'Memo') {
    v_datatype = 2;
  }
  
  // Return the determined data type code
  return v_datatype;
};

const getAlmReleaseFields = async (req, res) => {
  db.query("SELECT * FROM alm_data", (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    
    const formattedResults = results.map(row => {
      const isRequired = row.required === 1;
      const supportsMultivalue = row.supportsMultivalue === 1;
      
      return {
        ...row,
        required: isRequired,
        supportsMultivalue: supportsMultivalue,
        typeCode: getTypeCode(row.type, supportsMultivalue)
      };
    });
    
    res.json(formattedResults);
  });
};

// ------------------------------
// Read and Validate JSON
// ------------------------------
const loadJsonAndValidate = async () => {
  const jsonFilePath = path.join(__dirname, "../../data/Releasesdatafile/AlmReleaseFields.json");

  try {
    if (!fs.existsSync(jsonFilePath)) {
      console.error(" JSON file does not exist:", jsonFilePath);
      return [];
    }

    const rawData = fs.readFileSync(jsonFilePath, "utf-8");
    const parsedData = JSON.parse(rawData);

    if (
      !Array.isArray(parsedData) &&
      (!parsedData.Fields || !Array.isArray(parsedData.Fields.Field))
    ) {
      console.error(" Unexpected JSON structure:", parsedData);
      return [];
    }

    const normalizedData = Array.isArray(parsedData)
      ? parsedData
      : parsedData.Fields.Field;


    const validated = normalizedData.map((item) => {
      const filtered = {};
      requiredFields.forEach((field) => {
        filtered[field] = item[field] !== undefined ? item[field] : null;
      });
      return filtered;
    });

    return validated;
  } catch (err) {
    console.error(" Error reading/parsing JSON file:", err.message);
    return [];
  }
};


const getAlmFieldByPhysicalName = async (req, res) => {
  const { physicalName } = req.params;

  if (!physicalName) {
    return res.status(400).json({ error: "Physical name is required" });
  }

  db.query(
    "SELECT * FROM alm_data WHERE physicalName = ?",
    [physicalName],
    (err, results) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }

      if (results.length === 0) {
        return res.status(404).json({ error: "Field not found" });
      }

      // Convert numeric 0/1 back to boolean true/false for display and add typeCode
      const isRequired = results[0].required === 1;
      const supportsMultivalue = results[0].supportsMultivalue === 1;

      const formattedResult = {
        ...results[0],
        required: isRequired,
        supportsMultivalue: supportsMultivalue,
        typeCode: getTypeCode(results[0].type, supportsMultivalue)
      };

      res.json(formattedResult);
    }
  );
};

// Fixed createAlmJsonFile function from ALMReleasesFieldsController.js
const createAlmJsonFile = async (req, res) => {
  const { physicalName } = req.body;

  if (!physicalName) {
    return res.status(400).json({ error: "Physical name is required" });
  }

  try {
    // Fetch field from alm_data table
    const result = await new Promise((resolve, reject) => {
      db.query(
        "SELECT * FROM alm_data WHERE physicalName = ?",
        [physicalName],
        (err, results) => {
          if (err) return reject(err);
          if (!results.length) return reject(new Error("Field not found"));
          resolve(results[0]);
        }
      );
    });

    const isRequired = result.required === 1;
    const supportsMultivalue = result.supportsMultivalue === 1;

    let jsonData;

    if (result.type === "LookupList") {
      if (!result.listId) {
        throw new Error("Missing listId in alm_data for LookupList");
      }

      // Fetch values from listereleases table using listId
      const listValues = await new Promise((resolve, reject) => {
        db.query(
          "SELECT value FROM listereleases WHERE id = ?",
          [result.listId],
          (err, results) => {
            if (err) return reject(err);
            if (!results.length) return reject(new Error("No values found in listereleases table"));
            resolve(results);
          }
        );
      });

      const allowedValues = listValues.map((item, index) => ({
        label: item.value,
        is_default: false,
        is_active: true,
      }));

      jsonData = {
        label: result.label,
        allowed_values: allowedValues,
        data_type: getTypeCode(result.type, supportsMultivalue),
        multiple: supportsMultivalue,
        is_active: true,
      };
    } else {
      // Non-lookup field
      jsonData = {
        label: result.label,
        data_type: getTypeCode(result.type, supportsMultivalue),
        required: isRequired,
        is_active: true,
      };
    }

    // Create the directory structure if it doesn't exist
    const dataDir = path.join(__dirname, "../../data");
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Create Releasesdatafile directory if it doesn't exist
    const releasesDir = path.join(dataDir, "Releasesdatafile");
    if (!fs.existsSync(releasesDir)) {
      fs.mkdirSync(releasesDir, { recursive: true });
    }

    // Write to file - use the correct path mentioned in your error
    const filePath = path.join(releasesDir, "ALMListReleases.json");
    fs.writeFileSync(filePath, JSON.stringify(jsonData, null, 2), "utf-8");

    console.log("✅ JSON file created:", filePath);

    res.status(200).json({
      message: "JSON file created successfully",
      data: jsonData,
      filePath,
    });
  } catch (error) {
    console.error("❌ Error creating JSON file:", error.message);
    res.status(error.message === "Field not found" ? 404 : 500).json({
      error: error.message,
    });
  }
};

const init = async () => {
  try {
    console.log(" Fetching ALM release fields...");
    await fetchAlmReleasesFields();
    console.log("✅ Fetch complete.");
    
    // Create tables if they don't exist
    await createTables();
    
    // Insert data from JSON
    await insertDataJson();
    
    console.log("✅ ALM initialization complete.");
  } catch (err) {
    console.error(" Failed to initialize ALM data:", err.message);
    process.exit(1);
  }
};

// ------------------------------
// Create Table if not exists
// ------------------------------
const createTables = async () => {
  return new Promise((resolve, reject) => {
    const dropreleasestQuery = `DROP TABLE IF EXISTS alm_data`;
    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS alm_data (
        id INT AUTO_INCREMENT PRIMARY KEY,
        label TEXT,
        name TEXT,
        type TEXT,
        physicalName TEXT,
        required TINYINT(1),
        listId INT,
        supportsMultivalue TINYINT(1),
        qtest_id INT
      )
    `;

    db.query(dropreleasestQuery, (dropErr) => {
      if (dropErr) {
        console.error("Error dropping table:", dropErr.message);
        return reject(dropErr);
      }
    
    db.query(createTableQuery, (err) => {
      if (err) {
        console.error("❌ Error creating table:", err.message);
        return reject(err);
      }
      console.log("✅ Table 'alm_data' created successfully (or already exists).");
      resolve(true);
    });
  });
  });
};

// ------------------------------
// Insert JSON Data into DB
// ------------------------------
const insertDataJson = async () => {
  try {
    const jsonData = await loadJsonAndValidate();

    return new Promise((resolve, reject) => {
      db.query("SELECT COUNT(*) AS count FROM alm_data", (err, results) => {
        if (err) {
          console.error("Error checking existing data:", err.message);
          return reject(err);
        }

        const existingCount = results[0].count;
        if (existingCount > 0) {
          console.log("⚠️ Data already exists in alm_data table. Skipping insert.");
          return resolve(false);
        }

        const insertQuery = `
          INSERT INTO alm_data 
          (label, name, type, physicalName, required, listId, supportsMultivalue, qtest_id)
          VALUES ?
        `;

        const values = jsonData.map(item => [
          item.label,
          item.name,
          item.type,
          item.physicalName,
          item.required ? 1 : 0,
          item.listId || null,
          item.supportsMultivalue ? 1 : 0,
          item.qtest_id || null
        ]);

        db.query(insertQuery, [values], (insertErr) => {
          if (insertErr) {
            console.error("❌ Error inserting data:", insertErr.message);
            return reject(insertErr);
          }

          console.log("✅ Data inserted successfully into alm_data table.");
          resolve(true);
        });
      });
    });
  } catch (err) {
    console.error("❌ Failed to insert data from JSON:", err.message);
    throw err;
  }
};


// ------------------------------
// Get All Test Cases
// ------------------------------
const getAllTestCases = (req, res) => {
  db.query("SELECT * FROM alm_data", (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    
    const formattedResults = results.map(row => {
      const isRequired = row.required === 1;
      const supportsMultivalue = row.supportsMultivalue === 1;
      
      return {
        ...row,
        required: isRequired,
        supportsMultivalue: supportsMultivalue,
        typeCode: getTypeCode(row.type, supportsMultivalue)
      };
    });
    
    res.json(formattedResults);
  });
};

// ------------------------------
// Insert New Test Cases (API)
// ------------------------------
const createTestCases = async (req, res) => {
  const testCases = req.body;

  if (!Array.isArray(testCases) || testCases.length === 0) {
    return res
      .status(400)
      .json({ message: "Invalid input, expecting an array of test cases" });
  }
  const insertPromises = testCases.map((item) => {
    return new Promise((resolve, reject) => {
      const sql = `
        INSERT INTO alm_data (label, name, type, physicalName, required, listId, supportsMultivalue, qtest_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `;
      
      const values = [
        item.label || null,
        item.name || null,
        item.type || null,
        item.physicalName || null,
        item.required === true ? 1 : 0, 
        item.listId,
        item.supportsMultivalue === true ? 1 : 0,
        item.qtest_id || null
      ];
      
      db.query(sql, values, (err, result) => {
        if (err) {
          console.error(" Error inserting row:", err.message);
          return reject(err);
        }
        resolve(result);
      });
    });
  });

  try {
    await Promise.all(insertPromises);
    res.status(201).json({ 
      message: `${testCases.length} new test cases added successfully` 
    });
  } catch (err) {
    console.error(" Error inserting data:", err.message);
    return res.status(500).json({ error: err.message });
  }
};


// Fixed uploadAlmJsonFile function from ALMReleasesFieldsController.js
const uploadAlmJsonFile = async (req, res) => {
  try {
    const credentialsPath = path.join(__dirname, "../../data/qTestCredentials.json");
    const credentialsData = fs.readFileSync(credentialsPath, "utf-8");
    const config = JSON.parse(credentialsData);

    const qTestDomain = config.qTestDomain;
    const apiToken = config.apiToken;
    const projectId = config.projectId;

    // Update the path to match the path in createAlmJsonFile
    const payloadPath = path.join(__dirname, "../../data/Releasesdatafile/ALMListReleases.json");
    
    // Check if file exists
    if (!fs.existsSync(payloadPath)) {
      return res.status(404).json({
        error: "ALMListReleases.json file not found. Please create it first using the create-alm-field endpoint."
      });
    }
    
    const payload = JSON.parse(fs.readFileSync(payloadPath, "utf-8"));

    const response = await axios.post(
      `${qTestDomain}/api/v3/projects/${projectId}/settings/releases/fields`,
      payload,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiToken}`,
        },
      }
    );

    console.log("✅ Uploaded to qTest");
    res.status(200).json({
      message: "Uploaded to qTest successfully",
      statusCode: response.status,
      data: response.data,
    });
  } catch (error) {
    console.error("❌ Upload error:", error.message);
    res.status(500).json({
      error: error.message,
    });
  }
};

const getListValues = async (req, res) => {
  const { listId } = req.params;
  
  if (!listId) {
    return res.status(400).json({ error: "listId is required" });
  }

  db.query(
    "SELECT value FROM listereleases WHERE id = ?",
    [listId],
    (err, results) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      res.json(results);
    }
  );
};

module.exports = {
  init,
  createTables,
  insertDataJson,
  getAllTestCases,
  getAlmReleaseFields,
  createTestCases,
  createAlmJsonFile,
  getAlmFieldByPhysicalName,
  uploadAlmJsonFile,
  getListValues
};

