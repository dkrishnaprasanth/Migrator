const fs = require("fs");
const path = require("path");
const axios = require("axios");
const db = require("../../config/db");
 
const formatDateForQTest = (date) => {
  if (!date || isNaN(date.getTime())) return null;
  const year = date.getUTCFullYear();
  const month = String(date.getUTCMonth() + 1).padStart(2, '0');
  const day = String(date.getUTCDate()).padStart(2, '0');
  return `${year}-${month}-${day}T00:00:00+00:00`;
};
 

 
// Rest of your existing code for upload functions...

const insertSampleData = async (req, res) => {
  try {
    // Get field mappings
    const [columns] = await db.promise().query(
      "SELECT ep1_name, ep1_type, ep2_field_id FROM Field_mappings WHERE artifact_type='Release' "
    );
 
    if (!columns || columns.length === 0) {
      return res.status(400).json({
        success: false,
        message: "No mapping columns found. Please create mappings first."
      });
    }
 
    // Check if JSON file exists
    const jsonFilePath = path.join(__dirname, '../../data/Releasesdatafile/AlmReleases.json');
    if (!fs.existsSync(jsonFilePath)) {
      return res.status(404).json({
        success: false,
        message: `JSON file not found at: ${jsonFilePath}`
      });
    }
 
    const jsonData = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'));
    console.log(`Loaded ${jsonData.entities?.length || 0} entities from JSON`);
 
    // Get table structure
    const [tableInfo] = await db.promise().query("DESCRIBE releases");
    const tableColumns = tableInfo.map(column => column.Field);
 
    // Generate mapping columns (normalize column names)
    const mappingColumns = columns.map(col =>
      col.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase()
    );
 
    // Required columns
    const requiredColumns = ['id', 'name', 'has_link', 'has_attachment', 'last_modified', 'qtest_releases_id', 'upload_status', 'attach_status'];
 
    const validMappingColumns = mappingColumns.filter(col => tableColumns.includes(col));
    const validRequiredColumns = requiredColumns.filter(col => tableColumns.includes(col));
 
    const finalColumns = [...new Set([...validMappingColumns, ...validRequiredColumns])];
 
    if (finalColumns.length === 0) {
      return res.status(400).json({
        success: false,
        message: "No valid columns found for insertion"
      });
    }
 
    const columnSQL = finalColumns.map(col => `\`${col}\``).join(', ');
    const allRowsToInsert = [];
 
    // Prepare data
    for (const entity of jsonData.entities) {
      const rowData = {};
      finalColumns.forEach(col => { rowData[col] = null; });
 
      for (const column of columns) {
        const columnName = column.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
        if (!tableColumns.includes(columnName)) continue;
 
        const matchingField = entity.Fields?.find(field =>
          field.Name?.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase() === columnName
        );
 
        if (!matchingField || !matchingField.values || matchingField.values.length === 0) {
          rowData[columnName] = null;
        } else {
          const combinedValue = matchingField.values.map(v => v.value).join(',');
          switch (column.ep1_type) {
            case 'Number':
              rowData[columnName] = isNaN(Number(combinedValue)) ? null : Number(combinedValue);
              break;
            case 'Date':
              rowData[columnName] = formatDateForQTest(new Date(combinedValue));
              break;
            default:
              rowData[columnName] = combinedValue;
          }
        }
      }
 
      // Handle required fields
      if (tableColumns.includes('id')) {
        const idField = entity.Fields?.find(f => f.Name === 'id');
        rowData['id'] = idField?.values?.[0]?.value ? Number(idField.values[0].value) : null;
      }
      if (tableColumns.includes('name')) {
        const nameField = entity.Fields?.find(f => f.Name === 'name');
        rowData['name'] = nameField?.values?.[0]?.value || null;
      }
      if (tableColumns.includes('has_link')) {
        const linkField = entity.Fields?.find(f => f.Name === 'req-count');
        rowData['has_link'] = linkField?.values?.[0]?.value || null;
      }
      if (tableColumns.includes('has_attachment')) {
        const attachmentField = entity.Fields?.find(f => f.Name === 'has-attachments');
        rowData['has_attachment'] = attachmentField?.values?.[0]?.value || null;
      }
      if (tableColumns.includes('last_modified')) {
        const modifiedField = entity.Fields?.find(f => f.Name === 'last-modified');
        rowData['last_modified'] = modifiedField?.values?.[0]?.value || null;
      }
      if (tableColumns.includes('qtest_releases_id')) rowData['qtest_releases_id'] = null;
      if (tableColumns.includes('upload_status')) rowData['upload_status'] = null;
      if (tableColumns.includes('attach_status')) rowData['attach_status'] = null;
 
      allRowsToInsert.push(finalColumns.map(col => rowData[col]));
    }
 
    if (allRowsToInsert.length === 0) {
      return res.status(400).json({ success: false, message: 'No data to insert.' });
    }
 
    let insertedCount = 0;
    let updatedCount = 0;
 
    for (const rowValues of allRowsToInsert) {
      const rowData = {};
      finalColumns.forEach((col, index) => { rowData[col] = rowValues[index]; });
 
      if (!rowData.id) continue;
 
      const [existingRows] = await db.promise().query(
        "SELECT id, last_modified, upload_status, qtest_releases_id FROM releases WHERE id = ?",
        [rowData.id]
      );
 
      if (existingRows.length === 0) {
        const insertSQL = `INSERT INTO releases (${columnSQL}) VALUES (${finalColumns.map(() => '?').join(', ')})`;
        await db.promise().query(insertSQL, rowValues);
        insertedCount++;
      } else {
        const existing = existingRows[0];
        const isModified = new Date(existing.last_modified).getTime() !== new Date(rowData.last_modified).getTime();
 
        if (isModified) {
          let newStatus = existing.qtest_releases_id ? 'modified' : 'changed';
          const columnsToUpdate = finalColumns.filter(
            col => col !== 'id' && (existing.qtest_releases_id ? col !== 'qtest_releases_id' : true)
          );
 
          const updateSQL = `UPDATE releases SET ${columnsToUpdate.map(col => `\`${col}\` = ?`).join(', ')}, upload_status = ? WHERE id = ?`;
          const updateValues = columnsToUpdate.map(col => rowData[col]).concat([newStatus, rowData.id]);
 
          await db.promise().query(updateSQL, updateValues);
          updatedCount++;
        }
      }
    }
 
    // ✅ Get total count after insert/update
    const [totalRows] = await db.promise().query("SELECT COUNT(*) as count FROM releases");
 
    res.status(200).json({
      success: true,
      message: `Releases processed successfully`,
      details: {
        inserted: insertedCount,
        updated: updatedCount,
        skipped: allRowsToInsert.length - insertedCount - updatedCount,
        totalProcessed: allRowsToInsert.length
      },
      totalCount: totalRows[0].count
    });
 
  } catch (error) {
    console.error('❌ Error inserting data:', error);
    res.status(500).json({
      success: false,
      message: `Error inserting data: ${error.message}`,
      stack: error.stack
    });
  }
};
 

const credentials = require("../../data/qTestCredentials.json");
let uploadStats = {
  total: 0,
  success: 0,
  failed: 0,
  skipped: 0,
  updated: 0,
  pending: 0
};
 
const validateFieldValue = (field, mapping) => {
  if (field.field_value === null || field.field_value === undefined || field.field_value === '') {
    return { valid: false, error: 'Empty value' };
  }
 
  if (mapping.ep1_type === 'Date') {
    const dateValue = field.field_value;
    if (typeof dateValue === 'string' && !isNaN(Date.parse(dateValue))) {
      const date = new Date(dateValue);
      field.field_value = formatDateForQTest(date);
      return { valid: true };
    } else {
      return { valid: false, error: 'Invalid date format' };
    }
  }
 
  if (mapping.ep1_type === 'Number') {
    if (isNaN(Number(field.field_value))) {
      return { valid: false, error: 'Invalid number format' };
    }
    field.field_value = Number(field.field_value);
    return { valid: true };
  }
 
  if (mapping.ep1_type === 'String') {
    if (typeof field.field_value !== 'string') {
      field.field_value = String(field.field_value);
    }
    if (field.field_value.length > 255) {
      field.field_value = field.field_value.substring(0, 255);
    }
    return { valid: true };
  }
 
  return { valid: true };
};
 
const getQTestFieldDefinitions = async () => {
  try {
    const endpoints = [
      // `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/settings/release/fields`,
      // `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/releases/fields`
    ];
 
    for (const endpoint of endpoints) {
      try {
        const response = await axios.get(endpoint, {
          headers: {
            Authorization: `Bearer ${credentials.apiToken}`,
          },
          timeout: 10000
        });
 
        if (response.data && Array.isArray(response.data)) {
          console.log(`✅ Successfully fetched field definitions from: ${endpoint}`);
          return response.data;
        }
      } catch (endpointError) {
        // console.log(`⚠️ Endpoint failed: ${endpoint} - ${endpointError.response?.status || endpointError.message}`);
        continue;
      }
    }
 
    // console.log('ℹ️ Could not fetch field definitions from any endpoint, continuing without validation');
    return [];
  } catch (error) {
    // console.log('ℹ️ Field definitions not available, continuing without additional validation');
    return [];
  }
};
 
const validatePayload = async (payload, mappings) => {
  const errors = [];
  const warnings = [];
 
  if (!payload.name || payload.name.trim() === '') {
    errors.push('Release name is required');
  } else if (payload.name.length > 255) {
    warnings.push('Release name is too long, truncating to 255 characters');
    payload.name = payload.name.substring(0, 255);
  }
 
  const qTestFields = await getQTestFieldDefinitions();
  const qTestFieldMap = {};
 
  if (qTestFields && qTestFields.length > 0) {
    qTestFields.forEach(field => {
      qTestFieldMap[field.id] = field;
    });
    // console.log(`ℹ️ Using ${qTestFields.length} field definitions for validation`);
  } else {
    // console.log('ℹ️ Proceeding with basic validation only');
  }
 
  for (let i = payload.properties.length - 1; i >= 0; i--) {
    const property = payload.properties[i];
    const mapping = mappings.find(m => m.ep2_field_id === property.field_id);
 
    if (!mapping) {
      warnings.push(`No mapping found for field_id: ${property.field_id}`);
      continue;
    }
 
    const validation = validateFieldValue(property, mapping);
    if (!validation.valid) {
      warnings.push(`Invalid value for ${property.field_name}: ${validation.error}`);
      payload.properties.splice(i, 1);
      continue;
    }
 
    const qTestField = qTestFieldMap[property.field_id];
    if (qTestField && qTestField.required && (property.field_value === null || property.field_value === '')) {
      errors.push(`Required field ${property.field_name} is empty`);
    }
  }
 
  return { errors, warnings, isValid: errors.length === 0 };
};
 
const uploadReleaseToQTest = async (payload, releaseId, mappings, uploadStatus, qtestReleaseId) => {
  try {
    const validation = await validatePayload(payload, mappings);
 
    if (validation.warnings.length > 0) {
      console.warn(`⚠️ Validation warnings for release ${releaseId}:`, validation.warnings);
    }
 
    if (!validation.isValid) {
      console.error(`❌ Validation errors for release ${releaseId}:`, validation.errors);
      await db.promise().query("UPDATE releases SET upload_status = ? WHERE id = ?", [
        `failed_validation: ${validation.errors.join(', ')}`,
        releaseId,
      ]);
 
      uploadStats.failed++;
      uploadStats.pending--;
      return { success: false, error: `Validation failed: ${validation.errors.join(', ')}` };
    }
 
    let response;
    //let isUpdate = (uploadStatus === 'changed' && qtestReleaseId);
 
    let isUpdate = (uploadStatus === 'modified' && qtestReleaseId);
 
 
    if (isUpdate) {
      console.log(`🔁 Updating release ${releaseId} via PUT to qTest ID ${qtestReleaseId}`);
      response = await axios.put(
        `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/releases/${qtestReleaseId}`,
        payload,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${credentials.apiToken}`,
          },
          timeout: 30000
        }
      );
    } else {
      console.log(`➕ Creating new release ${releaseId} via POST`);
      response = await axios.post(
        `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/releases`,
        payload,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${credentials.apiToken}`,
          },
          timeout: 30000
        }
      );
    }
 
    if ([200, 201].includes(response.status)) {
      await db.promise().query(
        "UPDATE releases SET upload_status = ?, qtest_releases_id = ? WHERE id = ?",
        ["completed", response.data.id || qtestReleaseId, releaseId]
      );
 
      // uploadStats.success++;
      // uploadStats.pending--;
 
      // console.log(`✅ Release ${releaseId} ${isUpdate ? 'updated' : 'uploaded'} successfully`);
      // return { success: true, qTestId: response.data.id || qtestReleaseId };
 
      if (isUpdate) {
        uploadStats.updated++; // ✅ Track updated separately
      } else {
        uploadStats.success++;
      }
      uploadStats.pending--; // ✅ Reduce pending for successful cases
 
      console.log(`✅ Release ${releaseId} ${isUpdate ? 'updated' : 'uploaded'} successfully`);
      return { success: true, qTestId: response.data.id || qtestReleaseId };
 
 
    } else {
      await db.promise().query("UPDATE releases SET upload_status = ? WHERE id = ?", [
        `failed_${response.status}`,
        releaseId,
      ]);
 
      uploadStats.failed++;
      uploadStats.pending--;
      return { success: false, error: `HTTP Status: ${response.status}` };
    }
  } catch (error) {
    const status = error.response?.status || "unknown_error";
    const errorMessage = error.response?.data?.message || error.response?.data || error.message || "Unknown error";
 
    console.error(`❌ Upload error for release ${releaseId}:`, { status, errorMessage });
 
    const detailedError = `${status}: ${errorMessage}`;
    await db.promise().query("UPDATE releases SET upload_status = ? WHERE id = ?", [
      `failed_${detailedError}`.substring(0, 255),
      releaseId,
    ]);
 
    uploadStats.failed++;
    uploadStats.pending--;
    return { success: false, error: errorMessage };
  }
};
 

const processReleases = async (releaseRows) => {
  const [mappingRow] = await db
    .promise()
    .query("SELECT DISTINCT link_name FROM Field_mappings WHERE artifact_type = 'Release'");
 
  const currentTable = mappingRow.length > 0 ? mappingRow[0].link_name : null;
  if (!currentTable) throw new Error("No active mapping table found.");
 
  const [mappings] = await db
    .promise()
    .query(
      "SELECT ep1_name, ep1_type, ep2_label, ep2_field_id FROM Field_mappings WHERE  artifact_type = 'Release' AND link_name = ?",
      [currentTable]
    );
 
  console.log(`Found ${mappings.length} field mappings`);
 
  let counter = 1;
 
  for (let row of releaseRows) {
    console.log(`🔄 Processing Release ${counter}/${releaseRows.length} (ID: ${row.id})`);
 
 
    if (row.upload_status === 'completed' && row.qtest_releases_id) {
      console.log(`⏭️ Skipping Release ID ${row.id} - already completed and has qTest ID`);
      uploadStats.skipped++;
      uploadStats.pending--;
      continue;
    }
 
 
 
    let releaseName = `Release_${row.id}`;
 
    if (row.name && row.name.trim() !== '') {
      releaseName = row.name.trim();
    }
 
    // console.log(`📝 Release name: ${releaseName}`);
 
    const properties = [];
 
    for (let mapping of mappings) {
      const columnName = mapping.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
      const rawValue = row[columnName];
 
      console.log(`🔍 Processing field: ${mapping.ep1_name} (${columnName}) = ${rawValue} (type: ${mapping.ep1_type})`);
 
      if (rawValue === null || rawValue === undefined || rawValue === '') {
        console.log(`⚠️ Skipping empty value for ${columnName}`);
        continue;
      }
 
      if (mapping.ep1_type === "LookupList") {
        const valuesToCheck = typeof rawValue === 'string' ? rawValue.split(',').map(v => v.trim()) : [rawValue];
 
        const [valueMappings] = await db.promise().query(`
          SELECT ep1_value, ep2_value_id, ep2_value
          FROM value_mappings
          WHERE ep1_name = ? AND ep2_field_id = ?
        `, [mapping.ep1_name, mapping.ep2_field_id]);
 
        console.log(`🔎 Found ${valueMappings.length} value mappings for ${mapping.ep1_name}`);
        const matchedEp2Ids = [];
        const matchedEp2Names = [];
 
        valuesToCheck.forEach(value => {
          const match = valueMappings.find(vm => vm.ep1_value === value);
          if (match) {
            matchedEp2Ids.push(match.ep2_value_id);
            matchedEp2Names.push(match.ep2_value);
            console.log(`✅ Matched value: ${value} -> ${match.ep2_value_id} (${match.ep2_value})`);
          } else {
            console.log(`❌ No match found for value: ${value}`);
          }
        });
 
        if (matchedEp2Ids.length > 0) {
          const fieldValue = matchedEp2Ids.length === 1 ? matchedEp2Ids[0] : matchedEp2Ids[0];
          const fieldValueName = matchedEp2Names.length === 1 ? matchedEp2Names[0] : matchedEp2Names[0];
          properties.push({
            field_id: mapping.ep2_field_id,
            field_name: mapping.ep2_label,
            field_value: fieldValue,
            field_value_name: fieldValueName
          });
          console.log(`✅ Added LookupList property: ${mapping.ep2_label} = ${fieldValue} with name ${fieldValueName}`);
        }
      } 
      
       else if (mapping.ep1_type === "UsersList") {
  const valuesToCheck = typeof rawValue === 'string' 
    ? rawValue.split(',').map(v => v.trim()) 
    : [rawValue];

  for (const value of valuesToCheck) {
    // Query users table to match the Name column
    const [userMatch] = await db.promise().query(`
      SELECT qtest_id, first_name 
      FROM users 
      WHERE Name = ?
      LIMIT 1
    `, [value]);

    if (userMatch.length > 0) {
      const { qtest_id, first_name } = userMatch[0];

      properties.push({
        field_id: mapping.ep2_field_id,
        field_name: mapping.ep2_label,
        field_value: qtest_id,
        field_value_name: first_name
      });

      console.log(`✅ Matched user: ${value} -> ${qtest_id} (${first_name})`);
    } else {
      console.log(`❌ No match found in users table for: ${value}`);
    }
  }
}

      else {
        let processedValue = rawValue;
 
        if (mapping.ep1_type === 'Number') {
          processedValue = isNaN(Number(rawValue)) ? null : Number(rawValue);
        } else if (mapping.ep1_type === 'Date') {
          const parsedDate = new Date(rawValue);
          processedValue = formatDateForQTest(parsedDate);
        } else if (mapping.ep1_type === 'String') {
          processedValue = String(rawValue).trim();
        }
 
        if (processedValue !== null && processedValue !== '') {
          properties.push({
            field_id: mapping.ep2_field_id,
            field_name: mapping.ep2_label,
            field_value: processedValue
          });
          console.log(`✅ Added ${mapping.ep1_type} property: ${mapping.ep2_label} = ${processedValue}`);
        }
      }
    }
 
    // console.log(`📊 Total properties created: ${properties.length}`);
 
    if (!releaseName || releaseName.trim() === '' || releaseName === 'Release_') {
      console.error(`❌ Skipping release with invalid name: ${row.id}`);
      await db.promise().query("UPDATE releases SET upload_status = ? WHERE id = ?", ['failed_no_name', row.id]);
      uploadStats.skipped++;
      uploadStats.pending--;
      continue;
    }
 
    const singlePayload = {
      name: releaseName.trim(),
      properties: properties
    };
 
    // console.log(`📋 Final payload:`, JSON.stringify(singlePayload, null, 2));
 
    const outputPath = path.join(__dirname, "../../data/Releasesdatafile/ReleasesfinalPayload.json");
    fs.writeFileSync(outputPath, JSON.stringify(singlePayload, null, 2), "utf8");
 
    //const uploadResult = await uploadReleaseToQTest(singlePayload, row.id, mappings);
 
    const uploadResult = await uploadReleaseToQTest(
      singlePayload,
      row.id,
      mappings,
      row.upload_status,
      row.qtest_releases_id
    );
 
 
    if (!uploadResult.success) {
      console.error(`❌ Upload failed for Release ${releaseName}: ${uploadResult.error}`);
    } else {
      console.log(`✅ Successfully uploaded Release ${releaseName} with ID ${uploadResult.qTestId}`);
    }
 
    counter++;
    await new Promise(resolve => setTimeout(resolve, 1000));
  }
};
 
const processAndUploadAllReleases = async (req, res) => {
  try {
    uploadStats = {
      total: 0,
      success: 0,
      failed: 0,
      updated: 0,
      skipped: 0,
      pending: 0
    };
 
    //const [releaseRows] = await db.promise().query("SELECT * FROM releases WHERE upload_status IS NULL OR upload_status LIKE 'failed%' OR upload_status = 'pending'");
 
    //     const [releaseRows] = await db.promise().query(`
    //   SELECT * FROM releases
    //   WHERE upload_status IS NULL
    //      OR upload_status LIKE 'failed%'
    //      OR upload_status = 'pending'
    //      OR upload_status = 'changed'
    // `);
 
    const [releaseRows] = await db.promise().query(`
  SELECT * FROM releases
  WHERE upload_status IS NULL
     OR upload_status LIKE 'failed%'
     OR upload_status = 'pending'
     OR upload_status = 'modified'
     OR upload_status = 'completed'
`);
 
 
 
    uploadStats.total = releaseRows.length;
    uploadStats.pending = releaseRows.length;
 
    //     uploadStats.total = releaseRows.length;
 
    // // ✅ Pending should exclude already completed releases
    // uploadStats.pending = releaseRows.filter(row =>
    //   row.upload_status !== 'completed'
    // ).length;
 
 
    await processReleases(releaseRows);
 
    res.status(200).json({
      message: "Migration completed",
      counts: uploadStats,
    });
  } catch (error) {
    console.error("❌ Error processing releases:", error.message);
    res.status(500).json({ message: "Migration failed", error: error.message });
  }
};
 
const getMigrationStatus = async (req, res) => {
 
  res.json({ counts: uploadStats });
 
};

const getReleasesCount = async (req, res) => {
  try {
    const jsonFilePath = path.join(__dirname, '../../data/Releasesdatafile/AlmReleases.json');

    if (!fs.existsSync(jsonFilePath)) {
      return res.status(404).json({
        success: false,
        message: `JSON file not found at: ${jsonFilePath}`
      });
    }

    const jsonData = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'));
    const totalCount = jsonData.entities?.length || 0;

    res.json({ totalCount });
  } catch (error) {
    console.error("❌ Error fetching release count:", error);
    res.status(500).json({ error: "Failed to fetch release count" });
  }
};
 
module.exports = {
  insertSampleData,
  processAndUploadAllReleases,
  getMigrationStatus,
  getReleasesCount
};
 
 