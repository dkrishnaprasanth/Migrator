


const db = require("../../config/db");
const fs = require("fs");
const path = require("path");
const { fetchqTestReleasesFields } = require("../ReleaseControllerfile/qTestReleasesFields");

// ------------------------------
// Read and Validate JSON
// ------------------------------
const loadJsonAndValidate = async () => {
  const jsonFilePath = path.join(__dirname, "../../data/Releasesdatafile/qTestReleaseFields.json");

  try {
    const rawData = fs.readFileSync(jsonFilePath, "utf-8");
    if (!rawData) {
      console.error("❌ JSON file is empty.");
      return [];
    }

    const parsedData = JSON.parse(rawData);
    if (
      !Array.isArray(parsedData) &&
      (!parsedData.Fields || !Array.isArray(parsedData.Fields.Field))
    ) {
      console.error("❌ Unexpected JSON structure:", parsedData);
      return [];
    }

    return Array.isArray(parsedData) ? parsedData : parsedData.Fields.Field;
  } catch (err) {
    console.error("❌ Error reading/parsing JSON file:", err);
    return [];
  }
};

// ------------------------------
// Check and Update Table Schema
// ------------------------------
const checkAndUpdateSchema = async () => {
  return new Promise((resolve, reject) => {
    // Check if required column exists in qtest_releases table
    const checkColumnQuery = `
      SELECT COLUMN_NAME 
      FROM INFORMATION_SCHEMA.COLUMNS 
      WHERE TABLE_NAME = 'qtest_releases' 
      AND COLUMN_NAME = 'required'
    `;

    db.query(checkColumnQuery, (err, results) => {
      if (err) {
        console.error("❌ Error checking column:", err);
        return reject(err);
      }

      if (results.length === 0) {
        // Column doesn't exist, add it
        const addColumnQuery = `ALTER TABLE qtest_releases ADD COLUMN required TINYINT(1) DEFAULT NULL`;
        
        db.query(addColumnQuery, (err) => {
          if (err) {
            console.error("❌ Error adding required column:", err);
            return reject(err);
          }
          console.log("✅ Added required column to qtest_releases table");
          resolve();
        });
      } else {
        console.log("✅ Required column already exists");
        resolve();
      }
    });
  });
};

// ------------------------------
// Create Tables
// ------------------------------
const createTable = async () => {
  return new Promise((resolve, reject) => {
     const dropQtestFieldsTable = `DROP TABLE IF EXISTS qtest_data ;`;
    const createQtestDataTable = `
      CREATE TABLE IF NOT EXISTS qtest_data (
        id INT PRIMARY KEY,
        attribute_type VARCHAR(255),
        label TEXT,
        required TINYINT(1)
      )`;

    const dropComboValuesTable = `DROP TABLE IF EXISTS qtest_releases;`;
    const createQtestReleasesTable = `
      CREATE TABLE IF NOT EXISTS qtest_releases (
        id INT,
        attribute_type VARCHAR(255),
        label TEXT,
        required TINYINT(1),
        value INT,
        label_value TEXT
      )
    `;

     db.query(dropQtestFieldsTable, (dropErr1) => {
      if (dropErr1) {
        console.error("Error dropping qtest_requirement_data:", dropErr1.message);
        return reject(dropErr1);
      }

      db.query(dropComboValuesTable, (dropErr2) => {
        if (dropErr2) {
          console.error("Error dropping qtest_requirement:", dropErr2.message);
          return reject(dropErr2);
        }

    db.query(createQtestDataTable, (err) => {
      if (err) return reject(err);
      db.query(createQtestReleasesTable, async (err) => {
        if (err) return reject(err);
        
        // Check and update schema for existing tables
        try {
          await checkAndUpdateSchema();
          resolve();
        } catch (schemaErr) {
          reject(schemaErr);
        }
      });
    });
  });
});
});
};

// ------------------------------
// Insert Data From JSON
// ------------------------------
const insertDataFromJson = async () => {
  try {
    const jsonData = await loadJsonAndValidate();
    if (!jsonData || jsonData.length === 0) return;

    const [dataResult] = await db.promise().query("SELECT COUNT(*) AS count FROM qtest_data");
    if (dataResult[0].count > 0) {
      console.log("⚠️ Data already exists in qtest_data.");
      return;
    }

    // Insert into qtest_data table
    const qtestDataValues = jsonData.map(item => [
      item.id || null,
      item.attribute_type || null,
      item.label || null,
      item.required || null,
    ]);

    await db.promise().query(
      `INSERT INTO qtest_data (id, attribute_type, label, required) VALUES ?`,
      [qtestDataValues]
    );
    console.log("✅ qtest_data inserted.");

    // Insert into qtest_releases (includes all entries, with or without allowed_values)
    let qtestReleasesValues = [];

    jsonData.forEach(item => {
      if (item.allowed_values && Array.isArray(item.allowed_values) && item.allowed_values.length > 0) {
        // insert each allowed value
        item.allowed_values.forEach(val => {
          if (val.value != null && val.label != null) {
            qtestReleasesValues.push([
              item.id,
              item.attribute_type,
              item.label,
              item.required,
              val.value,
              val.label
            ]);
          }
        });
      } else {
        // if no allowed_values, still insert one row with nulls for value and label_value
        qtestReleasesValues.push([
          item.id,
          item.attribute_type,
          item.label,
          item.required,
          null,
          null
        ]);
      }
    });

    if (qtestReleasesValues.length > 0) {
      await db.promise().query(
        `INSERT INTO qtest_releases (id, attribute_type, label, required, value, label_value) VALUES ?`,
        [qtestReleasesValues]
      );
      console.log("✅ qtest_releases data inserted.");
    }

  } catch (err) {
    console.error("❌ Error in insertDataFromJson:", err);
  }
};

// ------------------------------
// Main Init
// ------------------------------
const init = async () => {
  try {
    console.log("🚀 Fetching fields...");
    await fetchqTestReleasesFields();
    console.log("✅ Fetch done.");
    await createTable();
    await insertDataFromJson();
  } catch (err) {
    console.error("❌ Initialization failed:", err);
    process.exit(1);
  }
};

// ------------------------------
// Refresh Data
// ------------------------------
// const refreshQTestData = async (req, res) => {
//   try {
//     console.log("➡️ Fetching qTest release fields...");
//     const fetchResult = await fetchqTestReleasesFields();
    
//     if (!fetchResult.success) {
//       return res.status(400).json({ error: fetchResult.message });
//     }

//     const jsonFilePath = path.join(__dirname, "../../data/Releasesdatafile/qTestReleaseFields.json");
//     console.log("➡️ Loading JSON data...");
    
//     // Verify file exists
//     if (!fs.existsSync(jsonFilePath)) {
//       console.error("❌ JSON file does not exist at:", jsonFilePath);
//       return res.status(400).json({ error: "qTest data file not found." });
//     }
    
//     // Read file with error handling
//     const rawData = fs.readFileSync(jsonFilePath, "utf-8");
//     if (!rawData || rawData.trim() === '') {
//       console.error("❌ JSON file is empty.");
//       return res.status(400).json({ error: "qTest data file is empty." });
//     }
    
//     // Parse JSON with error handling
//     let jsonData;
//     try {
//       jsonData = JSON.parse(rawData);
//       console.log(`✅ Successfully parsed JSON data with ${jsonData.length} entries`);
//     } catch (parseError) {
//       console.error("❌ Error parsing JSON data:", parseError);
//       return res.status(400).json({ error: "Invalid JSON format in qTest data file." });
//     }

//     if (!jsonData || jsonData.length === 0) {
//       console.log("❌ JSON is empty. Aborting.");
//       return res.status(400).json({ error: "No valid qTest data found." });
//     }

//     // Ensure schema is updated before proceeding
//     await checkAndUpdateSchema();

//     // Clear existing data
//     await db.promise().query("DELETE FROM qtest_data");
//     await db.promise().query("DELETE FROM qtest_releases");
//     console.log("✅ Cleared existing data from tables");

//     // Insert into qtest_data
//     const qtestDataValues = jsonData.map(item => [
//       item.id || null,
//       item.attribute_type || null,
//       item.label || null,
//       item.required || null,
//     ]);

//     const [dataResult] = await db.promise().query(
//       `INSERT INTO qtest_data (id, attribute_type, label, required) VALUES ?`,
//       [qtestDataValues]
//     );
//     console.log(`✅ Inserted ${dataResult.affectedRows} rows into qtest_data table`);

//     // Insert into qtest_releases (with or without allowed values)
//     let qtestReleasesValues = [];
//     jsonData.forEach(item => {
//       if (item.allowed_values && Array.isArray(item.allowed_values) && item.allowed_values.length > 0) {
//         // Insert each allowed value
//         item.allowed_values.forEach(val => {
//           if (val.value != null && val.label != null) {
//             qtestReleasesValues.push([
//               item.id,
//               item.attribute_type,
//               item.label,
//               item.required,
//               val.value,
//               val.label
//             ]);
//           }
//         });
//       } else {
//         // If no allowed_values, still insert one row with nulls for value and label_value
//         qtestReleasesValues.push([
//           item.id,
//           item.attribute_type,
//           item.label,
//           item.required,
//           null,
//           null
//         ]);
//       }
//     });

//     let releasesCount = 0;
//     if (qtestReleasesValues.length > 0) {
//       const [releaseResult] = await db.promise().query(
//         `INSERT INTO qtest_releases (id, attribute_type, label, required, value, label_value) VALUES ?`,
//         [qtestReleasesValues]
//       );
//       releasesCount = releaseResult.affectedRows;
//       console.log(`✅ Inserted ${releasesCount} rows into qtest_releases table`);
//     }

//     return res.status(200).json({
//       message: "✅ qTest data refreshed successfully",
//       count: {
//         qtest_data: dataResult.affectedRows,
//         qtest_releases: releasesCount,
//       },
//     });
//   } catch (error) {
//     console.error("❌ Error in refresh:", error.message);
//     return res.status(500).json({ error: error.message });
//   }
// };

// ------------------------------
// Get All Data
// ------------------------------
const getAllData = async (req, res) => {
  try {
    // Get all fields from qtest_data
    const [fields] = await db.promise().query("SELECT * FROM qtest_data");
    
    // For each field, get its allowed values from qtest_releases
    const fieldsWithValues = await Promise.all(fields.map(async (field) => {
      const [values] = await db.promise().query(
        "SELECT value, label_value FROM qtest_releases WHERE id = ? AND value IS NOT NULL",
        [field.id]
      );
      return {
        ...field,
        allowed_values: values
      };
    }));

    res.json(fieldsWithValues);
  } catch (err) {
    console.error("❌ Error fetching data:", err);
    res.status(500).json({ error: err.message });
  }
};
// ------------------------------
// Get Releases Data
// ------------------------------
const getReleasesData = (req, res) => {
  db.query("SELECT * FROM qtest_releases", (err, results) => {
    if (err) {
      console.error("❌ Error fetching releases data:", err);
      return res.status(500).json({ error: err.message });
    }
    res.json(results);
  });
};

// ------------------------------
// Insert qtest_data via API
// ------------------------------
const insertData = (req, res) => {
  const testCases = req.body;

  if (!Array.isArray(testCases) || testCases.length === 0) {
    return res.status(400).json({ message: "Invalid input: expected an array of test cases." });
  }

  const values = testCases.map(item => [
    item.id || null,
    item.attribute_type || null,
    item.label || null,
    item.required || null
  ]);

  const sql = `
    INSERT INTO qtest_data (id, attribute_type, label, required)
    VALUES ?
  `;

  db.query(sql, [values], (err, result) => {
    if (err) {
      console.error("❌ Error inserting via API:", err);
      return res.status(500).json({ error: err.message });
    }
    res.status(201).json({ message: `${result.affectedRows} records added.` });
  });
};

// ------------------------------
// Insert qtest_releases via API
// ------------------------------
const insertReleasesData = (req, res) => {
  const releaseData = req.body;

  if (!Array.isArray(releaseData) || releaseData.length === 0) {
    return res.status(400).json({ message: "Invalid input: expected an array of release data." });
  }

  const values = releaseData.map(item => [
    item.id || null,
    item.attribute_type || null,
    item.label || null,
    item.required || null,
    item.value || null,
    item.label_value || null
  ]);

  const sql = `
    INSERT INTO qtest_releases (id, attribute_type, label, required, value, label_value)
    VALUES ?
  `;

  db.query(sql, [values], (err, result) => {
    if (err) {
      console.error("❌ Error inserting releases via API:", err);
      return res.status(500).json({ error: err.message });
    }
    res.status(201).json({ message: `${result.affectedRows} release records added.` });
  });
};

// ------------------------------
// Export Functions
// ------------------------------
module.exports = {
  init,
  createTable,
  insertDataFromJson,
  getAllData,
  getReleasesData,
  insertData,
  insertReleasesData,
  // refreshQTestData
};