

const db = require("../../config/db");
const fs = require("fs");
const path = require("path");
const { fetchListReleasesFields } = require("../ReleaseControllerfile/ALMListReleaseValuesFields");

const requiredFields = ["name", "id", "value"];

const getListReleaseFields = async (req, res) => {
  db.query("SELECT * FROM listereleases", (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    const formattedResults = results.map(row => ({
      ...row,
      required: row.required === 1,
      supportsMultivalue: row.supportsMultivalue === 1
    }));

    res.json(formattedResults);
  });
};

const loadJsonAndValidate = async () => {
  const jsonFilePath = path.join(__dirname, "../../data/Releasesdatafile/ALMListReleasesValues.json");

  try {
    if (!fs.existsSync(jsonFilePath)) {
      console.error("JSON file does not exist:", jsonFilePath);
      return [];
    }

    const rawData = fs.readFileSync(jsonFilePath, "utf-8");
    const parsedData = JSON.parse(rawData);

    console.log("Raw data from JSON:", parsedData); // Log raw data for debugging

    // Adjust the parsing logic to handle 'lists' and 'Items'
    const normalizedData = Array.isArray(parsedData.lists) ? parsedData.lists : [];

    // Process each list and flatten the structure for database insertion
    const flattenedData = [];
    
    normalizedData.forEach(listItem => {
      const listName = listItem.Name || null;
      const listId = listItem.Id || null;
      
      // Check if Items array exists and has entries
      if (Array.isArray(listItem.Items) && listItem.Items.length > 0) {
        // For each item in the Items array, create a record
        listItem.Items.forEach(item => {
          flattenedData.push({
            name: listName,
            id: listId,
            value: item.value || null
          });
        });
      } else {
        // If no items, still add the list with null value
        flattenedData.push({
          name: listName,
          id: listId,
          value: null
        });
      }
    });

    console.log("Flattened data for DB insertion:", flattenedData);
    return flattenedData;

  } catch (err) {
    console.error("Error reading/parsing JSON file:", err.message);
    return [];
  }
};

const initlist = async () => {
  try {
    console.log("Fetching ALM release fields...");
    await fetchListReleasesFields();
    console.log("✅ Fetch complete.");

    await createListTables();
    await insertListDataJson();

    console.log("✅ ALM initialization complete.");
  } catch (err) {
    console.error("Failed to initialize ALM data:", err.message);
    process.exit(1);
  }
};

const createListTables = async () => {
  return new Promise((resolve, reject) => {
    const droplistQuery = `DROP TABLE IF EXISTS listereleases`;
    const createTableQuery = `
    CREATE TABLE IF NOT EXISTS listereleases (
      name VARCHAR(255),
      id INT,
      value VARCHAR(255)
    )
  `;

  db.query(droplistQuery, (dropErr) => {
      if (dropErr) {
        console.error("Error dropping table:", dropErr.message);
        return reject(dropErr);
      }
  
    db.query(createTableQuery, (err) => {
      if (err) {
        console.error("❌ Error creating table:", err.message);
        return reject(err);
      }
      console.log("✅ Table 'listereleases' created successfully.");
      resolve(true);
    });
  });
  });
};

const insertListDataJson = async () => {
  try {
    const jsonData = await loadJsonAndValidate();

    if (jsonData.length === 0) {
      console.log("No valid data to insert.");
      return;
    }

    console.log("Inserting data into 'listereleases' table...");

    // Check if the table already has data
    return new Promise((resolve, reject) => {
      db.query("SELECT COUNT(*) AS count FROM listereleases", (err, results) => {
        if (err) {
          console.error("Error checking existing data:", err.message);
          return reject(err);
        }

        if (results[0].count > 0) {
          console.log("Data already exists. Skipping insertion.");
          return resolve(false);
        }

        // Create an array to hold all insertion promises
        const insertPromises = [];

        // Process each flattened record
        jsonData.forEach((record, index) => {
          const insertPromise = new Promise((resolve, reject) => {
            const sql = `INSERT INTO listereleases (name, id, value) VALUES (?, ?, ?)`;
            const values = [record.name, record.id, record.value];
            
            console.log(`Inserting: name=${record.name}, id=${record.id}, value=${record.value}`);
            
            db.query(sql, values, (err, result) => {
              if (err) {
                console.error("Error inserting row:", err.message);
                return reject(err);
              }
              resolve(result);
            });
          });
          
          insertPromises.push(insertPromise);
        });

        // Wait for all insertions to complete
        Promise.all(insertPromises)
          .then(() => {
            console.log(`✅ Inserted ${jsonData.length} records successfully.`);
            resolve(true);
          })
          .catch(err => {
            console.error("Error in batch insertion:", err.message);
            reject(err);
          });
      });
    });
  } catch (err) {
    console.error("Failed to insert data:", err.message);
    throw err;
  }
};

const refreshListData = async (req, res) => {
  try {
    await fetchListReleasesFields();
    const jsonData = await loadJsonAndValidate();

    if (jsonData.length === 0) {
      return res.status(400).json({ error: "No valid data to insert" });
    }

    await new Promise((resolve, reject) => {
      db.query("DELETE FROM listereleases", (err) => {
        if (err) {
          console.error("Error clearing table:", err.message);
          return reject(err);
        }
        console.log("✅ Table 'listereleases' cleared.");
        resolve();
      });
    });

    const insertPromises = jsonData.map((record, index) => {
      const values = [record.name, record.id, record.value];
      console.log(`Inserting record ${index + 1}:`, values);  // Log each record to be inserted

      return new Promise((resolve, reject) => {
        const sql = `INSERT INTO listereleases (name, id, value) VALUES (?, ?, ?)`;

        db.query(sql, values, (err, result) => {
          if (err) {
            console.error("Error inserting row:", err.message);
            return reject(err);
          }
          resolve(result);
        });
      });
    });

    await Promise.all(insertPromises);

    return res.status(200).json({ 
      message: "ALM List data refreshed successfully", 
      count: jsonData.length 
    });
  } catch (error) {
    console.error("Failed to refresh ALM List data:", error.message);
    return res.status(500).json({ error: error.message });
  }
};

const getAllListTestCases = (req, res) => {
  db.query("SELECT * FROM listereleases", (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    const formattedResults = results.map(row => ({
      ...row,
      required: row.required === 1,
      supportsMultivalue: row.supportsMultivalue === 1
    }));

    res.json(formattedResults);
  });
};

const createListTestCases = async (req, res) => {
  const testCases = req.body;

  if (!Array.isArray(testCases) || testCases.length === 0) {
    return res.status(400).json({ message: "Invalid input, expecting an array of test cases" });
  }

  const insertPromises = testCases.map((item, index) => {
    const values = [item.name || null, item.id || null, item.value || null];
    console.log(`Inserting new test case ${index + 1}:`, values);  // Log each record to be inserted

    return new Promise((resolve, reject) => {
      const sql = `INSERT INTO listereleases (name, id, value) VALUES (?, ?, ?)`;

      db.query(sql, values, (err, result) => {
        if (err) {
          console.error("Error inserting row:", err.message);
          return reject(err);
        }
        resolve(result);
      });
    });
  });

  try {
    await Promise.all(insertPromises);
    res.status(201).json({ message: `${testCases.length} new test cases added.` });
  } catch (err) {
    console.error("Error inserting data:", err.message);
    return res.status(500).json({ error: err.message });
  }
};

module.exports = {
  initlist,
  createListTables,
  insertListDataJson,
  getAllListTestCases,
  getListReleaseFields,
  createListTestCases,
  refreshListData
};