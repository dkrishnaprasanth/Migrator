// // const log = require('../logger');

// // const runProcess = (req, res) => {
// //   log("✅ Process started by user");

// //   for (let i = 1; i <= 100; i++) {
// //     log(`📦 Process step ${i}`);
// //   }

// //   res.json({ message: 'Process completed and logged successfully.' });
// // };

// // module.exports = { runProcess };


// // const log = require('../logger');

// // const runProcess = (req, res) => {
// //   log("✅ Process started by user");

// //   for (let i = 1; i <= 100; i++) {
// //     if (i % 10 === 0) {
// //       // Simulating failure every 10th step
// //       log(`❌ Failed at step ${i}`, 'fail');
// //     } else {
// //       log(`📦 Process step ${i}`, 'success');
// //     }
// //   }

// //   res.json({ message: 'Process completed with logs.' });
// // };

// // module.exports = { runProcess };



// const log = require('../logger');

// const runProcess = (req, res) => {
//   log("✅ Process started by user", 'success');

//   for (let i = 1; i <= 100; i++) {
//     if (i % 10 === 0) {
//       log(`❌ Failed at step ${i}`, 'fail');
//     } else {
//       log(`📦 Process step ${i}`, 'success');
//     }
//   }

//   res.json({ message: 'Process completed with logs.' });
// };

// module.exports = { runProcess };




// // const db = require('../config/db'); // Correct path to db.js in project root

// // exports.runProcess = (req, res) => {
// //     console.log('Process started...');
// //     db.query('SELECT * FROM your_table', (err, results) => {
// //         if (err) {
// //             console.fail('Database query failed:', err);
// //             return res.status(500).json({ error: 'Database error' });
// //         }
// //         console.log('Query successful:', results);
// //         res.json(results);
// //     });
// // };




const log = require('../logger');

const runProcess = (req, res) => {
  log("✅ Process started by user", 'success');

  for (let i = 1; i <= 100; i++) {
    if (i % 10 === 0) {
      log(`❌ Failed at step ${i}`, 'fail');
    } else {
      log(`📦 Process step ${i}`, 'success');
    }
  }

  log("✅ Process completed successfully", 'success');

  res.json({ message: 'Process completed with logs.' });
};

module.exports = { runProcess };
