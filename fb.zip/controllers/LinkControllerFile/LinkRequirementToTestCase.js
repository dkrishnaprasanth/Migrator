

// const fs = require('fs');
// const path = require('path');
// const axios = require('axios');
// const db = require('../../config/db').promise(); // Importing from db.js and enabling async/await

// // Helper functions
// function loadJSON(filePath) {
//   return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
// }

// function getCookieValue(setCookieHeaders, name) {
//   for (const header of setCookieHeaders || []) {
//     const parts = header.split(';')[0].split('=');
//     if (parts[0] === name) return parts[1];
//   }
//   return null;
// } 

// function getFieldValue(fields, name) {
//   for (const field of fields) {
//     if (field.Name === name && Array.isArray(field.values) && field.values.length > 0) {
//       return field.values[0].value;
//     }
//   }
//   return null;
// }

// function parseIntSafe(val) {
//   const parsed = parseInt(val);
//   return isNaN(parsed) ? 0 : parsed;
// }

// // Controller
// exports.linkRequirementToTest = async (req, res) => {
//   try {
//     const almConfig = loadJSON(path.join(__dirname, '../../data/ALMcredentials.json'));
//     const qTestConfig = loadJSON(path.join(__dirname, '../../data/qTestCredentials.json'));

//     // Step 1: Authenticate with ALM
//     const authUrl = `${almConfig.almServerUrl}/api/authentication/sign-in`;
//     const encodedAuth = Buffer.from(`${almConfig.username}:${almConfig.password}`).toString('base64');

//     const authResponse = await axios.post(authUrl, {}, {
//       headers: {
//         'Content-Type': 'application/json',
//         'Authorization': `Basic ${encodedAuth}`
//       },
//       withCredentials: true
//     });

//     const cookies = authResponse.headers['set-cookie'];
//     const cookieHeader = [
//       `XSRF-TOKEN=${getCookieValue(cookies, 'XSRF-TOKEN')}`,
//       `JSESSIONID=${getCookieValue(cookies, 'JSESSIONID')}`,
//       `LWSSO_COOKIE_KEY=${getCookieValue(cookies, 'LWSSO_COOKIE_KEY')}`,
//       `ALM_USER=${getCookieValue(cookies, 'ALM_USER')}`,
//       `QCSession=${getCookieValue(cookies, 'QCSession')}`
//     ].join('; ');

//     // Step 2: Fetch requirement-test links
//     const dataUrl = `${almConfig.almServerUrl}/rest/domains/${almConfig.domain}/projects/${almConfig.project}/requirement-coverages`;
//     const response = await axios.get(dataUrl, {
//       headers: {
//         'Cookie': cookieHeader,
//         'Accept': 'application/json'
//       }
//     });

//     const entities = response.data.entities || [];

//     // Save to file (optional)
//     const outputPath = path.join(__dirname, '../../data/LinksDataFile/RequirementToTestCaseLink.json');
//     fs.writeFileSync(outputPath, JSON.stringify(response.data, null, 2));

//     // Step 3: Insert into MySQL
//     await db.execute('DROP TABLE IF EXISTS ReqToTestLink');
//     await db.execute(`
//       CREATE TABLE IF NOT EXISTS ReqToTestLink (
//         id INT PRIMARY KEY,
//         test_id INT,
//         req_id INT,
//         entity_type TEXT,
//         link_status TEXT
//       )
//     `);

//     for (const entity of entities) {
//       const fields = entity.Fields;
//       const id = getFieldValue(fields, 'id');
//       const reqId = getFieldValue(fields, 'requirement-id');
//       const testId = getFieldValue(fields, 'test-id');
//       const entityType = getFieldValue(fields, 'entity-type');

//       if (id && reqId && testId) {
//         await db.execute(
//           'INSERT INTO ReqToTestLink (id, req_id, test_id, entity_type) VALUES (?, ?, ?, ?)',
//           [parseIntSafe(id), parseIntSafe(reqId), parseIntSafe(testId), entityType]
//         );
//       }
//     }

//     // Step 4: Link in qTest
//     const [rows] = await db.execute(`
//       SELECT rtl.req_id, rtl.test_id, r.qtest_requirement_id AS req_qtest_id,
//              t.qtest_test_id AS test_qtest_id
//         FROM ReqToTestLink rtl
//         JOIN requirement r ON rtl.req_id = r.id
//         JOIN tests t ON rtl.test_id = t.id
//        WHERE rtl.link_status IS NULL OR rtl.link_status <> 'linked'
//     `);

//     for (const row of rows) {
//       const { req_id, test_id, req_qtest_id, test_qtest_id } = row;
//       const linkUrl = `${qTestConfig.qTestDomain}/api/v3/projects/${qTestConfig.projectId}/requirements/${req_qtest_id}/link?type=test-cases`;

//       try {
//         const result = await axios.post(linkUrl, [test_qtest_id], {
//           headers: {
//             'Authorization': `Bearer ${qTestConfig.apiToken}`,
//             'Content-Type': 'application/json'
//           }
//         });

//         const status = (result.status === 200 || result.status === 201) ? 'linked' : 'failed';
//         await db.execute(
//           'UPDATE ReqToTestLink SET link_status = ? WHERE req_id = ? AND test_id = ?',
//           [status, req_id, test_id]
//         );
//       } catch (err) {
//         console.error(`❌ Link failed for req_id=${req_id}, test_id=${test_id}: ${err.message}`);
//         await db.execute(
//           'UPDATE ReqToTestLink SET link_status = ? WHERE req_id = ? AND test_id = ?',
//           ['failed', req_id, test_id]
//         );
//       }
//     }

//     res.json({ message: '✅ Requirement-to-Test linking completed successfully.' });
//   } catch (err) {
//     console.error('❌ Error in linking process:', err.message);
//     res.status(500).json({ error: err.message });
//   }
// };






// const fs = require('fs');
// const path = require('path');
// const axios = require('axios');
// const db = require('../../config/db').promise(); // Importing from db.js and enabling async/await

// // Helper functions
// function loadJSON(filePath) {
//   return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
// }

// function getCookieValue(setCookieHeaders, name) {
//   for (const header of setCookieHeaders || []) {
//     const parts = header.split(';')[0].split('=');
//     if (parts[0] === name) return parts[1];
//   }
//   return null;
// } 

// function getFieldValue(fields, name) {
//   for (const field of fields) {
//     if (field.Name === name && Array.isArray(field.values) && field.values.length > 0) {
//       return field.values[0].value;
//     }
//   }
//   return null;
// }

// function parseIntSafe(val) {
//   const parsed = parseInt(val);
//   return isNaN(parsed) ? 0 : parsed;
// }

// // Controller
// exports.linkRequirementToTest = async (req, res) => {
//   try {
//     const almConfig = loadJSON(path.join(__dirname, '../../data/ALMcredentials.json'));
//     const qTestConfig = loadJSON(path.join(__dirname, '../../data/qTestCredentials.json'));

//     // Step 1: Authenticate with ALM
//     const authUrl = `${almConfig.almServerUrl}/api/authentication/sign-in`;
//     const encodedAuth = Buffer.from(`${almConfig.username}:${almConfig.password}`).toString('base64');

//     const authResponse = await axios.post(authUrl, {}, {
//       headers: {
//         'Content-Type': 'application/json',
//         'Authorization': `Basic ${encodedAuth}`
//       },
//       withCredentials: true
//     });

//     const cookies = authResponse.headers['set-cookie'];
//     const cookieHeader = [
//       `XSRF-TOKEN=${getCookieValue(cookies, 'XSRF-TOKEN')}`,
//       `JSESSIONID=${getCookieValue(cookies, 'JSESSIONID')}`,
//       `LWSSO_COOKIE_KEY=${getCookieValue(cookies, 'LWSSO_COOKIE_KEY')}`,
//       `ALM_USER=${getCookieValue(cookies, 'ALM_USER')}`,
//       `QCSession=${getCookieValue(cookies, 'QCSession')}`
//     ].join('; ');

//     // Step 2: Fetch requirement-test links
//     const dataUrl = `${almConfig.almServerUrl}/rest/domains/${almConfig.domain}/projects/${almConfig.project}/requirement-coverages`;
//     const response = await axios.get(dataUrl, {
//       headers: {
//         'Cookie': cookieHeader,
//         'Accept': 'application/json'
//       }
//     });

//     const entities = response.data.entities || [];

//     // Save to file (optional)
//     const outputPath = path.join(__dirname, '../../data/LinksDataFile/RequirementToTestCaseLink.json');
//     fs.writeFileSync(outputPath, JSON.stringify(response.data, null, 2));

//     // Step 3: Insert into MySQL
//     await db.execute('DROP TABLE IF EXISTS ReqToTestLink');
//     await db.execute(`
//       CREATE TABLE IF NOT EXISTS ReqToTestLink (
//         id INT PRIMARY KEY,
//         test_id INT,
//         req_id INT,
//         entity_type TEXT,
//         link_status TEXT
//       )
//     `);

//     for (const entity of entities) {
//       const fields = entity.Fields;
//       const id = getFieldValue(fields, 'id');
//       const reqId = getFieldValue(fields, 'requirement-id');
//       const testId = getFieldValue(fields, 'test-id');
//       const entityType = getFieldValue(fields, 'entity-type');

//       if (id && reqId && testId) {
//         await db.execute(
//           'INSERT INTO ReqToTestLink (id, req_id, test_id, entity_type) VALUES (?, ?, ?, ?)',
//           [parseIntSafe(id), parseIntSafe(reqId), parseIntSafe(testId), entityType]
//         );
//       }
//     }

//     // Step 4: Link in qTest
//     const [rows] = await db.execute(`
//       SELECT rtl.req_id, rtl.test_id, r.qtest_requirement_id AS req_qtest_id,
//              t.qtest_testcase_id AS test_qtest_id
//         FROM ReqToTestLink rtl
//         JOIN requirement r ON rtl.req_id = r.id
//         JOIN tests t ON rtl.test_id = t.id
//        WHERE rtl.link_status IS NULL OR rtl.link_status <> 'linked'
//     `);

//     for (const row of rows) {
//       const { req_id, test_id, req_qtest_id, test_qtest_id } = row;
//       const linkUrl = `${qTestConfig.qTestDomain}/api/v3/projects/${qTestConfig.projectId}/requirements/${req_qtest_id}/link?type=test-cases`;

//       try {
//         const result = await axios.post(linkUrl, [test_qtest_id], {
//           headers: {
//             'Authorization': `Bearer ${qTestConfig.apiToken}`,
//             'Content-Type': 'application/json'
//           }
//         });

//         const status = (result.status === 200 || result.status === 201) ? 'linked' : 'failed';
//         await db.execute(
//           'UPDATE ReqToTestLink SET link_status = ? WHERE req_id = ? AND test_id = ?',
//           [status, req_id, test_id]
//         );
//       } catch (err) {
//         console.error(`❌ Link failed for req_id=${req_id}, test_id=${test_id}: ${err.message}`);
//         await db.execute(
//           'UPDATE ReqToTestLink SET link_status = ? WHERE req_id = ? AND test_id = ?',
//           ['failed', req_id, test_id]
//         );
//       }
//     }

//     res.json({ message: '✅ Requirement-to-Test linking completed successfully.' });
//   } catch (err) {
//     console.error('❌ Error in linking process:', err.message);
//     res.status(500).json({ error: err.message });
//   }
// };



 
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const db = require('../../config/db').promise(); // Importing from db.js and enabling async/await
 
// Helper functions
function loadJSON(filePath) {
  return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
}
 
function getCookieValue(setCookieHeaders, name) {
  for (const header of setCookieHeaders || []) {
    const parts = header.split(';')[0].split('=');
    if (parts[0] === name) return parts[1];
  }
  return null;
}
 
function getFieldValue(fields, name) {
  for (const field of fields) {
    if (field.Name === name && Array.isArray(field.values) && field.values.length > 0) {
      return field.values[0].value;
    }
  }
  return null;
}
 
function parseIntSafe(val) {
  const parsed = parseInt(val);
  return isNaN(parsed) ? 0 : parsed;
}
 
// Controller
const linkRequirementToTest = async (req, res) => {
  try {
    const almConfig = loadJSON(path.join(__dirname, '../../data/ALMcredentials.json'));
    const qTestConfig = loadJSON(path.join(__dirname, '../../data/qTestCredentials.json'));
 
    // Step 1: Authenticate with ALM
    const authUrl = `${almConfig.almServerUrl}/api/authentication/sign-in`;
    const encodedAuth = Buffer.from(`${almConfig.username}:${almConfig.password}`).toString('base64');
 
    const authResponse = await axios.post(authUrl, {}, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Basic ${encodedAuth}`
      },
      withCredentials: true
    });
 
    const cookies = authResponse.headers['set-cookie'];
    const cookieHeader = [
      `XSRF-TOKEN=${getCookieValue(cookies, 'XSRF-TOKEN')}`,
      `JSESSIONID=${getCookieValue(cookies, 'JSESSIONID')}`,
      `LWSSO_COOKIE_KEY=${getCookieValue(cookies, 'LWSSO_COOKIE_KEY')}`,
      `ALM_USER=${getCookieValue(cookies, 'ALM_USER')}`,
      `QCSession=${getCookieValue(cookies, 'QCSession')}`
    ].join('; ');
 
    // Step 2: Fetch requirement-test links with pagination
    const baseUrl = `${almConfig.almServerUrl}/rest/domains/${almConfig.domain}/projects/${almConfig.project}/requirement-coverages`;
    const pageSize = 100; // Can be adjusted
    let startIndex = 1;
    let hasMore = true;
    let allEntities = [];
 
    while (hasMore) {
      const pagedUrl = `${baseUrl}?start-index=${startIndex}&page-size=${pageSize}`;
      const response = await axios.get(pagedUrl, {
        headers: {
          'Cookie': cookieHeader,
          'Accept': 'application/json'
        }
      });
 
      const entities = response.data.entities || [];
      allEntities.push(...entities);
 
      if (entities.length < pageSize) {
        hasMore = false;
      } else {
        startIndex += pageSize;
      }
    }
 
    // Save to file (optional)
    const outputPath = path.join(__dirname, '../../data/LinksDataFile/RequirementToTestCaseLink.json');
    fs.writeFileSync(outputPath, JSON.stringify({ entities: allEntities }, null, 2));
 
    // Step 3: Insert into MySQL
    await db.execute('DROP TABLE IF EXISTS ReqToTestLink');
    await db.execute(`
      CREATE TABLE IF NOT EXISTS ReqToTestLink (
        id INT PRIMARY KEY,
        test_id INT,
        req_id INT,
        entity_type TEXT,
        link_status TEXT
      )
    `);
 
    for (const entity of allEntities) {
      const fields = entity.Fields;
      const id = getFieldValue(fields, 'id');
      const reqId = getFieldValue(fields, 'requirement-id');
      const testId = getFieldValue(fields, 'test-id');
      const entityType = getFieldValue(fields, 'entity-type');
 
      if (id && reqId && testId) {
        await db.execute(
          'INSERT INTO ReqToTestLink (id, req_id, test_id, entity_type) VALUES (?, ?, ?, ?)',
          [parseIntSafe(id), parseIntSafe(reqId), parseIntSafe(testId), entityType]
        );
      }
    }
 
    // Step 4: Link in qTest
    const [rows] = await db.execute(`
      SELECT rtl.req_id, rtl.test_id, r.qtest_requirement_id AS req_qtest_id,
             t.qtest_testcase_id AS test_qtest_id
        FROM ReqToTestLink rtl
        JOIN requirement r ON rtl.req_id = r.id
        JOIN tests t ON rtl.test_id = t.id
       WHERE rtl.link_status IS NULL OR rtl.link_status <> 'linked'
    `);
 
    for (const row of rows) {
      const { req_id, test_id, req_qtest_id, test_qtest_id } = row;
      const linkUrl = `${qTestConfig.qTestDomain}/api/v3/projects/${qTestConfig.projectId}/requirements/${req_qtest_id}/link?type=test-cases`;
 
      try {
        const result = await axios.post(linkUrl, [test_qtest_id], {
          headers: {
            'Authorization': `Bearer ${qTestConfig.apiToken}`,
            'Content-Type': 'application/json'
          }
        });
 
        const status = (result.status === 200 || result.status === 201) ? 'linked' : 'failed';
        await db.execute(
          'UPDATE ReqToTestLink SET link_status = ? WHERE req_id = ? AND test_id = ?',
          [status, req_id, test_id]
        );
      } catch (err) {
        console.error(`❌ Link failed for req_id=${req_id}, test_id=${test_id}: ${err.message}`);
        await db.execute(
          'UPDATE ReqToTestLink SET link_status = ? WHERE req_id = ? AND test_id = ?',
          ['failed', req_id, test_id]
        );
      }
    }
 
    res.json({ message: '✅ Requirement-to-Test linking completed successfully.' });
  } catch (err) {
    console.error('❌ Error in linking process:', err.message);
    res.status(500).json({ error: err.message });
  }
};
 
 module.exports = { linkRequirementToTest };
//linkRequirementToTest();
 
 