

// const fs = require('fs');
// const path = require('path');
// const axios = require('axios');
// const db = require('../../config/db'); // Use shared db connection

// // Load credentials
// const almConfig = JSON.parse(fs.readFileSync(path.join(__dirname, '../../data/AlmCredentials.json'), 'utf-8'));
// const qTestConfig = JSON.parse(fs.readFileSync(path.join(__dirname, '../../data/qTestCredentials.json'), 'utf-8'));

// // Helpers
// function extractCookies(setCookieHeaders) {
//   const cookieMap = {};
//   setCookieHeaders.forEach(cookieStr => {
//     const [name, value] = cookieStr.split(';')[0].split('=');
//     cookieMap[name.trim()] = value.trim();
//   });
//   return cookieMap;
// }

// function getFieldValue(fields, name) {
//   for (const field of fields) {
//     if (field.Name === name && Array.isArray(field.values) && field.values.length > 0) {
//       return field.values[0].value || null;
//     }
//   }
//   return null;
// }

// function parseIntSafe(value) {
//   const parsed = parseInt(value);
//   return isNaN(parsed) ? 0 : parsed;
// }

// // Main controller function
// exports.linkReleaseToRequirement = async (req, res) => {
//   const { almServerUrl, username, password, domain, project } = almConfig;
//   const releaseDataUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/requirement-target-releases`;

//   try {
//     // ALM Login
//     const loginUrl = `${almServerUrl}/api/authentication/sign-in`;
//     const authString = Buffer.from(`${username}:${password}`).toString('base64');

//     const loginResponse = await axios.post(loginUrl, {}, {
//       headers: {
//         'Content-Type': 'application/json',
//         'Authorization': `Basic ${authString}`
//       },
//       withCredentials: true
//     });

//     const cookies = extractCookies(loginResponse.headers['set-cookie'] || []);
//     const cookieHeader = ['XSRF-TOKEN', 'JSESSIONID', 'LWSSO_COOKIE_KEY', 'ALM_USER', 'QCSession']
//       .map(name => `${name}=${cookies[name]}`).join('; ');

//     // Fetch Release Link Data
//     const releaseResponse = await axios.get(releaseDataUrl, {
//       headers: {
//         'Accept': 'application/json',
//         'Cookie': cookieHeader
//       }
//     });

//     const jsonData = releaseResponse.data;
//     const savePath = path.join(__dirname, '../../data/LinksDataFile/ReleaseToRequirementLink.json');
//     fs.writeFileSync(savePath, JSON.stringify(jsonData, null, 2), 'utf-8');

//     // Create Link Table
//     await db.promise().execute('DROP TABLE IF EXISTS ReleaseToReqLink');
//     await db.promise().execute(`
//       CREATE TABLE IF NOT EXISTS ReleaseToReqLink (
//         id INT PRIMARY KEY,
//         rel_id INT,
//         req_id INT,
//         link_status TEXT
//       )
//     `);

//     // Insert links into DB
//     const entities = jsonData.entities || [];
//     for (const entity of entities) {
//       const fields = entity.Fields;
//       const id = getFieldValue(fields, 'id');
//       const first = getFieldValue(fields, 'first-endpoint-id');
//       const second = getFieldValue(fields, 'second-endpoint-id');
//       await db.promise().execute(
//         'INSERT INTO ReleaseToReqLink (id, req_id, rel_id) VALUES (?, ?, ?)',
//         [parseIntSafe(id), parseIntSafe(first), parseIntSafe(second)]
//       );
//     }

//     // Fetch data to link in qTest
//     const [rows] = await db.promise().execute(`
//       SELECT rtl.rel_id, rtl.req_id, r.qtest_releases_id AS release_qtest_id,
//              req.qtest_requirement_id AS req_qtest_id
//         FROM ReleaseToReqLink rtl
//         JOIN releases r ON rtl.rel_id = r.id
//         JOIN requirement req ON rtl.req_id = req.id
//        WHERE rtl.link_status IS NULL OR rtl.link_status <> 'linked'
//     `);

//     // Link to qTest
//     for (const row of rows) {
//       const url = `${qTestConfig.qTestDomain}/api/v3/projects/${qTestConfig.projectId}/releases/${row.release_qtest_id}/link?type=requirements`;
//       const payload = [row.req_qtest_id];

//       try {
//         const response = await axios.post(url, payload, {
//           headers: {
//             'Content-Type': 'application/json',
//             'Authorization': `Bearer ${qTestConfig.apiToken}`
//           }
//         });

//         const status = (response.status === 200 || response.status === 201) ? 'linked' : 'failed';
//         await db.promise().execute(
//           'UPDATE ReleaseToReqLink SET link_status = ? WHERE rel_id = ? AND req_id = ?',
//           [status, row.rel_id, row.req_id]
//         );
//       } catch (err) {
//         await db.promise().execute(
//           'UPDATE ReleaseToReqLink SET link_status = ? WHERE rel_id = ? AND req_id = ?',
//           ['failed', row.rel_id, row.req_id]
//         );
//       }
//     }

//     res.json({ message: '✅ Release-to-Requirement linking completed successfully.' });
//   } catch (error) {
//     console.error('❌ Error:', error.message);
//     res.status(500).json({ error: error.message });
//   }
// };







// const fs = require('fs');
// const path = require('path');
// const axios = require('axios');
// const db = require('../../config/db'); // Use shared db connection

// // Load credentials
// const almConfig = JSON.parse(fs.readFileSync(path.join(__dirname, '../../data/AlmCredentials.json'), 'utf-8'));
// const qTestConfig = JSON.parse(fs.readFileSync(path.join(__dirname, '../../data/qTestCredentials.json'), 'utf-8'));

// // Helpers
// function extractCookies(setCookieHeaders) {
//   const cookieMap = {};
//   setCookieHeaders.forEach(cookieStr => {
//     const [name, value] = cookieStr.split(';')[0].split('=');
//     cookieMap[name.trim()] = value.trim();
//   });
//   return cookieMap;
// }

// function getFieldValue(fields, name) {
//   for (const field of fields) {
//     if (field.Name === name && Array.isArray(field.values) && field.values.length > 0) {
//       return field.values[0].value || null;
//     }
//   }
//   return null;
// }

// function parseIntSafe(value) {
//   const parsed = parseInt(value);
//   return isNaN(parsed) ? 0 : parsed;
// }

// // Main controller function
// exports.linkReleaseToRequirement = async (req, res) => {
//   const { almServerUrl, username, password, domain, project } = almConfig;
//   const releaseDataUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/requirement-target-releases`;

//   try {
//     // ALM Login
//     const loginUrl = `${almServerUrl}/api/authentication/sign-in`;
//     const authString = Buffer.from(`${username}:${password}`).toString('base64');

//     const loginResponse = await axios.post(loginUrl, {}, {
//       headers: {
//         'Content-Type': 'application/json',
//         'Authorization': `Basic ${authString}`
//       },
//       withCredentials: true
//     });

//     const cookies = extractCookies(loginResponse.headers['set-cookie'] || []);
//     const cookieHeader = ['XSRF-TOKEN', 'JSESSIONID', 'LWSSO_COOKIE_KEY', 'ALM_USER', 'QCSession']
//       .map(name => `${name}=${cookies[name]}`).join('; ');

//     // Fetch Release Link Data
//     const releaseResponse = await axios.get(releaseDataUrl, {
//       headers: {
//         'Accept': 'application/json',
//         'Cookie': cookieHeader
//       }
//     });

//     const jsonData = releaseResponse.data;
//     const savePath = path.join(__dirname, '../../data/LinksDataFile/ReleaseToRequirementLink.json');
//     fs.writeFileSync(savePath, JSON.stringify(jsonData, null, 2), 'utf-8');

//     // Create Link Table
//     await db.promise().execute('DROP TABLE IF EXISTS ReleaseToReqLink');
//     await db.promise().execute(`
//       CREATE TABLE IF NOT EXISTS ReleaseToReqLink (
//         id INT PRIMARY KEY,
//         rel_id INT,
//         req_id INT,
//         link_status TEXT
//       )
//     `);

//     // Insert links into DB
//     const entities = jsonData.entities || [];
//     for (const entity of entities) {
//       const fields = entity.Fields;
//       const id = getFieldValue(fields, 'id');
//       const first = getFieldValue(fields, 'first-endpoint-id');
//       const second = getFieldValue(fields, 'second-endpoint-id');
//       await db.promise().execute(
//         'INSERT INTO ReleaseToReqLink (id, req_id, rel_id) VALUES (?, ?, ?)',
//         [parseIntSafe(id), parseIntSafe(first), parseIntSafe(second)]
//       );
//     }

//     // Fetch data to link in qTest
//     const [rows] = await db.promise().execute(`
//       SELECT rtl.rel_id, rtl.req_id, r.qtest_releases_id AS release_qtest_id,
//              req.qtest_requirement_id AS req_qtest_id
//         FROM ReleaseToReqLink rtl
//         JOIN releases r ON rtl.rel_id = r.id
//         JOIN requirement req ON rtl.req_id = req.id
//        WHERE rtl.link_status IS NULL OR rtl.link_status <> 'linked'
//     `);

//     // Link to qTest
//     for (const row of rows) {
//       const url = `${qTestConfig.qTestDomain}/api/v3/projects/${qTestConfig.projectId}/releases/${row.release_qtest_id}/link?type=requirements`;
//       const payload = [row.req_qtest_id];

//       try {
//         const response = await axios.post(url, payload, {
//           headers: {
//             'Content-Type': 'application/json',
//             'Authorization': `Bearer ${qTestConfig.apiToken}`
//           }
//         });

//         const status = (response.status === 200 || response.status === 201) ? 'linked' : 'failed';
//         await db.promise().execute(
//           'UPDATE ReleaseToReqLink SET link_status = ? WHERE rel_id = ? AND req_id = ?',
//           [status, row.rel_id, row.req_id]
//         );
//       } catch (err) {
//         await db.promise().execute(
//           'UPDATE ReleaseToReqLink SET link_status = ? WHERE rel_id = ? AND req_id = ?',
//           ['failed', row.rel_id, row.req_id]
//         );
//       }
//     }

//     res.json({ message: '✅ Release-to-Requirement linking completed successfully.' });
//   } catch (error) {
//     console.error('❌ Error:', error.message);
//     res.status(500).json({ error: error.message });
//   }
// };





 
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const db = require('../../config/db'); // Use shared db connection
 
// Load credentials
const almConfig = JSON.parse(fs.readFileSync(path.join(__dirname, '../../data/AlmCredentials.json'), 'utf-8'));
const qTestConfig = JSON.parse(fs.readFileSync(path.join(__dirname, '../../data/qTestCredentials.json'), 'utf-8'));
 
// Helpers
function extractCookies(setCookieHeaders) {
  const cookieMap = {};
  setCookieHeaders.forEach(cookieStr => {
    const [name, value] = cookieStr.split(';')[0].split('=');
    cookieMap[name.trim()] = value.trim();
  });
  return cookieMap;
}
 
function getFieldValue(fields, name) {
  for (const field of fields) {
    if (field.Name === name && Array.isArray(field.values) && field.values.length > 0) {
      return field.values[0].value || null;
    }
  }
  return null;
}
 
function parseIntSafe(value) {
  const parsed = parseInt(value);
  return isNaN(parsed) ? 0 : parsed;
}
 
// Main controller function
exports.linkReleaseToRequirement = async (req, res) => {
  const { almServerUrl, username, password, domain, project } = almConfig;
  const baseUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/requirement-target-releases`;
 
  try {
    // ALM Login
    const loginUrl = `${almServerUrl}/api/authentication/sign-in`;
    const authString = Buffer.from(`${username}:${password}`).toString('base64');
 
    const loginResponse = await axios.post(loginUrl, {}, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Basic ${authString}`
      },
      withCredentials: true
    });
 
    const cookies = extractCookies(loginResponse.headers['set-cookie'] || []);
    const cookieHeader = ['XSRF-TOKEN', 'JSESSIONID', 'LWSSO_COOKIE_KEY', 'ALM_USER', 'QCSession']
      .map(name => `${name}=${cookies[name]}`).join('; ');
 
    // Fetch paginated Release-to-Requirement link data
    const allEntities = [];
    const pageSize = 100;
    let startIndex = 1;
    let hasMore = true;
 
    while (hasMore) {
      const pagedUrl = `${baseUrl}?start-index=${startIndex}&page-size=${pageSize}`;
      const response = await axios.get(pagedUrl, {
        headers: {
          'Accept': 'application/json',
          'Cookie': cookieHeader
        }
      });
 
      const entities = response.data.entities || [];
      allEntities.push(...entities);
 
      if (entities.length < pageSize) {
        hasMore = false;
      } else {
        startIndex += pageSize;
      }
    }
 
    // Save to file
    const savePath = path.join(__dirname, '../../data/LinksDataFile/ReleaseToRequirementLink.json');
    fs.writeFileSync(savePath, JSON.stringify({ entities: allEntities }, null, 2), 'utf-8');
 
    // Create Link Table
    await db.promise().execute('DROP TABLE IF EXISTS ReleaseToReqLink');
    await db.promise().execute(`
      CREATE TABLE IF NOT EXISTS ReleaseToReqLink (
        id INT PRIMARY KEY,
        rel_id INT,
        req_id INT,
        link_status TEXT
      )
    `);
 
    // Insert links into DB
    for (const entity of allEntities) {
      const fields = entity.Fields;
      const id = getFieldValue(fields, 'id');
      const first = getFieldValue(fields, 'first-endpoint-id');
      const second = getFieldValue(fields, 'second-endpoint-id');
      await db.promise().execute(
        'INSERT INTO ReleaseToReqLink (id, req_id, rel_id) VALUES (?, ?, ?)',
        [parseIntSafe(id), parseIntSafe(first), parseIntSafe(second)]
      );
    }
 
    // Fetch data to link in qTest
    const [rows] = await db.promise().execute(`
      SELECT rtl.rel_id, rtl.req_id, r.qtest_releases_id AS release_qtest_id,
             req.qtest_requirement_id AS req_qtest_id
        FROM ReleaseToReqLink rtl
        JOIN releases r ON rtl.rel_id = r.id
        JOIN requirement req ON rtl.req_id = req.id
       WHERE rtl.link_status IS NULL OR rtl.link_status <> 'linked'
    `);
 
    // Link to qTest
    for (const row of rows) {
      const url = `${qTestConfig.qTestDomain}/api/v3/projects/${qTestConfig.projectId}/releases/${row.release_qtest_id}/link?type=requirements`;
      const payload = [row.req_qtest_id];
 
      try {
        const response = await axios.post(url, payload, {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${qTestConfig.apiToken}`
          }
        });
 
        const status = (response.status === 200 || response.status === 201) ? 'linked' : 'failed';
        await db.promise().execute(
          'UPDATE ReleaseToReqLink SET link_status = ? WHERE rel_id = ? AND req_id = ?',
          [status, row.rel_id, row.req_id]
        );
      } catch (err) {
        await db.promise().execute(
          'UPDATE ReleaseToReqLink SET link_status = ? WHERE rel_id = ? AND req_id = ?',
          ['failed', row.rel_id, row.req_id]
        );
      }
    }
 
    res.json({ message: '✅ Release-to-Requirement linking completed successfully.' });
  } catch (error) {
    console.error('❌ Error:', error.message);
    res.status(500).json({ error: error.message });
  }
};
 
 