// // --- controller/defectLinkController.js ---

// const fs = require('fs');
// const path = require('path');
// const axios = require('axios');
// const db = require('../../config/db').promise(); // Correct usage of your shared db connection
//  // Replace JSON with shared db.js

// // --- UTILITY FUNCTIONS ---
// function parseIntSafe(val) {
//     const num = parseInt(val);
//     return isNaN(num) ? 0 : num;
// }

// function getFieldValue(fields, name) {
//     for (const field of fields) {
//         if (field.Name === name && Array.isArray(field.values) && field.values.length > 0) {
//             return field.values[0].value;
//         }
//     }
//     return null;
// }

// function extractCookies(setCookies) {
//     const cookieMap = {};
//     setCookies.forEach(cookieStr => {
//         const parts = cookieStr.split(';')[0].split('=');
//         const key = parts[0].trim();
//         const val = parts[1] ? parts[1].trim() : '';
//         cookieMap[key] = val;
//     });
//     return cookieMap;
// }

// // --- ALM DEFECT LINK DOWNLOAD ---
// async function downloadDefectLinksFromALM(almConfigPath, outputJsonPath) {
//     const config = JSON.parse(fs.readFileSync(almConfigPath, 'utf-8'));
//     const authHeader = 'Basic ' + Buffer.from(`${config.username}:${config.password}`).toString('base64');
//     const loginUrl = `${config.almServerUrl}/api/authentication/sign-in`;
//     const defectLinksUrl = `${config.almServerUrl}/rest/domains/${config.domain}/projects/${config.project}/defect-links`;

//     const loginResponse = await axios.post(loginUrl, {}, {
//         headers: {
//             'Authorization': authHeader,
//             'Content-Type': 'application/json'
//         },
//         withCredentials: true
//     });

//     const cookies = loginResponse.headers['set-cookie'] || [];
//     const cookieMap = extractCookies(cookies);
//     const cookieHeader = Object.entries(cookieMap).map(([k, v]) => `${k}=${v}`).join('; ');

//     const response = await axios.get(defectLinksUrl, {
//         headers: {
//             Cookie: cookieHeader,
//             Accept: 'application/json'
//         }
//     });

//     fs.writeFileSync(outputJsonPath, JSON.stringify(response.data, null, 2));
//     console.log('✔ ALM defect links downloaded.');
// }

// // --- INSERT DEFECT LINKS INTO DB ---
// async function insertDefectsLinksIntoDB(db, defectLinksPath) {
//     const json = JSON.parse(fs.readFileSync(defectLinksPath, 'utf-8'));
//     const entities = json.entities;

//     await db.execute(`DROP TABLE IF EXISTS defectslinks`);
//     await db.execute(`
//         CREATE TABLE defectslinks (
//             id INT PRIMARY KEY,
//             defect_id INT,
//             endpoint_id INT,
//             entity_type TEXT,
//             link_status TEXT 
//         )
//     `);

//     for (const entity of entities) {
//         const fields = entity.Fields;
//         if (Array.isArray(fields)) {
//             const id = getFieldValue(fields, 'id');
//             const defectId = getFieldValue(fields, 'first-endpoint-id');
//             const endpointId = getFieldValue(fields, 'second-endpoint-id');
//             const entityType = getFieldValue(fields, 'second-endpoint-type');

//             await db.execute(
//                 `INSERT INTO defectslinks (id, defect_id, endpoint_id, entity_type) VALUES (?, ?, ?, ?)`,
//                 [parseIntSafe(id), parseIntSafe(defectId), parseIntSafe(endpointId), entityType]
//             );
//         }
//     }
//     console.log('✔ defectlinks.json loaded into database.');
// }

// // --- QTEST LINKING FUNCTIONALITY ---
// async function loadQTestConfig(filePath) {
//     const json = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
//     return {
//         baseUrl: json.baseUrl,
//         token: json.token,
//         projectId: json.projectId
//     };
// }

// async function getQTestId(db, table, column, id) {
//     const [rows] = await db.execute(`SELECT ${column} FROM ${table} WHERE id = ?`, [id]);
//     return rows.length ? rows[0][column] : null;
// }

// async function sendLinkRequest(url, token, payloadArray) {
//     try {
//         const response = await axios.put(url, payloadArray, {
//             headers: {
//                 'Content-Type': 'application/json',
//                 'Authorization': `Bearer ${token}`
//             }
//         });
//         if (response.status === 200) {
//             console.log(`✔ Linked successfully: ${url}`);
//         } else {
//             console.log(`✘ Failed to link: ${url} → Status: ${response.status}`);
//         }
//     } catch (err) {
//         console.error(`❌ Error linking to ${url}:`, err.message);
//     }
// }

// async function updateLinkStatus(db, defectId, endpointId) {
//     await db.execute(
//         `UPDATE defectslinks SET link_status = 'linked' WHERE defect_id = ? AND endpoint_id = ?`,
//         [defectId, endpointId]
//     );
// }

// async function processDefectLinking(db, qTest) {
//     const [rows] = await db.execute(
//         `SELECT defect_id, endpoint_id, entity_type FROM defectslinks WHERE link_status != 'linked'`
//     );

//     for (const row of rows) {
//         const { defect_id, endpoint_id, entity_type } = row;
//         const qtestDefectId = await getQTestId(db, 'defect', 'qtest_defect_id', defect_id);
//         if (!qtestDefectId) continue;

//         const payload = [qtestDefectId];

//         if (entity_type.toLowerCase() === 'run') {
//             const qtestLogId = await getQTestId(db, 'testlogs', 'qtest_testlog_id', endpoint_id);
//             if (qtestLogId) {
//                 const url = `${qTest.baseUrl}/api/v3/projects/${qTest.projectId}/test-logs/${qtestLogId}/link?type=defects`;
//                 await sendLinkRequest(url, qTest.token, payload);
//                 await updateLinkStatus(db, defect_id, endpoint_id);
//             }
//         } else if (entity_type.toLowerCase() === 'run-steps') {
//             const qtestStepId = await getQTestId(db, 'testlogsteps', 'qtest_testlogstep_id', endpoint_id);
//             if (qtestStepId) {
//                 const url = `${qTest.baseUrl}/api/v3/projects/${qTest.projectId}/test-steps/${qtestStepId}/link?type=defects`;
//                 await sendLinkRequest(url, qTest.token, payload);
//                 await updateLinkStatus(db, defect_id, endpoint_id);
//             }
//         }
//     }
//     console.log('✔ All unlinked defects processed.');
// }

// // --- CONTROLLER EXPORT ---
// exports.linkDefects = async (req, res) => {
//     const almCredPath = path.join(__dirname, '../../data/ALMcredentials.json');
//     const defectLinksJsonPath = path.join(__dirname, '../../data/LinksDataFile/DefectsLink.json');
//     const qTestCredPath = path.join(__dirname, '../../data/qTestCredentials.json');

//     try {
//          // Uses config from db.js
//         const qTest = await loadQTestConfig(qTestCredPath);

//         // Optional: Uncomment to download from ALM
//         await downloadDefectLinksFromALM(almCredPath, defectLinksJsonPath);

//         await insertDefectsLinksIntoDB(db, defectLinksJsonPath);
//         await processDefectLinking(db, qTest);
       

//         res.json({ message: '✅ Defect linking completed.' });
//     } catch (err) {
//         console.error('❌ Error during defect linking:', err.message);
//         res.status(500).json({ error: err.message });
//     }
// };





// --- controller/defectLinkController.js ---

// const fs = require('fs');
// const path = require('path');
// const axios = require('axios');
// const db = require('../../config/db').promise(); // Correct usage of your shared db connection
//  // Replace JSON with shared db.js

// // --- UTILITY FUNCTIONS ---
// function parseIntSafe(val) {
//     const num = parseInt(val);
//     return isNaN(num) ? 0 : num;
// }

// function getFieldValue(fields, name) {
//     for (const field of fields) {
//         if (field.Name === name && Array.isArray(field.values) && field.values.length > 0) {
//             return field.values[0].value;
//         }
//     }
//     return null;
// }

// function extractCookies(setCookies) {
//     const cookieMap = {};
//     setCookies.forEach(cookieStr => {
//         const parts = cookieStr.split(';')[0].split('=');
//         const key = parts[0].trim();
//         const val = parts[1] ? parts[1].trim() : '';
//         cookieMap[key] = val;
//     });
//     return cookieMap;
// }

// // --- ALM DEFECT LINK DOWNLOAD ---
// async function downloadDefectLinksFromALM(almConfigPath, outputJsonPath) {
//     const config = JSON.parse(fs.readFileSync(almConfigPath, 'utf-8'));
//     const authHeader = 'Basic ' + Buffer.from(`${config.username}:${config.password}`).toString('base64');
//     const loginUrl = `${config.almServerUrl}/api/authentication/sign-in`;
//     const defectLinksUrl = `${config.almServerUrl}/rest/domains/${config.domain}/projects/${config.project}/defect-links`;

//     const loginResponse = await axios.post(loginUrl, {}, {
//         headers: {
//             'Authorization': authHeader,
//             'Content-Type': 'application/json'
//         },
//         withCredentials: true
//     });

//     const cookies = loginResponse.headers['set-cookie'] || [];
//     const cookieMap = extractCookies(cookies);
//     const cookieHeader = Object.entries(cookieMap).map(([k, v]) => `${k}=${v}`).join('; ');

//     const response = await axios.get(defectLinksUrl, {
//         headers: {
//             Cookie: cookieHeader,
//             Accept: 'application/json'
//         }
//     });

//     fs.writeFileSync(outputJsonPath, JSON.stringify(response.data, null, 2));
//     console.log('✔ ALM defect links downloaded.');
// }

// // --- INSERT DEFECT LINKS INTO DB ---
// async function insertDefectsLinksIntoDB(db, defectLinksPath) {
//     const json = JSON.parse(fs.readFileSync(defectLinksPath, 'utf-8'));
//     const entities = json.entities;

//     await db.execute(`DROP TABLE IF EXISTS defectslinks`);
//     await db.execute(`
//         CREATE TABLE defectslinks (
//             id INT PRIMARY KEY,
//             defect_id INT,
//             endpoint_id INT,
//             entity_type TEXT,
//             link_status TEXT
//         )
//     `);

//     for (const entity of entities) {
//         const fields = entity.Fields;
//         if (Array.isArray(fields)) {
//             const id = getFieldValue(fields, 'id');
//             const defectId = getFieldValue(fields, 'first-endpoint-id');
//             const endpointId = getFieldValue(fields, 'second-endpoint-id');
//             const entityType = getFieldValue(fields, 'second-endpoint-type');

//             await db.execute(
//                 `INSERT INTO defectslinks (id, defect_id, endpoint_id, entity_type) VALUES (?, ?, ?, ?)`,
//                 [parseIntSafe(id), parseIntSafe(defectId), parseIntSafe(endpointId), entityType]
//             );
//         }
//     }
//     console.log('✔ defectlinks.json loaded into database.');
// }

// // --- QTEST LINKING FUNCTIONALITY ---
// async function loadQTestConfig(filePath) {
//     const json = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
//     return {
//         baseUrl: json.qTestDomain,
//         token: json.apiToken,
//         projectId: json.projectId
//     };
// }

// async function getQTestId(db, table, column, id) {
//     const [rows] = await db.execute(`SELECT ${column} FROM ${table} WHERE id = ?`, [id]);
//     return rows.length ? rows[0][column] : null;
// }

// async function sendLinkRequest(url, token, payloadArray) {
//     try {
//         const response = await axios.post(url, payloadArray, {
//             headers: {
//                 'Content-Type': 'application/json',
//                 'Authorization': `Bearer ${token}`
//             }
//         });
//         if (response.status === 200 || response.status === 201) {
//             console.log(`✔ Linked successfully: ${url}`);
//         } else {
//             console.log(`✘ Failed to link: ${url} → Status: ${response.status}`);
//         }
//     } catch (err) {
//         console.error(`❌ Error linking to ${url}:`, err.message);
//     }
// }

// async function updateLinkStatus(db, defectId, endpointId) {
//     await db.execute(
//         `UPDATE defectslinks SET link_status = 'linked' WHERE defect_id = ? AND endpoint_id = ?`,
//         [defectId, endpointId]
//     );
// }

// async function processDefectLinking(db, qTest) {
//     const [rows] = await db.execute(
//         `SELECT defect_id, endpoint_id, entity_type FROM defectslinks WHERE link_status != 'linked' OR link_status IS NULL`
//     );

//     for (const row of rows) {
//         const { defect_id, endpoint_id, entity_type } = row;
//         const qtestDefectId = await getQTestId(db, 'defects', 'qtest_defects_id', defect_id);
//         if (!qtestDefectId) continue;

//         const payload = [qtestDefectId];

//         if (entity_type.toLowerCase() === 'run') {
//             const qtestLogId = await getQTestId(db, 'testlogs', 'qTest_id', endpoint_id);
//             if (qtestLogId) {
//                 const url = `${qTest.baseUrl}/api/v3/projects/${qTest.projectId}/test-logs/${qtestLogId}/link?type=defects`;
//                 await sendLinkRequest(url, qTest.token, payload);
//                 await updateLinkStatus(db, defect_id, endpoint_id);
//             }
//         } else if (entity_type.toLowerCase() === 'run-step') {
//             const qtestStepId = await getQTestId(db, 'testlogsteps', 'qtest_testlogstep_id', endpoint_id);
//             if (qtestStepId) {
//                 const url = `${qTest.baseUrl}/api/v3/projects/${qTest.projectId}/test-steps/${qtestStepId}/link?type=defects`;
//                 await sendLinkRequest(url, qTest.token, payload);
//                 await updateLinkStatus(db, defect_id, endpoint_id);
//             }
//         }
//     }
//     console.log('✔ All unlinked defects processed.');
// }

// // --- CONTROLLER EXPORT ---
// exports.linkDefects = async (req, res) => {
//     const almCredPath = path.join(__dirname, '../../data/ALMcredentials.json');
//     const defectLinksJsonPath = path.join(__dirname, '../../data/LinksDataFile/DefectsLink.json');
//     const qTestCredPath = path.join(__dirname, '../../data/qTestCredentials.json');

//     try {
//          // Uses config from db.js
//         const qTest = await loadQTestConfig(qTestCredPath);

//         // Optional: Uncomment to download from ALM
//         await downloadDefectLinksFromALM(almCredPath, defectLinksJsonPath);

//         await insertDefectsLinksIntoDB(db, defectLinksJsonPath);
//         await processDefectLinking(db, qTest);
       

//         res.json({ message: '✅ Defect linking completed.' });
//     } catch (err) {
//         console.error('❌ Error during defect linking:', err.message);
//         res.status(500).json({ error: err.message });
//     }
// };



 
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const db = require('../../config/db').promise(); // Correct usage of your shared db connection
 // Replace JSON with shared db.js
 
// --- UTILITY FUNCTIONS ---
function parseIntSafe(val) {
    const num = parseInt(val);
    return isNaN(num) ? 0 : num;
}
 
function getFieldValue(fields, name) {
    for (const field of fields) {
        if (field.Name === name && Array.isArray(field.values) && field.values.length > 0) {
            return field.values[0].value;
        }
    }
    return null;
}
 
function extractCookies(setCookies) {
    const cookieMap = {};
    setCookies.forEach(cookieStr => {
        const parts = cookieStr.split(';')[0].split('=');
        const key = parts[0].trim();
        const val = parts[1] ? parts[1].trim() : '';
        cookieMap[key] = val;
    });
    return cookieMap;
}
 
// --- ALM DEFECT LINK DOWNLOAD ---
// async function downloadDefectLinksFromALM(almConfigPath, outputJsonPath) {
//     const config = JSON.parse(fs.readFileSync(almConfigPath, 'utf-8'));
//     const authHeader = 'Basic ' + Buffer.from(`${config.username}:${config.password}`).toString('base64');
//     const loginUrl = `${config.almServerUrl}/api/authentication/sign-in`;
//     const defectLinksUrl = `${config.almServerUrl}/rest/domains/${config.domain}/projects/${config.project}/defect-links`;
 
//     const loginResponse = await axios.post(loginUrl, {}, {
//         headers: {
//             'Authorization': authHeader,
//             'Content-Type': 'application/json'
//         },
//         withCredentials: true
//     });
 
//     const cookies = loginResponse.headers['set-cookie'] || [];
//     const cookieMap = extractCookies(cookies);
//     const cookieHeader = Object.entries(cookieMap).map(([k, v]) => `${k}=${v}`).join('; ');
 
//     const response = await axios.get(defectLinksUrl, {
//         headers: {
//             Cookie: cookieHeader,
//             Accept: 'application/json'
//         }
//     });
 
//     fs.writeFileSync(outputJsonPath, JSON.stringify(response.data, null, 2));
//     console.log('✔ ALM defect links downloaded.');
// }
 
 
 
async function downloadDefectLinksFromALM(almConfigPath, outputJsonPath) {
    const config = JSON.parse(fs.readFileSync(almConfigPath, 'utf-8'));
    const authHeader = 'Basic ' + Buffer.from(`${config.username}:${config.password}`).toString('base64');
    const loginUrl = `${config.almServerUrl}/api/authentication/sign-in`;
    const baseDefectLinksUrl = `${config.almServerUrl}/rest/domains/${config.domain}/projects/${config.project}/defect-links`;
 
    // Step 1: Authenticate
    const loginResponse = await axios.post(loginUrl, {}, {
        headers: {
            'Authorization': authHeader,
            'Content-Type': 'application/json'
        },
        withCredentials: true
    });
 
    const cookies = loginResponse.headers['set-cookie'] || [];
    const cookieMap = extractCookies(cookies);
    const cookieHeader = Object.entries(cookieMap).map(([k, v]) => `${k}=${v}`).join('; ');
 
    // Step 2: Pagination loop
    const pageSize = 100;
    let startIndex = 1;
    let allEntities = [];
    let hasMore = true;
 
    while (hasMore) {
        const url = `${baseDefectLinksUrl}?start-index=${startIndex}&page-size=${pageSize}`;
        const response = await axios.get(url, {
            headers: {
                Cookie: cookieHeader,
                Accept: 'application/json'
            }
        });
 
        const entities = response.data.entities || [];
        allEntities.push(...entities);
 
        if (entities.length < pageSize) {
            hasMore = false;
        } else {
            startIndex += pageSize;
        }
    }
 
    // Save to output JSON
    fs.writeFileSync(outputJsonPath, JSON.stringify({ entities: allEntities }, null, 2), 'utf-8');
    console.log(`✔ ALM defect links downloaded: ${allEntities.length} records`);
}
 
 
 
 
// --- INSERT DEFECT LINKS INTO DB ---
async function insertDefectsLinksIntoDB(db, defectLinksPath) {
    const json = JSON.parse(fs.readFileSync(defectLinksPath, 'utf-8'));
    const entities = json.entities;
 
    await db.execute(`DROP TABLE IF EXISTS defectslinks`);
    await db.execute(`
        CREATE TABLE defectslinks (
            id INT PRIMARY KEY,
            defect_id INT,
            endpoint_id INT,
            entity_type TEXT,
            link_status TEXT
        )
    `);
 
    for (const entity of entities) {
        const fields = entity.Fields;
        if (Array.isArray(fields)) {
            const id = getFieldValue(fields, 'id');
            const defectId = getFieldValue(fields, 'first-endpoint-id');
            const endpointId = getFieldValue(fields, 'second-endpoint-id');
            const entityType = getFieldValue(fields, 'second-endpoint-type');
 
            await db.execute(
                `INSERT INTO defectslinks (id, defect_id, endpoint_id, entity_type) VALUES (?, ?, ?, ?)`,
                [parseIntSafe(id), parseIntSafe(defectId), parseIntSafe(endpointId), entityType]
            );
        }
    }
    console.log('✔ defectlinks.json loaded into database.');
}
 
// --- QTEST LINKING FUNCTIONALITY ---
async function loadQTestConfig(filePath) {
    const json = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    return {
        baseUrl: json.qTestDomain,
        token: json.apiToken,
        projectId: json.projectId
    };
}
 
async function getQTestId(db, table, column, id) {
    const [rows] = await db.execute(`SELECT ${column} FROM ${table} WHERE id = ?`, [id]);
    return rows.length ? rows[0][column] : null;
}
 
async function sendLinkRequest(url, token, payloadArray) {
    try {
        const response = await axios.post(url, payloadArray, {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            }
        });
        if (response.status === 200 || response.status === 201) {
            console.log(`✔ Linked successfully: ${url}`);
        } else {
            console.log(`✘ Failed to link: ${url} → Status: ${response.status}`);
        }
    } catch (err) {
        console.error(`❌ Error linking to ${url}:`, err.message);
    }
}
 
async function updateLinkStatus(db, defectId, endpointId) {
    await db.execute(
        `UPDATE defectslinks SET link_status = 'linked' WHERE defect_id = ? AND endpoint_id = ?`,
        [defectId, endpointId]
    );
}
 
async function processDefectLinking(db, qTest) {
    const [rows] = await db.execute(
        `SELECT defect_id, endpoint_id, entity_type FROM defectslinks WHERE link_status != 'linked' OR link_status IS NULL`
    );
 
    for (const row of rows) {
        const { defect_id, endpoint_id, entity_type } = row;
        const qtestDefectId = await getQTestId(db, 'defects', 'qtest_defects_id', defect_id);
        if (!qtestDefectId) continue;
 
        const payload = [qtestDefectId];
 
        if (entity_type.toLowerCase() === 'run') {
            const qtestLogId = await getQTestId(db, 'testlogs', 'qTest_id', endpoint_id);
            if (qtestLogId) {
                const url = `${qTest.baseUrl}/api/v3/projects/${qTest.projectId}/test-logs/${qtestLogId}/link?type=defects`;
                await sendLinkRequest(url, qTest.token, payload);
                await updateLinkStatus(db, defect_id, endpoint_id);
            }
        } else if (entity_type.toLowerCase() === 'run-step') {
            const qtestStepId = await getQTestId(db, 'testlogsteps', 'qtest_testlogstep_id', endpoint_id);
            if (qtestStepId) {
                const url = `${qTest.baseUrl}/api/v3/projects/${qTest.projectId}/test-steps/${qtestStepId}/link?type=defects`;
                await sendLinkRequest(url, qTest.token, payload);
                await updateLinkStatus(db, defect_id, endpoint_id);
            }
        }
    }
    console.log('✔ All unlinked defects processed.');
}
 
// --- CONTROLLER EXPORT ---
exports.linkDefects = async (req, res) => {
    const almCredPath = path.join(__dirname, '../../data/ALMcredentials.json');
    const defectLinksJsonPath = path.join(__dirname, '../../data/LinksDataFile/DefectsLink.json');
    const qTestCredPath = path.join(__dirname, '../../data/qTestCredentials.json');
 
    try {
         // Uses config from db.js
        const qTest = await loadQTestConfig(qTestCredPath);
 
        // Optional: Uncomment to download from ALM
        await downloadDefectLinksFromALM(almCredPath, defectLinksJsonPath);
 
        await insertDefectsLinksIntoDB(db, defectLinksJsonPath);
        await processDefectLinking(db, qTest);
       
 
        res.json({ message: '✅ Defect linking completed.' });
    } catch (err) {
        console.error('❌ Error during defect linking:', err.message);
        res.status(500).json({ error: err.message });
    }
};
 