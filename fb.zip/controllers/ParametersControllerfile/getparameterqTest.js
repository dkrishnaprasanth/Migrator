const fs = require('fs');
const path = require('path');
const axios = require('axios');

// Load qTest credentials from external JSON file
const credentialsPath = path.join(__dirname, '../../data/qTestCredentials.json');
const { apiToken } = JSON.parse(fs.readFileSync(credentialsPath, 'utf-8'));

// Base URL
const baseUrl = `https://parameter-13.qtestnet.com/api/v1/parameters`;

async function fetchQtestParameters() {
  let allParameters = [];
  let page = 1;
  const pageSize = 50; // Max allowed per qTest API (default is 50)

  try {
    while (true) {
      const response = await axios.get(baseUrl, {
        headers: {
          Authorization: `Bearer ${apiToken}`,
          'Content-Type': 'application/json'
        },
        params: {
          page,
          pageSize
        }
      });

      const items = response.data.items || [];
      allParameters = allParameters.concat(items);

      console.log(`📥 Fetched page ${page} with ${items.length} items.`);

      if (items.length < pageSize) break; // Last page reached

      page++; // Move to next page
    }

    // Save full result
    const outputPath = path.join(__dirname, '../../data/ParametersDataFile/qtestparameters.json');
    fs.writeFileSync(outputPath, JSON.stringify({ items: allParameters }, null, 2));
    console.log(`✅ All qTest parameters saved to: ${outputPath}`);

  } catch (error) {
    console.error('❌ Failed to fetch qTest parameters:', error.response?.data || error.message);
  }
}

module.exports = { fetchQtestParameters };

