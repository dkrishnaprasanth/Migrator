const fs = require('fs');
const axios = require('axios');
const path = require('path');

// Load ALM server config and credentials from external JSON file
const configPath = path.join(__dirname, '../../data/AlmCredentials.json');
const almConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'));

const {
    almServerUrl,
    username,
    password,
    domain,
    project
} = almConfig;

const loginUrl = `${almServerUrl}/api/authentication/sign-in`;
const releaseDataUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/test-parameters`;

// const fetchAlmparameter = async () => {
//     try {
//         // Perform authentication
//         const auth = Buffer.from(`${username}:${password}`).toString('base64');
//         const loginResponse = await axios.post(loginUrl, {}, {
//             headers: {
//                 'Authorization': `Basic ${auth}`,
//                 'Content-Type': 'application/json'
//             },
//             withCredentials: true
//         });

//         const setCookies = loginResponse.headers['set-cookie'] || [];
//         const cookieMap = getCookiesMap(setCookies);

//         const {
//             'XSRF-TOKEN': xsrfToken,
//             'JSESSIONID': sessionCookie,
//             'LWSSO_COOKIE_KEY': lwssoCookie,
//             'ALM_USER': almUser,
//             'QCSession': qcSession
//         } = cookieMap;

//         if (xsrfToken && sessionCookie) {
//             const cookieHeader = buildCookieHeader(cookieMap);

//             const releaseResponse = await axios.get(releaseDataUrl, {
//                 headers: {
//                     'Accept': 'application/json',
//                     'Cookie': cookieHeader
//                 }
//             });

//             const responseBody = releaseResponse.data;

//             const outputFile = path.join(__dirname, "../../data/Parametersdatafile/ALMParameters.json");
//             fs.writeFileSync(outputFile, JSON.stringify(responseBody, null, 2));

//             console.log("All parameters fields responses are saved.");
//         } else {
//             console.log("Authentication failed. XSRF Token or Session Cookie missing.");
//             throw new Error("Authentication failed");
//         }
//     } catch (error) {
//         console.error("Error:", error.message || error);
//     }
// };



const fetchAlmparameter = async () => {
    try {
        const auth = Buffer.from(`${username}:${password}`).toString('base64');
        const loginResponse = await axios.post(loginUrl, {}, {
            headers: {
                'Authorization': `Basic ${auth}`,
                'Content-Type': 'application/json'
            },
            withCredentials: true
        });

        const setCookies = loginResponse.headers['set-cookie'] || [];
        const cookieMap = getCookiesMap(setCookies);

        const {
            'XSRF-TOKEN': xsrfToken,
            'JSESSIONID': sessionCookie,
            'LWSSO_COOKIE_KEY': lwssoCookie,
            'ALM_USER': almUser,
            'QCSession': qcSession
        } = cookieMap;

        if (!xsrfToken || !sessionCookie) {
            console.log("Authentication failed. XSRF Token or Session Cookie missing.");
            throw new Error("Authentication failed");
        }

        const cookieHeader = buildCookieHeader(cookieMap);

        // Pagination parameters
        const pageSize = 100; // Increase to max allowed by ALM (usually 1000)
        let startIndex = 1;
        let totalFetched = 0;
        let allEntities = [];

        while (true) {
            const pagedUrl = `${releaseDataUrl}?start-index=${startIndex}&page-size=${pageSize}`;
            const response = await axios.get(pagedUrl, {
                headers: {
                    'Accept': 'application/json',
                    'Cookie': cookieHeader
                }
            });

            const entities = response.data.entities || [];
            allEntities = allEntities.concat(entities);

            totalFetched += entities.length;
            console.log(`Fetched: ${totalFetched} records`);

            // Stop when fewer than pageSize records are returned
            if (entities.length < pageSize) break;

            startIndex += pageSize;
        }

        const finalData = {
            total_count: allEntities.length,
            entities: allEntities
        };

        const outputFile = path.join(__dirname, "../../data/Parametersdatafile/ALMParameters.json");
        fs.writeFileSync(outputFile, JSON.stringify(finalData, null, 2));

        console.log(`✅ Fetched ${allEntities.length} parameters from ALM.`);
    } catch (error) {
        console.error("❌ Error fetching parameters:", error.message || error);
    }
};





function getCookiesMap(setCookies) {
    const cookieMap = {};
    setCookies.forEach(cookie => {
        const parts = cookie.split(';')[0].split('=');
        if (parts.length === 2) {
            cookieMap[parts[0].trim()] = parts[1].trim();
        }
    });
    return cookieMap;
}

function buildCookieHeader(cookieMap) {
    return Object.entries(cookieMap)
        .map(([key, value]) => `${key}=${value}`)
        .join('; ');
}

 module.exports = { fetchAlmparameter };

//fetchAlmparameter();