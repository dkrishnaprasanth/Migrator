



const { fetchAlmparameter } = require('../ParametersControllerfile/ALMParameters');
const { cleanHtmlFromJson } = require('../../controllers/ParametersControllerfile/ParameterFilter');
const { fetchAlmparameterToDB } = require('../ParametersControllerfile/ALMParametersToDB');
const { fetchAlmparameterDuplicateRemover } = require('../ParametersControllerfile/ParameterDuplicateRemover');
const { fetchAlmparameterUploader } = require('../../controllers/ParametersControllerfile/ParameterUploader');
const { fetchAlmparameterValueUploader } = require('../../controllers/ParametersControllerfile/ParameterValueUploader');
const { fetchQtestParameters } = require('./getparameterqTest');
const { insertQtestParameters, getParameterCount } = require('./insertqTestparamToDb');
const { updateQtestParamIds } = require('./parametercheck');

const db = require('../../config/db'); 

 
const insertparameters = async (req, res) => {
  try {
    console.log("📥 Fetching ALM parameters...");
    await fetchAlmparameter();

    console.log("🧹 Cleaning HTML content from JSON...");
    await cleanHtmlFromJson();

    console.log("💾 Saving parameters to database...");
    const insertResult = await fetchAlmparameterToDB();

    console.log("🗑️ Removing duplicate parameters...");
    await fetchAlmparameterDuplicateRemover();

    console.log("get qtest parameters...");
    await fetchQtestParameters();

    console.log("insert qtest parameters to db...");
    await insertQtestParameters();

    // ✅ Database count
    const [countResult] = await db.promise().query(
      "SELECT COUNT(*) AS totalCount FROM parameters"
    );
    const totalCount = countResult[0].totalCount;

    console.log("✅🚀 Database and ALM setup completed successfully.");
    res.status(200).json({
      success: true,
      message: 'ALM Setup completed successfully.',
      stats: {
        inserted: insertResult?.affectedRows || 0,
        totalCount
      }
    });

  } catch (error) {
    console.error("❌ Setup failed:", error);
    res.status(500).json({ error: 'ALM Setup failed', details: error.message });
  }
};


const uploadparameters = async (req, res) => {
    try {
        console.log("checking values...");
        await updateQtestParamIds();
 
        console.log("📤 Uploading cleaned parameters...");
        await fetchAlmparameterUploader();
 
        console.log("📤 Uploading parameter values...");
        await fetchAlmparameterValueUploader();
 
        console.log("✅🚀 Database and ALM setup completed successfully.");
        res.status(200).json({ message: 'ALM Setup completed successfully.' });
    } catch (error) {
        console.error("❌ Setup failed:", error);
        res.status(500).json({ error: 'ALM Setup failed', details: error.message });
    }
};
 
 
module.exports = { insertparameters, uploadparameters, getParameterCount };
 




