const fs = require('fs');
const path = require('path');
const axios = require('axios');
const db = require("../../config/db"); // use this, no need to create new connection
 
const qTestConfigPath = path.join(__dirname, '../../data/qTestCredentials.json');
 
const fetchAlmparameterValueUploader = async () => {
    let qTestConfig;
 
    try {
        qTestConfig = JSON.parse(fs.readFileSync(qTestConfigPath, 'utf8'));
    } catch (err) {
        console.error('Error reading config file:', err.message);
        return;
    }
 
    const { apiToken } = qTestConfig;
    const qTestUrl = "https://parameter-13.qtestnet.com/api/v1/parameters";
 
    try {
        const [rows] = await db.promise().query(
            `SELECT id, qTest_Params_id, value FROM parameters WHERE value IS NOT NULL`
        );
 
        for (const row of rows) {
            const rowId = row.id;
            const paramId = row.qTest_Params_id;
 
            // 🔄 Replace ' | ' with '\n' to meet qTest requirement
            const rawValue = row.value || '';
            const value = rawValue
                .split('|')           // split by pipe
                .map(v => v.trim())   // trim each value
                .join('\n');          // join with newline
 
            const postUrl = `${qTestUrl}/${paramId}/values`;
 
            let qtestValueId = null;
            let valueStatus = 'Failed';
 
            try {
                const payload = { value };
 
                const response = await axios.post(postUrl, payload, {
                    headers: {
                        Authorization: `Bearer ${apiToken}`,
                        'Content-Type': 'application/json'
                    }
                });
 
                console.log("\n---");
                console.log("POST to URL:", postUrl);
                console.log("Payload:", JSON.stringify(payload));
                console.log("Response Code:", response.status);
                console.log("Response Body:", JSON.stringify(response.data));
                console.log("---\n");
 
                if (response.data?.created) {
                    qtestValueId = response.data.created;
                    valueStatus = 'Uploaded';
                }
 
            } catch (err) {
                console.error(`❌ Error sending value for row ${rowId}:`, err.message);
            }
 
            const updateQuery = `UPDATE parameters SET qTest_value_count = ?, value_status = ? WHERE id = ?`;
            await db.promise().query(updateQuery, [qtestValueId, valueStatus, rowId]);
 
            console.log(`Row ID ${rowId} -> Status: ${valueStatus}`);
        }
 
        console.log("✅ All values processed.");
    } catch (err) {
        console.error("❌ Fatal error in value upload:", err.message);
    }
};
 
module.exports = { fetchAlmparameterValueUploader };
