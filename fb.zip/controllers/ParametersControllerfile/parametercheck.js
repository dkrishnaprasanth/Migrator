const db = require('../../config/db'); // uses your db.js

const updateQtestParamIds = async () => {
  try {
    // Step 1: Get parameters with null qTest_Params_id
    const [params] = await db.promise().query(
      "SELECT id, name, value FROM parameters WHERE qTest_Params_id IS NULL"
    );

    if (params.length === 0) {
      console.log('✅ No rows with null qTest_Params_id found.');
      return;
    }

    for (const row of params) {
      const { id, name, value: paramValue } = row;

      // Step 2: Find match in qtest_parameters (case-insensitive)
      const [match] = await db.promise().query(
        "SELECT id, value FROM qtest_parameters WHERE LOWER(identifier) = LOWER(?)",
        [name]
      );

      if (match.length > 0) {
        const qtestId = match[0].id;
        const qtestValue = match[0].value || '';

        // Step 3: Update qTest_Params_id
        await db.promise().query(
          "UPDATE parameters SET qTest_Params_id = ? , Status_Params = 'completed' WHERE id = ?",
          [qtestId, id]
        );
        console.log(`✅ Updated: '${name}' → qTest_Params_id = ${qtestId}`);

        // Step 4: Clean value column if matching
        if (paramValue && qtestValue) {
          const paramParts = paramValue.split('|').map(v => v.trim()).filter(v => v);
          const qtestParts = qtestValue.split('|').map(v => v.trim()).filter(v => v);

          // Remove all qtest parts from param parts
          const cleanedParts = paramParts.filter(pv => !qtestParts.includes(pv));

          // Join cleaned parts back with pipe or set to NULL if empty
          const newValue = cleanedParts.length > 0 ? cleanedParts.join(' | ') : null;

          await db.promise().query(
            "UPDATE parameters SET value = ? WHERE id = ?",
            [newValue, id]
          );

          console.log(`🧹 Cleaned value column for id ${id}`);
        }

      } else {
        console.log(`❌ No match found for: '${name}'`);
      }
    }

    console.log('🎉 Finished updating parameters table.');
  } catch (err) {
    console.error('❌ Error:', err.message || err);
  }
};

//updateQtestParamIds();

module.exports = { updateQtestParamIds };