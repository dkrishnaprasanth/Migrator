const db = require("../../config/db");
 
const fetchAlmparameterDuplicateRemover = async () => {
  try {
    const connection = db.promise();
 
    const queries = [
      `SET SQL_SAFE_UPDATES = 0;`,
 
      // Step 1: Remove exact duplicates (same name + trimmed value)
      `DELETE t1
       FROM parameters t1
       JOIN (
           SELECT MIN(id) AS keep_id, name, TRIM(value) AS trimmed_value
           FROM parameters
           GROUP BY name, trimmed_value
       ) t2 ON t1.name = t2.name AND TRIM(t1.value) = t2.trimmed_value
       WHERE t1.id > t2.keep_id;`,
 
      // Step 2: Drop temp table
      `DROP TEMPORARY TABLE IF EXISTS temp_parameters;`,
 
      // ✅ Step 3: Create temp table with truly deduplicated trimmed values
      `CREATE TEMPORARY TABLE temp_parameters AS
       SELECT 
         MIN(id) AS keep_id,
         name,
         (
           SELECT GROUP_CONCAT(val SEPARATOR ' | ')
           FROM (
             SELECT DISTINCT TRIM(value) AS val
             FROM parameters p2
             WHERE p2.name = p1.name
           ) AS sub
         ) AS combined_value
       FROM parameters p1
       GROUP BY name;`,
 
      // Step 4: Update the combined value
      `UPDATE parameters p
       JOIN temp_parameters t ON p.id = t.keep_id
       SET p.value = t.combined_value;`,
 
      // Step 5: Delete non-kept rows
      `DELETE p FROM parameters p
       LEFT JOIN temp_parameters t ON p.id = t.keep_id
       WHERE t.keep_id IS NULL;`
    ];
 
    for (const query of queries) {
      console.log("Executing:\n" + query + "\n");
      await connection.query(query);
    }
 
    console.log("✅ All queries executed successfully.");
  } catch (err) {
    console.error("❌ Error executing queries:", err.message);
  }
};

module.exports = { fetchAlmparameterDuplicateRemover };
//fetchAlmparameterDuplicateRemover();