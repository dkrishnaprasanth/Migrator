
const fs = require("fs");
const path = require("path");
const db = require("../../config/db");

const almJsonPath = path.join(__dirname, "../../data/Parametersdatafile/ALMParameters.json");

const fetchAlmparameterToDB = async () => {
  try {
    // Drop the table if it exists
    await new Promise((resolve, reject) => {
      const dropQuery = `DROP TABLE IF EXISTS parameters`;
      db.query(dropQuery, (err) => {
        if (err) {
          console.error("❌ Error dropping table:", err.message);
          return reject(err);
        }
        console.log("✅ Dropped existing 'parameters' table (if it existed).");
        resolve();
      });
    });

    // Create the new table with link_name
    await new Promise((resolve, reject) => {
      const createTableQuery = `
        CREATE TABLE parameters (
          id INT PRIMARY KEY,
          parent_id INT,
          value VARCHAR(255),
          name TEXT,
          description TEXT,
          qTest_Params_id INT,
          Status_Params TEXT,
          qTest_value_count INT,
          value_status TEXT,
          link_name VARCHAR(255)
        )
      `;
      db.query(createTableQuery, (err) => {
        if (err) {
          console.error("❌ Error creating table:", err.message);
          return reject(err);
        }
        console.log("✅ Table 'parameters' created successfully.");
        resolve();
      });
    });

    // Read and parse the JSON
    const root = JSON.parse(fs.readFileSync(almJsonPath, "utf-8"));
    const entities = root.entities;

    // Get the structure of link_table to determine ordering column
    const [tableInfo] = await db.promise().query("DESCRIBE link_table");
    const columns = tableInfo.map(col => col.Field);

    let orderColumn = 'id'; // default
    if (columns.includes('created_at')) {
      orderColumn = 'created_at';
    } else if (columns.includes('creation_date')) {
      orderColumn = 'creation_date';
    }

    console.log(`🧭 Using '${orderColumn}' to determine default link_name from link_table`);

    // Insert each parameter
    for (const entity of entities) {
      const fields = entity.Fields;

      const id = getFieldValue(fields, "id");
      const parentId = getFieldValue(fields, "parent-id");
      const defaultValue = getFieldValue(fields, "default-value");
      const name = getFieldValue(fields, "name");
      const description = getFieldValue(fields, "description");
      let linkName = getFieldValue(fields, "link-name");

      // 🔄 Begin link_name validation logic
      if (linkName && linkName.trim() !== "") {
        const [linkResult] = await db.promise().query(
          "SELECT link_name FROM link_table WHERE link_name = ? AND is_current = 1",
          [linkName]
        );

        if (linkResult.length === 0) {
          const [defaultLink] = await db.promise().query(
            `SELECT link_name FROM link_table WHERE is_current = 1 ORDER BY ${orderColumn} DESC LIMIT 1`
          );

          if (defaultLink.length === 0) {
            console.warn(`⚠️ No active link_name found in link_table. '${linkName}' set to NULL`);
            linkName = null;
          } else {
            linkName = defaultLink[0].link_name;
            console.log(`🔁 Fallback to default link_name: ${linkName}`);
          }
        } else {
          linkName = linkResult[0].link_name;
          console.log(`✅ Validated link_name: ${linkName}`);
        }
      } else if (linkName === "") {
        linkName = null;
      } else {
        const [defaultLink] = await db.promise().query(
          `SELECT link_name FROM link_table WHERE is_current = 1 ORDER BY ${orderColumn} DESC LIMIT 1`
        );

        linkName = defaultLink.length > 0 ? defaultLink[0].link_name : null;
        // console.log(linkName ? `📌 Default link_name used: ${linkName}` : "⚠️ No link_name available, set to NULL");
      }

      // 🔄 End link_name logic

      const insertSQL = `
        INSERT INTO parameters (id, parent_id, value, name, description, link_name)
        VALUES (?, ?, ?, ?, ?, ?)
      `;

      await new Promise((resolve, reject) => {
        db.query(
          insertSQL,
          [
            parseIntSafe(id),
            parseNullableInt(parentId),
            defaultValue,
            name,
            description,
            linkName,
          ],
          (err) => {
            if (err) {
              console.error("❌ Error inserting data:", err.message);
              return reject(err);
            }
            resolve();
          }
        );
      });
    }

    console.log("✅ All ALM parameters inserted successfully.");
  } catch (err) {
    console.error("❌ Error during ALM data processing:", err.message);
  }
};

// Helpers
function getFieldValue(fields, name) {
  for (const field of fields) {
    if (
      field.Name === name &&
      Array.isArray(field.values) &&
      field.values.length > 0
    ) {
      return field.values[0].value || null;
    }
  }
  return null;
}

function parseNullableInt(val) {
  const n = parseInt(val);
  return isNaN(n) ? null : n;
}

function parseIntSafe(val) {
  const n = parseInt(val);
  return isNaN(n) ? 0 : n;
}

module.exports = { fetchAlmparameterToDB };
