
// const fs = require('fs');
// const path = require('path');
// const cheerio = require('cheerio');


// const cleanHtmlFromJson = () => {
//     const filePath = path.join(__dirname,  "../../data/Parametersdatafile/ALMParameters.json");

//     try {
//         const jsonInput = fs.readFileSync(filePath, 'utf-8');
//         const root = JSON.parse(jsonInput);
//         const entities = root.entities;

//         for (const entity of entities) {
//             const fields = entity.Fields;

//             for (const field of fields) {
//                 const name = field.Name;

//                 if (name === 'default-value' || name === 'description') {
//                     const values = field.values;

//                     for (const valueObj of values) {
//                         if (valueObj.hasOwnProperty('value')) {
//                             const html = valueObj.value;
//                             const plainText = cheerio.load(html).text(); // Strip HTML
//                             valueObj.value = plainText;
//                         }
//                     }
//                 }
//             }
//         }

//         fs.writeFileSync(filePath, JSON.stringify(root, null, 2), 'utf-8');
//         console.log("Cleaned JSON saved to", filePath);
//     } catch (error) {
//         console.error("Error reading or writing the JSON file:", error.message);
//     }
// };

// module.exports = {cleanHtmlFromJson};





const fs = require('fs');
const path = require('path');
const cheerio = require('cheerio');

const cleanHtmlFromJson = () => {
    const filePath = path.join(__dirname, "../../data/Parametersdatafile/ALMParameters.json");

    try {
        const jsonInput = fs.readFileSync(filePath, 'utf-8');
        const root = JSON.parse(jsonInput);
        const entities = root.entities;

        for (const entity of entities) {
            const fields = entity.Fields;

            for (const field of fields) {
                const name = field.Name;

                if (name === 'default-value' || name === 'description') {
                    const values = field.values;

                    for (const valueObj of values) {
                        if (valueObj.hasOwnProperty('value')) {
                            const html = valueObj.value;
                            let plainText = cheerio.load(html).text(); // Strip HTML

                            if (name === 'default-value') {
                                // Replace multiple newlines with pipe, after trimming
                                plainText = plainText
                                    .split('\n')                    // Split by newline
                                    .map(v => v.trim())             // Trim each value
                                    .filter(v => v)                 // Remove empty strings
                                    .join(' | ');                   // Join using pipe
                            } else {
                                // For description: just trim
                                plainText = plainText.trim();
                            }

                            valueObj.value = plainText;
                        }
                    }
                }
            }
        }

        fs.writeFileSync(filePath, JSON.stringify(root, null, 2), 'utf-8');
        console.log("✅ Cleaned JSON saved to", filePath);
    } catch (error) {
        console.error("❌ Error reading or writing the JSON file:", error.message);
    }
};

// Run the function


module.exports = {cleanHtmlFromJson};