const fs = require('fs');
const path = require('path');
const db = require('../../config/db'); // Uses your db.js

const insertQtestParameters = async () => {
  try {
    const filePath = path.join(__dirname, '../../data/Parametersdatafile/qtestparameters.json');
    const fileData = fs.readFileSync(filePath, 'utf-8');
    const jsonData = JSON.parse(fileData);
    const items = jsonData.items;

    if (!Array.isArray(items) || items.length === 0) {
      console.log('⚠️ No items found in JSON.');
      return;
    }

    // 🗑️ Drop table if exists
    const dropTableQuery = `DROP TABLE IF EXISTS qtest_parameters`;
    await new Promise((resolve, reject) => {
      db.query(dropTableQuery, (err) => {
        if (err) return reject(err);
        console.log('🗑️ Dropped existing table `qtest_parameters` (if any).');
        resolve();
      });
    });

    // ✅ Create table with an additional `value` column
    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS qtest_parameters (
        id BIGINT PRIMARY KEY,
        identifier VARCHAR(255),
        value TEXT
      )
    `;
    await new Promise((resolve, reject) => {
      db.query(createTableQuery, (err) => {
        if (err) return reject(err);
        console.log('✅ Table `qtest_parameters` ready.');
        resolve();
      });
    });

    // ✅ Prepare bulk insert values
    const values = items.map(item => {
      const id = parseInt(item.id);
      const identifier = item.identifier || '';
      let value = '';

      // Handle different forms of `values` field
      if (Array.isArray(item.values)) {
        value = item.values.join('|');
      } else if (typeof item.values === 'string') {
        // Convert comma-separated string to pipe-separated
        value = item.values.split(',').map(v => v.trim()).join('|');
      }

      return [id, identifier, value];
    });

    const insertQuery = `
      INSERT INTO qtest_parameters (id, identifier, value)
      VALUES ?
      ON DUPLICATE KEY UPDATE 
        identifier = VALUES(identifier),
        value = VALUES(value)
    `;

    await new Promise((resolve, reject) => {
      db.query(insertQuery, [values], (err, result) => {
        if (err) return reject(err);
        console.log(`✅ Inserted/Updated ${result.affectedRows} rows.`);
        resolve();
      });
    });

  } catch (error) {
    console.error('❌ Error:', error.message || error);
  }
};

// Exportable function if needed
// module.exports = insertQtestParameters;

const getParameterCount = async (req, res) => {
  try {
    const jsonFilePath = path.join(__dirname, "../../data/Parametersdatafile/almparameters.json");

    if (!fs.existsSync(jsonFilePath)) {
      return res.status(404).json({ success: false, message: "Parameter JSON not found" });
    }

    const jsonData = JSON.parse(fs.readFileSync(jsonFilePath, "utf8"));
    const totalCount = jsonData.entities?.length || 0;

    res.json({ totalCount });
  } catch (error) {
    console.error("❌ Error in getParameterCount:", error);
    res.status(500).json({ error: "Failed to fetch parameters count" });
  }
};

module.exports = {insertQtestParameters, getParameterCount};
