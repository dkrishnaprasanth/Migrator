
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const db = require("../../config/db"); // your MySQL connection file

// File path for qTest credentials
const QTEST_CREDENTIALS_PATH = path.join(__dirname, '../../data/qTestCredentials.json');

// Load JSON credentials from file
function loadJson(filePath) {
    try {
        const data = fs.readFileSync(filePath, 'utf8');
        return JSON.parse(data);
    } catch (err) {
        throw new Error(`Failed to read JSON from ${filePath}: ${err.message}`);
    }
}

const fetchAlmparameterUploader = async () => {
    try {
        const qTestCreds = loadJson(QTEST_CREDENTIALS_PATH);
        const token = qTestCreds.apiToken;
        const projectId = qTestCreds.projectId;
        const qTestUrl = "https://parameter-13.qtestnet.com/api/v1/parameters";

        // Promisify the db connection
        const promiseDb = db.promise();

        // Fetch parameters from the database
        const [rows] = await promiseDb.query('SELECT id, name, description FROM parameters WHERE qTest_Params_id IS NULL');
        const updateQuery = 'UPDATE parameters SET qTest_Params_id = ?, Status_Params = ? WHERE id = ?';

        for (const row of rows) {
            const { id, name, description } = row;

            const payload = {
                identifier: name,
                description: description,
                status: "Active",
                project_ids: [projectId]
            };

            let qTestId = null;
            let status = "Failed";

            try {
                const response = await axios.post(`${qTestUrl}/create`, payload, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    }
                });

                qTestId = response.data?.id || null;
                status = qTestId ? "completed" : "Failed";
                console.log(`Uploaded parameter ID ${id}, received qTest ID: ${qTestId}`);
            } catch (error) {
                console.error(`Error uploading parameter ID ${id}:`, error.message);
            }

            await promiseDb.query(updateQuery, [qTestId, status, id]);
        }

        console.log("All parameters uploaded and database updated.");

    } catch (err) {
        console.error("Fatal Error:", err.message);
    }
};

module.exports = { fetchAlmparameterUploader };
//fetchAlmparameterUploader();
