const db = require("../../config/db");
const fs = require('fs');
const path = require('path');
 
const TYPE_MAPPING = {
  'Number': ['Number'],
  'String': ['Text box'],
  'LookupList': ['Combo box', 'Multiple selection combo box'],
  'UserList': ['User List'],
  'Date': ['Date'],
  'DateTime': ['Date and time picker'],
  'Memo': ['LongText', 'Text area']
};
 
// Helper function to promisify db queries
function queryAsync(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.query(sql, params, (err, results) => {
      if (err) {
        reject(err);
      } else {
        resolve(results);
      }
    });
  });
}
 
async function validateFieldMappings() {
  try {
    console.log('Starting field validation using existing DB connection...');
 
    // Get current active links
    const linkRows = await queryAsync(`
      SELECT link_name, domain, project, projectId
      FROM link_table
      WHERE is_current = 1
    `);
 
    if (!linkRows.length) {
      console.log('No active link found.');
      return {
        status: 'completed',
        message: 'No active link found.',
        result: []
      };
    }
 
    console.log(`Found ${linkRows.length} active links`);
    const result = [];
 
    for (const { link_name, domain, project, projectId } of linkRows) {
      console.log(`Processing link: ${link_name}`);
     
      // Get field mappings for this link
      const fields = await queryAsync(
        `SELECT artifact_type, ep1_label, ep1_type, ep2_label, ep2_type
         FROM field_mappings
         WHERE link_name = ?`,
        [link_name]
      );
 
      console.log(`Found ${fields.length} field mappings for ${link_name}`);
 
      const artifacts = {};
      let allPassed = true;
 
      for (const row of fields) {
        const { artifact_type, ep1_label, ep1_type, ep2_label, ep2_type } = row;
       
        if (!artifacts[artifact_type]) {
          artifacts[artifact_type] = {
            mapped_fields: [],
            status: 'success',
            failed_fields: []
          };
        }
 
        // Check if the mapping is valid
        let isValid = TYPE_MAPPING[ep1_type] && TYPE_MAPPING[ep1_type].includes(ep2_type);
 
        if (
  artifact_type === 'Release' &&
  ep2_label.toLowerCase() === 'status'
) {
  isValid = ep1_type === 'LookupList';
}
 
        artifacts[artifact_type].mapped_fields.push({
          alm_field: ep1_label,
          qtest_field: ep2_label,
          alm_type: ep1_type,
          qtest_type: ep2_type,
          status: isValid ? 'pass' : 'fail'
        });
 
        if (!isValid) {
          artifacts[artifact_type].status = 'fail';
          artifacts[artifact_type].failed_fields.push({
            alm_field: ep1_label,
            qtest_field: ep2_label,
            ep1_type,
            ep2_type
          });
          allPassed = false;
        }
      }
 
      result.push({
        link_name,
        domain,
        project,
        projectId,
        validation_status: allPassed ? 'success' : 'fail',
        artifacts
      });
    }
 
    // Create directory if it doesn't exist and save the report
    try {
      const filePath = path.join('C:', 'Users', 'ElitteBook', 'Pictures', 'Build project', 'backend', 'data', 'fieldvalidationreport.json');
      const dir = path.dirname(filePath);
     
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
 
      fs.writeFileSync(filePath, JSON.stringify(result, null, 2));
      console.log(`Report saved to: ${filePath}`);
    } catch (fileError) {
      console.error('Error saving file:', fileError.message);
      // Continue execution even if file save fails
    }
 
    return {
      status: 'completed',
      message: 'Validation complete',
      result
    };
 
  } catch (error) {
    console.error('Validation error:', error.message);
    console.error('Stack trace:', error.stack);
    return {
      status: 'error',
      message: `Database error: ${error.message}`
    };
  }
}
 
module.exports = validateFieldMappings;
 