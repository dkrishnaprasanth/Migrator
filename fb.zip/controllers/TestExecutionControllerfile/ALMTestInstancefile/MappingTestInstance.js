

const fs = require("fs");
const path = require("path");
const axios = require("axios");
const db = require("../../../config/db");


const insertSampleData = async (req, res) => {
  try {
    const [columns] = await db.promise().query(
      `SELECT ep1_name, ep1_type, ep2_field_id
       FROM Field_mappings
       WHERE artifact_type='TestInstance'
         AND link_name = (SELECT link_name FROM link_table WHERE is_current = 1 LIMIT 1)`
    );
 
    if (!columns || columns.length === 0) {
      return res.status(400).json({
        success: false,
        message: "No mapping columns found. Please create mappings first."
      });
    }
 
    const jsonFilePath = path.join(__dirname, '../../../data/TestExecutiondatafile/ALMTestInstancedata/ALMTestInstance.json');
    if (!fs.existsSync(jsonFilePath)) {
      return res.status(404).json({
        success: false,
        message: `JSON file not found at: ${jsonFilePath}`
      });
    }
 
    const jsonData = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'));
 
    const [existingRows] = await db.promise().query(
      "SELECT id, last_modified, qtest_testinstance_id, upload_status FROM testinstance"
    );
 
    const existingMap = new Map(
      existingRows.map(row => [
        Number(row.id),
        {
          last_modified: row.last_modified ? new Date(row.last_modified).toISOString().slice(0, 19) : null,
          qtestId: row.qtest_testinstance_id,
          status: row.upload_status
        }
      ])
    );
 
    const [tableInfo] = await db.promise().query("DESCRIBE testinstance");
    const tableColumns = tableInfo.map(column => column.Field);
 
    const mappingColumns = columns.map(col => col.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase());
    const requiredColumns = [
      'name', 'test_id', 'has_link', 'has_attachment',
      'last_modified', 'parent_id', 'qtest_testinstance_id', 'upload_status'
    ];
 
    const allColumns = [...mappingColumns, ...requiredColumns].filter(col => tableColumns.includes(col));
    const columnSQL = allColumns.map(col => `\`${col}\``).join(', ');
 
    const allRowsToInsert = [];
    let insertedCount = 0;
    let updatedCount = 0;
    let skippedCount = 0;
 
    for (const entity of jsonData.entities) {
      const rowData = {};
 
      // Fill mapped columns
      for (const column of columns) {
        const columnName = column.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
        const matchingField = entity.Fields.find(field =>
          field.Name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase() === columnName
        );
 
        if (!matchingField || !matchingField.values?.length) {
          rowData[columnName] = null;
        } else {
          const combinedValue = matchingField.values.map(v => v.value).join(',');
          switch (column.ep1_type) {
            case 'Number':
              rowData[columnName] = isNaN(Number(combinedValue)) ? null : Number(combinedValue);
              break;
            case 'Date':
              const parsedDate = new Date(combinedValue);
              rowData[columnName] = isNaN(parsedDate.getTime())
                ? null
                : parsedDate.toISOString().split('T')[0];
              break;
            default:
              rowData[columnName] = combinedValue;
          }
        }
      }
 
      // Required fields
      rowData['name'] = entity.Fields.find(f => f.Name === 'name')?.values?.[0]?.value || null;
      rowData['test_id'] = entity.Fields.find(f => f.Name === 'test-id')?.values?.[0]?.value || null;
      rowData['has_link'] = entity.Fields.find(f => f.Name === 'req-count')?.values?.[0]?.value || null;
      rowData['has_attachment'] = entity.Fields.find(f => f.Name === 'has-attachments')?.values?.[0]?.value || null;
      rowData['last_modified'] = entity.Fields.find(f => f.Name === 'last-modified')?.values?.[0]?.value || null;
      rowData['parent_id'] = entity.Fields.find(f => f.Name === 'cycle-id')?.values?.[0]?.value || null;
      rowData['qtest_testinstance_id'] = null;
 
      const instanceId = Number(entity.Fields.find(f => f.Name === 'id')?.values?.[0]?.value || null);
      const newLastModified = rowData['last_modified']
        ? new Date(rowData['last_modified']).toISOString().slice(0, 19)
        : null;
 
      // Compare with DB
      if (instanceId && existingMap.has(instanceId)) {
        const { last_modified: existingModified, qtestId } = existingMap.get(instanceId);
        if (existingModified === newLastModified) {
          skippedCount++;
          continue;
        } else {
          rowData['upload_status'] = qtestId ? 'modified' : 'changed';
          updatedCount++;
        }
      } else {
        rowData['upload_status'] = null;
        insertedCount++;
      }
 
      const rowValues = allColumns.map(col => rowData[col]);
      allRowsToInsert.push(rowValues);
    }
 
    if (!allRowsToInsert.length) {
      return res.status(200).json({
        success: false,
        message: 'No new data to insert or update.',
        details: {
          inserted: insertedCount,
          updated: updatedCount,
          skipped: skippedCount,
          totalProcessed: insertedCount + updatedCount + skippedCount
        }
      });
    }
 
    // Batch insert
    const BATCH_SIZE = 100;
    for (let i = 0; i < allRowsToInsert.length; i += BATCH_SIZE) {
      const batch = allRowsToInsert.slice(i, i + BATCH_SIZE);
      const placeholders = batch.map(() => `(${new Array(allColumns.length).fill('?').join(', ')})`).join(', ');
      const flatValues = batch.flat();
 
      const updateSQL = allColumns
        .filter(col => col !== 'id' && col !== 'qtest_testinstance_id')
        .map(col => `\`${col}\` = VALUES(\`${col}\`)`)
        .join(', ');
 
      const insertSQL = `INSERT INTO testinstance (${columnSQL}) VALUES ${placeholders} ON DUPLICATE KEY UPDATE ${updateSQL}`;
      await db.promise().query(insertSQL, flatValues);
    }
 
    // Total DB count
    const [totalCount] = await db.promise().query("SELECT COUNT(*) as count FROM testinstance");
 
    res.status(200).json({
      success: true,
      message: "Test Instances processed successfully",
      details: {
        inserted: insertedCount,
        updated: updatedCount,
        skipped: skippedCount,
        totalProcessed: insertedCount + updatedCount + skippedCount
      },
      totalCount: totalCount[0].count
    });
 
  } catch (error) {
    console.error('Error inserting test instance data:', error);
    res.status(500).json({
      success: false,
      message: `Error: ${error.message}`
    });
  }
};
 

const credentials = require("../../../data/qTestCredentials.json");

// Global variable to store migration statistics
let uploadStats = {
  total: 0,
  success: 0,
  failed: 0,
  skipped: 0,
  pending: 0
};



const uploadTestInstanceToQTest = async (payload, row, parentId = 0) => {
  try {
    const { id, upload_status, qtest_testinstance_id } = row;

    // ✅ Skip if status is completed
    if (upload_status === 'completed') {
      console.log(`⏭️ Skipping TestInstance ID ${id} (already completed)`);
      uploadStats.skipped++;
      uploadStats.pending--;
      return { skipped: true };
    }

    // ✅ Construct URL
    let url = `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/test-runs`;
    let method = 'post';

    // ✅ Use PUT if status is modified and qTest ID exists
    if (upload_status === 'modified' && qtest_testinstance_id) {
      url += `/${qtest_testinstance_id}`;
      method = 'put';
    } else if (parentId) {
      // Append parent info for POST
      url += `?parentId=${parentId}&parentType=test-suite`;
    }

    const response = await axios({
      method,
      url,
      data: payload,
      headers: {
        Authorization: `Bearer ${credentials.apiToken}`,
        'Content-Type': 'application/json',
      },
      validateStatus: () => true,
    });

    if (response.status === 200 || response.status === 201) {
      const qTestId = response.data?.id || qtest_testinstance_id || null;

      await db.promise().query(
        "UPDATE testinstance SET upload_status = ?, qtest_testinstance_id = ? WHERE id = ?",
        ['completed', qTestId, id]
      );

      uploadStats.success++;
      uploadStats.pending--;
      return { success: true, qTestId };
    } else {
      await db.promise().query(
        "UPDATE testinstance SET upload_status = ? WHERE id = ?",
        [`failed_${response.status}`, id]
      );
      uploadStats.failed++;
      uploadStats.pending--;
      return { success: false, error: `HTTP ${response.status}` };
    }
  } catch (error) {
    const status = error.response?.status || "unknown_error";
    const message = error.response?.data?.message || error.message || "Unknown error";

    await db.promise().query(
      "UPDATE testinstance SET upload_status = ? WHERE id = ?",
      [`failed_${status}`, row.id]
    );

    uploadStats.failed++;
    uploadStats.pending--;
    return { success: false, error: message };
  }
};


const processTestInstances = async (testInstanceRows, mappings, testCaseMap, parentIdMap) => {
  let counter = 1;

  for (let row of testInstanceRows) {
    console.log(`🔄 Processing Test Instance ${counter}/${testInstanceRows.length} (ID: ${row.id})`);

    let testInstanceName = `TestInstance_${row.id}`;

    if (row.name && row.name.trim() !== '') {
      testInstanceName = row.name.trim();
    }

    console.log(`📝 Test Instance name: ${testInstanceName}`);

    const properties = [];

    for (let mapping of mappings) {
      const columnName = mapping.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
      const rawValue = row[columnName];

      console.log(`🔍 Processing field: ${mapping.ep1_name} (${columnName}) = ${rawValue} (type: ${mapping.ep1_type})`);

      if (rawValue === null || rawValue === undefined || rawValue === '') {
        console.log(`⚠️ Skipping empty value for ${columnName}`);
        continue;
      }

      if (mapping.ep1_type === "LookupList") {
        const valuesToCheck = typeof rawValue === 'string' ? rawValue.split(',').map(v => v.trim()) : [rawValue];

        const [valueMappings] = await db.promise().query(`
          SELECT ep1_value, ep2_value_id, ep2_value 
          FROM value_mappings 
          WHERE ep1_name = ? AND ep2_field_id = ?
        `, [mapping.ep1_name, mapping.ep2_field_id]);

        console.log(`🔎 Found ${valueMappings.length} value mappings for ${mapping.ep1_name}`);
        const matchedEp2Ids = [];
        const matchedEp2Names = [];

        valuesToCheck.forEach(value => {
          const match = valueMappings.find(vm => vm.ep1_value === value);
          if (match) {
            matchedEp2Ids.push(match.ep2_value_id);
            matchedEp2Names.push(match.ep2_value);
            console.log(`✅ Matched value: ${value} -> ${match.ep2_value_id} (${match.ep2_value})`);
          } else {
            console.log(`❌ No match found for value: ${value}`);
          }
        });

        if (matchedEp2Ids.length > 0) {
          const fieldValue = matchedEp2Ids.length === 1 ? matchedEp2Ids[0] : matchedEp2Ids[0];
          const fieldValueName = matchedEp2Names.length === 1 ? matchedEp2Names[0] : matchedEp2Names[0];
          properties.push({
            field_id: mapping.ep2_field_id,
            field_name: mapping.ep2_label,
            field_value: fieldValue,
            field_value_name: fieldValueName
          });
          console.log(`✅ Added LookupList property: ${mapping.ep2_label} = ${fieldValue} with name ${fieldValueName}`);
        }
      } 
       else if (mapping.ep1_type === "UsersList") {
  const valuesToCheck = typeof rawValue === 'string' 
    ? rawValue.split(',').map(v => v.trim()) 
    : [rawValue];

  for (const value of valuesToCheck) {
    // Query users table to match the Name column
    const [userMatch] = await db.promise().query(`
      SELECT qtest_id, first_name 
      FROM users 
      WHERE Name = ?
      LIMIT 1
    `, [value]);

    if (userMatch.length > 0) {
      const { qtest_id, first_name } = userMatch[0];

      properties.push({
        field_id: mapping.ep2_field_id,
        field_name: mapping.ep2_label,
        field_value: qtest_id,
        field_value_name: first_name
      });

      console.log(`✅ Matched user: ${value} -> ${qtest_id} (${first_name})`);
    } else {
      console.log(`❌ No match found in users table for: ${value}`);
    }
  }
}

      else {
        let processedValue = rawValue;

        if (mapping.ep1_type === 'Number') {
          processedValue = isNaN(Number(rawValue)) ? null : Number(rawValue);
        } else if (mapping.ep1_type === 'Date') {
          const parsedDate = new Date(rawValue);
          processedValue = formatDateForQTest(parsedDate);
        } else if (mapping.ep1_type === 'String') {
          processedValue = String(rawValue).trim();
        }

        if (processedValue !== null && processedValue !== '') {
          properties.push({
            field_id: mapping.ep2_field_id,
            field_name: mapping.ep2_label,
            field_value: processedValue
          });
          console.log(`✅ Added ${mapping.ep1_type} property: ${mapping.ep2_label} = ${processedValue}`);
        }
      }
    }

    console.log(`📊 Total properties created: ${properties.length}`);

    if (!testInstanceName || testInstanceName.trim() === '' || testInstanceName === 'TestInstance_') {
      console.error(`❌ Skipping test instance with invalid name: ${row.id}`);
      await db.promise().query("UPDATE testinstance SET upload_status = ? WHERE id = ?", ['failed_no_name', row.id]);
      uploadStats.skipped++;
      uploadStats.pending--;
      continue;
    }

    // Determine parent-id for the API call, but DO NOT include it in the payload
    let parentId = 0;
    if (row.parent_id) {
      const parentQTestId = parentIdMap.get(String(row.parent_id));
      if (parentQTestId) {
        parentId = parentQTestId;
      }
    }

    const singlePayload = {
      name: testInstanceName.trim(),
      properties: properties
    };

    // Add test case mapping if available
    const matchedTestCaseId = testCaseMap.get(String(row.test_id));
    if (matchedTestCaseId) {
      singlePayload.test_case = {
        id: matchedTestCaseId
      };
    }

    console.log(`📋 Final payload:`, JSON.stringify(singlePayload, null, 2));

    const outputPath = path.join(__dirname, "../../../data/TestExecutiondatafile/ALMTestInstancedata/TestInstanceFinalPayload.json");
    fs.writeFileSync(outputPath, JSON.stringify(singlePayload, null, 2), "utf8");

    //const uploadResult = await uploadReleaseToQTest(singlePayload, row.id, parentId);

    const uploadResult = await uploadTestInstanceToQTest(singlePayload, row, parentId);


    if (!uploadResult.success) {
      console.error(`❌ Upload failed for Test Instance ${testInstanceName}: ${uploadResult.error}`);
    } else {
      console.log(`✅ Successfully uploaded Test Instance ${testInstanceName} with ID ${uploadResult.qTestId}`);
    }

    counter++;
    await new Promise(resolve => setTimeout(resolve, 1000));
  }
};

const processAndUploadAllTestInstance = async (req, res) => {
  try {
    // Reset statistics before starting
    uploadStats = {
      total: 0,
      success: 0,
      failed: 0,
      skipped: 0,
      pending: 0
    };

    // Fetch the current mapping field name
    const [mappingRow] = await db
      .promise()
      .query("SELECT DISTINCT link_name FROM Field_mappings WHERE artifact_type = 'TestInstance'");

    const currentTable = mappingRow.length > 0 ? mappingRow[0].link_name : null;
    if (!currentTable) throw new Error("No active mapping table found.");

    // Fetch mappings with proper filtering like releases
    const [mappings] = await db
      .promise()
      .query(
        "SELECT ep1_name, ep1_type, ep2_label, ep2_field_id FROM Field_mappings WHERE  artifact_type = 'TestInstance' AND link_name = ?",
        [currentTable]
      );

    console.log(`Found ${mappings.length} field mappings`);

    // Fetch test instances that need to be processed
    //const [testInstanceRows] = await db.promise().query("SELECT * FROM testinstance WHERE upload_status IS NULL OR upload_status LIKE 'failed%' OR upload_status = 'pending'");

    const [testInstanceRows] = await db.promise().query(
      "SELECT * FROM testinstance WHERE upload_status IS NULL OR upload_status LIKE 'failed%' OR upload_status = 'pending' OR upload_status = 'modified' OR upload_status = 'changed'"
    );



    // Fetch test case mappings
    const [testMappings] = await db.promise().query("SELECT id, qtest_testcase_id FROM tests");

    // Build map: test_id => qtest_testcase_id
    const testCaseMap = new Map(testMappings.map(row => [String(row.id), row.qtest_testcase_id]));

    // Set initial statistics
    uploadStats.total = testInstanceRows.length;
    uploadStats.pending = testInstanceRows.length;

    // Fetch parent ID to qTest ID mappings
    const [parentMappings] = await db.promise().query("SELECT id, qtest_testset_id FROM testset");
    const parentIdMap = new Map(parentMappings.map(row => [String(row.id), row.qtest_testset_id]));

    await processTestInstances(testInstanceRows, mappings, testCaseMap, parentIdMap);

    res.status(200).json({
      message: "Migration completed",
      counts: uploadStats,
    });
  } catch (error) {
    console.error("❌ Error processing test instances:", error.message);
    res.status(500).json({ message: "Migration failed", error: error.message });
  }
};

const getMigrationStatus = async (req, res) => {
  try {
    const [totalCount] = await db.promise().query("SELECT COUNT(*) as count FROM testinstance");
    const [completedCount] = await db.promise().query("SELECT COUNT(*) as count FROM testinstance WHERE upload_status = 'completed'");
    const [failedCount] = await db.promise().query("SELECT COUNT(*) as count FROM testinstance WHERE upload_status LIKE 'failed%'");
    const [pendingCount] = await db.promise().query("SELECT COUNT(*) as count FROM testinstance WHERE upload_status IS NULL OR upload_status = 'pending'");

    res.json({
      counts: {
        total: totalCount[0].count,
        success: completedCount[0].count,
        failed: failedCount[0].count,
        pending: pendingCount[0].count
      }
    });
  } catch (error) {
    console.error("❌ Error fetching testinstance status:", error.message);
    res.status(500).json({
      message: "Error getting test instance migration status",
      error: error.message
    });
  }
};

const getTestRunsCount = async (req, res) => {
  try {
    const jsonFilePath = path.join(__dirname, "../../../data/TestExecutiondatafile/ALMTestInstancedata/ALMTestInstance.json");

    if (!fs.existsSync(jsonFilePath)) {
      return res.status(404).json({ success: false, message: "Requirements JSON not found" });
    }

    const jsonData = JSON.parse(fs.readFileSync(jsonFilePath, "utf8"));
    const totalCount = jsonData.entities?.length || 0;

    res.json({ totalCount });
  } catch (error) {
    console.error("❌ Error in getTestRunsCount:", error);
    res.status(500).json({ error: "Failed to fetch testcases count" });
  }
};

module.exports = {
  insertSampleData,
  processAndUploadAllTestInstance,
  getMigrationStatus,
  getTestRunsCount
};









