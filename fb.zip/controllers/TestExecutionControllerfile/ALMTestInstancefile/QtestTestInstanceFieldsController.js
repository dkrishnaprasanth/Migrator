const db = require("../../../config/db");
const fs = require("fs");
const path = require("path");
const { fetchqTestTestInstanceFields } = require("./QtestTestInstanceFields");

// ------------------------------
// Read and Validate JSON
// ------------------------------
const loadJsonAndValidateqtestrequirement = async () => {
  const jsonFilePath = path.join(__dirname, '../../../data/TestExecutiondatafile/ALMTestInstancedata/QtestTestInstanceFields.json');

  try {
    const rawData = fs.readFileSync(jsonFilePath, "utf-8");
    if (!rawData) {
      console.error("❌ JSON file is empty.");
      return [];
    }

    const parsedData = JSON.parse(rawData);
    if (
      !Array.isArray(parsedData) &&
      (!parsedData.Fields || !Array.isArray(parsedData.Fields.Field))
    ) {
      console.error("❌ Unexpected JSON structure:", parsedData);
      return [];
    }

    return Array.isArray(parsedData) ? parsedData : parsedData.Fields.Field;
  } catch (err) {
    console.error("❌ Error reading/parsing JSON file:", err);
    return [];
  }
};

// ------------------------------
// Create Tables
// ------------------------------
const createTableqtestTestSet = async () => {
  return new Promise((resolve, reject) => {
     const dropQtestFieldsTable = `DROP TABLE IF EXISTS qtest_testinstance_fields;`;
    const createQtestDataTable = `
      CREATE TABLE IF NOT EXISTS qtest_testinstance_fields (
        id INT PRIMARY KEY,
        attribute_type VARCHAR(255),
        label TEXT
      ) `;

        const dropComboValuesTable = `DROP TABLE IF EXISTS  qtest_testinstance_combo_values;`;
    const createQtestReleasesTable = `
      CREATE TABLE IF NOT EXISTS qtest_testinstance_combo_values (
        id INT,
        attribute_type VARCHAR(255),
        label TEXT,
        value INT,
        label_value TEXT
      )
    `;

    
      db.query(dropQtestFieldsTable, (dropErr1) => {
      if (dropErr1) {
        console.error("Error dropping qtest_requirement_data:", dropErr1.message);
        return reject(dropErr1);
      }

      db.query(dropComboValuesTable, (dropErr2) => {
        if (dropErr2) {
          console.error("Error dropping qtest_requirement:", dropErr2.message);
          return reject(dropErr2);
        }


    db.query(createQtestDataTable, (err) => {
      if (err) return reject(err);
      db.query(createQtestReleasesTable, (err) => {
        if (err) return reject(err);
        resolve();
      });
    });
  });
   });
    });
};

// ------------------------------
// Insert Data From JSON
// ------------------------------
const insertqtestTestSetFieldsFromJson = async () => {
  try {
    const jsonData = await  loadJsonAndValidateqtestrequirement();
    if (!jsonData || jsonData.length === 0) return;

    const [dataResult] = await db.promise().query("SELECT COUNT(*) AS count FROM qtest_testinstance_fields");
    if (dataResult[0].count > 0) {
      console.log("⚠️ Data already exists in qtest_testinstance_fields.");
      return;
    }

    // Insert into qtest_testinstance_fields table
    const qtestDataValues = jsonData.map(item => [
      item.id || null,
      item.attribute_type || null,
      item.label || null,
    ]);

    await db.promise().query(
      `INSERT INTO qtest_testinstance_fields (id, attribute_type, label) VALUES ?`,
      [qtestDataValues]
    );
    console.log("✅ qtest_testinstance_fields inserted.");

    // Insert into qtest_testinstance_combo_values (includes all entries, with or without allowed_values)
    let qtestReleasesValues = [];

    jsonData.forEach(item => {
      if (item.allowed_values && Array.isArray(item.allowed_values) && item.allowed_values.length > 0) {
        // insert each allowed value
        item.allowed_values.forEach(val => {
          if (val.value != null && val.label != null) {
            qtestReleasesValues.push([
              item.id,
              item.attribute_type,
              item.label,
              val.value,
              val.label
            ]);
          }
        });
      } else {
        // if no allowed_values, still insert one row with nulls for value and label_value
        qtestReleasesValues.push([
          item.id,
          item.attribute_type,
          item.label,
          null,
          null
        ]);
      }
    });

    await db.promise().query(
      `INSERT INTO qtest_testinstance_combo_values (id, attribute_type, label, value, label_value) VALUES ?`,
      [qtestReleasesValues]
    );
    console.log("✅ qtest_testinstance_combo_values data inserted.");

  } catch (err) {
    console.error("❌ Error in insertDataFromJson:", err);
  }
};


// ------------------------------
// Main Init
// ------------------------------
const qtestrequirementinit = async () => {
  try {
    console.log("🚀 Fetching fields...");
    await fetchqTestTestInstanceFields();
    console.log("✅ Fetch done.");
    await createTableqtestTestSet();
    await insertqtestTestSetFieldsFromJson ();
  } catch (err) {
    console.error("❌ Initialization failed:", err);
    process.exit(1);
  }
};

// ------------------------------
// Refresh Data
// ------------------------------
const refreshQTestTestSetFields = async (req, res) => {
  try {
    console.log("➡️ Fetching qTest release fields...");
    const fetchResult = await fetchqTestTestInstanceFields();
    
    if (!fetchResult.success) {
      return res.status(400).json({ error: fetchResult.message });
    }

    const jsonFilePath =  path.join(__dirname, '../../../data/TestExecutiondatafile/ALMTestInstancedata/QtestTestInstanceFields.json');
    console.log("➡️ Loading JSON data...");
    
    // Verify file exists
    if (!fs.existsSync(jsonFilePath)) {
      console.error("❌ JSON file does not exist at:", jsonFilePath);
      return res.status(400).json({ error: "qTest data file not found." });
    }
    
    // Read file with error handling
    const rawData = fs.readFileSync(jsonFilePath, "utf-8");
    if (!rawData || rawData.trim() === '') {
      console.error("❌ JSON file is empty.");
      return res.status(400).json({ error: "qTest data file is empty." });
    }
    
    // Parse JSON with error handling
    let jsonData;
    try {
      jsonData = JSON.parse(rawData);
      console.log(`✅ Successfully parsed JSON data with ${jsonData.length} entries`);
    } catch (parseError) {
      console.error("❌ Error parsing JSON data:", parseError);
      return res.status(400).json({ error: "Invalid JSON format in qTest data file." });
    }

    if (!jsonData || jsonData.length === 0) {
      console.log("❌ JSON is empty. Aborting.");
      return res.status(400).json({ error: "No valid qTest data found." });
    }

    // Clear existing data
    await db.promise().query("DELETE FROM qtest_testinstance_fields");
    await db.promise().query("DELETE FROM qtest_testinstance_combo_values");
    console.log("✅ Cleared existing data from tables");

    // Insert into qtest_testinstance_fields
    const qtestDataValues = jsonData.map(item => [
      item.id || null,
      item.attribute_type || null,
      item.label || null,
    ]);

    const [dataResult] = await db.promise().query(
      `INSERT INTO qtest_testinstance_fields (id, attribute_type, label) VALUES ?`,
      [qtestDataValues]
    );
    console.log(`✅ Inserted ${dataResult.affectedRows} rows into qtest_testinstance_fields table`);

    // Insert into qtest_testinstance_combo_values (with or without allowed values)
    let qtestReleasesValues = [];
    jsonData.forEach(item => {
      if (item.allowed_values && Array.isArray(item.allowed_values) && item.allowed_values.length > 0) {
        // Insert each allowed value
        item.allowed_values.forEach(val => {
          if (val.value != null && val.label != null) {
            qtestReleasesValues.push([
              item.id,
              item.attribute_type,
              item.label,
              val.value,
              val.label
            ]);
          }
        });
      } else {
        // If no allowed_values, still insert one row with nulls for value and label_value
        qtestReleasesValues.push([
          item.id,
          item.attribute_type,
          item.label,
          null,
          null
        ]);
      }
    });

    let releasesCount = 0;
    if (qtestReleasesValues.length > 0) {
      const [releaseResult] = await db.promise().query(
        `INSERT INTO qtest_testinstance_combo_values (id, attribute_type, label, value, label_value) VALUES ?`,
        [qtestReleasesValues]
      );
      releasesCount = releaseResult.affectedRows;
      console.log(`✅ Inserted ${releasesCount} rows into qtest_testinstance_combo_values table`);
    }

    return res.status(200).json({
      message: "✅ qTest data refreshed successfully",
      count: {
        qtest_testinstance_fields: dataResult.affectedRows,
        qtest_testinstance_combo_values: releasesCount,
      },
    });
  } catch (error) {
    console.error("❌ Error in refresh:", error.message);
    return res.status(500).json({ error: error.message });
  }
};


// ------------------------------
// Get All Data
// ------------------------------
const getqtestTestSetAllFields = async  (req, res) => {


   try {
    // Get all fields from qtest_data
    const [fields] = await db.promise().query("SELECT * FROM qtest_testinstance_fields");
    
    // For each field, get its allowed values from qtest_releases
    const fieldsWithValues = await Promise.all(fields.map(async (field) => {
      const [values] = await db.promise().query(
        "SELECT value, label_value FROM qtest_testinstance_combo_values WHERE id = ? AND value IS NOT NULL",
        [field.id]
      );
      return {
        ...field,
        allowed_values: values
      };
    }));

    res.json(fieldsWithValues);
  } catch (err) {
    console.error("❌ Error fetching data:", err);
    res.status(500).json({ error: err.message });
  }
};

// ------------------------------
// Get Releases Data
// ------------------------------
const getTestSetFields = (req, res) => {
  db.query("SELECT * FROM qtest_testinstance_combo_values", (err, results) => {
    if (err) {
      console.error("❌ Error fetching releases data:", err);
      return res.status(500).json({ error: err.message });
    }
    res.json(results);
  });
};

// ------------------------------
// Insert qtest_testinstance_fields via API
// ------------------------------
const insertqtestTestSetFields = (req, res) => {
  const testCases = req.body;

  if (!Array.isArray(testCases) || testCases.length === 0) {
    return res.status(400).json({ message: "Invalid input: expected an array of test cases." });
  }

  const values = testCases.map(item => [
    item.id || null,
    item.attribute_type || null,
    item.label || null
  ]);

  const sql = `
    INSERT INTO qtest_testinstance_fields (id, attribute_type, label)
    VALUES ?
  `;

  db.query(sql, [values], (err, result) => {
    if (err) {
      console.error("❌ Error inserting via API:", err);
      return res.status(500).json({ error: err.message });
    }
    res.status(201).json({ message: `${result.affectedRows} records added.` });
  });
};

// ------------------------------
// Insert qtest_testinstance_combo_values via API
// ------------------------------
const insertQtestTestSetComboValues = (req, res) => {
  const releaseData = req.body;

  if (!Array.isArray(releaseData) || releaseData.length === 0) {
    return res.status(400).json({ message: "Invalid input: expected an array of release data." });
  }

  const values = releaseData.map(item => [
    item.id || null,
    item.attribute_type || null,
    item.label || null,
    item.value || null,
    item.label_value || null
  ]);

  const sql = `
    INSERT INTO qtest_testinstance_combo_values (id, attribute_type, label, value, label_value)
    VALUES ?
  `;

  db.query(sql, [values], (err, result) => {
    if (err) {
      console.error("❌ Error inserting releases via API:", err);
      return res.status(500).json({ error: err.message });
    }
    res.status(201).json({ message: `${result.affectedRows} release records added.` });
  });
};

// ------------------------------
// Export Functions
// ------------------------------
module.exports = {
  qtestrequirementinit,
  createTableqtestTestSet,
  insertqtestTestSetFieldsFromJson ,
  getqtestTestSetAllFields,
  getTestSetFields,
  insertqtestTestSetFields,
  insertQtestTestSetComboValues ,
  refreshQTestTestSetFields
};
