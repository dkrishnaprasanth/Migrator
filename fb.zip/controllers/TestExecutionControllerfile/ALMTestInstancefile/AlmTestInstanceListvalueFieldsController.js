const db = require("../../../config/db");
const fs = require("fs");
const path = require("path");
const { fetchListTestInstanceFields } = require("../../../controllers/TestExecutionControllerfile/ALMTestInstancefile/AlmTestInstanceListValueFields");

const requiredFields = ["name", "id", "value"];

const getListTestSetFields = async (req, res) => {
  db.query("SELECT * FROM Alm_TestInstance_Lists", (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    const formattedResults = results.map(row => ({
      ...row,
      required: row.required === 1,
      supportsMultivalue: row.supportsMultivalue === 1
    }));

    res.json(formattedResults);
  });
};


const loadJsonAndRequirementValidate = async () => {
  const jsonFilePath = path.join(__dirname, "../../../data/TestExecutiondatafile/ALMTestInstancedata/AlmTestInstanceListFieldValues.json");

  try {
    if (!fs.existsSync(jsonFilePath)) {
      console.error("JSON file does not exist:", jsonFilePath);
      return [];
    }

    const rawData = fs.readFileSync(jsonFilePath, "utf-8");
    const parsedData = JSON.parse(rawData);

    console.log("Raw data from JSON:", parsedData); // Log raw data for debugging

    // Adjust the parsing logic to handle 'lists' and 'Items'
    const normalizedData = Array.isArray(parsedData.lists) ? parsedData.lists : [];

    // Process each list and flatten the structure for database insertion
    const result = [];
    
    normalizedData.forEach(listItem => {
      const listName = listItem.Name || null;
      const listId = listItem.Id || null;
      
      // For each item in the list, create a record with the list name, id and the item's value
      if (Array.isArray(listItem.Items)) {
        listItem.Items.forEach(item => {
          result.push({
            name: listName,
            id: listId,
            value: item.value || null
          });
        });
      }
    });

    console.log("Validated data:", result);  // Log validated data for debugging
    return result;

  } catch (err) {
    console.error("Error reading/parsing JSON file:", err.message);
    return [];
  }
};

const insertListTestSetDataJson = async () => {
  try {
    const jsonData = await loadJsonAndRequirementValidate();

    if (jsonData.length === 0) {
      console.log("No valid data to insert.");
      return;
    }

    console.log("Inserting data into 'Alm_TestInstance_Lists' table...");

    // Check if the table already has data
    return new Promise((resolve, reject) => {
      db.query("SELECT COUNT(*) AS count FROM Alm_TestInstance_Lists", (err, results) => {
        if (err) {
          console.error("Error checking existing data:", err.message);
          return reject(err);
        }

        if (results[0].count > 0) {
          console.log("Data already exists. Skipping insertion.");
          return resolve(false);
        }

        // Create an array to hold all insertion promises
        const insertPromises = [];

        // Process each flattened record
        jsonData.forEach(item => {
          // Create insert promise for this item
          const insertPromise = new Promise((resolve, reject) => {
            const sql = `INSERT INTO Alm_TestInstance_Lists (name, id, value) VALUES (?, ?, ?)`;
            const values = [item.name, item.id, item.value];
            
            console.log(`Inserting: name=${item.name}, id=${item.id}, value=${item.value}`);
            
            db.query(sql, values, (err, result) => {
              if (err) {
                console.error("Error inserting row:", err.message);
                return reject(err);
              }
              resolve(result);
            });
          });
          
          insertPromises.push(insertPromise);
        });

        // Wait for all insertions to complete
        Promise.all(insertPromises)
          .then(() => {
            console.log(`✅ Inserted ${jsonData.length} records successfully.`);
            resolve(true);
          })
          .catch(err => {
            console.error("Error in batch insertion:", err.message);
            reject(err);
          });
      });
    });
  } catch (err) {
    console.error("Failed to insert data:", err.message);
    throw err;
  }
};
  const initlistTestSet = async () => {
    try {
      console.log("Fetching ALM TestInstance fields...");
      await fetchListTestInstanceFields();
      console.log("✅ Fetch complete.");
  
      await createListTestSetTables();
      await insertListTestSetDataJson();
  
      console.log("✅ ALM initialization complete.");
    } catch (err) {
      console.error("Failed to initialize ALM data:", err.message);
      process.exit(1);
    }
  };
  
  const createListTestSetTables = async () => {
    return new Promise((resolve, reject) => {
       const dropreleasestQuery = `DROP TABLE IF EXISTS Alm_TestInstance_Lists`;
      const createRequirementTableQuery = `
      CREATE TABLE IF NOT EXISTS Alm_TestInstance_Lists (
        name VARCHAR(255),
        id INT,
        value VARCHAR(255)
      )
    `;
    
     db.query(dropreleasestQuery, (dropErr) => {
      if (dropErr) {
        console.error("Error dropping table:", dropErr.message);
        return reject(dropErr);
      }
  
      db.query(createRequirementTableQuery, (err) => {
        if (err) {
          console.error("❌ Error creating table:", err.message);
          return reject(err);
        }
        console.log("✅ Table 'Alm_TestInstance_Lists' created successfully.");
        resolve(true);
      });
    });
     });
  };

  const refreshTestSetListData = async (req, res) => {
    try {
      await fetchListTestInstanceFields();
      const jsonData = await loadJsonAndRequirementValidate();
  
      if (jsonData.length === 0) {
        return res.status(400).json({ error: "No valid data to insert" });
      }
  
      await new Promise((resolve, reject) => {
        db.query("DELETE FROM Alm_TestInstance_Lists", (err) => {
          if (err) {
            console.error("Error clearing table:", err.message);
            return reject(err);
          }
          console.log("✅ Table 'Alm_TestInstance_Lists' cleared.");
          resolve();
        });
      });
  
      const insertPromises = jsonData.map((item, index) => {
        const values = [item.name, item.id, item.value];
        console.log(`Inserting record ${index + 1}:`, values);  // Log each record to be inserted
  
        return new Promise((resolve, reject) => {
          const sql = `INSERT INTO Alm_TestInstance_Lists (name, id, value) VALUES (?, ?, ?)`;
  
          db.query(sql, values, (err, result) => {
            if (err) {
              console.error("Error inserting row:", err.message);
              return reject(err);
            }
            resolve(result);
          });
        });
      });
  
      await Promise.all(insertPromises);
  
      return res.status(200).json({ 
        message: "ALM List data refreshed successfully", 
        count: jsonData.length 
      });
    } catch (error) {
      console.error("Failed to refresh ALM List data:", error.message);
      return res.status(500).json({ error: error.message });
    }
  };

const getAllListTestSet = (req, res) => {
  db.query("SELECT * FROM Alm_TestInstance_Lists", (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    const formattedResults = results.map(row => ({
      ...row,
      required: row.required === 1,
      supportsMultivalue: row.supportsMultivalue === 1
    }));

    res.json(formattedResults);
  });
};

const createListTestSet = async (req, res) => {
  const testCases = req.body;

  if (!Array.isArray(testCases) || testCases.length === 0) {
    return res.status(400).json({ message: "Invalid input, expecting an array of test cases" });
  }

  const insertPromises = testCases.map((item, index) => {
    const values = [item.name || null, item.id || null, item.value || null];
    console.log(`Inserting new test case ${index + 1}:`, values);  // Log each record to be inserted

    return new Promise((resolve, reject) => {
      const sql = `INSERT INTO Alm_TestInstance_Lists (name, id, value) VALUES (?, ?, ?)`;

      db.query(sql, values, (err, result) => {
        if (err) {
          console.error("Error inserting row:", err.message);
          return reject(err);
        }
        resolve(result);
      });
    });
  });

  try {
    await Promise.all(insertPromises);
    res.status(201).json({ message: `${testCases.length} new test cases added.` });
  } catch (err) {
    console.error("Error inserting data:", err.message);
    return res.status(500).json({ error: err.message });
  }
};

module.exports = {
  initlistTestSet ,
  createListTestSetTables,
  insertListTestSetDataJson,
  getAllListTestSet,
  getListTestSetFields,
  createListTestSet,
  refreshTestSetListData
};


// const db = require("../../../config/db");
// const fs = require("fs");
// const path = require("path");
// const { fetchListTestInstanceFields } = require("../../../controllers/TestExecutionControllerfile/ALMTestInstancefile/AlmTestInstanceListValueFields");

// const requiredFields = ["name", "id", "value"];


// const getTypeCode = (type, supportsMultivalue) => {

//   let v_datatype = 1;
  
//   if (!type) return v_datatype;
  
//   if (type === 'Number') {
//     v_datatype = 7;
//   } else if (type === 'String') {
//     v_datatype = 1;
//   } else if (type === 'LookupList') {
//     if (supportsMultivalue) {
//       v_datatype = 17;
//     } else {
//       v_datatype = 3;
//     }
//   } else if (type === 'UsersList') {
//     v_datatype = 5;
//   } else if (type === 'Date') {
//     v_datatype = 4;
//   } else if (type === 'DateTime') {
//     v_datatype = 9;
//   } else if (type === 'Memo') {
//     v_datatype = 2;
//   }
  
//   // Return the determined data type code
//   return v_datatype;
// };

// const getListTestSetFields = async (req, res) => {
//   db.query("SELECT * FROM Alm_TestInstance_Lists", (err, results) => {
//     if (err) {
//       return res.status(500).json({ error: err.message });
//     }

//     const formattedResults = results.map(row => ({
//       ...row,
//       required: row.required === 1,
//       supportsMultivalue: row.supportsMultivalue === 1
//     }));

//     res.json(formattedResults);
//   });
// };


// const loadJsonAndRequirementValidate = async () => {
//   const jsonFilePath = path.join(__dirname, "../../../data/TestExecutiondatafile/ALMTestInstancedata/AlmTestInstanceListFieldValues.json");

//   try {
//     if (!fs.existsSync(jsonFilePath)) {
//       console.error("JSON file does not exist:", jsonFilePath);
//       return [];
//     }

//     const rawData = fs.readFileSync(jsonFilePath, "utf-8");
//     const parsedData = JSON.parse(rawData);

//     console.log("Raw data from JSON:", parsedData); // Log raw data for debugging

//     // Adjust the parsing logic to handle 'lists' and 'Items'
//     const normalizedData = Array.isArray(parsedData.lists) ? parsedData.lists : [];

//     // Process each list and flatten the structure for database insertion
//     const result = [];
    
//     normalizedData.forEach(listItem => {
//       const listName = listItem.Name || null;
//       const listId = listItem.Id || null;
      
//       // For each item in the list, create a record with the list name, id and the item's value
//       if (Array.isArray(listItem.Items)) {
//         listItem.Items.forEach(item => {
//           result.push({
//             name: listName,
//             id: listId,
//             value: item.value || null
//           });
//         });
//       }
//     });

//     console.log("Validated data:", result);  // Log validated data for debugging
//     return result;

//   } catch (err) {
//     console.error("Error reading/parsing JSON file:", err.message);
//     return [];
//   }
// };

// const getAlmFieldByPhysicalName = async (req, res) => {
//   const { physicalName } = req.params;

//   if (!physicalName) {
//     return res.status(400).json({ error: "Physical name is required" });
//   }

//   db.query(
//     "SELECT * FROM alm_testinstance_fields WHERE physicalName = ?",
//     [physicalName],
//     (err, results) => {
//       if (err) {
//         return res.status(500).json({ error: err.message });
//       }

//       if (results.length === 0) {
//         return res.status(404).json({ error: "Field not found" });
//       }

//       // Convert numeric 0/1 back to boolean true/false for display and add typeCode
//       const isRequired = results[0].required === 1;
//       const supportsMultivalue = results[0].supportsMultivalue === 1;

//       const formattedResult = {
//         ...results[0],
//         required: isRequired,
//         supportsMultivalue: supportsMultivalue,
//         typeCode: getTypeCode(results[0].type, supportsMultivalue)
//       };

//       res.json(formattedResult);
//     }
//   );
// };

// const createAlmJsonFile = async (req, res) => {
//   const { physicalName } = req.body;

//   if (!physicalName) {
//     return res.status(400).json({ error: "Physical name is required" });
//   }

//   try {
//     // Fetch field from alm_data table
//     const result = await new Promise((resolve, reject) => {
//       db.query(
//         "SELECT * FROM alm_data WHERE physicalName = ?",
//         [physicalName],
//         (err, results) => {
//           if (err) return reject(err);
//           if (!results.length) return reject(new Error("Field not found"));
//           resolve(results[0]);
//         }
//       );
//     });

//     const isRequired = result.required === 1;
//     const supportsMultivalue = result.supportsMultivalue === 1;

//     let jsonData;

//     if (result.type === "LookupList") {
//       if (!result.listId) {
//         throw new Error("Missing listId in alm_testinstance_fields for LookupList");
//       }

//       // Fetch values from listereleases table using listId
//       const listValues = await new Promise((resolve, reject) => {
//         db.query(
//           "SELECT value FROM Alm_TestInstance_Lists WHERE id = ?",
//           [result.listId],
//           (err, results) => {
//             if (err) return reject(err);
//             if (!results.length) return reject(new Error("No values found in listereleases table"));
//             resolve(results);
//           }
//         );
//       });

//       const allowedValues = listValues.map((item, index) => ({
//         label: item.value,
//         is_default: false,
//         is_active: true,
//       }));

//       jsonData = {
//         label: result.label,
//         allowed_values: allowedValues,
//         data_type: getTypeCode(result.type, supportsMultivalue),
//         multiple: supportsMultivalue,
//         is_active: true,
//       };
//     } else {
//       // Non-lookup field
//       jsonData = {
//         label: result.label,
//         data_type: getTypeCode(result.type, supportsMultivalue),
//         required: isRequired,
//         is_active: true,
//       };
//     }

//     // Create the directory structure if it doesn't exist
//     const dataDir = path.join(__dirname, "../../data");
//     if (!fs.existsSync(dataDir)) {
//       fs.mkdirSync(dataDir, { recursive: true });
//     }

//     // Create Releasesdatafile directory if it doesn't exist
//     const releasesDir = path.join(dataDir, "TestExecutiondatafile");
//     if (!fs.existsSync(releasesDir)) {
//       fs.mkdirSync(releasesDir, { recursive: true });
//     }

//     // Write to file - use the correct path mentioned in your error
//     const filePath = path.join(releasesDir, "ALMTestInstancedata/AlmTestInstance.json");
//     fs.writeFileSync(filePath, JSON.stringify(jsonData, null, 2), "utf-8");

//     console.log("✅ JSON file created:", filePath);

//     res.status(200).json({
//       message: "JSON file created successfully",
//       data: jsonData,
//       filePath,
//     });
//   } catch (error) {
//     console.error("❌ Error creating JSON file:", error.message);
//     res.status(error.message === "Field not found" ? 404 : 500).json({
//       error: error.message,
//     });
//   }
// };


// const insertListTestSetDataJson = async () => {
//   try {
//     const jsonData = await loadJsonAndRequirementValidate();

//     if (jsonData.length === 0) {
//       console.log("No valid data to insert.");
//       return;
//     }

//     console.log("Inserting data into 'Alm_TestInstance_Lists' table...");

//     // Check if the table already has data
//     return new Promise((resolve, reject) => {
//       db.query("SELECT COUNT(*) AS count FROM Alm_TestInstance_Lists", (err, results) => {
//         if (err) {
//           console.error("Error checking existing data:", err.message);
//           return reject(err);
//         }

//         if (results[0].count > 0) {
//           console.log("Data already exists. Skipping insertion.");
//           return resolve(false);
//         }

//         // Create an array to hold all insertion promises
//         const insertPromises = [];

//         // Process each flattened record
//         jsonData.forEach(item => {
//           // Create insert promise for this item
//           const insertPromise = new Promise((resolve, reject) => {
//             const sql = `INSERT INTO Alm_TestInstance_Lists (name, id, value) VALUES (?, ?, ?)`;
//             const values = [item.name, item.id, item.value];
            
//             console.log(`Inserting: name=${item.name}, id=${item.id}, value=${item.value}`);
            
//             db.query(sql, values, (err, result) => {
//               if (err) {
//                 console.error("Error inserting row:", err.message);
//                 return reject(err);
//               }
//               resolve(result);
//             });
//           });
          
//           insertPromises.push(insertPromise);
//         });

//         // Wait for all insertions to complete
//         Promise.all(insertPromises)
//           .then(() => {
//             console.log(`✅ Inserted ${jsonData.length} records successfully.`);
//             resolve(true);
//           })
//           .catch(err => {
//             console.error("Error in batch insertion:", err.message);
//             reject(err);
//           });
//       });
//     });
//   } catch (err) {
//     console.error("Failed to insert data:", err.message);
//     throw err;
//   }
// };
//   const initlistTestSet = async () => {
//     try {
//       console.log("Fetching ALM TestInstance fields...");
//       await fetchListTestInstanceFields();
//       console.log("✅ Fetch complete.");
  
//       await createListTestSetTables();
//       await insertListTestSetDataJson();
  
//       console.log("✅ ALM initialization complete.");
//     } catch (err) {
//       console.error("Failed to initialize ALM data:", err.message);
//       process.exit(1);
//     }
//   };
  
//   const createListTestSetTables = async () => {
//     return new Promise((resolve, reject) => {
//        const dropreleasestQuery = `DROP TABLE IF EXISTS Alm_TestInstance_Lists`;
//       const createRequirementTableQuery = `
//       CREATE TABLE IF NOT EXISTS Alm_TestInstance_Lists (
//         name VARCHAR(255),
//         id INT,
//         value VARCHAR(255)
//       )
//     `;
    
//      db.query(dropreleasestQuery, (dropErr) => {
//       if (dropErr) {
//         console.error("Error dropping table:", dropErr.message);
//         return reject(dropErr);
//       }
  
//       db.query(createRequirementTableQuery, (err) => {
//         if (err) {
//           console.error("❌ Error creating table:", err.message);
//           return reject(err);
//         }
//         console.log("✅ Table 'Alm_TestInstance_Lists' created successfully.");
//         resolve(true);
//       });
//     });
//      });
//   };

//   const refreshTestSetListData = async (req, res) => {
//     try {
//       await fetchListTestInstanceFields();
//       const jsonData = await loadJsonAndRequirementValidate();
  
//       if (jsonData.length === 0) {
//         return res.status(400).json({ error: "No valid data to insert" });
//       }
  
//       await new Promise((resolve, reject) => {
//         db.query("DELETE FROM Alm_TestInstance_Lists", (err) => {
//           if (err) {
//             console.error("Error clearing table:", err.message);
//             return reject(err);
//           }
//           console.log("✅ Table 'Alm_TestInstance_Lists' cleared.");
//           resolve();
//         });
//       });
  
//       const insertPromises = jsonData.map((item, index) => {
//         const values = [item.name, item.id, item.value];
//         console.log(`Inserting record ${index + 1}:`, values);  // Log each record to be inserted
  
//         return new Promise((resolve, reject) => {
//           const sql = `INSERT INTO Alm_TestInstance_Lists (name, id, value) VALUES (?, ?, ?)`;
  
//           db.query(sql, values, (err, result) => {
//             if (err) {
//               console.error("Error inserting row:", err.message);
//               return reject(err);
//             }
//             resolve(result);
//           });
//         });
//       });
  
//       await Promise.all(insertPromises);
  
//       return res.status(200).json({ 
//         message: "ALM List data refreshed successfully", 
//         count: jsonData.length 
//       });
//     } catch (error) {
//       console.error("Failed to refresh ALM List data:", error.message);
//       return res.status(500).json({ error: error.message });
//     }
//   };

// const getAllListTestSet = (req, res) => {
//   db.query("SELECT * FROM Alm_TestInstance_Lists", (err, results) => {
//     if (err) {
//       return res.status(500).json({ error: err.message });
//     }

//     const formattedResults = results.map(row => ({
//       ...row,
//       required: row.required === 1,
//       supportsMultivalue: row.supportsMultivalue === 1
//     }));

//     res.json(formattedResults);
//   });
// };

// const createListTestSet = async (req, res) => {
//   const testCases = req.body;

//   if (!Array.isArray(testCases) || testCases.length === 0) {
//     return res.status(400).json({ message: "Invalid input, expecting an array of test cases" });
//   }

//   const insertPromises = testCases.map((item, index) => {
//     const values = [item.name || null, item.id || null, item.value || null];
//     console.log(`Inserting new test case ${index + 1}:`, values);  // Log each record to be inserted

//     return new Promise((resolve, reject) => {
//       const sql = `INSERT INTO Alm_TestInstance_Lists (name, id, value) VALUES (?, ?, ?)`;

//       db.query(sql, values, (err, result) => {
//         if (err) {
//           console.error("Error inserting row:", err.message);
//           return reject(err);
//         }
//         resolve(result);
//       });
//     });
//   });

//   try {
//     await Promise.all(insertPromises);
//     res.status(201).json({ message: `${testCases.length} new test cases added.` });
//   } catch (err) {
//     console.error("Error inserting data:", err.message);
//     return res.status(500).json({ error: err.message });
//   }
// };

// const uploadAlmJsonFile = async (req, res) => {
//   try {
//     const credentialsPath = path.join(__dirname, "../../../data/qTestCredentials.json");
//     const credentialsData = fs.readFileSync(credentialsPath, "utf-8");
//     const config = JSON.parse(credentialsData);

//     const qTestDomain = config.qTestDomain;
//     const apiToken = config.apiToken;
//     const projectId = config.projectId;

//     // Update the path to match the path in createAlmJsonFile
//     const payloadPath = path.join(__dirname, "../../../data/TestExecutiondatafile/ALMTestInstancedata/AlmTestInstance.json");
    
//     // Check if file exists
//     if (!fs.existsSync(payloadPath)) {
//       return res.status(404).json({
//         error: "ALMListReleases.json file not found. Please create it first using the create-alm-field endpoint."
//       });
//     }
    
//     const payload = JSON.parse(fs.readFileSync(payloadPath, "utf-8"));

//     const response = await axios.post(
//       `${qTestDomain}/api/v3/projects/${projectId}/settings/releases/fields`,
//       payload,
//       {
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${apiToken}`,
//         },
//       }
//     );

//     console.log("✅ Uploaded to qTest");
//     res.status(200).json({
//       message: "Uploaded to qTest successfully",
//       statusCode: response.status,
//       data: response.data,
//     });
//   } catch (error) {
//     console.error("❌ Upload error:", error.message);
//     res.status(500).json({
//       error: error.message,
//     });
//   }
// };

// module.exports = {
//   initlistTestSet ,
//   createListTestSetTables,
//   insertListTestSetDataJson,
//   getAllListTestSet,
//   getListTestSetFields,
//   createListTestSet,
//   refreshTestSetListData
// };






