

const fs = require("fs");
const axios = require("axios");
const util = require("util");
const path = require("path");
const db = require("../../../config/db");
const query = util.promisify(db.query).bind(db);

// Load qTest credentials
const qtestCreds = JSON.parse(
  fs.readFileSync(path.join(__dirname, "../../../data/qtestCredentials.json"), "utf-8")
);
const { qTestDomain, apiToken, projectId } = qtestCreds;
const headers = {
  Authorization: `Bearer ${apiToken}`,
  "Content-Type": "application/json",
};

const cleanText = (str) =>
  (str || "")
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ")
    .replace(/[^\x20-\x7E]/g, "")
    .replace(/\s+/g, " ")
    .trim();

const fetchAlmMigratetestlogandsteps = async () => {
  try {
    console.log("✅ Connected to MySQL");

    const runIdRows = await query("SELECT DISTINCT run_id FROM testlogsteps where qtest_testlogstep_id is null");
    if (!Array.isArray(runIdRows)) throw new Error("runIdRows is not iterable");

    for (const { run_id } of runIdRows) {
      console.log(`\n▶ Processing run_id: ${run_id}`);

      const stepRows = await query("SELECT * FROM testlogsteps WHERE run_id = ?", [run_id]);
      if (!Array.isArray(stepRows) || stepRows.length === 0) {
        console.warn(`⚠️ No step rows found for run_id ${run_id}`);
        continue;
      }

      const test_id = stepRows[0].test_id;
      const testRowRes = await query("SELECT qtest_testcase_id FROM tests WHERE id = ?", [test_id]);
      const testRow = testRowRes?.[0];

      if (!testRow || !testRow.qtest_testcase_id) {
        console.warn(`⚠️ No qTest Test Case ID found for test_id ${test_id}`);
        continue;
      }

      const qtest_testcase_id = testRow.qtest_testcase_id;

      const reusedSteps = await query(
        "SELECT qtest_testcasestep_id FROM testlogsteps WHERE run_id != ? AND test_id = ? AND qtest_testcasestep_id IS NOT NULL LIMIT 1",
        [run_id, test_id]
      );

      if (reusedSteps.length > 0) {
        console.log(`♻️ Reused test_id detected. Cleaning existing steps from qTest test case ID: ${qtest_testcase_id}`);
        let deleteCount = 0;
        while (true) {
          try {
            const stepFetchRes = await axios.get(
              `${qTestDomain}/api/v3/projects/${projectId}/test-cases/${qtest_testcase_id}/test-steps`,
              { headers }
            );
            const currentSteps = stepFetchRes.data;
            if (!Array.isArray(currentSteps) || currentSteps.length === 0) {
              console.log("✅ All steps deleted from test case.");
              break;
            }

            const stepToDelete = currentSteps[0];
            const stepId = stepToDelete.id;

            await axios.delete(
              `${qTestDomain}/api/v3/projects/${projectId}/test-cases/${qtest_testcase_id}/test-steps/${stepId}`,
              { headers }
            );

            console.log(`🗑 Deleted step ID ${stepId}`);
            deleteCount++;
          } catch (delErr) {
            console.error("❌ Error deleting step:", delErr.response?.data || delErr.message);
            break;
          }
        }
        console.log(`🔁 Total deleted steps: ${deleteCount}`);
      }

      const uploadedStepIds = [];
      for (const step of stepRows) {
        const stepPayload = {
          description: cleanText(step.description),
          expected: cleanText(step.expected),
        };

        console.log("📤 Uploading single step to:", `${qTestDomain}/api/v3/projects/${projectId}/test-cases/${qtest_testcase_id}/test-steps`);
        console.log("📦 Payload:", JSON.stringify(stepPayload, null, 2));

        try {
          const response = await axios.post(
            `${qTestDomain}/api/v3/projects/${projectId}/test-cases/${qtest_testcase_id}/test-steps`,
            stepPayload,
            { headers }
          );

          const stepId = response.data?.id;
          uploadedStepIds.push(stepId);
          await query("UPDATE testlogsteps SET qtest_testcasestep_id = ? WHERE id = ?", [stepId, step.id]);
        } catch (stepErr) {
          console.error("❌ Error uploading step:", stepErr.response?.data || stepErr.message);
          continue;
        }
      }

      await axios.put(`${qTestDomain}/api/v3/projects/${projectId}/test-cases/${qtest_testcase_id}/approve`, {}, { headers });
      console.log("✅ Test case approved:", qtest_testcase_id);

      const logRowRes = await query("SELECT * FROM testlogs WHERE id = ?", [run_id]);
      const logRow = logRowRes?.[0];

      if (!logRow) {
        console.warn(`⚠️ No testlog found for run_id: ${run_id}`);
        continue;
      }

      const instRowRes = await query("SELECT qtest_testinstance_id FROM testinstance WHERE id = ?", [logRow.testcycl_id]);
      const instRow = instRowRes?.[0];

      if (!instRow || !instRow.qtest_testinstance_id) {
        console.warn(`⚠️ No test instance found for testcycl_id: ${logRow.testcycl_id}`);
        continue;
      }

      const statusMap = {
        passed: { id: 601, name: "Passed" },
        failed: { id: 602, name: "Failed" },
        "not completed": { id: 603, name: "InComplete" },
        blocked: { id: 604, name: "Blocked" },
        "no run": { id: 605, name: "Unexecuted" },
      };

      const statusMapstep = {
        passed: { id: 601, name: "Passed" },
        failed: { id: 602, name: "Failed" },
        notcompleted: { id: 603, name: "InComplete" },
        blocked: { id: 604, name: "Blocked" },
      };

      const exeDateStr = logRow.execution_date.toISOString().split("T")[0];
      const startDate = new Date(`${exeDateStr}T${logRow.execution_time}`);
      const endDate = new Date(startDate.getTime() + (logRow.duration || 0) * 1000);
      const statusObj = statusMap[(logRow.status || "").toLowerCase()] || statusMap["not completed"];

      const updatedStepRows = await query("SELECT * FROM testlogsteps WHERE run_id = ?", [run_id]);

      const test_step_logs = updatedStepRows.map((row) => {
        const stepStatus = (row.status || "").toLowerCase().trim();
        return {
          test_step_id: row.qtest_testcasestep_id,
          status: statusMapstep[stepStatus] || { id: 603, name: "Incomplete" },
          actual_result: row.actual || "",
        };
      });

      const testLogPayload = {
        exe_start_date: startDate.toISOString(),
        exe_end_date: endDate.toISOString(),
        status: statusObj,
        test_step_logs,
      };

      console.log("📦 Test Log Payload:", JSON.stringify(testLogPayload, null, 2));
      console.log("📤 Uploading testlogs to:", `${qTestDomain}/api/v3/projects/${projectId}/test-runs/${instRow.qtest_testinstance_id}/test-logs`);

      try {
        const logRes = await axios.post(
          `${qTestDomain}/api/v3/projects/${projectId}/test-runs/${instRow.qtest_testinstance_id}/test-logs`,
          testLogPayload,
          { headers }
        );

        const logId = logRes.data?.id;
        const stepLogIds = logRes.data?.test_step_logs || [];

        await query("UPDATE testlogs SET qtest_testlog_id = ?, upload_status = 'completed' WHERE id = ?", [logId, run_id]);

        for (const log of stepLogIds) {
          const matchingRow = updatedStepRows.find((row) => row.qtest_testcasestep_id === log.test_step_id);
          if (matchingRow) {
            await query("UPDATE testlogsteps SET qtest_testlogstep_id = ? WHERE id = ?", [
              log.test_step_log_id,
              matchingRow.id,
            ]);
          } else {
            console.warn(`⚠️ No match found for test_step_id ${log.test_step_id}`);
          }
        }

        console.log("✅ Test log completed and DB updated.");
      } catch (logErr) {
        console.error("❌ Error uploading test log:", logErr.response?.data || logErr.message);

        await query(
          "UPDATE testlogs SET upload_status = 'failed' WHERE id = ?",
          [run_id]
        );

      }
    }
  } catch (err) {
    console.error("❌ Error during migration:", err.message);
  }
};


module.exports = { fetchAlmMigratetestlogandsteps };

//fetchAlmMigratetestlogandsteps(); // Automatically invoke the function to fetch data