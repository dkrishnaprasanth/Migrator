
 
 
const { fetchAlmtestlog } = require('./ALMTestLog');
const { fetchAlmtestrunstepsfromalm} = require('./ALMtestrunstepsfromALM');
const { fetchalmtestruntoDB } = require('./ALMtestruntoDB');
const { fetchAlmtestrunstepstoDB } = require('./ALMtestrunstepstoDB');
const { fetchAlmMigratetestlogandsteps } = require('./ALMtetestlogandsteps');
 
// ✅ Import DB connection
const db = require('../../../config/db'); 

const insertrunAlmTestLog = async (req, res) => {
  try {
    console.log("📥 get testlogs.");
    await fetchAlmtestlog();
 
    console.log("💾 testlog to db");
    await fetchalmtestruntoDB();
 
    console.log("🧹 get testlog steps");
    await fetchAlmtestrunstepsfromalm();
 
    console.log("🗑️ testlogstep to db");
   const insertResult =  await fetchAlmtestrunstepstoDB();
 
   // ✅ Count total logs from DB
    const [countResult] = await db.promise().query(
      "SELECT COUNT(*) AS totalCount FROM testlogs"   
    );
    const totalCount = countResult[0].totalCount;

    console.log("✅🚀 log progress finished");
    res.status(200).json({
      success: true,
      message: 'Logs uploaded successfully.',
      stats: {
        inserted: insertResult?.affectedRows || 0,
        totalCount
      }
    });

  } catch (error) {
    console.error("❌ log mig failed:", error);
    res.status(500).json({ error: 'error in mig', details: error.message });
  }
};
 
 
const uploadrunAlmTestLog = async (req, res) => {
  try {
 
    console.log("📤 Uploading testlogs");
    await fetchAlmMigratetestlogandsteps(); // Ensure this is awaited!
 
    console.log("✅🚀 log progress finished");
    res.status(200).json({ message: 'logs upload successfully.' });
  } catch (error) {
    console.error("❌ log mig failed:", error);
    res.status(500).json({ error: 'error in mig', details: error.message });
  }
};
 
const getTestLogCount = async (req, res) => {
  try {
    const [[{ count: total }]] = await db.promise().query(`
      SELECT COUNT(*) as count FROM Testlogs
    `);
    res.status(200).json({ total });
  } catch (error) {
    console.error('❌ Error fetching test log count:', error);
    res.status(500).json({ error: 'Failed to fetch test log count', details: error.message });
  }
};

module.exports = {insertrunAlmTestLog ,  uploadrunAlmTestLog, fetchAlmtestlog, getTestLogCount};
 
 
 