

const fs = require('fs');
const path = require('path');
const db = require('../../../config/db');
const util = require('util');

const query = util.promisify(db.query).bind(db);
const jsonPath = path.join(__dirname, '../../../data/TestExecutiondatafile/ALMTestLog/ALMTestRuns.json');

const fetchalmtestruntoDB = async () => {
  try {
    // ✅ Move file read into the function
    const fileContent = fs.readFileSync(jsonPath, 'utf8');
    if (!fileContent || fileContent.trim() === '') {
      console.warn('⚠️ ALMTestRuns.json is empty. Skipping DB insert.');
      return;
    }

    const rawData = JSON.parse(fileContent);
    if (!rawData.entities || !Array.isArray(rawData.entities)) {
      console.warn('⚠️ Invalid or missing "entities" array in ALMTestRuns.json.');
      return;
    }

    const entities = rawData.entities;

    // console.log("📂 Dropping existing TestLogs table if exists...");
    // await query(`DROP TABLE IF EXISTS TestLogs`);

    console.log("📦 Creating new TestLogs table...");
    const createTableSQL = `
      CREATE TABLE IF NOT EXISTS TestLogs (
        id INT,
        test_id INT,
        test_instance_id INT,
        testcycl_id INT,
        cycle_id INT,
        name TEXT,
        test_name TEXT,
        testcycl_name TEXT,
        attachment TEXT,
        execution_time VARCHAR(20),
        duration INT,
        execution_date DATE,
        last_modified TIMESTAMP,
        status TEXT,
        qtest_testlog_id INT,
        attach_status VARCHAR(20),
        upload_status TEXT
      )
    `;
    await query(createTableSQL);

    const insertSQL = `
      INSERT INTO TestLogs (
        id, test_id, cycle_id, name, test_name, testcycl_name,
        attachment, status, test_instance_id, testcycl_id,
        execution_time, duration, execution_date,last_modified
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)
    `;

    console.log(`📥 Inserting ${entities.length} test logs...`);

    for (const entity of entities) {
      const fields = entity.Fields;
      if (!Array.isArray(fields)) continue;

      const id = getFieldValue(fields, "id");
      const testId = getFieldValue(fields, "test-id");
      const cycleId = getFieldValue(fields, "cycle-id");
      const name = getFieldValue(fields, "name");
      const testName = getFieldValue(fields, "test-name");
      const testCyclName = getFieldValue(fields, "testcycl-name");
      const attachment = getFieldValue(fields, "attachment");
      const status = getFieldValue(fields, "status");
      const testInstanceId = getFieldValue(fields, "test-instance");
      const testCyclId = getFieldValue(fields, "testcycl-id");
      const executionTime = getFieldValue(fields, "execution-time");
      const duration = getFieldValue(fields, "duration");
      const executionDate = getFieldValue(fields, "execution-date");
      const last = getFieldValue(fields, "last-modified");

      const existing = await query(`SELECT id FROM TestLogs WHERE id = ?`, [parseIntSafe(id)]);
if (existing && existing.length > 0) {
 console.log(`⏭️ Skipping TestLog with ID ${id} (already exists)`);
        continue; // Skip this row
      }


      await query(insertSQL, [
        parseIntSafe(id),
        parseNullableInt(testId),
        parseNullableInt(cycleId),
        name,
        testName,
        testCyclName,
        attachment,
        status,
        parseNullableInt(testInstanceId),
        parseNullableInt(testCyclId),
        executionTime,
        parseNullableInt(duration),
        executionDate,
        last
      ]);
    }

    console.log("✅ All TestRuns processed and inserted into DB.");
  } catch (err) {
    console.error("❌ Error inserting TestRuns into DB:", err);
  }
};

// Helper functions
function getFieldValue(fields, name) {
  for (const field of fields) {
    if (field.Name === name && Array.isArray(field.values) && field.values.length > 0) {
      const value = field.values[0];
      if (value && value.value !== undefined) {
        return value.value;
      }
    }
  }
  return null;
}

function parseNullableInt(val) {
  if (val === null || val === undefined || val === "") return null;
  const num = parseInt(val);
  return isNaN(num) ? null : num;
}

function parseIntSafe(val) {
  const num = parseInt(val);
  return isNaN(num) ? 0 : num;
}

module.exports = { fetchalmtestruntoDB };