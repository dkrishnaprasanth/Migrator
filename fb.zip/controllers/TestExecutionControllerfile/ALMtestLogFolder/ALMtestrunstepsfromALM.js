const fs = require('fs');
const path = require('path');
const axios = require('axios');
const db = require("../../../config/db"); // Already connected db

const almConfigPath = path.join(__dirname, '../../../data/AlmCredentials.json');
const almConfig = JSON.parse(fs.readFileSync(almConfigPath, 'utf8'));

const {
  almServerUrl,
  username,
  password,
  domain,
  project
} = almConfig;

const loginUrl = `${almServerUrl}/api/authentication/sign-in`;

const fetchAlmtestrunstepsfromalm = async () => {
  try {
    // Step 1: Fetch run IDs from DB
    const runIds = await getAllRunIdsFromDatabase();
    if (runIds.length === 0) {
      console.log('No run IDs found in database.');
      return;
    }

    // Step 2: Authenticate with ALM
    const authResponse = await axios.post(loginUrl, {}, {
      headers: {
        'Authorization': 'Basic ' + Buffer.from(`${username}:${password}`).toString('base64')
      },
      withCredentials: true
    });

    const cookies = extractCookies(authResponse.headers['set-cookie'] || []);
    const cookieHeader = buildCookieHeader(cookies);

    if (!cookieHeader) {
      console.log("Authentication failed. Missing cookies.");
      return;
    }

    const allRunStepsArray = [];

    // Step 3: Fetch run steps for each runId
    for (const runId of runIds) {
      const runStepsUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/runs/${runId}/run-steps`;

      try {
        const response = await axios.get(runStepsUrl, {
          headers: {
            'Cookie': cookieHeader,
            'Accept': 'application/json'
          }
        });

        const wrapped = {
          run_id: runId,
          run_steps: response.data
        };

        allRunStepsArray.push(wrapped);
        console.log(`Fetched run steps for ID: ${runId}`);
      } catch (err) {
        console.log(`Failed to fetch run steps for ID ${runId}. Error: ${err.message}`);
      }
    }

    // Step 4: Save all run steps to file
const outputPath = path.join(__dirname, '../../../data/TestExecutiondatafile/ALMTestLog/ALMTestRunSteps.json');

    // Ensure directory exists
    const outputDir = path.dirname(outputPath);
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }

    if (allRunStepsArray.length > 0) {
      try {
        fs.writeFileSync(outputPath, JSON.stringify(allRunStepsArray, null, 2));
        console.log("✅ All run steps saved to file:", outputPath);
      } catch (writeErr) {
        console.error("❌ Failed to write file:", writeErr.message);
      }
    } else {
      console.log("⚠️ No run step data to save.");
    }
  } catch (err) {
    console.error('❌ Error:', err);
  }
};

// ✅ Use existing connected `db` instance
async function getAllRunIdsFromDatabase() {
  return new Promise((resolve, reject) => {
    db.query('SELECT id FROM testlogs', (err, rows) => {
      if (err) {
        console.error('DB error:', err.message);
        return resolve([]);
      }
      const ids = rows.map(row => row.id);
      resolve(ids);
    });
  });
}

// ✅ Cookie extraction helper
function extractCookies(setCookiesArray) {
  const cookies = {};
  setCookiesArray.forEach(cookieStr => {
    const [cookiePair] = cookieStr.split(';');
    const [name, value] = cookiePair.split('=');
    cookies[name.trim()] = value.trim();
  });
  return cookies;
}

// ✅ Build cookie string for ALM requests
function buildCookieHeader(cookies) {
  const keys = ['XSRF-TOKEN', 'JSESSIONID', 'LWSSO_COOKIE_KEY', 'ALM_USER', 'QCSession'];
  if (keys.every(k => cookies[k])) {
    return keys.map(k => `${k}=${cookies[k]}`).join('; ');
  }
  return null;
}

module.exports = { fetchAlmtestrunstepsfromalm };

 // Automatically invoke the function to fetch data
