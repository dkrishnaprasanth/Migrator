const fs = require('fs');
const path = require('path');
const db = require('../../../config/db');
const util = require('util');
 
const query = util.promisify(db.query).bind(db);
const jsonPath = path.join(__dirname, '../../../data/TestExecutiondatafile/ALMTestLog/ALMTestRunSteps.json');
 
const fetchAlmtestrunstepstoDB = async () => {
  try {
    const fileContent = fs.readFileSync(jsonPath, 'utf8');
    if (!fileContent || fileContent.trim() === '') {
      console.warn("⚠️ ALMTestRunSteps.json is empty. Skipping step insertion.");
      return;
    }
 
    const jsonData = JSON.parse(fileContent);
    if (!Array.isArray(jsonData)) {
      console.warn("⚠️ ALMTestRunSteps.json must be an array. Skipping step insertion.");
      return;
    }
 
    const createTableSQL = `
      CREATE TABLE IF NOT EXISTS TestLogSteps (
        id INT PRIMARY KEY,
        run_id INT,
        parent_Id INT,
        testreal_id INT,
        desstep_id INT,
        description TEXT,
        expected TEXT,
        actual TEXT,
        status VARCHAR(50),
        step_order INT,
        execution_date VARCHAR(20),
        execution_time VARCHAR(20),
        execution_user VARCHAR(100),
        name VARCHAR(100),
        defect_link VARCHAR(255),
        attachment VARCHAR(5),
        qtest_testcasestep_id INT,
        qtest_testlogstep_id INT,
        attach_status VARCHAR(20),
        test_id INT
      )
    `;
    await query(createTableSQL);
 
    const insertSQL = `
      INSERT INTO TestLogSteps (
        id, parent_Id, testreal_id, description, expected, actual,
        status, step_order, execution_date, execution_time,
        execution_user, name, desstep_id, attachment, run_id,
        defect_link, test_id
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
 
    for (const runObj of jsonData) {
      const runId = parseNullableInt(runObj.run_id);
      const entities = runObj.run_steps?.entities;
      if (!Array.isArray(entities)) continue;
 
      for (const entity of entities) {
        const fields = entity.Fields;
        if (!Array.isArray(fields)) continue;
 
        const id = parseIntSafe(getFieldValue(fields, "id"));
        const parentId = parseNullableInt(getFieldValue(fields, "parent-id"));
        const testRealId = parseNullableInt(getFieldValue(fields, "test-id"));
        const description = cleanHtmlEntities(getFieldValue(fields, "description"));
        const expected = cleanHtmlEntities(getFieldValue(fields, "expected"));
        const actual = getFieldValue(fields, "actual");
        const status = getFieldValue(fields, "status");
        const stepOrder = parseNullableInt(getFieldValue(fields, "step-order"));
        const execDate = getFieldValue(fields, "execution-date");
        const execTime = getFieldValue(fields, "execution-time");
        const execUser = getFieldValue(fields, "execution-user");
        const name = getFieldValue(fields, "name");
        const desstepId = parseNullableInt(getFieldValue(fields, "desstep-id"));
        const attachment = getFieldValue(fields, "attachment");
        const defectLink = getFieldValue(fields, "has-linkage");
 
        // Check if already exists
        const existingStep = await query(`SELECT id FROM TestLogSteps WHERE id = ?`, [id]);
        if (existingStep && existingStep.length > 0) {
          console.log(`⏭️ Skipping TestLogStep with ID ${id} (already exists)`);
          continue;
        }
 
        // ✅ Fetch test_id from testlogs table using run_id
        let testId = null;
        if (runId) {
          const testIdResult = await query(`SELECT test_id FROM testlogs WHERE id = ? LIMIT 1`, [runId]);
          testId = testIdResult?.[0]?.test_id ?? null;
        }
 
        // Insert into TestLogSteps
        await query(insertSQL, [
          id,
          parentId,
          testRealId,
          description,
          expected,
          actual,
          status,
          stepOrder,
          execDate,
          execTime,
          execUser,
          name,
          desstepId,
          attachment,
          runId,
          defectLink,
          testId
        ]);
      }
    }
 
    console.log("✅ All TestRun steps inserted into DB with test_id populated.");
 
  } catch (err) {
    console.error("❌ Error inserting TestRun steps into DB:", err);
  }
};
 
// Helpers
function getFieldValue(fields, name) {
  for (const field of fields) {
    if (field.Name === name && Array.isArray(field.values) && field.values.length > 0) {
      const valueObj = field.values[0];
      if (valueObj && valueObj.value !== undefined) {
        return valueObj.value;
      }
    }
  }
  return null;
}
 
function parseNullableInt(val) {
  if (val === null || val === undefined || val === "") return null;
  const num = parseInt(val);
  return isNaN(num) ? null : num;
}
 
function parseIntSafe(val) {
  const num = parseInt(val);
  return isNaN(num) ? 0 : num;
}
 
function cleanHtmlEntities(text) {
  if (typeof text !== 'string') return text;
  return text.replace(/&lt;/g, '').replace(/&gt;/g, '');
}
 
module.exports = { fetchAlmtestrunstepstoDB };