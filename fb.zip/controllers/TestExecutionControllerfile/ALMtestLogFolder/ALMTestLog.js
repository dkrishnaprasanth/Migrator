


////------------------------------------------------------



 
 
 
const axios = require('axios');
const fs = require('fs');
const path = require('path');
 
const CONFIG_PATH = path.join(__dirname, '../../../data/AlmCredentials.json');
 const OUTPUT_PATH = path.join(__dirname, '../../../data/TestExecutiondatafile/ALMTestLog/ALMTestRuns.json');
 
const loadConfigFromFile = (filePath) => {
    const rawData = fs.readFileSync(filePath);
    return JSON.parse(rawData);
};
 
const parseCookies = (cookieArray) => {
    const cookieMap = {};
    cookieArray.forEach(cookie => {
        const [cookiePair] = cookie.split(';');
        const [name, value] = cookiePair.split('=');
        cookieMap[name.trim()] = value;
    });
    return cookieMap;
};
 
const buildCookieHeader = ({ xsrfToken, sessionCookie, lwssoCookie, almUser, qcSession }) => {
    return `XSRF-TOKEN=${xsrfToken}; JSESSIONID=${sessionCookie}; LWSSO_COOKIE_KEY=${lwssoCookie}; ALM_USER=${almUser}; QCSession=${qcSession}`;
};


const fetchAlmtestlog = async (customReleaseUrl = '') => {
    try {
        const config = loadConfigFromFile(CONFIG_PATH);
        const { almServerUrl, username, password, domain, project } = config;
 
        const loginUrl = `${almServerUrl}/api/authentication/sign-in`;
        const baseUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/runs`;
 
        const targetUrl = customReleaseUrl && customReleaseUrl.trim().length > 0
            ? `${baseUrl}${customReleaseUrl}`
            : baseUrl;
 
        const useAmpersand = customReleaseUrl && customReleaseUrl.trim().length > 0;
        const queryPrefix = useAmpersand ? '&' : '?';
 
        const authHeader = 'Basic ' + Buffer.from(`${username}:${password}`).toString('base64');
 
        const loginResponse = await axios.post(loginUrl, {}, {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': authHeader
            },
            withCredentials: true
        });
 
        const cookies = loginResponse.headers['set-cookie'] || [];
        const cookieMap = parseCookies(cookies);
 
        const {
            'XSRF-TOKEN': xsrfToken,
            'JSESSIONID': sessionCookie,
            'LWSSO_COOKIE_KEY': lwssoCookie,
            'ALM_USER': almUser,
            'QCSession': qcSession
        } = cookieMap;
 
        const cookieHeader = buildCookieHeader({ xsrfToken, sessionCookie, lwssoCookie, almUser, qcSession });
 
        if (!xsrfToken || !sessionCookie) {
            console.error("❌ Missing authentication tokens from ALM.");
            return;
        }
 
        const pageSize = 100;
        let startIndex = 1;
        let allEntities = [];
 
        while (true) {
            const pagedUrl = `${targetUrl}${queryPrefix}start-index=${startIndex}&page-size=${pageSize}`;
            const response = await axios.get(pagedUrl, {
                headers: {
                    'Accept': 'application/json',
                    'Cookie': cookieHeader
                }
            });
 
            const currentEntities = response.data.entities || [];
 
            if (currentEntities.length === 0) break;
 
            allEntities = allEntities.concat(currentEntities);
            console.log(`📥 Fetched ${currentEntities.length} logs (total so far: ${allEntities.length})`);
 
            if (currentEntities.length < pageSize) break; // No more pages
 
            startIndex += pageSize;
        }
 
        const finalData = { entities: allEntities };
        fs.writeFileSync(OUTPUT_PATH, JSON.stringify(finalData, null, 2), 'utf8');
        console.log(`✅ All ALM logss saved to ${OUTPUT_PATH}. Total records: ${allEntities.length}`);
    } catch (error) {
        console.error("❌ Failed to fetch ALM logs:", error.message);
        if (error.response) {
            console.error("Status:", error.response.status);
            console.error("Response:", error.response.data);
        }
        throw error;
    }
};
 
module.exports = {
    fetchAlmtestlog
 };
 
 
 
 
 
 
 
 
 
 
 
 
 