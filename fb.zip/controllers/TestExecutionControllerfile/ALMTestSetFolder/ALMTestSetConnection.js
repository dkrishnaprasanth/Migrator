// const { fetchAlmTestSetFolder} = require('../../TestExecutionControllerfile/ALMTestSetFolder/ALMTestSetFolder');
// const { fetchAlmtestsetToDB } = require('../../../controllers/TestExecutionControllerfile/ALMTestSetFolder/TestSetFolderToDB');
// const { fetchqTestTestCycle } = require('../../TestExecutionControllerfile/ALMTestSetFolder/qTestTestCycle');

// const runAlmTestSetup = async (req, res) => {
//     try {
//         console.log("📥 Fetching ALM testsetfolder...");
//         await fetchAlmTestSetFolder();

//         console.log("Saving testsetfolder to database...");
//         await fetchAlmtestsetToDB ();

//         console.log(" Fetching qtesttestsetfolder...");
//         await fetchqTestTestCycle();

//         console.log("✅🚀 Database and ALM setup completed successfully.");
//         res.status(200).json({ message: 'ALM Setup completed successfully.' });
//     } catch (error) {
//         console.error("❌ Setup failed:", error);
//         res.status(500).json({ error: 'ALM Setup failed', details: error.message });
//     }
// };

// module.exports = { runAlmTestSetup };





const { fetchAlmTestSetFolder} = require('../../TestExecutionControllerfile/ALMTestSetFolder/ALMTestSetFolder');
const { fetchAlmtestsetToDB } = require('../../../controllers/TestExecutionControllerfile/ALMTestSetFolder/TestSetFolderToDB');
const { fetchqTestTestCycle } = require('../../TestExecutionControllerfile/ALMTestSetFolder/qTestTestCycle');
const db = require('../../../config/db');

const insertTestSetupToDB = async (req, res) => {
    try {
        console.log("📥 Fetching ALM testsetfolder...");
        await fetchAlmTestSetFolder();
 
        console.log("Saving testsetfolder to database...");
        await fetchAlmtestsetToDB ();
 
        console.log("✅🚀 Database and ALM setup completed successfully.");
        res.status(200).json({ message: 'ALM Setup completed successfully.' });
    } catch (error) {
        console.error("❌ Setup failed:", error);
        res.status(500).json({ error: 'ALM Setup failed', details: error.message });
    }
};
 
const uploadTestSetupToDB  = async (req, res) => {
    try {
 
        console.log(" Fetching qtesttestsetfolder...");
        await fetchqTestTestCycle();
 
        console.log("✅🚀 Database and ALM setup completed successfully.");
        res.status(200).json({ message: 'ALM Setup completed successfully.' });
    } catch (error) {
        console.error("❌ Setup failed:", error);
        res.status(500).json({ error: 'ALM Setup failed', details: error.message });
    }
};
 
 
const getTestSetFolderCount = async (req, res) => {
  try {
    const [[{ count: total }]] = await db.promise().query(`
      SELECT COUNT(*) as count FROM TestSetFolder
    `);
    res.status(200).json({ total });
  } catch (error) {
    console.error('❌ Error fetching test set folder count:', error);
    res.status(500).json({ error: 'Failed to fetch test set folder count', details: error.message });
  }
};
module.exports = { insertTestSetupToDB , uploadTestSetupToDB, getTestSetFolderCount};
 
 