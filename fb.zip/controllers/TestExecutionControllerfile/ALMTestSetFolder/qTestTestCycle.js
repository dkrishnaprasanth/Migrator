



// const fs = require('fs');
// const path = require('path');
// const db = require("../../../config/db");
// const axios = require('axios');

// let QTEST_TOKEN, PROJECT_ID, BASE_URL, base_domain;

// const fetchqTestTestCycle = async () => {
//   try {
//     loadQTestConfig(path.join(__dirname, '../../../data/qTestCredentials.json'));
//     BASE_URL = `${base_domain}/api/v3/projects/${PROJECT_ID}/test-cycles`;

//     // Fetch rows that are not yet uploaded or failed
//     const rows = await new Promise((resolve, reject) => {
//       db.query("SELECT * FROM testsetfolder WHERE upload_status IS NULL OR upload_status NOT IN ('completed')", (err, result) => {
//         if (err) return reject(err);
//         resolve(result);
//       });
//     });

//     for (const row of rows) {
//       const { id, parent_id, name, description, upload_status } = row;

//       if (upload_status === 'completed') {
//         console.log(`✅ Skipping already completed test cycle ID: ${id}`);
//         continue;
//       }

//       try {
//         const parentQTestId = await getParentQTestId(parent_id);
//         const payload = {
//           name: name || "Unnamed",
//           description: description || ""
//         };

//         let url = BASE_URL;
//         if (parentQTestId !== null) {
//           url += `?parentId=${parentQTestId}&parentType=test-cycle`;
//         }

//         const response = await sendPostRequest(url, payload);
//         const qTestId = response.id;

//         console.log(`✅ Uploaded test cycle ID ${id}: qTest_id = ${qTestId}`);
//         await updateQTestCycleSuccess(id, qTestId);
//       } catch (err) {
//         console.error(`❌ Failed to upload test cycle ID ${id}: ${err.message}`);
//         await updateQTestCycleFailure(id, err.message);
//       }
//     }
//   } catch (err) {
//     console.error('❌ Fatal error in fetchqTestTestCycle:', err.message);
//   }
// };

// function loadQTestConfig(filePath) {
//   const content = fs.readFileSync(filePath, 'utf-8');
//   const json = JSON.parse(content);
//   QTEST_TOKEN = json.apiToken;
//   PROJECT_ID = json.projectId;
//   base_domain = json.qTestDomain;
// }

// async function getParentQTestId(parentId) {
//   if (parentId === -1 || parentId === null) return null;

//   const rows = await new Promise((resolve, reject) => {
//     db.query("SELECT qTest_id FROM testsetfolder WHERE id = ?", [parentId], (err, result) => {
//       if (err) return reject(err);
//       resolve(result);
//     });
//   });

//   return rows.length > 0 && rows[0].qTest_id ? rows[0].qTest_id : null;
// }

// async function sendPostRequest(url, payload) {
//   try {
//     const response = await axios.post(url, payload, {
//       headers: {
//         'Content-Type': 'application/json',
//         'Authorization': `Bearer ${QTEST_TOKEN}`
//       }
//     });
//     return response.data;
//   } catch (error) {
//     const status = error.response?.status || "unknown";
//     const message = error.response?.data?.message || error.message || "Unknown error";
//     throw new Error(`${status}: ${message}`);
//   }
// }

// async function updateQTestCycleSuccess(id, qTestId) {
//   await db.promise().query(
//     "UPDATE testsetfolder SET qTest_id = ?, upload_status = 'completed' WHERE id = ?",
//     [qTestId, id]
//   );
// }

// async function updateQTestCycleFailure(id, errorMsg) {
//   const statusTag = errorMsg.split(':')[0];
//   await db.promise().query(
//     "UPDATE testsetfolder SET upload_status = ? WHERE id = ?",
//     [`failed_${statusTag}`, id]
//   );
// }

// module.exports = { fetchqTestTestCycle };







 
const fs = require('fs');
const path = require('path');
const db = require("../../../config/db");
const axios = require('axios');
 
let QTEST_TOKEN, PROJECT_ID, BASE_URL, base_domain;
 
const fetchqTestTestCycle = async () => {
  try {
    loadQTestConfig(path.join(__dirname, '../../../data/qTestCredentials.json'));
    BASE_URL = `${base_domain}/api/v3/projects/${PROJECT_ID}/test-cycles`;
 
    // Fetch rows that are not yet uploaded or failed
    const rows = await new Promise((resolve, reject) => {
      db.query(
        "SELECT * FROM testsetfolder WHERE upload_status IS NULL OR upload_status NOT IN ('completed')",
        (err, result) => {
          if (err) return reject(err);
          resolve(result);
        }
      );
    });
 
    for (const row of rows) {
      const { id, parent_id, name, description, upload_status } = row;
 
      if (upload_status === 'completed') {
        console.log(`✅ Skipping already successful test cycle ID: ${id}`);
        continue;
      }
 
      try {
        const parentQTestId = await getParentQTestId(parent_id);
        const payload = {
          name: name || "Unnamed",
          description: description || ""
        };
 
        let url = BASE_URL;
        if (parentQTestId !== null) {
          url += `?parentId=${parentQTestId}&parentType=test-cycle`;
        }
 
        const response = await sendPostRequest(url, payload);
        const qTestId = response.id;
 
        console.log(`✅ Uploaded test cycle ID ${id}: qTest_id = ${qTestId}`);
        await updateQTestCycleSuccess(id, qTestId);
      } catch (err) {
        console.error(`❌ Failed to upload test cycle ID ${id}: ${err.message}`);
        await updateQTestCycleFailure(id);
      }
    }
  } catch (err) {
    console.error('❌ Fatal error in fetchqTestTestCycle:', err.message);
  }
};
 
function loadQTestConfig(filePath) {
  const content = fs.readFileSync(filePath, 'utf-8');
  const json = JSON.parse(content);
  QTEST_TOKEN = json.apiToken;
  PROJECT_ID = json.projectId;
  base_domain = json.qTestDomain;
}
 
async function getParentQTestId(parentId) {
  if (parentId === -1 || parentId === null) return null;
 
  const rows = await new Promise((resolve, reject) => {
    db.query(
      "SELECT qTest_id FROM testsetfolder WHERE id = ?",
      [parentId],
      (err, result) => {
        if (err) return reject(err);
        resolve(result);
      }
    );
  });
 
  return rows.length > 0 && rows[0].qTest_id ? rows[0].qTest_id : null;
}
 
async function sendPostRequest(url, payload) {
  try {
    const response = await axios.post(url, payload, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${QTEST_TOKEN}`
      }
    });
    return response.data;
  } catch (error) {
    const status = error.response?.status || "unknown";
    const message = error.response?.data?.message || error.message || "Unknown error";
    throw new Error(`${status}: ${message}`);
  }
}
 
async function updateQTestCycleSuccess(id, qTestId) {
  await db.promise().query(
    "UPDATE testsetfolder SET qTest_id = ?, upload_status = 'completed' WHERE id = ?",
    [qTestId, id]
  );
}
 
async function updateQTestCycleFailure(id) {
  await db.promise().query(
    "UPDATE testsetfolder SET upload_status = 'failure' WHERE id = ?",
    [id]
  );
}
 
module.exports = { fetchqTestTestCycle };
 
 