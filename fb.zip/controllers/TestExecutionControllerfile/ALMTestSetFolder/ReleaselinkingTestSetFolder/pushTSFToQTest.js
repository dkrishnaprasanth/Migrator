// const fs = require('fs');

// const path = require('path');

// const db = require('../../../../config/db'); // Replaces mysql.createConnection

// const axios = require('axios');
 
// // Globals

// let QTEST_TOKEN, PROJECT_ID, BASE_URL, base_domain;
 
// // Load qTest credentials

// function loadQTestConfig(filePath) {

//   const config = JSON.parse(fs.readFileSync(filePath, 'utf-8'));

//   QTEST_TOKEN = config.apiToken;

//   PROJECT_ID = config.projectId;

//   base_domain = config.qTestDomain;

//   BASE_URL = `${base_domain}/api/v3/projects/${PROJECT_ID}/test-cycles`;

// }
 
// // Extract qTest ID from API response

// function extractQTestId(responseData) {

//   return responseData.id;

// }
 
// // Main Execution

// const pushTSFToQTest = async () => {

//   try {

//     // Load qTest credentials

//     loadQTestConfig(path.join(__dirname, '../../../../data/qTestCredentials.json'));
 
//     // Fetch records to process

//     const [rows] = await db.promise().query("SELECT * FROM TestSetFolder WHERE qTest_id IS NULL");
 
//     for (const row of rows) {

//       const { id, parent_id, name, description, assign_rcyc } = row;

//       let url = BASE_URL;

//       const payload = {

//         name: name || "Unnamed",

//         description: description || ""

//       };
 
//       if (assign_rcyc != null) {

//         const [releaseResult] = await db.promise().query(

//           `SELECT r.qtest_release_id 

//            FROM cyc_table c 

//            JOIN releases r ON c.parent_id = r.id 

//            WHERE c.id = ?`,

//           [assign_rcyc]

//         );
 
//         if (releaseResult.length > 0 && releaseResult[0].qtest_release_id) {

//           url += `?parentId=${releaseResult[0].qtest_release_id}&parentType=release`;

//         } else {

//           console.log(`⚠️ No matching release for assign_rcyc = ${assign_rcyc}, falling back to parent test cycle.`);

//           await fallbackToParentCycle(id, parent_id, payload, url);

//           continue;

//         }

//       } else {

//         await fallbackToParentCycle(id, parent_id, payload, url);

//         continue;

//       }
 
//       await postAndUpdate(id, url, payload);

//     }
 
//     console.log("✅ All TSF records uploaded to qTest.");

//   } catch (err) {

//     console.error("❌ Error:", err.message);

//   }

// };
 
// // Fallback: use parent test-cycle if assign_rcyc isn't usable

// async function fallbackToParentCycle(id, parentId, payload, baseUrl) {

//   let url = baseUrl;

//   if (parentId !== -1) {

//     const [parentRes] = await db.promise().query(

//       "SELECT qTest_id FROM TestSetFolder WHERE id = ?",

//       [parentId]

//     );

//     if (parentRes.length > 0 && parentRes[0].qTest_id != null) {

//       url += `?parentId=${parentRes[0].qTest_id}&parentType=test-cycle`;

//     }

//   }

//   await postAndUpdate(id, url, payload);

// }
 
// // POST to qTest and update DB

// async function postAndUpdate(id, url, payload) {

//   try {

//     const response = await axios.post(url, payload, {

//       headers: {

//         'Authorization': `Bearer ${QTEST_TOKEN}`,

//         'Content-Type': 'application/json'

//       }

//     });
 
//     const qTestId = extractQTestId(response.data);

//     console.log(`📤 DB ID ${id} → qTest_id: ${qTestId}`);
 
//     await db.promise().query(

//       "UPDATE TestSetFolder SET qTest_id = ? WHERE id = ?",

//       [qTestId, id]

//     );

//   } catch (err) {

//     const errorMsg = err.response?.data || err.message;

//     console.error(`❌ Error processing ID ${id}:`, errorMsg);

//   }

// }
 
// // Run
// module.exports = {
//    pushTSFToQTest
// };







 
const fs = require('fs');
const path = require('path');
const db = require('../../../../config/db'); // Replaces mysql.createConnection
const axios = require('axios');
 
// Globals
let QTEST_TOKEN, PROJECT_ID, BASE_URL, base_domain;
 
// Load qTest credentials
function loadQTestConfig(filePath) {
  const config = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  QTEST_TOKEN = config.apiToken;
  PROJECT_ID = config.projectId;
  base_domain = config.qTestDomain;
  BASE_URL = `${base_domain}/api/v3/projects/${PROJECT_ID}/test-cycles`;
}
 
// Extract qTest ID from API response
function extractQTestId(responseData) {
  return responseData.id;
}
 
// Main Execution
const pushTSFToQTest = async () => {
  try {
    // Load qTest credentials
    loadQTestConfig(path.join(__dirname, '../../../../data/qTestCredentials.json'));
 
    // Fetch records to process
    const [rows] = await db.promise().query(
      "SELECT * FROM TestSetFolder WHERE qTest_id IS NULL"
    );
 
    for (const row of rows) {
      const { id, parent_id, name, description, assign_rcyc } = row;
      let url = BASE_URL;
      const payload = {
        name: name || "Unnamed",
        description: description || ""
      };
 
      if (assign_rcyc != null) {
        const [releaseResult] = await db.promise().query(
          `SELECT r.qtest_release_id
           FROM cyc_table c
           JOIN releases r ON c.parent_id = r.id
           WHERE c.id = ?`,
          [assign_rcyc]
        );
 
        if (releaseResult.length > 0 && releaseResult[0].qtest_release_id) {
          url += `?parentId=${releaseResult[0].qtest_release_id}&parentType=release`;
        } else {
          console.log(`⚠️ No matching release for assign_rcyc = ${assign_rcyc}, falling back to parent test cycle.`);
          await fallbackToParentCycle(id, parent_id, payload, url);
          continue;
        }
      } else {
        await fallbackToParentCycle(id, parent_id, payload, url);
        continue;
      }
 
      await postAndUpdate(id, url, payload);
    }
 
    console.log("✅ All TSF records processed.");
  } catch (err) {
    console.error("❌ Error:", err.message);
  }
};
 
// Fallback: use parent test-cycle if assign_rcyc isn't usable
async function fallbackToParentCycle(id, parentId, payload, baseUrl) {
  let url = baseUrl;
  if (parentId !== -1) {
    const [parentRes] = await db.promise().query(
      "SELECT qTest_id FROM TestSetFolder WHERE id = ?",
      [parentId]
    );
    if (parentRes.length > 0 && parentRes[0].qTest_id != null) {
      url += `?parentId=${parentRes[0].qTest_id}&parentType=test-cycle`;
    }
  }
  await postAndUpdate(id, url, payload);
}
 
// POST to qTest and update DB
async function postAndUpdate(id, url, payload) {
  try {
    const response = await axios.post(url, payload, {
      headers: {
        'Authorization': `Bearer ${QTEST_TOKEN}`,
        'Content-Type': 'application/json'
      }
    });
 
    const qTestId = extractQTestId(response.data);
    console.log(`📤 DB ID ${id} → qTest_id: ${qTestId}`);
 
    await db.promise().query(
      "UPDATE TestSetFolder SET qTest_id = ?, upload_status = 'completed' WHERE id = ?",
      [qTestId, id]
    );
  } catch (err) {
    const errorMsg = err.response?.data || err.message;
    console.error(`❌ Error processing ID ${id}:`, errorMsg);
 
    await db.promise().query(
      "UPDATE TestSetFolder SET upload_status = 'failure' WHERE id = ?",
      [id]
    );
  }
}
 
// Run
module.exports = {
  pushTSFToQTest
};
 
 
 