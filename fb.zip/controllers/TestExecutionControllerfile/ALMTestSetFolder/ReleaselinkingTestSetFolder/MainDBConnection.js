const { FoldersToDB } = require("./FoldersToDB");
const { main } = require("./Main");
const { pushCYC } = require("./pushCYC");
const { pushTSFToQTest } = require("./pushTSFToQTest");
const { TestSetFolderCyc } = require("./TestSetFolderCyc");

const db = require('../../../../config/db'); 
 
const insertreleaselinkingTestSetupToDB = async (req, res) => {
    try {
        console.log("📥 Fetching ALM main...");
        await main();
 
        console.log("Saving testsetfolder to database...");
        await TestSetFolderCyc ();
 
        console.log(" Fetching fetchTestSetFoldersToDB...");
       const insertResult =  await FoldersToDB();

       
        console.log(" Fetching pushCYC...");
        await pushCYC();
 
        // ✅ Database count
    const [countResult] = await db.promise().query(
      "SELECT COUNT(*) AS totalCount FROM testsetfolder"
    );
    const totalCount = countResult[0].totalCount;

    console.log("✅🚀 Database and ALM setup completed successfully.");
    res.status(200).json({
      success: true,
      message: 'ALM Setup completed successfully.',
      stats: {
        inserted: insertResult?.affectedRows || 0,
        totalCount
      }
    });

    } catch (error) {
        console.error("❌ Setup failed:", error);
        res.status(500).json({ error: 'ALM insert Setup failed', details: error.message });
    }
};
 
const uploadreleaselinkingTestSetupToDB = async (req, res) => {
    try {
       
        console.log(" Fetching pushTSFToQTest();...");
        await pushTSFToQTest();
 
        console.log("✅🚀 Database and ALM upload setup completed successfully.");
        res.status(200).json({ message: 'ALM upload Setup completed successfully.' });
    } catch (error) {
        console.error("❌ Setup failed:", error);
        res.status(500).json({ error: 'ALM upload Setup failed', details: error.message });
    }
};
 
 
module.exports = {uploadreleaselinkingTestSetupToDB ,insertreleaselinkingTestSetupToDB};
 
 