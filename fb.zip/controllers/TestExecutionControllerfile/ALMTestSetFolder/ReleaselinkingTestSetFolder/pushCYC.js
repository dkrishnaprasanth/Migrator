const fs = require('fs');

const path = require('path');

const db = require('../../../../config/db'); // use existing DB connection
 
// Paths

const cyclesDataPath = path.join(__dirname, '../../../../data/TestExecutiondatafile/ALMTestSetFolder/almcycles.json');
 
// Helper functions

function getFieldValue(fields, name) {

  for (const field of fields) {

    if (field.Name === name && Array.isArray(field.values) && field.values.length > 0) {

      return field.values[0].value || null;

    }

  }

  return null;

}
 
function parseNullableInt(val) {

  const parsed = parseInt(val);

  return isNaN(parsed) ? null : parsed;

}
 
function parseIntSafe(val) {

  const parsed = parseInt(val);

  return isNaN(parsed) ? 0 : parsed;

}
 
// Main execution

const pushCYC = async () => {

  try {

    // Drop table if exists

    await new Promise((resolve, reject) => {

      db.query(`DROP TABLE IF EXISTS CYC_Table`, (err) => {

        if (err) {

          console.error('❌ Error dropping table:', err.message);

          return reject(err);

        }

        console.log("✅ Dropped existing 'CYC_Table' (if it existed).");

        resolve();

      });

    });
 
    // Create table

    const createTableSQL = `

      CREATE TABLE IF NOT EXISTS CYC_Table (

        id INT PRIMARY KEY,

        parent_id INT,

        name TEXT

      )

    `;

    await new Promise((resolve, reject) => {

      db.query(createTableSQL, (err) => {

        if (err) {

          console.error('❌ Error creating table:', err.message);

          return reject(err);

        }

        console.log("✅ Table 'CYC_Table' created successfully.");

        resolve();

      });

    });
 
    // Read and insert data

    const cyclesJson = JSON.parse(fs.readFileSync(cyclesDataPath, 'utf8'));

    const entities = cyclesJson.entities;
 
    if (Array.isArray(entities)) {

      for (const entity of entities) {

        const fields = entity.Fields;

        if (Array.isArray(fields)) {

          const id = getFieldValue(fields, 'id');

          const parentId = getFieldValue(fields, 'parent-id');

          const name = getFieldValue(fields, 'name');
 
          const insertSQL = `INSERT INTO CYC_Table (id, parent_id, name) VALUES (?, ?, ?)`;
 
          await new Promise((resolve, reject) => {

            db.query(

              insertSQL,

              [parseIntSafe(id), parseNullableInt(parentId), name],

              (err) => {

                if (err) {

                  console.error(`❌ Insert failed for id ${id}:`, err.message);

                  return reject(err);

                }

                resolve();

              }

            );

          });

        }

      }

    }
 
    console.log('✅ All CYC records processed.');

  } catch (err) {

    console.error('❌ Error:', err.message);

  }

};
 
module.exports = {
   pushCYC
};

 