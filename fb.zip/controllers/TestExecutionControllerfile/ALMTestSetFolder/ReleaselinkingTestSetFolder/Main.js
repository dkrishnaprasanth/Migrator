// getTSF.js
 
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const https = require('https');
 
// File paths
const configPath = path.join(__dirname, '../../../../data/AlmCredentials.json');
const outputPath = path.join(__dirname, '../../../../data/TestExecutiondatafile/ALMTestSetFolder/AlmTestSetFolder.json');
 
// Load ALM credentials
const loadConfig = () => {
  const rawData = fs.readFileSync(configPath, 'utf-8');
  return JSON.parse(rawData);
};
 
// Encode username:password to base64
const encodeBasicAuth = (username, password) => {
  return Buffer.from(`${username}:${password}`).toString('base64');
};
 
// Parse cookies from Set-Cookie headers
const parseCookies = (setCookieHeaders, name) => {
  for (const cookie of setCookieHeaders || []) {
    const parts = cookie.split(';');
    for (const part of parts) {
      if (part.trim().startsWith(name + '=')) {
        return part.trim().split('=')[1];
      }
    }
  }
  return null;
};
 
// Save JSON data to file
const saveJsonToFile = (data, filePath) => {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
    console.log(`✅ Saved JSON to ${filePath}`);
  } catch (error) {
    console.error("❌ Error writing to file:", error.message);
  }
};
 
const main = async () => {
  try {
    const config = loadConfig();
    const { almServerUrl, username, password, domain, project } = config;

    const loginUrl = `${almServerUrl}/api/authentication/sign-in`;
    const tsfBaseUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/test-set-folders`;

    // Step 1: Authenticate
    const loginResponse = await axios.post(loginUrl, {}, {
      headers: {
        'Authorization': `Basic ${encodeBasicAuth(username, password)}`,
        'Content-Type': 'application/json'
      },
      httpsAgent: new https.Agent({ rejectUnauthorized: false })
    });

    const setCookies = loginResponse.headers['set-cookie'];
    const xsrfToken = parseCookies(setCookies, 'XSRF-TOKEN');
    const sessionCookie = parseCookies(setCookies, 'JSESSIONID');
    const lwssoCookie = parseCookies(setCookies, 'LWSSO_COOKIE_KEY');
    const almUser = parseCookies(setCookies, 'ALM_USER');
    const qcSession = parseCookies(setCookies, 'QCSession');

    if (!xsrfToken || !sessionCookie) {
      console.error("❌ Authentication failed. Missing required cookies.");
      return;
    }

    const cookieHeader = `XSRF-TOKEN=${xsrfToken}; JSESSIONID=${sessionCookie}; LWSSO_COOKIE_KEY=${lwssoCookie}; ALM_USER=${almUser}; QCSession=${qcSession}`;

    const allData = [];
    const pageSize = 100;
    let startIndex = 1;

    while (true) {
      const pagedUrl = `${tsfBaseUrl}?start-index=${startIndex}&page-size=${pageSize}`;

      const response = await axios.get(pagedUrl, {
        headers: {
          'Cookie': cookieHeader,
          'Accept': 'application/json'
        },
        httpsAgent: new https.Agent({ rejectUnauthorized: false })
      });

      const entities = response.data.entities || [];
      console.log(`📦 Fetched ${entities.length} records from index ${startIndex}`);

      if (entities.length === 0) break;

      allData.push(...entities);
      startIndex += pageSize;
    }

    // Save all data to file
    saveJsonToFile({ entities: allData }, outputPath);
    console.log(`✅ All ${allData.length} test set folders saved to ${outputPath}`);
  } catch (error) {
    console.error("❌ Error:", error.message);
  }
};

 
module.exports = {
   main
};

