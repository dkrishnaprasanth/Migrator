// getCYC.js
 
const fs = require('fs');

const path = require('path');

const axios = require('axios');

const https = require('https');
 
// Load ALM credentials from JSON file

const configPath = path.join(__dirname, '../../../../data/AlmCredentials.json');

const outputPath = path.join(__dirname, '../../../../data/TestExecutiondatafile/ALMTestSetFolder/almcycles.json');
 
const loadConfig = () => {

  const rawData = fs.readFileSync(configPath, 'utf-8');

  return JSON.parse(rawData);

};
 
const encodeBasicAuth = (username, password) => {

  return Buffer.from(`${username}:${password}`).toString('base64');

};
 
const parseCookies = (setCookieHeaders, name) => {

  for (const header of setCookieHeaders || []) {

    const parts = header.split(';');

    for (const part of parts) {

      if (part.trim().startsWith(name + '=')) {

        return part.trim().split('=')[1];

      }

    }

  }

  return null;

};
 
const saveJsonToFile = (data, filePath) => {

  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');

  console.log(`Saved JSON to ${filePath}`);

};
 
// const TestSetFolderCyc = async () => {

//   try {

//     const config = loadConfig();

//     const { almServerUrl, username, password, domain, project } = config;
 
//     const loginUrl = `${almServerUrl}/api/authentication/sign-in`;

//     const releaseDataUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/release-cycles`;
 
//     // Authenticate and get cookies

//     const loginResponse = await axios.post(loginUrl, {}, {

//       headers: {

//         'Authorization': `Basic ${encodeBasicAuth(username, password)}`,

//         'Content-Type': 'application/json'

//       },

//       httpsAgent: new https.Agent({ rejectUnauthorized: false })

//     });
 
//     const setCookies = loginResponse.headers['set-cookie'];

//     const xsrfToken = parseCookies(setCookies, 'XSRF-TOKEN');

//     const sessionCookie = parseCookies(setCookies, 'JSESSIONID');

//     const lwssoCookie = parseCookies(setCookies, 'LWSSO_COOKIE_KEY');

//     const almUser = parseCookies(setCookies, 'ALM_USER');

//     const qcSession = parseCookies(setCookies, 'QCSession');
 
//     if (xsrfToken && sessionCookie) {

//       const cookieHeader = `XSRF-TOKEN=${xsrfToken}; JSESSIONID=${sessionCookie}; LWSSO_COOKIE_KEY=${lwssoCookie}; ALM_USER=${almUser}; QCSession=${qcSession}`;
 
//       const releaseResponse = await axios.get(releaseDataUrl, {

//         headers: {

//           'Cookie': cookieHeader,

//           'Accept': 'application/json'

//         },

//         httpsAgent: new https.Agent({ rejectUnauthorized: false })

//       });
 
//       saveJsonToFile(releaseResponse.data, outputPath);

//       console.log("All TSF responses are saved.");

//     } else {

//       console.error("Authentication failed. XSRF Token or Session Cookie missing.");

//       throw new Error("Missing authentication cookies.");

//     }
 
//   } catch (error) {

//     console.error("Error:", error.message);

//   }

// };


const TestSetFolderCyc = async () => {
  try {
    const config = loadConfig();
    const { almServerUrl, username, password, domain, project } = config;

    const loginUrl = `${almServerUrl}/api/authentication/sign-in`;
    const releaseBaseUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/release-cycles`;

    // Authenticate
    const loginResponse = await axios.post(loginUrl, {}, {
      headers: {
        'Authorization': `Basic ${encodeBasicAuth(username, password)}`,
        'Content-Type': 'application/json'
      },
      httpsAgent: new https.Agent({ rejectUnauthorized: false })
    });

    const setCookies = loginResponse.headers['set-cookie'];
    const xsrfToken = parseCookies(setCookies, 'XSRF-TOKEN');
    const sessionCookie = parseCookies(setCookies, 'JSESSIONID');
    const lwssoCookie = parseCookies(setCookies, 'LWSSO_COOKIE_KEY');
    const almUser = parseCookies(setCookies, 'ALM_USER');
    const qcSession = parseCookies(setCookies, 'QCSession');

    if (!xsrfToken || !sessionCookie) {
      throw new Error("Missing authentication cookies.");
    }

    const cookieHeader = `XSRF-TOKEN=${xsrfToken}; JSESSIONID=${sessionCookie}; LWSSO_COOKIE_KEY=${lwssoCookie}; ALM_USER=${almUser}; QCSession=${qcSession}`;

    // Pagination loop
    const pageSize = 1000;
    let startIndex = 1;
    let allEntities = [];

    while (true) {
      const pagedUrl = `${releaseBaseUrl}?page-size=${pageSize}&start-index=${startIndex}`;
      const response = await axios.get(pagedUrl, {
        headers: {
          'Cookie': cookieHeader,
          'Accept': 'application/json'
        },
        httpsAgent: new https.Agent({ rejectUnauthorized: false })
      });

      const entities = response.data.entities || [];
      allEntities.push(...entities);

      console.log(`Fetched ${entities.length} records (Start Index: ${startIndex})`);

      if (entities.length < pageSize) break;
      startIndex += pageSize;
    }

    // Save all to file
    saveJsonToFile({ entities: allEntities }, outputPath);
    console.log(`✅ All ${allEntities.length} release-cycles fetched and saved.`);

  } catch (error) {
    console.error("❌ Error:", error.message);
  }
};

 
module.exports = {
   TestSetFolderCyc
};

 