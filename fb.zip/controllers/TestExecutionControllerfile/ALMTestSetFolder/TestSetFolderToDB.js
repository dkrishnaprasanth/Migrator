const fs = require('fs');
const path = require('path');
const db = require("../../../config/db");

const fetchAlmtestsetToDB = async () => {
  try {
    // Ensure table exists
    await db.promise().query(`
      CREATE TABLE IF NOT EXISTS TestSetFolder (
        id INT PRIMARY KEY,
        parent_id INT,
        name TEXT,
        description TEXT,
        assign_rcyc TEXT,
        last_modified TIMESTAMP,
        qTest_id INT,
        upload_status TEXT
      )
    `);

    const jsonFilePath = path.join(__dirname, '../../../data/TestExecutiondatafile/ALMTestSetFolder/AlmTestSetFolder.json');
    const jsonData = JSON.parse(fs.readFileSync(jsonFilePath, 'utf-8'));
    const entities = jsonData.entities;

    let insertedCount = 0;
    let skippedCount = 0;

    if (Array.isArray(entities)) {
      for (const entity of entities) {
        const fields = entity.Fields;
        if (Array.isArray(fields)) {
          const id = parseIntSafe(getFieldValue(fields, "id"));
          const parentId = parseNullableInt(getFieldValue(fields, "parent-id"));
          const assign_rcyc = getFieldValue(fields, "assign-rcyc");
          const name = getFieldValue(fields, "name");
          const description = getFieldValue(fields, "description");
          const last_modified = getFieldValue(fields, "last-modified");
          const qTestId = parseNullableInt(getFieldValue(fields, "qTest-id"));

          // Skip if ID already exists
          const [existing] = await db.promise().query("SELECT id FROM TestSetFolder WHERE id = ?", [id]);
          if (existing.length > 0) {
            console.log(`⏭️ Skipping TestSetFolder ID ${id} (already exists).`);
            skippedCount++;
            continue;
          }

          // Insert new record
          await db.promise().query(
            `INSERT INTO TestSetFolder (id, parent_id, name, description, assign_rcyc,last_modified, qTest_id) VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [id, parentId, name, description, assign_rcyc,last_modified, qTestId]
          );
          insertedCount++;
        }
      }
    }

    console.log(`✅ Done. Inserted: ${insertedCount}, Skipped: ${skippedCount}`);
    return { inserted: insertedCount, skipped: skippedCount }; // <-- return counts
  } catch (err) {
    console.error("❌ Error:", err.message);
    throw err;
  }
};

function getFieldValue(fields, name) {
  const field = fields.find(f => f.Name === name);
  return field?.values?.[0]?.value ?? null;
}

function parseNullableInt(val) {
  if (!val || val === "") return null;
  const parsed = parseInt(val);
  return isNaN(parsed) ? null : parsed;
}

function parseIntSafe(val) {
  const parsed = parseInt(val);
  return isNaN(parsed) ? 0 : parsed;
}

module.exports = { fetchAlmtestsetToDB };

// fetchAlmtestsetToDB();
