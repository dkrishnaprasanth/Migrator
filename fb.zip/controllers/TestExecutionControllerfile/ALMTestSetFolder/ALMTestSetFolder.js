const axios = require('axios');
const fs = require('fs');
const path = require('path');

const CONFIG_PATH = path.join(__dirname, '../../../data/AlmCredentials.json');
const OUTPUT_PATH = path.join(__dirname, '../../../data/TestExecutiondatafile/ALMTestSetFolder/AlmTestSetFolder.json');

// Load configuration from file
const loadConfigFromFile = (filePath) => {
    if (!fs.existsSync(filePath)) {
        throw new Error(`Config file not found at path: ${filePath}`);
    }
    const rawData = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(rawData);
};

// Parse cookie array into key-value map
const parseCookies = (cookieArray) => {
    const cookieMap = {};
    cookieArray.forEach(cookie => {
        const [cookiePair] = cookie.split(';');
        const [name, ...rest] = cookiePair.split('=');
        cookieMap[name.trim()] = rest.join('=').trim();
    });
    return cookieMap;
};

// Build 'Cookie' header string from tokens
const buildCookieHeader = (tokens) => {
    return Object.entries(tokens)
        .map(([key, value]) => `${key}=${value}`)
        .join('; ');
};

const fetchAlmTestSetFolder = async () => {
    try {
        const config = loadConfigFromFile(CONFIG_PATH);
        const { almServerUrl, username, password, domain, project } = config;

        const loginUrl = `${almServerUrl}/api/authentication/sign-in`;
        const baseUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/test-set-folders`;
        const authHeader = 'Basic ' + Buffer.from(`${username}:${password}`).toString('base64');

        const loginResponse = await axios.post(loginUrl, {}, {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': authHeader
            },
            withCredentials: true
        });

        const cookies = loginResponse.headers['set-cookie'] || [];
        const cookieMap = parseCookies(cookies);

        const headers = {
            'Accept': 'application/json',
            'Cookie': buildCookieHeader({
                'XSRF-TOKEN': cookieMap['XSRF-TOKEN'],
                'JSESSIONID': cookieMap['JSESSIONID'],
                'LWSSO_COOKIE_KEY': cookieMap['LWSSO_COOKIE_KEY'],
                'ALM_USER': cookieMap['ALM_USER'],
                'QCSession': cookieMap['QCSession']
            })
        };

        let allEntities = [];
        let startIndex = 1;
        const pageSize = 100; // You can adjust this if needed

        while (true) {
            const url = `${baseUrl}?page-size=${pageSize}&start-index=${startIndex}`;
            const response = await axios.get(url, { headers });

            const entities = response.data.entities || [];
            if (entities.length === 0) break;

            allEntities.push(...entities);
            console.log(`📄 Retrieved ${entities.length} records (start-index: ${startIndex})`);

            if (entities.length < pageSize) break; // End of data
            startIndex += pageSize;
        }

        fs.writeFileSync(OUTPUT_PATH, JSON.stringify({ entities: allEntities }, null, 2), 'utf8');
        console.log(`✅ Total ${allEntities.length} test set folders saved to AlmTestSetFolder.json`);
    } catch (error) {
        console.error("❌ Failed to fetch ALM Test Set Folder:", error.message);
        if (error.response) {
            console.error("Status:", error.response.status);
            console.error("Response:", error.response.data);
        }
    }
};




module.exports = {
    fetchAlmTestSetFolder
};

