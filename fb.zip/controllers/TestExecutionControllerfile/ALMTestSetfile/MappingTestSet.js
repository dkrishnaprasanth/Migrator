const fs = require("fs");
const path = require("path");
const axios = require("axios");
const db = require("../../../config/db");

// const insertSampleData = async (req, res) => {
//   try {

//     const [columns] = await db.promise().query(
//       "SELECT ep1_name, ep1_type, ep2_field_id FROM Field_mappings WHERE artifact_type='TestSet' AND link_name = (SELECT link_name FROM link_table WHERE is_current = 1 LIMIT 1)"
//     );

//     if (!columns || columns.length === 0) {
//       return res.status(400).json({
//         success: false,
//         message: "No mapping columns found. Please create mappings first."
//       });
//     }

//     const jsonFilePath = path.join(__dirname, '../../../data/TestExecutiondatafile/ALMTestSetdata/AlmTestSet.json');
//     if (!fs.existsSync(jsonFilePath)) {
//       return res.status(404).json({
//         success: false,
//         message: `JSON file not found at: ${jsonFilePath}`
//       });
//     }

//     const jsonData = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'));

//     // Clear existing data
//     //await db.promise().query("TRUNCATE TABLE testset");


//     // ✅ Fetch all existing IDs with last_modified and upload_status
//     // const [existingRows] = await db.promise().query(
//     //   "SELECT id, last_modified, upload_status FROM testset"
//     // );
//     // const existingMap = new Map(
//     //   existingRows.map(row => [
//     //     Number(row.id),
//     //     {
//     //       //last_modified: row.last_modified?.toISOString()?.split('T')[0],
//     //       last_modified: new Date(row.last_modified).toISOString(),
//     //       status: row.upload_status
//     //     }
//     //   ])
//     // );


//     // Fetch existing rows for comparison
//     const [existingRows] = await db.promise().query(
//       "SELECT id, last_modified, upload_status, qtest_testset_id FROM testset"
//     );
//     const existingMap = new Map(existingRows.map(row => [row.id, row]));




//     // Get the structure of the testset table to ensure correct columns
//     const [tableInfo] = await db.promise().query("DESCRIBE testset");
//     const tableColumns = tableInfo.map(column => column.Field);
//     console.log("Table columns:", tableColumns);

//     // Generate the actual columns we'll use for insertion
//     const mappingColumns = columns.map(col =>
//       col.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase());

//     // Make sure all required columns are included
//     const requiredColumns = ['name', 'has_link', 'has_attachment', 'last_modified', 'parent_id', 'qtest_testset_id', 'upload_status'];

//     // Combine and filter to only use columns that exist in the table
//     const allColumns = [...mappingColumns, ...requiredColumns].filter(
//       col => tableColumns.includes(col)
//     );

//     console.log("Columns for insertion:", allColumns);

//     // Generate SQL column string with backticks
//     const columnSQL = allColumns.map(col => `\`${col}\``).join(', ');

//     const allRowsToInsert = [];

//     for (const entity of jsonData.entities) {
//       // Process entity data to match our columns
//       const rowData = {};



//       // Process mapping columns first
//       for (const column of columns) {
//         const columnName = column.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
//         const matchingField = entity.Fields.find(field =>
//           field.Name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase() === columnName
//         );

//         if (!matchingField || !matchingField.values || matchingField.values.length === 0) {
//           rowData[columnName] = null;
//         } else {
//           const combinedValue = matchingField.values.map(v => v.value).join(',');

//           switch (column.ep1_type) {
//             case 'Number':
//               rowData[columnName] = isNaN(Number(combinedValue)) ? null : Number(combinedValue);
//               break;
//             case 'Date': {
//               const parsedDate = new Date(combinedValue);
//               rowData[columnName] = isNaN(parsedDate.getTime()) ? null : parsedDate.toISOString().split('T')[0];
//               break;
//             }
//             case 'String':
//             default:
//               rowData[columnName] = combinedValue;
//           }
//         }
//       }

//       // Add required fields
//       rowData['name'] = entity.Fields.find(f => f.Name === 'name')?.values?.[0]?.value || null;
//       rowData['has_link'] = entity.Fields.find(f => f.Name === 'has-linkage')?.values?.[0]?.value || null;
//       rowData['has_attachment'] = entity.Fields.find(f => f.Name === 'attachment')?.values?.[0]?.value || null;
//       rowData['last_modified'] = entity.Fields.find(f => f.Name === 'last-modified')?.values?.[0]?.value || null;
//       rowData['parent_id'] = entity.Fields.find(f => f.Name === 'parent-id')?.values?.[0]?.value || null;
//       rowData['qtest_testset_id'] = null;
//       //rowData['upload_status'] = 'null';



//       // const setId = Number(entity.Fields.find(f => f.Name === 'id')?.values?.[0]?.value || null);
//       // const newLastModified = rowData['last_modified'] ? new Date(rowData['last_modified']).toISOString() : null;

//       // if (setId && existingMap.has(setId)) {
//       //   //const { last_modified: existingModified, status, qtest_id } = existingMap.get(setId);

//       //   const { last_modified: existingModified, upload_status: status, qtest_testset_id } = existingMap.get(setId);



//       //   if (existingModified === newLastModified) {
//       //     console.log(`⏭️ Skipping unchanged TestSet ID ${setId}`);
//       //     continue;
//       //   }

//       //   // last_modified is different → update
//       //   if (qtest_id) {
//       //     // Has qtest_testset_id
//       //     if (status === 'completed' || status === 'uploaded') {
//       //       rowData['upload_status'] = 'modified';
//       //     } else {
//       //       rowData['upload_status'] = status; // keep existing status
//       //     }
//       //   } else {
//       //     // No qtest_testset_id
//       //     rowData['upload_status'] = 'changed';
//       //   }

//       // } else {
//       //   // New record
//       //   rowData['upload_status'] = null;
//       // }



//       // // Extract values in the same order as columns
//       // // const rowValues = allColumns.map(col => rowData[col]);
//       // // allRowsToInsert.push(rowValues);

//       // // const setId = Number(entity.Fields.find(f => f.Name === 'id')?.values?.[0]?.value || null);
//       // // const newLastModified = rowData['last_modified'] ? new Date(rowData['last_modified']) : null;

//       // if (!setId) {
//       //   console.warn(`⚠️ Skipping record with missing ID`);
//       //   continue;
//       // }

//       // const existing = existingMap.get(setId);

//       // if (!existing) {
//       //   // New insert
//       //   rowData['qtest_testset_id'] = null;
//       //   rowData['upload_status'] = null;

//       //   const insertCols = allColumns.filter(c => c !== 'id');
//       //   const insertSQL = `INSERT INTO testset (\`id\`, ${insertCols.map(c => `\`${c}\``).join(', ')}) VALUES (?, ${insertCols.map(() => '?').join(', ')})`;
//       //   const values = [setId, ...insertCols.map(c => rowData[c])];
//       //   await db.promise().query(insertSQL, values);

//       // } else {
//       //   // Compare last_modified
//       //   const dbLastModified = new Date(existing.last_modified);
//       //   const isModified = dbLastModified.getTime() !== newLastModified?.getTime();

//       //   if (isModified) {
//       //     let newStatus;
//       //     if (existing.qtest_testset_id) {
//       //       // Already uploaded
//       //       newStatus = (existing.upload_status === 'completed' || existing.upload_status === 'uploaded') ? 'changed' : existing.upload_status;
//       //     } else {
//       //       // Not uploaded yet
//       //       newStatus = 'changed';
//       //     }

//       //     const updateCols = allColumns.filter(c => c !== 'id' && c !== 'qtest_testset_id');
//       //     const updateSQL = `UPDATE testset SET ${updateCols.map(c => `\`${c}\` = ?`).join(', ')}, upload_status = ? WHERE id = ?`;
//       //     const values = [...updateCols.map(c => rowData[c]), newStatus, setId];
//       //     await db.promise().query(updateSQL, values);
//       //   }
//       // }


//       const setId = Number(entity.Fields.find(f => f.Name === 'id')?.values?.[0]?.value || null);
//       const newLastModified = rowData['last_modified'] ? new Date(rowData['last_modified']) : null;

//       if (!setId) {
//         console.warn(`⚠️ Skipping record with missing ID`);
//         continue;
//       }

//       const existing = existingMap.get(setId);

//       if (!existing) {
//         // --- INSERT NEW ---
//         rowData['qtest_testset_id'] = null;
//         rowData['upload_status'] = null;

//         const insertCols = allColumns.filter(c => c !== 'id');
//         const insertSQL = `INSERT INTO testset (\`id\`, ${insertCols.map(c => `\`${c}\``).join(', ')}) VALUES (?, ${insertCols.map(() => '?').join(', ')})`;
//         const values = [setId, ...insertCols.map(c => rowData[c])];
//         await db.promise().query(insertSQL, values);

//       } else {
//         // --- UPDATE OR SKIP ---
//         const dbLastModified = existing.last_modified ? new Date(existing.last_modified) : null;

//         if (dbLastModified && newLastModified && dbLastModified.getTime() === newLastModified.getTime()) {
//           console.log(`⏭️ Skipping unchanged TestSet ID ${setId}`);
//           continue;
//         }

//         let newStatus = existing.upload_status; // keep default

//         if (existing.qtest_testset_id) {
//           if (existing.upload_status === 'completed' || existing.upload_status === 'uploaded') {
//             newStatus = 'modified';
//           }
//         } else {
//           newStatus = 'changed';
//         }


//         const updateCols = allColumns.filter(c => c !== 'id' && c !== 'qtest_testset_id');
//         const updateSQL = `UPDATE testset SET ${updateCols.map(c => `\`${c}\` = ?`).join(', ')}, upload_status = ? WHERE id = ?`;
//         const values = [...updateCols.map(c => rowData[c]), newStatus, setId];
//         await db.promise().query(updateSQL, values);
//       }



//     }

//     // if (allRowsToInsert.length === 0) {
//     //   return res.status(200).json({
//     //     success: false,
//     //     message: 'No new data to insert or update.'
//     //   });
//     // }

//     // const BATCH_SIZE = 100;
//     // let insertedCount = 0;

//     // for (let i = 0; i < allRowsToInsert.length; i += BATCH_SIZE) {
//     //   const batch = allRowsToInsert.slice(i, i + BATCH_SIZE);
//     //   // Generate placeholders for each row - ensure the count matches allColumns.length
//     //   const placeholders = batch.map(() => `(${new Array(allColumns.length).fill('?').join(', ')})`).join(', ');
//     //   const flatValues = batch.flat();

//     //   console.log(`Executing: INSERT INTO testset (${columnSQL}) VALUES ${placeholders}`);
//     //   console.log(`With ${flatValues.length} values for ${batch.length} rows and ${allColumns.length} columns`);

//     //   // const insertSQL = `INSERT INTO testset (${columnSQL}) VALUES ${placeholders}`;

//     //   const updateSQL = allColumns
//     //     .filter(col => col !== 'id' && col !== 'qtest_testset_id')  // ✅ skip these
//     //     .map(col => `\`${col}\` = VALUES(\`${col}\`)`)
//     //     .join(', ');

//     //   const insertSQL = `INSERT INTO testset (${columnSQL}) VALUES ${placeholders} ON DUPLICATE KEY UPDATE ${updateSQL}`;


//     //   const [result] = await db.promise().query(insertSQL, flatValues);
//     //   insertedCount += result.affectedRows;
//     // }




//     res.status(200).json({
//       success: true,
//       message: `Successfully processed TestSet records`
//     });


//   } catch (error) {
//     console.error('Error inserting data:', error);
//     res.status(500).json({
//       success: false,
//       message: `Error inserting data: ${error.message}`
//     });
//   }
// };


const insertSampleData = async (req, res) => {
  try {
    const [columns] = await db.promise().query(
      "SELECT ep1_name, ep1_type, ep2_field_id FROM Field_mappings WHERE artifact_type='TestSet' AND link_name = (SELECT link_name FROM link_table WHERE is_current = 1 LIMIT 1)"
    );
 
    if (!columns || columns.length === 0) {
      return res.status(400).json({
        success: false,
        message: "No mapping columns found. Please create mappings first."
      });
    }
 
    const jsonFilePath = path.join(__dirname, '../../../data/TestExecutiondatafile/ALMTestSetdata/AlmTestSet.json');
    if (!fs.existsSync(jsonFilePath)) {
      return res.status(404).json({
        success: false,
        message: `JSON file not found at: ${jsonFilePath}`
      });
    }
 
    const jsonData = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'));
 
    const [existingRows] = await db.promise().query(
      "SELECT id, last_modified, upload_status, qtest_testset_id FROM testset"
    );
    const existingMap = new Map(existingRows.map(row => [row.id, row]));
 
    const [tableInfo] = await db.promise().query("DESCRIBE testset");
    const tableColumns = tableInfo.map(column => column.Field);
 
    const mappingColumns = columns.map(col =>
      col.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase()
    );
 
    const requiredColumns = ['name', 'has_link', 'has_attachment', 'last_modified', 'parent_id', 'qtest_testset_id', 'upload_status'];
 
    const allColumns = [...mappingColumns, ...requiredColumns].filter(col => tableColumns.includes(col));
 
    let insertCount = 0;
    let updateCount = 0;
    let skipCount = 0;
 
    for (const entity of jsonData.entities) {
      const rowData = {};
 
      // Map all columns
      for (const column of columns) {
        const columnName = column.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
        const matchingField = entity.Fields.find(field =>
          field.Name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase() === columnName
        );
 
        if (!matchingField || !matchingField.values || matchingField.values.length === 0) {
          rowData[columnName] = null;
        } else {
          const combinedValue = matchingField.values.map(v => v.value).join(',');
 
          switch (column.ep1_type) {
            case 'Number':
              rowData[columnName] = isNaN(Number(combinedValue)) ? null : Number(combinedValue);
              break;
            case 'Date': {
              const parsedDate = new Date(combinedValue);
              rowData[columnName] = isNaN(parsedDate.getTime()) ? null : parsedDate.toISOString().split('T')[0];
              break;
            }
            case 'String':
            default:
              rowData[columnName] = combinedValue;
          }
        }
      }
 
      // Required fields
      rowData['name'] = entity.Fields.find(f => f.Name === 'name')?.values?.[0]?.value || null;
      rowData['has_link'] = entity.Fields.find(f => f.Name === 'has-linkage')?.values?.[0]?.value || null;
      rowData['has_attachment'] = entity.Fields.find(f => f.Name === 'attachment')?.values?.[0]?.value || null;
      rowData['last_modified'] = entity.Fields.find(f => f.Name === 'last-modified')?.values?.[0]?.value || null;
      rowData['parent_id'] = entity.Fields.find(f => f.Name === 'parent-id')?.values?.[0]?.value || null;
      rowData['qtest_testset_id'] = null;
 
      const setId = Number(entity.Fields.find(f => f.Name === 'id')?.values?.[0]?.value || null);
      const newLastModified = rowData['last_modified'] ? new Date(rowData['last_modified']) : null;
 
      if (!setId) {
        console.warn(`⚠️ Skipping record with missing ID`);
        skipCount++;
        continue;
      }
 
      const existing = existingMap.get(setId);
 
      if (!existing) {
        // INSERT
        rowData['upload_status'] = null;
        const insertCols = allColumns.filter(c => c !== 'id');
        const insertSQL = `INSERT INTO testset (\`id\`, ${insertCols.map(c => `\`${c}\``).join(', ')}) VALUES (?, ${insertCols.map(() => '?').join(', ')})`;
        const values = [setId, ...insertCols.map(c => rowData[c])];
        await db.promise().query(insertSQL, values);
        insertCount++;
      } else {
        // UPDATE or SKIP
        const dbLastModified = existing.last_modified ? new Date(existing.last_modified) : null;
        if (dbLastModified && newLastModified && dbLastModified.getTime() === newLastModified.getTime()) {
          // Same last_modified, skip
          skipCount++;
          continue;
        }
 
        // Determine new upload_status
        let newStatus = existing.upload_status;
        if (existing.qtest_testset_id) {
          if (existing.upload_status === 'completed' || existing.upload_status === 'uploaded') {
            newStatus = 'modified';
          }
        } else {
          newStatus = 'changed';
        }
 
        const updateCols = allColumns.filter(c => c !== 'id' && c !== 'qtest_testset_id');
        const updateSQL = `UPDATE testset SET ${updateCols.map(c => `\`${c}\` = ?`).join(', ')}, upload_status = ? WHERE id = ?`;
        const values = [...updateCols.map(c => rowData[c]), newStatus, setId];
        await db.promise().query(updateSQL, values);
        updateCount++;
      }
    }
 
    const totalProcessed = insertCount + updateCount + skipCount;
 
    res.status(200).json({
      success: true,
      message: "TestSet processed successfully",
      details: {
        inserted: insertCount,
        updated: updateCount,
        skipped: skipCount,
        totalProcessed
      },
      totalCount: totalProcessed
    });
  } catch (error) {
    console.error('Error inserting data:', error);
    res.status(500).json({
      success: false,
      message: `Error inserting data: ${error.message}`
    });
  }
};
 

const credentials = require("../../../data/qTestCredentials.json");

// Global variable to store migration statistics
let uploadStats = {
  total: 0,
  success: 0,
  failed: 0,
  skipped: 0,
  pending: 0
};

const uploadReleaseToQTest = async (payload, releaseId, parentId = null) => {
  try {
    console.log(`📤 Uploading payload for release ID ${releaseId}:`, JSON.stringify(payload, null, 2));

    // Construct URL with query params if parentId is present
    let url = `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/test-suites`;
    if (parentId) {
      url += `?parentId=${parentId}&parentType=test-cycle`;
    }

    console.log(`🔗 API URL: ${url}`);

    const response = await axios.post(
      url,
      payload,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${credentials.apiToken}`,
        },
      }
    );

    if (response.status === 200 || response.status === 201) {
      await db
        .promise()
        .query("UPDATE testset SET upload_status = ?, qtest_testset_id = ? WHERE id = ?",
          ["completed", response.data.id, releaseId]);

      uploadStats.success++;
      uploadStats.pending--;

      return { success: true, qTestId: response.data.id };
    } else {
      await db
        .promise()
        .query("UPDATE testset SET upload_status = ? WHERE id = ?", [
          `failed_${response.status}`,
          releaseId,
        ]);

      uploadStats.failed++;
      uploadStats.pending--;

      return { success: false, error: `HTTP Status: ${response.status}` };
    }
  } catch (error) {
    console.error(`❌ API Error for release ${releaseId}:`, {
      status: error.response?.status,
      statusText: error.response?.statusText,
      data: error.response?.data,
      message: error.message
    });

    const status = error.response?.status || "unknown_error";
    const errorMessage = error.response?.data?.message || error.message || "Unknown error";

    await db
      .promise()
      .query("UPDATE testset SET upload_status = ? WHERE id = ?", [
        `failed_${status}`,
        releaseId,
      ]);

    uploadStats.failed++;
    uploadStats.pending--;

    return { success: false, error: errorMessage, details: error.response?.data };
  }
};


const updateTestSetInQTest = async (payload, testSetId, qTestId) => {
  try {
    const url = `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/test-suites/${qTestId}`;
    console.log(`✏️ Updating test set via PUT: ${url}`);

    const response = await axios.put(
      url,
      payload,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${credentials.apiToken}`,
        },
      }
    );

    if (response.status === 200 || response.status === 201) {
      await db
        .promise()
        .query("UPDATE testset SET upload_status = ? WHERE id = ?", [
          "completed",
          testSetId,
        ]);

      uploadStats.success++;
      uploadStats.pending--;
      return { success: true };
    } else {
      await db
        .promise()
        .query("UPDATE testset SET upload_status = ? WHERE id = ?", [
          `failed_${response.status}`,
          testSetId,
        ]);
      uploadStats.failed++;
      uploadStats.pending--;
      return { success: false, error: `HTTP Status: ${response.status}` };
    }
  } catch (error) {
    const status = error.response?.status || "unknown_error";
    const message = error.response?.data?.message || error.message || "Unknown error";

    await db
      .promise()
      .query("UPDATE testset SET upload_status = ? WHERE id = ?", [
        `failed_${status}`,
        testSetId,
      ]);
    uploadStats.failed++;
    uploadStats.pending--;
    return { success: false, error: message, details: error.response?.data };
  }
};



const processAndUploadAllTestset = async (req, res) => {
  try {
    // Reset statistics before starting
    uploadStats = {
      total: 0,
      success: 0,
      failed: 0,
      skipped: 0,
      pending: 0
    };

    // Fetch the current mapping field name
    const [mappingRow] = await db
      .promise()
      .query("SELECT DISTINCT link_name FROM Field_mappings WHERE artifact_type = 'TestSet'");

    const currentTable = mappingRow.length > 0 ? mappingRow[0].link_name : null;
    if (!currentTable) throw new Error("No active mapping table found.");

    // Fetch mappings
    const [mappings] = await db
      .promise()
      .query(
        "SELECT ep1_name, ep1_type, ep2_label, ep2_field_id FROM Field_mappings WHERE artifact_type = 'TestSet' AND link_name = ?",
        [currentTable]
      );

    console.log("📋 Field mappings:", mappings);

    // Fetch testset that need to be processed
    const [testsetRows] = await db.promise().query("SELECT * FROM testset WHERE upload_status IS NULL OR upload_status LIKE 'failed%' OR upload_status = 'null'");

    // Set initial statistics
    uploadStats.total = testsetRows.length;
    uploadStats.pending = testsetRows.length;

    // Fetch parent ID to qTest ID mappings
    const [parentMappings] = await db.promise().query("SELECT id, qTest_id FROM testsetfolder");
    const parentIdMap = new Map(parentMappings.map(row => [String(row.id), row.qTest_id]));

    console.log("🗂️ Parent ID mappings:", Object.fromEntries(parentIdMap));

    let counter = 1;

    for (let row of testsetRows) {
      console.log(`🔄 Processing TestSet ${counter}/${uploadStats.total}: ${row.name}...`);

      // Create testset name similar to releases logic
      let testsetName = `TestSet_${row.id}`;

      if (row.name && row.name.trim() !== '') {
        testsetName = row.name.trim();
      }

      console.log(`📝 TestSet name: ${testsetName}`);

      const properties = [];

      // Process each mapping
      for (let mapping of mappings) {
        const columnName = mapping.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
        const rawValue = row[columnName];

        console.log(`🔍 Processing field: ${mapping.ep1_name} (${columnName}) = ${rawValue} (type: ${mapping.ep1_type})`);

        // Skip null or undefined values for optional fields
        if (rawValue === null || rawValue === undefined || rawValue === '') {
          console.log(`⚠️ Skipping empty value for ${columnName}`);
          continue;
        }

        if (mapping.ep1_type === "LookupList") {
          // Handle LookupList similar to releases function
          const valuesToCheck = typeof rawValue === 'string' ? rawValue.split(',').map(v => v.trim()) : [rawValue];

          const [valueMappings] = await db.promise().query(`
            SELECT ep1_value, ep2_value_id, ep2_value 
            FROM value_mappings 
            WHERE ep1_name = ? AND ep2_field_id = ?
          `, [mapping.ep1_name, mapping.ep2_field_id]);

          console.log(`🔎 Found ${valueMappings.length} value mappings for ${mapping.ep1_name}`);
          const matchedEp2Ids = [];
          const matchedEp2Names = [];

          valuesToCheck.forEach(value => {
            const match = valueMappings.find(vm => vm.ep1_value === value);
            if (match) {
              matchedEp2Ids.push(match.ep2_value_id);
              matchedEp2Names.push(match.ep2_value);
              console.log(`✅ Matched value: ${value} -> ${match.ep2_value_id} (${match.ep2_value})`);
            } else {
              console.log(`❌ No match found for value: ${value}`);
            }
          });

          if (matchedEp2Ids.length > 0) {
            // Handle single or multiple values
            const fieldValue = matchedEp2Ids.length === 1 ? matchedEp2Ids[0] : matchedEp2Ids;
            const fieldValueName = matchedEp2Names.length === 1 ? matchedEp2Names[0] : matchedEp2Names;

            properties.push({
              field_id: mapping.ep2_field_id,
              field_name: mapping.ep2_label,
              field_value: fieldValue,
              field_value_name: fieldValueName
            });
            console.log(`✅ Added LookupList property: ${mapping.ep2_label} = ${fieldValue} with name ${fieldValueName}`);
          }
        } 
         else if (mapping.ep1_type === "UsersList") {
  const valuesToCheck = typeof rawValue === 'string' 
    ? rawValue.split(',').map(v => v.trim()) 
    : [rawValue];

  for (const value of valuesToCheck) {
    // Query users table to match the Name column
    const [userMatch] = await db.promise().query(`
      SELECT qtest_id, first_name 
      FROM users 
      WHERE Name = ?
      LIMIT 1
    `, [value]);

    if (userMatch.length > 0) {
      const { qtest_id, first_name } = userMatch[0];

      properties.push({
        field_id: mapping.ep2_field_id,
        field_name: mapping.ep2_label,
        field_value: qtest_id,
        field_value_name: first_name
      });

      console.log(`✅ Matched user: ${value} -> ${qtest_id} (${first_name})`);
    } else {
      console.log(`❌ No match found in users table for: ${value}`);
    }
  }
}

        else {
          // Handle other field types with validation similar to releases
          let processedValue = rawValue;

          if (mapping.ep1_type === 'Number') {
            processedValue = isNaN(Number(rawValue)) ? null : Number(rawValue);
          } else if (mapping.ep1_type === 'Date') {
            const parsedDate = new Date(rawValue);
            processedValue = formatDateForQTest(parsedDate);
          } else if (mapping.ep1_type === 'String') {
            processedValue = String(rawValue).trim();
          }

          if (processedValue !== null && processedValue !== '') {
            properties.push({
              field_id: mapping.ep2_field_id,
              field_name: mapping.ep2_label,
              field_value: processedValue
            });
            console.log(`✅ Added ${mapping.ep1_type} property: ${mapping.ep2_label} = ${processedValue}`);
          }
        }
      }

      console.log(`📊 Total properties created: ${properties.length}`);

      // Determine parent-id for the API call, but DO NOT include it in the payload
      let parentId = null;
      if (row.parent_id) {
        const parentQTestId = parentIdMap.get(String(row.parent_id));
        if (parentQTestId) {
          parentId = parentQTestId;
          console.log(`👨‍👩‍👧‍👦 Found parent ID: ${row.parent_id} -> qTest ID: ${parentQTestId}`);
        } else {
          console.log(`⚠️ Parent ID ${row.parent_id} not found in mappings`);
        }
      }

      // Validate required fields similar to releases logic
      if (!testsetName || testsetName.trim() === '' || testsetName === 'TestSet_') {
        console.error(`❌ Skipping testset with invalid name: ${row.id}`);
        await db.promise().query("UPDATE testset SET upload_status = ? WHERE id = ?", ['failed_no_name', row.id]);
        uploadStats.skipped++;
        uploadStats.pending--;
        continue;
      }

      const singlePayload = {
        name: testsetName.trim(),
        properties: properties.filter(prop => prop.field_value !== null && prop.field_value !== undefined)
        // Note: No parent_id here in the payload - it's passed as URL parameter
      };

      console.log(`📋 Final payload:`, JSON.stringify(singlePayload, null, 2));

      // Save payload for debugging
      const outputPath = path.join(__dirname, "../../../data/TestExecutiondatafile/ALMTestSetdata/TestSetFinalPayload.json");
      fs.writeFileSync(outputPath, JSON.stringify(singlePayload, null, 2), "utf8");

      console.log(`📄 Final payload for ${testsetName}:`, JSON.stringify(singlePayload, null, 2));


      let uploadResult;
      if (row.upload_status === 'modified' && row.qtest_testset_id) {
        // Use PUT for updates
        uploadResult = await updateTestSetInQTest(singlePayload, row.id, row.qtest_testset_id);
      } else {
        // Use POST for new or failed uploads
        uploadResult = await uploadReleaseToQTest(singlePayload, row.id, parentId);
      }



      // Pass parentId as a separate argument
      //const uploadResult = await uploadReleaseToQTest(singlePayload, row.id, parentId);

      if (!uploadResult.success) {
        console.error(`❌ Upload failed for TestSet ${testsetName}: ${uploadResult.error}`);
        if (uploadResult.details) {
          console.error(`📋 Error details:`, uploadResult.details);
        }
      } else {
        console.log(`✅ Successfully uploaded TestSet ${testsetName} with ID ${uploadResult.qTestId}`);
      }

      counter++;

      // Add a delay to avoid hitting API rate limits (similar to releases)
      await new Promise(resolve => setTimeout(resolve, 1000));
    }

    res.status(200).json({
      message: "Migration completed",
      counts: uploadStats,
    });
  } catch (error) {
    console.error("❌ Error processing testset:", error.message);
    console.error("❌ Stack trace:", error.stack);
    res.status(500).json({ message: "Migration failed", error: error.message });
  }
};


const getMigrationStatus = async (req, res) => {
  try {
    const [totalCount] = await db.promise().query("SELECT COUNT(*) as count FROM testset");
    const [completedCount] = await db.promise().query("SELECT COUNT(*) as count FROM testset WHERE upload_status = 'completed'");
    const [failedCount] = await db.promise().query("SELECT COUNT(*) as count FROM testset WHERE upload_status LIKE 'failed%'");
    const [pendingCount] = await db.promise().query("SELECT COUNT(*) as count FROM testset WHERE upload_status IS NULL OR upload_status = 'pending'");

    res.status(200).json({
      total: totalCount[0].count,
      success: completedCount[0].count,
      failed: failedCount[0].count,
      pending: pendingCount[0].count
    });
  } catch (error) {
    console.error("❌ Error getting test set migration status:", error.message);
    res.status(500).json({
      message: "Error getting test set migration status",
      error: error.message
    });
  }
};

const getTestSetCount = async (req, res) => {
  try {
    const jsonFilePath = path.join(__dirname, "../../../data/TestExecutiondatafile/ALMTestSetdata/AlmTestSet.json");

    if (!fs.existsSync(jsonFilePath)) {
      return res.status(404).json({ success: false, message: "Test Set JSON not found" });
    }

    const jsonData = JSON.parse(fs.readFileSync(jsonFilePath, "utf8"));
    const totalCount = jsonData.entities?.length || 0;

    res.json({ totalCount });
  } catch (error) {
    console.error("❌ Error in getTestSetCount:", error);
    res.status(500).json({ error: "Failed to fetch testset count" });
  }
};
module.exports = {
  insertSampleData,
  processAndUploadAllTestset,
  getMigrationStatus,
  getTestSetCount
};