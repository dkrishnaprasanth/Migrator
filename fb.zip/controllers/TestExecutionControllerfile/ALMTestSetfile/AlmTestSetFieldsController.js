
const db = require("../../../config/db");
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const { fetchAlmTestSetFields } = require("../../../controllers/TestExecutionControllerfile/ALMTestSetfile/AlmTestSetFields");

const requiredFields = ["label", "name", "type", "physicalName", "required", "listId", "supportsMultivalue", "qteat_id"];

const getrequirementTypeCode = (type, supportsMultivalue) => {

  let v_datatype = 1;
  
  if (!type) return v_datatype;
  
  if (type === 'Number') {
    v_datatype = 7;
  } else if (type === 'String') {
    v_datatype = 1;
  } else if (type === 'LookupList') {
    if (supportsMultivalue) {
      v_datatype = 17;
    } else {
      v_datatype = 3;
    }
  } else if (type === 'UsersList') {
    v_datatype = 5;
  } else if (type === 'Date') {
    v_datatype = 4;
  } else if (type === 'DateTime') {
    v_datatype = 9;
  } else if (type === 'Memo') {
    v_datatype = 2;
  }
  
  // Return the determined data type code
  return v_datatype;
};

const getAlmTestSetFields = async (req, res) => {
  db.query("SELECT * FROM alm_testset_fields", (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    
    const formattedResults = results.map(row => {
      const isRequired = row.required === 1;
      const supportsMultivalue = row.supportsMultivalue === 1;
      
      return {
        ...row,
        required: isRequired,
        supportsMultivalue: supportsMultivalue,
        typeCode: getrequirementTypeCode(row.type, supportsMultivalue)
      };
    });
    
    res.json(formattedResults);
  });
};

// ------------------------------
// Read and Validate JSON
// ------------------------------
const loadJsonAndValidateRequirement = async () => {
  const jsonFilePath = path.join(__dirname, '../../../data/TestExecutiondatafile/ALMTestSetdata/AlmTestSetFields.json');

  try {
    if (!fs.existsSync(jsonFilePath)) {
      console.error(" JSON file does not exist:", jsonFilePath);
      return [];
    }

    const rawData = fs.readFileSync(jsonFilePath, "utf-8");
    const parsedData = JSON.parse(rawData);

    if (
      !Array.isArray(parsedData) &&
      (!parsedData.Fields || !Array.isArray(parsedData.Fields.Field))
    ) {
      console.error(" Unexpected JSON structure:", parsedData);
      return [];
    }

    const normalizedData = Array.isArray(parsedData)
      ? parsedData
      : parsedData.Fields.Field;


    const validated = normalizedData.map((item) => {
      const filtered = {};
      requiredFields.forEach((field) => {
        filtered[field] = item[field] !== undefined ? item[field] : null;
      });
      return filtered;
    });

    return validated;
  } catch (err) {
    console.error(" Error reading/parsing JSON file:", err.message);
    return [];
  }
};


const getAlmTestSetFieldByPhysicalName = async (req, res) => {
  const { physicalName } = req.params;

  if (!physicalName) {
    return res.status(400).json({ error: "Physical name is required" });
  }

  db.query(
    "SELECT * FROM alm_testset_fields WHERE physicalName = ?",
    [physicalName],
    (err, results) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }

      if (results.length === 0) {
        return res.status(404).json({ error: "Field not found" });
      }

      // Convert numeric 0/1 back to boolean true/false for display and add typeCode
      const isRequired = results[0].required === 1;
      const supportsMultivalue = results[0].supportsMultivalue === 1;

      const formattedResult = {
        ...results[0],
        required: isRequired,
        supportsMultivalue: supportsMultivalue,
        typeCode: getrequirementTypeCode(results[0].type, supportsMultivalue)
      };

      res.json(formattedResult);
    }
  );
};

const createAlmTestSetFieldsListJsonFile = async (req, res) => {
  const { physicalName } = req.body;

  if (!physicalName) {
    return res.status(400).json({ error: "Physical name is required" });
  }

  try {
    // Fetch field from alm_testset_fields table
    const result = await new Promise((resolve, reject) => {
      db.query(
        "SELECT * FROM alm_testset_fields WHERE physicalName = ?",
        [physicalName],
        (err, results) => {
          if (err) return reject(err);
          if (!results.length) return reject(new Error("Field not found"));
          resolve(results[0]);
        }
      );
    });

    const isRequired = result.required === 1;
    const supportsMultivalue = result.supportsMultivalue === 1;

    let jsonData;

    if (result.type === "LookupList") {
      if (!result.listId) {
        throw new Error("Missing listId in alm_testset_fields for LookupList");
      }

      // Fetch values from Alm_TestSet_Lists table using listId
      const listValues = await new Promise((resolve, reject) => {
        db.query(
          "SELECT value FROM Alm_TestSet_Lists WHERE id = ?",
          [result.listId],
          (err, results) => {
            if (err) return reject(err);
            if (!results.length) return reject(new Error("No values found in Alm_TestSet_Lists table"));
            resolve(results);
          }
        );
      });

      const allowedValues = listValues.map((item, index) => ({
        label: item.value,
        is_default: false,
        is_active: true,
      }));

      jsonData = {
        label: result.label,
        allowed_values: allowedValues,
        data_type: getrequirementTypeCode(result.type, supportsMultivalue),
        multiple: supportsMultivalue,
        is_active: true,
      };
    } else {
      // Non-lookup field
      jsonData = {
        label: result.label,
        data_type: getrequirementTypeCode(result.type, supportsMultivalue),
        required: isRequired,
        is_active: true,
      };
    }

    const dataDir = path.join(__dirname, "../../../data/TestExecutiondatafile/ALMTestSetdata");
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Write to file
    const filePath = path.join(dataDir, "AlmTestSetListFieldPayload.json");
    fs.writeFileSync(filePath, JSON.stringify(jsonData, null, 2), "utf-8");

    console.log("✅ JSON file created:", filePath);

    res.status(200).json({
      message: "JSON file created successfully",
      data: jsonData,
      filePath,
    });
  } catch (error) {
    console.error("❌ Error creating JSON file:", error.message);
    res.status(error.message === "Field not found" ? 404 : 500).json({
      error: error.message,
    });
  }
};

const initTestSet = async () => {
  try {
    console.log(" Fetching ALM release fields...");
    await fetchAlmTestSetFields();
    console.log("✅ Fetch complete.");
    
    // Create tables if they don't exist
    await createAlmTestSetTables();
    
    // Insert data from JSON
    await insertTestSetFieldsJson();
    
    console.log("✅ ALM initialization complete.");
  } catch (err) {
    console.error(" Failed to initialize ALM data:", err.message);
    process.exit(1);
  }
};

// ------------------------------
// Create Table if not exists
// ------------------------------
const createAlmTestSetTables = async () => {
  try {
    const dropTableQuery = `DROP TABLE IF EXISTS alm_testset_fields`;
    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS alm_testset_fields (
        id INT AUTO_INCREMENT PRIMARY KEY,
        label TEXT,
        name TEXT,
        type TEXT,
        physicalName TEXT,
        required TINYINT(1),
        listId INT,
        supportsMultivalue TINYINT(1),
        qteat_id INT
      );
    `;

    await new Promise((resolve, reject) => {
      db.query(dropTableQuery, (dropErr) => {
        if (dropErr) {
          console.error("❌ Error dropping table:", dropErr.message);
          return reject(dropErr);
        }
        resolve();
      });
    });

    await new Promise((resolve, reject) => {
      db.query(createTableQuery, (createErr) => {
        if (createErr) {
          console.error("❌ Error creating table:", createErr.message);
          return reject(createErr);
        }
        console.log("✅ Table 'alm_testset_fields' created successfully.");
        resolve();
      });
    });

    return true;
  } catch (err) {
    throw err;
  }
};

// ------------------------------
// Insert JSON Data into DB
// ------------------------------
const insertTestSetFieldsJson = async () => {
  try {
    const jsonData = await loadJsonAndValidateRequirement();

    return new Promise((resolve, reject) => {
      db.query("SELECT COUNT(*) AS count FROM alm_testset_fields", (err, results) => {
        if (err) {
          console.error(" Error checking existing data:", err.message);
          return reject(err);
        }

        if (results[0].count > 0) {
          console.log(" Data already exists. Skipping insertion.");
          return resolve(false);
        }

        if (jsonData.length === 0) {
          console.log(" No valid data to insert.");
          return resolve(false);
        }

        const insertPromises = jsonData.map((item) => {
          return new Promise((resolve, reject) => {
            const sql = `
              INSERT INTO alm_testset_fields (label, name, type, physicalName, required, listId, supportsMultivalue, qteat_id)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            `;
            
            const values = [
              item.label || null,
              item.name || null,
              item.type || null,
              item.physicalName || null,
              item.required === true ? 1 : 0, // Convert boolean to 0/1
              item.listId,
              item.supportsMultivalue === true ? 1 : 0, // Convert boolean to 0/1
              item.qteat_id || null
            ];
            
            db.query(sql, values, (err, result) => {
              if (err) {
                console.error(" Error inserting row:", err.message);
                return reject(err);
              }
              resolve(result);
            });
          });
        });
        
        Promise.all(insertPromises)
          .then(() => {
            console.log(`✅ ${jsonData.length} records inserted successfully.`);
            resolve(true);
          })
          .catch(err => {
            console.error(" Error in batch insertion:", err.message);
            reject(err);
          });
      });
    });
  } catch (err) {
    console.error(" Failed to insert data:", err.message);
    throw err;
  }
};

// Clear table and insert new data
const refreshAlmTestSetFields = async (req, res) => {
  try {
    // Fetch fresh data from ALM
    await fetchAlmTestSetFields();
    
    // Load the new data from JSON
    const jsonData = await loadJsonAndValidateRequirement();
    
    if (jsonData.length === 0) {
      return res.status(400).json({ error: "No valid data to insert" });
    }
    
    // Clear existing table data
    await new Promise((resolve, reject) => {
      db.query("DELETE FROM alm_testset_fields", (err) => {
        if (err) {
          console.error(" Error clearing table:", err.message);
          return reject(err);
        }
        console.log("✅ Table 'alm_testset_fields' cleared successfully.");
        resolve();
      });
    });
    
    // Insert new data with proper handling of boolean values
    const insertPromises = jsonData.map((item) => {
      return new Promise((resolve, reject) => {
        const sql = `
          INSERT INTO alm_testset_fields (label, name, type, physicalName, required, listId, supportsMultivalue, qteat_id)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `;
        
        // Convert boolean values to 0/1 for database storage
        const values = [
          item.label || null,
          item.name || null,
          item.type || null,
          item.physicalName || null,
          item.required === true ? 1 : 0, // Convert boolean to 0/1
          item.listId,
          item.supportsMultivalue === true ? 1 : 0,
          item.qteat_id || null
        ];
        
        db.query(sql, values, (err, result) => {
          if (err) {
            console.error(" Error inserting row:", err.message);
            return reject(err);
          }
          resolve(result);
        });
      });
    });
    
    await Promise.all(insertPromises);
    
    return res.status(200).json({ 
      message: "ALM data refreshed successfully", 
      count: jsonData.length 
    });
  } catch (error) {
    console.error(" Failed to refresh ALM data:", error.message);
    return res.status(500).json({ error: error.message });
  }
};

// ------------------------------
// Get All Test Cases
// ------------------------------
const getAllAlmTestSetFields = (req, res) => {
  db.query("SELECT * FROM alm_testset_fields", (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    
    const formattedResults = results.map(row => {
      const isRequired = row.required === 1;
      const supportsMultivalue = row.supportsMultivalue === 1;
      
      return {
        ...row,
        required: isRequired,
        supportsMultivalue: supportsMultivalue,
        typeCode: getrequirementTypeCode(row.type, supportsMultivalue)
      };
    });
    
    res.json(formattedResults);
  });
};

// ------------------------------
// Insert New Test Cases (API)
// ------------------------------
const insertTestSetFields = async (req, res) => {
  const testCases = req.body;

  if (!Array.isArray(testCases) || testCases.length === 0) {
    return res
      .status(400)
      .json({ message: "Invalid input, expecting an array of test cases" });
  }
  const insertPromises = testCases.map((item) => {
    return new Promise((resolve, reject) => {
      const sql = `
        INSERT INTO alm_testset_fields (label, name, type, physicalName, required, listId, supportsMultivalue, qteat_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `;
      
      const values = [
        item.label || null,
        item.name || null,
        item.type || null,
        item.physicalName || null,
        item.required === true ? 1 : 0, 
        item.listId,
        item.supportsMultivalue === true ? 1 : 0,
        item.qteat_id || null
      ];
      
      db.query(sql, values, (err, result) => {
        if (err) {
          console.error(" Error inserting row:", err.message);
          return reject(err);
        }
        resolve(result);
      });
    });
  });

  try {
    await Promise.all(insertPromises);
    res.status(201).json({ 
      message: `${testCases.length} new test cases added successfully` 
    });
  } catch (err) {
    console.error(" Error inserting data:", err.message);
    return res.status(500).json({ error: err.message });
  }
};


const uploadAlmTestSetFields = async (req, res) => {
  try {
    const credentialsPath = path.join(__dirname, "../../../data/qTestCredentials.json");
    const credentialsData = fs.readFileSync(credentialsPath, "utf-8");
    const config = JSON.parse(credentialsData);

    const qTestDomain = config.qTestDomain;
    const apiToken = config.apiToken;
    const projectId = config.projectId;

    const payloadPath = path.join(__dirname, "../../../data/TestExecutiondatafile/ALMTestSetdata/AlmTestSetListFieldPayload.json"); // Match this with your create function
    const payload = JSON.parse(fs.readFileSync(payloadPath, "utf-8"));

    const response = await axios.post(
      `${qTestDomain}/api/v3/projects/${projectId}/settings/test-suites/fields`,
      payload,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiToken}`,
        },
      }
    );

    console.log("✅ Uploaded to qTest");
    res.status(200).json({
      message: "Uploaded to qTest successfully",
      statusCode: response.status,
      data: response.data,
    });
  } catch (error) {
    console.error("❌ Upload error:", error.message);
    res.status(500).json({
      error: error.message,
    });
  }
};



const gettestsetListValues = async (req, res) => {
  const { listId} = req.params;
  
  if (!listId ) {
    return res.status(400).json({ error: "listId is required" });
  }

  db.query(
    "SELECT value FROM Alm_TestSet_Lists WHERE id = ? ",
    [listId ],
    (err, results) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      res.json(results);
    }
  );
};


module.exports = {
  initTestSet,
  createAlmTestSetTables,
  insertTestSetFieldsJson,
  getAllAlmTestSetFields,
  getAlmTestSetFields,
  insertTestSetFields,
  refreshAlmTestSetFields,
  createAlmTestSetFieldsListJsonFile,
  getAlmTestSetFieldByPhysicalName ,
  uploadAlmTestSetFields,
  gettestsetListValues
};

