const fs = require("fs");
const path = require("path");
const db = require("../../../config/db");


const createMappingTable = async () => {
  try {
    const createReleasesMappingQuery = `
      CREATE TABLE IF NOT EXISTS Field_mappings (
        id INT PRIMARY KEY AUTO_INCREMENT,
        ep1_label VARCHAR(255) NOT NULL,
        ep1_name VARCHAR(255) NOT NULL,
        ep1_physical_name VARCHAR(255),
        ep1_type VARCHAR(255),
        ep2_label VARCHAR(255) NOT NULL,
        ep2_field_id INT NOT NULL,
        ep2_type VARCHAR(255),
        artifact_type VARCHAR(255),          
        link_name VARCHAR(255),            
        is_current BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )`;

    await db.promise().query(createReleasesMappingQuery);
    console.log("Field Mappings Table Verified/Created");
  } catch (err) {
    console.error("Error Creating Field Mappings Table:", err);
  }
};

// Value Mappings Table Creation
const createValueMappingTable = async () => {
  try {
    const createValueMappingsQuery = `
      CREATE TABLE IF NOT EXISTS value_mappings (
        id INT PRIMARY KEY AUTO_INCREMENT,
        ep1_label VARCHAR(255) NOT NULL,
        ep1_name VARCHAR(255) NOT NULL,
        ep1_value VARCHAR(255),
        ep1_type VARCHAR(255),
        ep2_label VARCHAR(255) NOT NULL,
        ep2_field_id INT NOT NULL,
        ep2_value VARCHAR(255),
        ep2_value_id VARCHAR(255),
        ep2_type VARCHAR(255),
        artifact_type VARCHAR(255),
        link_name VARCHAR(255),
        field_mapping_id INT,
        is_current BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (field_mapping_id) REFERENCES Field_mappings(id) ON DELETE CASCADE
      )`;

    await db.promise().query(createValueMappingsQuery);
    console.log("Value Mappings Table Verified/Created");
  } catch (err) {
    console.error("Error Creating Value Mappings Table:", err);
  }
};

const processLinkName = async (mappings) => {
  // Get the structure of link_table to see available columns
  const [tableInfo] = await db.promise().query("DESCRIBE link_table");
  const columns = tableInfo.map(col => col.Field);

  // Determine the appropriate ordering column
  let orderColumn = 'id'; // Default fallback
  if (columns.includes('created_at')) {
    orderColumn = 'created_at';
  } else if (columns.includes('creation_date')) {
    orderColumn = 'creation_date';
  }

  console.log(`Using ${orderColumn} for ordering in link_table queries`);

  // Process link_name for each mapping
  for (const mapping of mappings) {
    if (mapping.link_name && mapping.link_name.trim() !== '') {
      // Check if this specific link_name exists in link_table
      const [linkResult] = await db.promise().query(
        "SELECT link_name FROM link_table WHERE link_name = ? AND is_current = 1",
        [mapping.link_name]
      );

      if (linkResult.length === 0) {
        // If specific link_name not found, get the default current link_name
        const [defaultLink] = await db.promise().query(
          `SELECT link_name FROM link_table WHERE is_current = 1 ORDER BY ${orderColumn} DESC LIMIT 1`
        );

        if (defaultLink.length === 0) {
          throw new Error(`No active link_name found in link_table. The provided value '${mapping.link_name}' cannot be used.`);
        }

        // Use the default link_name
        mapping.link_name = defaultLink[0].link_name;
        console.log(`Using default link_name: ${mapping.link_name}`);
      } else {
        // Confirm we're using the validated link_name from the database
        mapping.link_name = linkResult[0].link_name;
        console.log(`Using validated link_name: ${mapping.link_name}`);
      }
    } else if (mapping.link_name === '') {
      // If link_name is empty string, set to null
      mapping.link_name = null;
    } else {
      // If no link_name specified, try to get the default current one
      const [defaultLink] = await db.promise().query(
        `SELECT link_name FROM link_table WHERE is_current = 1 ORDER BY ${orderColumn} DESC LIMIT 1`
      );

      if (defaultLink.length > 0) {
        mapping.link_name = defaultLink[0].link_name;
        console.log(`Using default link_name: ${mapping.link_name}`);
      } else {
        mapping.link_name = null;
        console.log("No default link_name available, setting to null");
      }
    }
  }

  console.log(`Processed ${mappings.length} mappings with link_name validation`);
};

const saveMappings = async (req, res) => {
  try {
    await createMappingTable(); // Ensure both tables exist

    const { mappings, tableName } = req.body;

    // Step 1: Get the current link_name
    const [rows] = await db.promise().query(
      `SELECT link_name FROM link_table WHERE is_current = TRUE LIMIT 1`
    );

    const linkName = rows.length > 0 ? rows[0].link_name : null;

    if (!linkName) {
      throw new Error("No current link_name found in link_table");
    }

    // Step 2: Delete old mappings for this artifact_type and link_name
    await db.promise().query(
      `DELETE FROM Field_mappings WHERE link_name = ? AND artifact_type = ?`,
      [linkName, 'TestSet']
    );


    if (!Array.isArray(mappings) || mappings.length === 0 || !tableName) {
      return res.status(400).json({ message: "Invalid data" });
    }

    const sanitizedTableName = tableName.replace(/[^a-zA-Z0-9_]/g, '_');

    // Check for existing table name in Field_mappings
    const [existingTable] = await db.promise().query(
      "SELECT link_name FROM Field_mappings WHERE link_name = ? LIMIT 1",
      [sanitizedTableName]
    );

    if (existingTable.length > 0) {
      return res.status(400).json({
        message: `Table name '${sanitizedTableName}' already exists. Choose a different name.`
      });
    }

    await processLinkName(mappings);

    // Get the structure of link_table to see available columns
    const [tableInfo] = await db.promise().query("DESCRIBE link_table");
    const columns = tableInfo.map(col => col.Field);

    // Determine the appropriate ordering column
    let orderColumn = 'id'; // Default fallback
    if (columns.includes('created_at')) {
      orderColumn = 'created_at';
    } else if (columns.includes('creation_date')) {
      orderColumn = 'creation_date';
    }

    console.log(`Using ${orderColumn} for ordering in link_table queries`);

    // Improved link_name handling
    for (const mapping of mappings) {
      // If mapping has a link_name specified
      if (mapping.link_name && mapping.link_name.trim() !== '') {
        // Check if this specific link_name exists in link_table
        const [linkResult] = await db.promise().query(
          "SELECT link_name FROM link_table WHERE link_name = ? AND is_current = 1",
          [mapping.link_name]
        );

        if (linkResult.length === 0) {
          // If specific link_name not found, get the default current link_name
          const [defaultLink] = await db.promise().query(
            `SELECT link_name FROM link_table WHERE is_current = 1 ORDER BY ${orderColumn} DESC LIMIT 1`
          );

          if (defaultLink.length === 0) {
            return res.status(400).json({
              message: `No active link_name found in link_table. The provided value '${mapping.link_name}' cannot be used.`
            });
          }

          // Use the default link_name
          mapping.link_name = defaultLink[0].link_name;
          console.log(`Using default link_name: ${mapping.link_name}`);
        } else {
          // Confirm we're using the validated link_name from the database
          mapping.link_name = linkResult[0].link_name;
          console.log(`Using validated link_name: ${mapping.link_name}`);
        }
      } else if (mapping.link_name === '') {
        // If link_name is empty string, set to null
        mapping.link_name = null;
      } else {
        // If no link_name specified, try to get the default current one
        const [defaultLink] = await db.promise().query(
          `SELECT link_name FROM link_table WHERE is_current = 1 ORDER BY ${orderColumn} DESC LIMIT 1`
        );

        if (defaultLink.length > 0) {
          mapping.link_name = defaultLink[0].link_name;
          console.log(`Using default link_name: ${mapping.link_name}`);
        } else {
          mapping.link_name = null;
          console.log("No default link_name available, setting to null");
        }
      }
    }

    // Log confirmation after processing all mappings
    console.log(`Processed ${mappings.length} mappings with link_name validation`);

    await processLinkName(mappings);

    await db.promise().query("UPDATE Field_mappings SET is_current = FALSE");

    const insertedMappings = [];

    for (const mapping of mappings) {
      const insertQuery = `
        INSERT INTO Field_mappings (
          ep1_label, ep1_name, ep1_physical_name,
          ep1_type, ep2_label, ep2_field_id, ep2_type,
          artifact_type, link_name, is_current
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

      const values = [
        mapping.ep1_label,
        mapping.ep1_name,
        mapping.ep1_physical_name,
        mapping.ep1_type,
        mapping.ep2_label,
        mapping.ep2_field_id,
        mapping.ep2_type,
        mapping.artifact_type || null,
        mapping.link_name || null,
        true
      ];

      const [result] = await db.promise().query(insertQuery, values);
      insertedMappings.push({
        ...mapping,
        field_mapping_id: result.insertId
      });
    }

    console.log("Field Mappings saved successfully");

    // Update any existing value mappings to reference the new field mappings
    await updateValueMappingsWithFieldIds(insertedMappings);

    await recreateNewTable(); // Optional: handle table recreation logic


    return res.status(201).json({
      message: `${insertedMappings.length} field mappings saved successfully`,
      mappingsAdded: insertedMappings.length,
      tableName: sanitizedTableName,
      fieldMappingIds: insertedMappings.map(m => m.field_mapping_id)
    });

  } catch (error) {
    console.error("Error saving mappings:", error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};


const updateValueMappingsWithFieldIds = async (fieldMappings) => {
  try {
    for (const fieldMapping of fieldMappings) {
      // Update value mappings that match this field mapping
      const updateQuery = `
        UPDATE value_mappings 
        SET field_mapping_id = ? 
        WHERE ep1_name = ? AND ep2_field_id = ? AND link_name = ?
      `;

      await db.promise().query(updateQuery, [
        fieldMapping.field_mapping_id,
        fieldMapping.ep1_name,
        fieldMapping.ep2_field_id,
        fieldMapping.link_name
      ]);
    }
    console.log("Value mappings updated with field mapping IDs");
  } catch (error) {
    console.error("Error updating value mappings with field IDs:", error);
  }
};



// Save Value Mappings
const savetestsetValueMappings = async (req, res) => {
  try {
    await createValueMappingTable(); 
    
    const { mappings, tableName } = req.body;

    // Step 1: Get the current link_name
    const [rows] = await db.promise().query(
      `SELECT link_name FROM link_table WHERE is_current = TRUE LIMIT 1`
    );

    const linkName = rows.length > 0 ? rows[0].link_name : null;

    if (!linkName) {
      throw new Error("No current link_name found in link_table");
    }

    // Step 2: Delete old mappings for this artifact_type and link_name
    await db.promise().query(
      `DELETE FROM value_mappings WHERE link_name = ? AND artifact_type = ?`,
      [linkName, 'TestSet']
    );


    if (!Array.isArray(mappings) || mappings.length === 0 || !tableName) {
      return res.status(400).json({ message: "Invalid data" });
    }

    const sanitizedTableName = tableName.replace(/[^a-zA-Z0-9_]/g, '_');

    // Check if table name already exists in value_mappings
    const [existingTable] = await db.promise().query(
      "SELECT link_name FROM value_mappings WHERE link_name = ? LIMIT 1",
      [sanitizedTableName]
    );

    if (existingTable.length > 0) {
      return res.status(400).json({
        message: `Table name '${sanitizedTableName}' already exists. Choose a different name.`
      });
    }

    // Process link_name validation
    await processLinkName(mappings);

    // Set all existing mappings as not current
    await db.promise().query("UPDATE value_mappings SET is_current = FALSE");

    // Find corresponding field mapping IDs for each value mapping
    const enrichedMappings = [];

    for (const mapping of mappings) {
      let fieldMappingId = mapping.value_mapping_id || null;

      // If no field mapping ID provided, try to find it
      if (!fieldMappingId) {
        const [fieldMapping] = await db.promise().query(
          `SELECT id FROM Field_mappings 
           WHERE ep1_name = ? AND ep2_field_id = ? AND link_name = ? AND is_current = TRUE`,
          [mapping.ep1_name, mapping.ep2_field_id, mapping.link_name]
        );

        if (fieldMapping.length > 0) {
          fieldMappingId = fieldMapping[0].id;
        }
      }

      enrichedMappings.push({
        ...mapping,
        field_mapping_id: fieldMappingId
      });
    }

    // Prepare mapping values for bulk insert
    const values = enrichedMappings.map(mapping => [
      mapping.ep1_label,
      mapping.ep1_name,
      mapping.ep1_value,
      mapping.ep1_type,
      mapping.ep2_label,
      mapping.ep2_field_id,
      mapping.ep2_value,
      mapping.ep2_value_id,
      mapping.ep2_type,
      mapping.artifact_type || null,
      mapping.link_name || null,
      mapping.value_mapping_id || null,
      true
    ]);

    // Insert new mappings
    const insertQuery = `
      INSERT INTO value_mappings (
        ep1_label, ep1_name, ep1_value,
        ep1_type, ep2_label, ep2_field_id,
        ep2_value, ep2_value_id, ep2_type,
        artifact_type, link_name,field_mapping_id, is_current
      ) VALUES ?
    `;

    await db.promise().query(insertQuery, [values]);

    console.log("Value Mappings saved successfully");


    return res.status(201).json({
      message: `${values.length} value mappings saved successfully`,
      mappingsAdded: values.length,
      tableName: sanitizedTableName
    });

  } catch (error) {
    console.error("Error saving value mappings:", error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};


const getAlmFieldData = async (req, res) => {
  try {
    const { ep1_physical_name } = req.params;

    if (!ep1_physical_name) {
      return res.status(400).json({ message: "ALM physical name is required" });
    }

    // Query to fetch the row matching the ep1_physical_name
    const query = `
      SELECT
        ep1_label,
        ep1_name,
        ep1_physical_name,
        ep1_type,
        ep2_label,
        ep2_field_id,
        ep2_type,
        link_name,
        is_current
      FROM Field_mappings
      WHERE ep1_physical_name = ?
    `;

    const [rows] = await db.promise().query(query, [ep1_physical_name]);

    if (rows.length === 0) {
      return res.status(404).json({ message: "No data found for this ALM physical name" });
    }

    // Return the first matching row
    res.status(200).json(rows[0]);
  } catch (error) {
    console.error("Error fetching ALM field data:", error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

const getCurrentTableName = async () => {
  try {
    const [rows] = await db.promise().query(
      'SELECT DISTINCT link_name FROM Field_mappings WHERE is_current = TRUE LIMIT 1'
    );
    return rows.length > 0 ? rows[0].link_name : null;
  } catch (error) {
    console.error("Error retrieving current table name:", error);
    return null;
  }
};

const getAllTableNames = async () => {
  const allRows = [];

  try {
    const [fieldRows] = await db.promise().query(`
      SELECT
        link_name,
        MAX(created_at) as created_date,
        MAX(is_current) as is_current,
        'field_mapping' as mapping_type
      FROM Field_mappings
      GROUP BY link_name
      ORDER BY created_date DESC
    `);
    allRows.push(...fieldRows);
  } catch (err) {
    console.error("❌ Field_mappings query failed:", err.message);
  }

  try {
    const [valueRows] = await db.promise().query(`
      SELECT
        link_name,
        MAX(created_at) as created_date,
        MAX(is_current) as is_current,
        'value_mapping' as mapping_type
      FROM value_mappings
      GROUP BY link_name
      ORDER BY created_date DESC
    `);
    allRows.push(...valueRows);
  } catch (err) {
    console.error("❌ value_mappings query failed:", err.message);
  }

  return allRows.map(row => ({
    tableName: row.link_name,
    createdAt: row.created_date,
    isCurrent: Boolean(row.is_current),
    mappingType: row.mapping_type
  }));
};

const fetchCurrentTableName = async (req, res) => {
  try {
    const tableName = await getCurrentTableName();
    if (tableName) {
      res.status(200).json({ tableName, isCurrent: true });
    } else {
      res.status(404).json({ message: "No current table name found" });
    }
  } catch (error) {
    console.error("Error in fetchCurrentTableName:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const fetchAllTableNames = async (req, res) => {
  try {
    const tableNames = await getAllTableNames();
    if (tableNames && tableNames.length > 0) {
      res.status(200).json({ tables: tableNames });
    } else {
      res.status(404).json({ message: "No table names found" });
    }
  } catch (error) {
    console.error("Error in fetchAllTableNames:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const setCurrentTable = async (req, res) => {
  try {
    const { tableName, mappingType } = req.body;

    if (!tableName) {
      return res.status(400).json({ message: "Table name is required" });
    }

    const tableToCheck = mappingType === 'value_mapping' ? 'value_mappings' : 'Field_mappings';

    const [tableExists] = await db.promise().query(
      `SELECT COUNT(*) as count FROM ${tableToCheck} WHERE link_name = ?`,
      [tableName]
    );

    if (tableExists[0].count === 0) {
      return res.status(404).json({ message: "Table not found in records" });
    }

    // Update the appropriate table
    await db.promise().query(`UPDATE ${tableToCheck} SET is_current = FALSE`);
    await db.promise().query(
      `UPDATE ${tableToCheck} SET is_current = TRUE WHERE link_name = ?`,
      [tableName]
    );

    res.status(200).json({ message: `Table ${tableName} set as current` });
  } catch (error) {
    console.error("Error in setCurrentTable:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const getStoredTableName = async () => {
  try {
    const [rows] = await db.promise().query(
      'SELECT DISTINCT link_name FROM Field_mappings LIMIT 1'
    );

    return rows.length > 0 ? rows[0].link_name : null;
  } catch (error) {
    console.error("Error retrieving stored table name:", error);
    return null;
  }
};

const fetchStoredTableName = async (req, res) => {
  try {
    const tableName = await getStoredTableName();
    if (tableName) {
      res.status(200).json({ tableName });
    } else {
      res.status(404).json({ message: "No table name found" });
    }
  } catch (error) {
    console.error("Error in fetchStoredTableName:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// Get mappings for a specific table name
const getMappingsForTable = async (req, res) => {
  try {
    const { tableName } = req.params;
    const { artifactType, mappingType } = req.query;

    if (!tableName) {
      return res.status(400).json({ message: "Table name is required" });
    }

    console.log(`🔍 Fetching mappings for table: ${tableName}, artifact: ${artifactType}, type: ${mappingType}`);

    // Get field mappings first
    let fieldQuery = `
      SELECT
        id, ep1_label, ep1_name, ep1_physical_name, ep1_type,
        ep2_label, ep2_field_id, ep2_type,
        artifact_type, link_name
      FROM Field_mappings
      WHERE link_name = ?
    `;

    const fieldParams = [tableName];

    // Add artifact type filter if specified for field mappings
    if (artifactType) {
      fieldQuery += ' AND artifact_type = ?';
      fieldParams.push(artifactType);
    }

    console.log(`🔍 Field query: ${fieldQuery}`);
    console.log(`🔍 Field params:`, fieldParams);

    const [fieldMappings] = await db.promise().query(fieldQuery, fieldParams);

     if (!fieldMappings || fieldMappings.length === 0) {
      console.warn(`⚠️ No field mappings found for table: ${tableName}`);
      return res.status(200).json([]); // ✅ return empty array instead of 500
    }


    console.log(`✅ Found ${fieldMappings.length} field mappings`);

    // Enhanced field mappings with value mappings
    const enhancedMappings = [];

    for (const fieldMapping of fieldMappings) {
      // Get value mappings for this field mapping
      const valueQuery = `
        SELECT
          ep1_label, ep1_name, ep1_value, ep1_type,
          ep2_label, ep2_field_id, ep2_value, ep2_value_id, ep2_type,
          artifact_type, link_name,field_mapping_id
        FROM value_mappings
        WHERE field_mapping_id = ? AND link_name = ?
      `;

  let valueMappings = [];
      try {
        const [rows] = await db.promise().query(valueQuery, [fieldMapping.id, tableName]);
        valueMappings = rows || [];
        console.log(` Found ${valueMappings.length} value mappings for field: ${fieldMapping.ep1_name}`);
      } catch (err) {
        console.error(`❌ Error fetching value mappings for fieldMapping ${fieldMapping.id}:`, err.message);
        valueMappings = [];
      }
      // Process value mappings into a structured format
      let processedValueMappings = {};

      if (valueMappings.length > 0) {
        // Group value mappings by source values
        valueMappings.forEach(valueMapping => {
          if (valueMapping.ep1_value && valueMapping.ep2_value_id) {
            processedValueMappings[valueMapping.ep1_value] = {
              value: valueMapping.ep2_value_id,
              label_value: valueMapping.ep2_value
            };
          }
        });
      }

      // Create enhanced field mapping object
      const enhancedMapping = {
        // Field mapping data
        id: fieldMapping.id,
        ep1_label: fieldMapping.ep1_label,
        ep1_name: fieldMapping.ep1_name,
        ep1_physical_name: fieldMapping.ep1_physical_name,
        ep1_type: fieldMapping.ep1_type,
        ep2_label: fieldMapping.ep2_label,
        ep2_field_id: fieldMapping.ep2_field_id,
        ep2_type: fieldMapping.ep2_type,
        artifact_type: fieldMapping.artifact_type,
        link_name: fieldMapping.link_name,

        // Value mappings data
        value_mappings: Object.keys(processedValueMappings).length > 0 ? processedValueMappings : null,
        has_value_mappings: Object.keys(processedValueMappings).length > 0,
        value_mapping_count: Object.keys(processedValueMappings).length
      };

      enhancedMappings.push(enhancedMapping);
    }

    console.log(`✅ Returning ${enhancedMappings.length} enhanced mappings with value mappings`);

    return res.status(200).json(enhancedMappings);

  } catch (error) {
    console.error("❌ Error getting mappings for table:", error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};



const recreateNewTable = async () => {
  try {
    const [rows] = await db.promise().query('SELECT ep1_name, ep1_type FROM Field_mappings WHERE artifact_type = "TestSet" AND link_name = (SELECT link_name FROM link_table WHERE is_current = 1 LIMIT 1)');

    if (rows.length === 0) {
      console.log('No mappings found to create testset.');
      return;
    }

    console.log('Dropping existing `testset`...');
    await db.promise().query('DROP TABLE IF EXISTS testset');

    let createTableSQL = `CREATE TABLE testset (
      id INT PRIMARY KEY,`;

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const columnName = row.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();

      if (columnName === 'id') continue;

      let columnType = 'TEXT';
      if (row.ep1_type === 'String') columnType = 'VARCHAR(255)';
      if (row.ep1_type === 'Number') columnType = 'INT';
      if (row.ep1_type === 'Date') columnType = 'DATE';

      createTableSQL += `\`${columnName}\` ${columnType}`;
      if (i < rows.length - 1 || true) {
        createTableSQL += ', ';
      }
    }

    createTableSQL += `
     
      name TEXT,
      has_link VARCHAR(500),
      has_attachment VARCHAR(500),
      last_modified TIMESTAMP,
      parent_id INT,
      qtest_testset_id INT,
      upload_status TEXT
    )`;

    console.log('Creating new `testset` table with SQL:', createTableSQL);
    await db.promise().query(createTableSQL);

    console.log('`testset` table created successfully.');
  } catch (error) {
    console.error('Error Creating testset:', error);
  }
};

const { insertSampleData, processAndUploadAllTestset } = require("../../TestExecutionControllerfile/ALMTestSetfile/MappingTestSet");

const insertSampleMappingData = async (req, res) => {
  try {
    await insertSampleData();
    res.status(201).json({ success: true, message: "Sample data inserted successfully" });
  } catch (error) {
    console.error("Error inserting sample data:", error);
    res.status(500).json({ success: false, message: "Error inserting sample data" });
  }
};

const getMappingData = async (req, res) => {
  try {
    const data = await processAndUploadAllTestset();
    res.status(200).json({ success: true, data });
  } catch (error) {
    console.error("Error getting mapping data:", error);
    res.status(500).json({ success: false, message: "Error getting mapping data" });
  }
};


module.exports = {
  saveMappings,
  createMappingTable,
  fetchCurrentTableName,
  fetchAllTableNames,
  setCurrentTable,
  fetchStoredTableName,
  getMappingData,
  insertSampleMappingData,
  getMappingsForTable,
  getAlmFieldData,


  savetestsetValueMappings,
  processLinkName,
  updateValueMappingsWithFieldIds
};
