const fs = require("fs");
const path = require("path");
const db = require("../config/db");
const axios = require("axios");

// Consistent data directory path
const DATA_DIR = path.join(__dirname, "../data");

// Create combined settings table if it doesn't exist
const createTableIfNeeded = (callback) => {
  const createTableQuery = `
    CREATE TABLE IF NOT EXISTS link_table (
      link_name VARCHAR(255),
      
      /* ALM settings */
      almServerUrl VARCHAR(255),
      username VARCHAR(255),
      password VARCHAR(255),
      domain VARCHAR(100),
      project VARCHAR(100),
      
      /* qTest settings */
      qTestDomain VARCHAR(255),
      apiToken VARCHAR(255),
      projectId VARCHAR(100),
      
      /* Added new fields */
      is_current BOOLEAN DEFAULT FALSE,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `;

  db.query(createTableQuery, callback);
};

// Create delete history table if it doesn't exist
const createDeleteTableIfNeeded = (callback) => {
  const createDeleteTableQuery = `
    CREATE TABLE IF NOT EXISTS delete_link_table (
      id INT AUTO_INCREMENT PRIMARY KEY,
      link_name VARCHAR(255),
      
      /* ALM settings */
      almServerUrl VARCHAR(255),
      username VARCHAR(255),
      password VARCHAR(255),
      domain VARCHAR(100),
      project VARCHAR(100),
      
      /* qTest settings */
      qTestDomain VARCHAR(255),
      apiToken VARCHAR(255),
      projectId VARCHAR(100),
      
      /* Delete history fields */
      was_current BOOLEAN DEFAULT FALSE,
      original_created_at TIMESTAMP NULL,
      deleted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      deleted_by VARCHAR(255) DEFAULT 'system'
    )
  `;

  db.query(createDeleteTableQuery, callback);
};

// Create restore field mappings table if it doesn't exist
const createRestoreFieldMappingsTableIfNeeded = (callback) => {
  const createRestoreFieldMappingsTableQuery = `
    CREATE TABLE IF NOT EXISTS restore_field_mappings (
      id INT AUTO_INCREMENT PRIMARY KEY,
      ep1_label VARCHAR(255) NOT NULL,
      ep1_name VARCHAR(255) NOT NULL,
      ep1_physical_name VARCHAR(255),
      ep1_type VARCHAR(255),
      ep2_label VARCHAR(255) NOT NULL,
      ep2_field_id INT NOT NULL,
      ep2_type VARCHAR(255),
      artifact_type VARCHAR(255),          
      link_name VARCHAR(255),             
      is_current BOOLEAN DEFAULT FALSE,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      moved_to_restore_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `;

  db.query(createRestoreFieldMappingsTableQuery, callback);
};

// Add this new function to check if name exists
exports.checkNameExists = (req, res) => {
  const { name } = req.params;

  createTableIfNeeded((err) => {
    if (err) return res.status(500).json({ error: "Failed to create table", details: err.message });

    db.query("SELECT COUNT(*) as count FROM link_table WHERE link_name = ?", [name], (err, results) => {
      if (err) return res.status(500).json({ error: "Failed to check name", details: err.message });

      const exists = results[0].count > 0;
      res.json({ exists });
    });
  });
};

// Updated saveSystemSettings function with duplicate check
exports.saveSystemSettings = (req, res) => {
  const {
    link_name,
    // ALM fields
    almServerUrl, username, password, domain, project,
    // qTest fields
    qTestDomain, apiToken, projectId
  } = req.body;

  // Validate that link_name is provided
  if (!link_name) {
    return res.status(400).json({ error: "Settings name (link_name) is required" });
  }

  createTableIfNeeded((err) => {
    if (err) return res.status(500).json({ error: "Failed to create table", details: err.message });

    // First check if name already exists
    db.query("SELECT COUNT(*) as count FROM link_table WHERE link_name = ?", [link_name], (err, results) => {
      if (err) return res.status(500).json({ error: "Failed to check existing names", details: err.message });

      if (results[0].count > 0) {
        return res.status(409).json({ error: "A setting with this name already exists. Please choose a different name." });
      }

      // If name doesn't exist, proceed with save
      // First, set all existing settings to is_current = FALSE
      db.query("UPDATE link_table SET is_current = FALSE", (err) => {
        if (err) return res.status(500).json({ error: "Failed to update existing settings", details: err.message });

        // Now insert the new setting with is_current = TRUE
        const insertQuery = `
          INSERT INTO link_table (
            link_name,
            almServerUrl, username, password, domain, project,
            qTestDomain, apiToken, projectId,
            is_current
          )
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, TRUE)
        `;

        db.query(
          insertQuery,
          [link_name, almServerUrl, username, password, domain, project, qTestDomain, apiToken, projectId],
          (err, result) => {
            if (err) return res.status(500).json({ error: "Insert failed", details: err.message });

            // Create a directory for the data files if it doesn't exist
            fs.mkdir(DATA_DIR, { recursive: true }, (err) => {
              if (err) return res.status(500).json({ error: "Failed to create data directory", details: err.message });

              // Save ALM credentials to file
              const almJsonData = { link_name, almServerUrl, username, password, domain, project };
              const almFilePath = path.join(DATA_DIR, "AlmCredentials.json");
              fs.writeFile(almFilePath, JSON.stringify(almJsonData, null, 2), (err) => {
                if (err) return res.status(500).json({ error: "Failed to write ALM credentials file", details: err.message });

                // Save qTest credentials to file
                const qtestJsonData = { link_name, qTestDomain, apiToken, projectId };
                const qtestFilePath = path.join(DATA_DIR, "qTestCredentials.json");
                fs.writeFile(qtestFilePath, JSON.stringify(qtestJsonData, null, 2), (err) => {
                  if (err) return res.status(500).json({ error: "Failed to write qTest credentials file", details: err.message });

                  // If everything succeeded, return success response
                  res.json({
                    message: "Settings saved successfully",
                    result: result
                  });
                });
              });
            });
          }
        );
      });
    });
  });
};

// New endpoint to save temporary ALM credentials for validation
exports.saveTempAlmCredentials = (req, res) => {
  const { almServerUrl, username, password, domain, project, link_name } = req.body;

  // Create the data directory if it doesn't exist
  fs.mkdir(DATA_DIR, { recursive: true }, (err) => {
    if (err) return res.status(500).json({
      success: false,
      error: "Failed to create data directory",
      details: err.message
    });

    // Save ALM credentials to file
    const almJsonData = { link_name, almServerUrl, username, password, domain, project };
    const almFilePath = path.join(DATA_DIR, "AlmCredentials.json");

    fs.writeFile(almFilePath, JSON.stringify(almJsonData, null, 2), (err) => {
      if (err) return res.status(500).json({
        success: false,
        error: "Failed to write ALM credentials file",
        details: err.message
      });

      res.json({
        success: true,
        message: "Temporary ALM credentials saved for validation"
      });
    });
  });
};

// New endpoint to save temporary qTest credentials for validation
exports.saveTempQtestCredentials = (req, res) => {
  const { qTestDomain, apiToken, projectId, link_name } = req.body;

  // Create the data directory if it doesn't exist
  fs.mkdir(DATA_DIR, { recursive: true }, (err) => {
    if (err) return res.status(500).json({
      success: false,
      error: "Failed to create data directory",
      details: err.message
    });

    // Save qTest credentials to file
    const qtestJsonData = { link_name, qTestDomain, apiToken, projectId };
    const qtestFilePath = path.join(DATA_DIR, "qTestCredentials.json");

    fs.writeFile(qtestFilePath, JSON.stringify(qtestJsonData, null, 2), (err) => {
      if (err) return res.status(500).json({
        success: false,
        error: "Failed to write qTest credentials file",
        details: err.message
      });

      res.json({
        success: true,
        message: "Temporary qTest credentials saved for validation"
      });
    });
  });
};

// Get all system settings
exports.getSystemSettings = (req, res) => {
  createTableIfNeeded((err) => {
    if (err) return res.status(500).json({ error: "Failed to create table", details: err.message });

    // Order by created_at DESC to get newest first
    db.query("SELECT * FROM link_table ORDER BY created_at DESC", (err, results) => {
      if (err) {
        console.error("Database error:", err);
        return res.status(500).json({ error: "Failed to fetch settings", details: err.message });
      }
      res.json(results);
    });
  });
};

// Get current active setting
exports.getCurrentSetting = (req, res) => {
  db.query("SELECT * FROM link_table WHERE is_current = TRUE LIMIT 1", (err, results) => {
    if (err) return res.status(500).json({ error: "Failed to fetch current setting", details: err.message });

    if (results.length === 0) {
      return res.status(404).json({ error: "No active setting found" });
    }

    res.json(results[0]);
  });
};

// Get single setting - using link_name
exports.getSingleSystemSetting = (req, res) => {
  const { id } = req.params; // We'll use this as link_name

  db.query("SELECT * FROM link_table WHERE link_name = ?", [id], (err, results) => {
    if (err) return res.status(500).json({ error: "Failed to fetch setting", details: err.message });
    if (results.length === 0) return res.status(404).json({ error: "Setting not found" });

    const setting = results[0];

    // Update both credential files
    fs.mkdir(DATA_DIR, { recursive: true }, (err) => {
      if (err) return res.status(500).json({ error: "Failed to create data directory", details: err.message });

      // Update ALM credentials file
      const almJsonData = {
        link_name: setting.link_name,
        almServerUrl: setting.almServerUrl,
        username: setting.username,
        password: setting.password,
        domain: setting.domain,
        project: setting.project
      };
      const almFilePath = path.join(DATA_DIR, "AlmCredentials.json");
      fs.writeFile(almFilePath, JSON.stringify(almJsonData, null, 2), (err) => {
        if (err) return res.status(500).json({ error: "Failed to write ALM credentials file", details: err.message });

        // Update qTest credentials file
        const qtestJsonData = {
          link_name: setting.link_name,
          qTestDomain: setting.qTestDomain,
          apiToken: setting.apiToken,
          projectId: setting.projectId
        };
        const qtestFilePath = path.join(DATA_DIR, "qTestCredentials.json");
        fs.writeFile(qtestFilePath, JSON.stringify(qtestJsonData, null, 2), (err) => {
          if (err) return res.status(500).json({ error: "Failed to write qTest credentials file", details: err.message });

          // Return the setting
          res.json(setting);
        });
      });
    });
  });
};

// Set a setting as current active
exports.setAsCurrent = (req, res) => {
  const { id } = req.params; // link_name to set as current

  // First set all to false
  db.query("UPDATE link_table SET is_current = FALSE", (err) => {
    if (err) return res.status(500).json({ error: "Failed to update settings", details: err.message });

    // Then set the selected one as current
    db.query(
      "UPDATE link_table SET is_current = TRUE WHERE link_name = ?",
      [id],
      (err, result) => {
        if (err) return res.status(500).json({ error: "Failed to set current setting", details: err.message });

        if (result.affectedRows === 0) {
          return res.status(404).json({ error: "Setting not found" });
        }

        res.json({ message: "Setting set as current successfully" });
      }
    );
  });
};

// Update setting - using link_name instead of id
exports.updateSystemSetting = (req, res) => {
  const { id } = req.params; // We'll use this as link_name
  const {
    link_name,
    almServerUrl, username, password, domain, project,
    // qTest fields
    qTestDomain, apiToken, projectId,
    // Status
    is_current
  } = req.body;

  // Validate that link_name is provided
  if (!link_name) {
    return res.status(400).json({ error: "Settings name (link_name) is required" });
  }

  // If setting as current, first set all others to false
  const updateCurrentFirst = (callback) => {
    if (is_current) {
      db.query("UPDATE link_table SET is_current = FALSE", (err) => {
        if (err) return res.status(500).json({ error: "Failed to update existing settings", details: err.message });
        callback();
      });
    } else {
      callback();
    }
  };

  updateCurrentFirst(() => {
    const updateQuery = `
      UPDATE link_table 
      SET 
        link_name = ?,
        almServerUrl = ?,
        username = ?,
        password = ?,
        domain = ?,
        project = ?,
        qTestDomain = ?,
        apiToken = ?,
        projectId = ?,
        is_current = ?
      WHERE link_name = ?
    `;

    const is_current_val = is_current ? true : false;

    db.query(
      updateQuery,
      [link_name, almServerUrl, username, password, domain, project, qTestDomain, apiToken, projectId, is_current_val, id],
      (err) => {
        if (err) return res.status(500).json({ error: "Update failed", details: err.message });

        // Create a directory for the data files if it doesn't exist
        fs.mkdir(DATA_DIR, { recursive: true }, (err) => {
          if (err) return res.status(500).json({ error: "Failed to create data directory", details: err.message });

          // Update ALM credentials file
          const almJsonData = { link_name, almServerUrl, username, password, domain, project };
          const almFilePath = path.join(DATA_DIR, "AlmCredentials.json");
          fs.writeFile(almFilePath, JSON.stringify(almJsonData, null, 2), (err) => {
            if (err) return res.status(500).json({ error: "Failed to write ALM credentials file", details: err.message });

            // Update qTest credentials file
            const qtestJsonData = { link_name, qTestDomain, apiToken, projectId };
            const qtestFilePath = path.join(DATA_DIR, "qTestCredentials.json");
            fs.writeFile(qtestFilePath, JSON.stringify(qtestJsonData, null, 2), (err) => {
              if (err) return res.status(500).json({ error: "Failed to write qTest credentials file", details: err.message });

              res.json({ message: "Settings updated successfully" });
            });
          });
        });
      }
    );
  });
};

// ENHANCED: Delete setting with history backup AND field mappings backup
exports.deleteSystemSetting = (req, res) => {
  const { id } = req.params; // We'll use this as link_name

  console.log(`🗑️ Starting enhanced delete process for: ${id}`);

  // Step 1: Create both delete history tables if needed
  createDeleteTableIfNeeded((err) => {
    if (err) {
      console.error("❌ Failed to create delete history table:", err);
      return res.status(500).json({
        error: "Failed to create delete history table",
        details: err.message
      });
    }

    console.log("✅ Delete history table ready");

    // Step 1.1: Create restore field mappings table if needed
    createRestoreFieldMappingsTableIfNeeded((err) => {
      if (err) {
        console.error("❌ Failed to create restore field mappings table:", err);
        return res.status(500).json({
          error: "Failed to create restore field mappings table",
          details: err.message
        });
      }

      console.log("✅ Restore field mappings table ready");

      // Step 2: Fetch the record to be deleted
      db.query("SELECT * FROM link_table WHERE link_name = ?", [id], (err, results) => {
        if (err) {
          console.error("❌ Failed to fetch record for deletion:", err);
          return res.status(500).json({
            error: "Failed to fetch record for deletion",
            details: err.message
          });
        }

        if (results.length === 0) {
          console.log("❌ Record not found for deletion");
          return res.status(404).json({ error: "Setting not found" });
        }

        const recordToDelete = results[0];
        console.log(`📦 Found record to delete: ${recordToDelete.link_name}`);

        // Step 3: Fetch field mappings for this link_name (check if field_mappings table exists)
        db.query("SHOW TABLES LIKE 'field_mappings'", (err, tableResults) => {
          if (err) {
            console.error("❌ Failed to check field_mappings table:", err);
            // Continue without field mappings if table doesn't exist
            proceedWithoutFieldMappings();
            return;
          }

          if (tableResults.length === 0) {
            console.log("📊 field_mappings table doesn't exist, proceeding without field mappings");
            proceedWithoutFieldMappings();
            return;
          }

          // Table exists, fetch field mappings
          db.query("SELECT * FROM field_mappings WHERE link_name = ?", [id], (err, fieldMappingsResults) => {
            if (err) {
              console.error("❌ Failed to fetch field mappings for deletion:", err);
              return res.status(500).json({
                error: "Failed to fetch field mappings for deletion",
                details: err.message
              });
            }

            console.log(`📊 Found ${fieldMappingsResults.length} field mapping(s) for ${id}`);
            proceedWithFieldMappings(fieldMappingsResults);
          });
        });

        function proceedWithoutFieldMappings() {
          insertIntoDeleteHistory(recordToDelete, () => {
            deleteMainLinkRecord(id, recordToDelete, null, 0, res);
          });
        }

        function proceedWithFieldMappings(fieldMappingsResults) {
          insertIntoDeleteHistory(recordToDelete, (historyId) => {
            if (fieldMappingsResults.length > 0) {
              moveFieldMappingsToRestore(fieldMappingsResults, () => {
                deleteFieldMappingsFromOriginal(id, () => {
                  deleteMainLinkRecord(id, recordToDelete, historyId, fieldMappingsResults.length, res);
                });
              });
            } else {
              console.log("📊 No field mappings found for this link, proceeding to delete main record");
              deleteMainLinkRecord(id, recordToDelete, historyId, 0, res);
            }
          });
        }

        function insertIntoDeleteHistory(recordToDelete, callback) {
          // Step 4: Insert link into delete history table
          const insertDeleteHistoryQuery = `
            INSERT INTO delete_link_table (
              link_name, almServerUrl, username, password, domain, project,
              qTestDomain, apiToken, projectId, was_current, original_created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `;

          const deleteHistoryValues = [
            recordToDelete.link_name,
            recordToDelete.almServerUrl,
            recordToDelete.username,
            recordToDelete.password,
            recordToDelete.domain,
            recordToDelete.project,
            recordToDelete.qTestDomain,
            recordToDelete.apiToken,
            recordToDelete.projectId,
            recordToDelete.is_current || false,
            recordToDelete.created_at
          ];

          db.query(insertDeleteHistoryQuery, deleteHistoryValues, (err, insertResult) => {
            if (err) {
              console.error("❌ Failed to insert into delete history:", err);
              return res.status(500).json({
                error: "Failed to store deletion history",
                details: err.message
              });
            }

            console.log(`✅ Successfully stored link in delete history with ID: ${insertResult.insertId}`);
            callback(insertResult.insertId);
          });
        }

        function moveFieldMappingsToRestore(fieldMappingsResults, callback) {
          const moveFieldMappingsPromises = fieldMappingsResults.map(mapping => {
            return new Promise((resolve, reject) => {
              const insertRestoreFieldMappingQuery = `
                INSERT INTO restore_field_mappings (
                  ep1_label, ep1_name, ep1_physical_name, 
                  ep1_type, ep2_label, ep2_field_id, ep2_type,
                  artifact_type, link_name, is_current
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
              `;

              const restoreFieldMappingValues = [
                mapping.ep1_label,
                mapping.ep1_name,
                mapping.ep1_physical_name,
                mapping.ep1_type,
                mapping.ep2_label,
                mapping.ep2_field_id,
                mapping.ep2_type,
                mapping.artifact_type || null,
                mapping.link_name || null,
                mapping.id
              ];

              db.query(insertRestoreFieldMappingQuery, restoreFieldMappingValues, (err, result) => {
                if (err) {
                  console.error(`❌ Failed to insert field mapping ${mapping.id} into restore table:`, err);
                  reject(err);
                } else {
                  console.log(`✅ Moved field mapping ${mapping.id} to restore table with new ID: ${result.insertId}`);
                  resolve(result);
                }
              });
            });
          });

          Promise.all(moveFieldMappingsPromises)
            .then(() => {
              console.log(`✅ All ${fieldMappingsResults.length} field mappings moved to restore table`);
              callback();
            })
            .catch((err) => {
              console.error("❌ Failed to move field mappings to restore table:", err);
              return res.status(500).json({
                error: "Failed to backup field mappings",
                details: err.message
              });
            });
        }

        function deleteFieldMappingsFromOriginal(linkName, callback) {
          db.query("DELETE FROM field_mappings WHERE link_name = ?", [linkName], (err, deleteMappingsResult) => {
            if (err) {
              console.error("❌ Failed to delete field mappings from original table:", err);
              return res.status(500).json({
                error: "Failed to delete field mappings",
                details: err.message
              });
            }

            console.log(`✅ Deleted ${deleteMappingsResult.affectedRows} field mapping(s) from original table`);
            callback();
          });
        }
      });
    });
  });
};

// Helper function to delete main link record
function deleteMainLinkRecord(linkName, recordToDelete, historyId, fieldMappingsCount, res) {
  db.query("DELETE FROM link_table WHERE link_name = ?", [linkName], (err, deleteResult) => {
    if (err) {
      console.error("❌ Failed to delete from main table:", err);
      return res.status(500).json({
        error: "Delete failed",
        details: err.message
      });
    }

    console.log(`✅ Successfully deleted from main table. Affected rows: ${deleteResult.affectedRows}`);

    // Step 8: Return comprehensive success response
    res.json({
      message: "Setting and associated field mappings deleted successfully",
      deletedRecord: {
        link_name: recordToDelete.link_name,
        was_current: recordToDelete.is_current || false,
        stored_in_history: true,
        history_id: historyId,
        field_mappings_moved: fieldMappingsCount,
        deleted_at: new Date().toISOString()
      },
      summary: {
        link_deleted: true,
        link_backed_up: true,
        field_mappings_moved: fieldMappingsCount,
        total_operations: fieldMappingsCount + 2 // link backup + link delete + field mappings operations
      }
    });
  });
}

// Get all restored field mappings
exports.getRestoredFieldMappings = (req, res) => {
  createRestoreFieldMappingsTableIfNeeded((err) => {
    if (err) return res.status(500).json({
      error: "Failed to create restore field mappings table",
      details: err.message
    });

    // Order by moved_to_restore_at DESC to get newest restorations first
    db.query("SELECT * FROM restore_field_mappings ORDER BY moved_to_restore_at DESC", (err, results) => {
      if (err) {
        console.error("Database error:", err);
        return res.status(500).json({
          error: "Failed to fetch restored field mappings",
          details: err.message
        });
      }
      res.json(results);
    });
  });
};

// Get restored field mappings by link_name
exports.getRestoredFieldMappingsByLink = (req, res) => {
  const { link_name } = req.params;

  createRestoreFieldMappingsTableIfNeeded((err) => {
    if (err) return res.status(500).json({
      error: "Failed to create restore field mappings table",
      details: err.message
    });

    db.query("SELECT * FROM restore_field_mappings WHERE link_name = ? ORDER BY moved_to_restore_at DESC", [link_name], (err, results) => {
      if (err) {
        console.error("Database error:", err);
        return res.status(500).json({
          error: "Failed to fetch restored field mappings for link",
          details: err.message
        });
      }
      res.json(results);
    });
  });
};

// Get all deleted records from history
exports.getDeletedSettings = (req, res) => {
  createDeleteTableIfNeeded((err) => {
    if (err) return res.status(500).json({
      error: "Failed to create delete history table",
      details: err.message
    });

    // Order by deleted_at DESC to get newest deletions first
    db.query("SELECT * FROM delete_link_table ORDER BY deleted_at DESC", (err, results) => {
      if (err) {
        console.error("Database error:", err);
        return res.status(500).json({
          error: "Failed to fetch deleted settings",
          details: err.message
        });
      }
      res.json(results);
    });
  });
};

// Restore a deleted setting
exports.restoreDeletedSetting = (req, res) => {
  const { id } = req.params; // This will be the history record ID

  // Step 1: Get the deleted record
  db.query("SELECT * FROM delete_link_table WHERE id = ?", [id], (err, results) => {
    if (err) return res.status(500).json({
      error: "Failed to fetch deleted record",
      details: err.message
    });

    if (results.length === 0) {
      return res.status(404).json({ error: "Deleted record not found" });
    }

    const deletedRecord = results[0];

    // Step 2: Check if name already exists in main table
    db.query("SELECT COUNT(*) as count FROM link_table WHERE link_name = ?", [deletedRecord.link_name], (err, countResults) => {
      if (err) return res.status(500).json({
        error: "Failed to check existing names",
        details: err.message
      });

      if (countResults[0].count > 0) {
        return res.status(409).json({
          error: "A setting with this name already exists in active settings. Cannot restore."
        });
      }

      // Step 3: Insert back into main table
      const restoreQuery = `
        INSERT INTO link_table (
          link_name, almServerUrl, username, password, domain, project,
          qTestDomain, apiToken, projectId, is_current
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, FALSE)
      `;

      const restoreValues = [
        deletedRecord.link_name,
        deletedRecord.almServerUrl,
        deletedRecord.username,
        deletedRecord.password,
        deletedRecord.domain,
        deletedRecord.project,
        deletedRecord.qTestDomain,
        deletedRecord.apiToken,
        deletedRecord.projectId
      ];

      db.query(restoreQuery, restoreValues, (err, restoreResult) => {
        if (err) return res.status(500).json({
          error: "Failed to restore setting",
          details: err.message
        });

        // Step 4: Remove from delete history
        db.query("DELETE FROM delete_link_table WHERE id = ?", [id], (err) => {
          if (err) {
            console.error("Warning: Failed to remove from delete history:", err);
            // Don't fail the request, just log the warning
          }

          res.json({
            message: "Setting restored successfully",
            restoredRecord: {
              link_name: deletedRecord.link_name,
              restored_at: new Date().toISOString()
            }
          });
        });
      });
    });
  });
};

// Validate ALM connection
exports.validateAlmConnection = async (req, res) => {
  try {
    console.log("🔍 Starting ALM connection validation...");

    // Method 1: Read from request body (recommended for frontend integration)
    let almConfig;
    if (req.body && Object.keys(req.body).length > 0) {
      almConfig = {
        almServerUrl: req.body.almServerUrl,
        username: req.body.username,
        password: req.body.password,
        domain: req.body.domain,
        project: req.body.project
      };
      console.log("Using credentials from request body");
    } else {
      // Method 2: Fallback to JSON file
      const configPath = path.join(__dirname, '../data/AlmCredentials.json');
      
      if (!fs.existsSync(configPath)) {
        console.error("❌ ALM credentials file not found:", configPath);
        return res.status(400).json({
          success: false,
          error: "Credentials file not found",
          message: "ALM credentials file not found. Please save credentials first."
        });
      }
      
      almConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
      console.log("Using credentials from JSON file");
    }

    const { almServerUrl: serverUrl, username, password, domain: domainToCheck, project: projectToCheck } = almConfig;

    // Validate required fields
    if (!serverUrl || !username || !password || !domainToCheck || !projectToCheck) {
      console.error("❌ Missing required ALM credentials");
      return res.status(400).json({
        success: false,
        error: "Missing credentials",
        message: "All ALM credentials are required (server URL, username, password, domain, project)"
      });
    }

    console.log("Server URL:", serverUrl);
    console.log("Domain:", domainToCheck);
    console.log("Project:", projectToCheck);

    // Step 1: Authenticate
    console.log("🔐 Authenticating...");
    const cookies = await authenticate(serverUrl, username, password);
    if (!cookies) {
      console.log("❌ Authentication failed.");
      return res.status(401).json({
        success: false,
        error: "Authentication failed",
        message: "Invalid ALM credentials. Please check username and password."
      });
    }
    console.log("✅ Authentication successful");

    // Step 2: Get and validate domains
    console.log("🔍 Checking domains...");
    const domains = await getDomains(serverUrl, cookies);
    const domainExists = domains.some(domain => 
      domain.Name && domain.Name.toLowerCase() === domainToCheck.toLowerCase()
    );

    if (!domainExists) {
      console.log(`❌ Domain '${domainToCheck}' not found.`);
      const availableDomains = domains.map(d => d.Name).filter(Boolean);
      return res.status(404).json({
        success: false,
        error: "Domain not found",
        message: `Domain '${domainToCheck}' not found`,
        availableDomains: availableDomains
      });
    }
    console.log(`✅ Domain '${domainToCheck}' found.`);

    // Step 3: Get and validate projects
    console.log("🔍 Checking projects...");
    const projects = await getProjects(serverUrl, cookies, domainToCheck);
    const projectExists = projects.some(project => 
      project.Name && project.Name.toLowerCase() === projectToCheck.toLowerCase()
    );

    if (projectExists) {
      console.log(`✅ Project '${projectToCheck}' found under domain '${domainToCheck}'.`);
      return res.status(200).json({
        success: true,
        message: "ALM connection validated successfully!",
        domain: domainToCheck,
        project: projectToCheck,
        totalDomains: domains.length,
        totalProjects: projects.length
      });
    } else {
      console.log(`❌ Project '${projectToCheck}' NOT found under domain '${domainToCheck}'.`);
      const availableProjects = projects.map(p => p.Name).filter(Boolean);
      return res.status(404).json({
        success: false,
        error: "Project not found",
        message: `Project '${projectToCheck}' not found under domain '${domainToCheck}'`,
        availableProjects: availableProjects
      });
    }

  } catch (err) {
    console.error("❌ ALM Connection Error:", err.message);
    
    // Handle specific error types
    if (err.code === 'ECONNREFUSED' || err.code === 'ENOTFOUND') {
      return res.status(400).json({
        success: false,
        error: "Connection error",
        message: "Cannot connect to ALM server. Please check the server URL."
      });
    } else if (err.response && err.response.status) {
      return res.status(400).json({
        success: false,
        error: "ALM API error",
        message: `HTTP ${err.response.status} error occurred`
      });
    } else {
      return res.status(500).json({
        success: false,
        error: "Unexpected error",
        message: err.message
      });
    }
  }
};

// Fixed authenticate function with proper base64 encoding
async function authenticate(serverUrl, username, password) {
  const authUrl = `${serverUrl}/api/authentication/sign-in`;
  
  // Fix: Use Buffer instead of base64 package
  const encodedCreds = Buffer.from(`${username}:${password}`).toString('base64');

  try {
    console.log("Attempting authentication to:", authUrl);
    
    const response = await axios.post(authUrl, {}, {
      headers: {
        'Authorization': `Basic ${encodedCreds}`,
        'Content-Type': 'application/json'
      },
      withCredentials: true,
      timeout: 10000 // 10 second timeout
    });

    const setCookie = response.headers['set-cookie'];
    if (!setCookie || setCookie.length === 0) {
      console.log("No cookies received from authentication");
      return null;
    }

    const cookies = setCookie.map(cookie => cookie.split(';')[0]).join('; ');
    console.log("Authentication cookies received");
    return cookies;

  } catch (error) {
    console.log(`❌ Auth failed. HTTP ${error.response?.status || 'UNKNOWN'}`);
    if (error.response?.data) {
      console.log("Auth error details:", error.response.data);
    }
    return null;
  }
}

async function getDomains(serverUrl, cookieHeader) {
  try {
    const url = `${serverUrl}/rest/domains`;
    console.log("Fetching domains from:", url);
    
    const response = await httpGet(url, cookieHeader);
    
    if (!response.Domains || !response.Domains.Domain) {
      console.log("No domains found in response");
      return [];
    }
    
    const domainEntry = response.Domains.Domain;
    const domains = Array.isArray(domainEntry) ? domainEntry : [domainEntry];
    console.log(`Found ${domains.length} domain(s)`);
    return domains;
    
  } catch (error) {
    console.error("Error fetching domains:", error.message);
    throw error;
  }
}

async function getProjects(serverUrl, cookieHeader, domain) {
  try {
    const url = `${serverUrl}/rest/domains/${encodeURIComponent(domain)}/projects`;
    console.log("Fetching projects from:", url);
    
    const response = await httpGet(url, cookieHeader);
    
    if (!response.Projects || !response.Projects.Project) {
      console.log("No projects found in response");
      return [];
    }
    
    const projectEntry = response.Projects.Project;
    const projects = Array.isArray(projectEntry) ? projectEntry : [projectEntry];
    console.log(`Found ${projects.length} project(s)`);
    return projects;
    
  } catch (error) {
    console.error("Error fetching projects:", error.message);
    throw error;
  }
}

async function httpGet(url, cookieHeader) {
  try {
    const response = await axios.get(url, {
      headers: {
        'Accept': 'application/json',
        'Cookie': cookieHeader
      },
      timeout: 10000 // 10 second timeout
    });
    
    return response.data;
    
  } catch (error) {
    console.error(`HTTP GET failed for ${url}:`, error.message);
    throw error;
  }
}

// Validate qTest connection

exports.validateQtestConnection = async (req, res) => {
  try {
    console.log("🔍 Received validation request:", req.body);

    // ✅ Step 1: Get credentials from request body (sent from frontend)
    const { qTestDomain, apiToken, projectId } = req.body;

    // Validate required credentials
    if (!qTestDomain || !apiToken || !projectId) {
      console.error("❌ Missing required credentials in request");
      return res.status(400).json({ 
        success: false, 
        error: "Missing required credentials",
        message: "qTestDomain, apiToken, and projectId are required" 
      });
    }

    console.log("🔍 Attempting to connect to qTest...");
    console.log("Domain:", qTestDomain);
    console.log("Project ID:", projectId);
 
    // ✅ Step 2: Send GET request to qTest and validate project access
    const response = await axios.get(`${qTestDomain}/api/v3/projects`, {
      headers: {
        'Authorization': `Bearer ${apiToken}`,
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      timeout: 10000 // 10 second timeout
    });
 
    const projects = response.data;
    console.log(`✅ Successfully connected to qTest. Found ${projects.length} accessible projects.`);
    
    // Find the specific project
    const project = projects.find(p => p.id == projectId); // Use loose equality in case of type mismatch
 
    if (project) {
      console.log("✅ Project access verified.");
      console.log("Project Details:", JSON.stringify(project, null, 2));
      
      return res.status(200).json({
        success: true,
        message: "qTest connection validated successfully!",
        project: project,
        totalProjects: projects.length
      });
    } else {
      console.log("❌ Given project ID not found in accessible projects.");
      console.log("Available project IDs:", projects.map(p => ({ id: p.id, name: p.name })));
      
      return res.status(400).json({
        success: false,
        error: "Project not found",
        message: `Project ID ${projectId} not found in accessible projects`,
        availableProjects: projects.map(p => ({ id: p.id, name: p.name }))
      });
    }
 
  } catch (error) {
    console.error("❌ qTest Connection Error:", error.message);
    
    if (error.response) {
      const status = error.response.status;
      const data = error.response.data;
      
      console.error(`Response Status: ${status}`);
      console.error("Response Data:", data);
      
      // Handle specific error cases
      switch (status) {
        case 401:
          console.error("🔑 Authentication failed - Token is invalid or expired");
          return res.status(400).json({
            success: false,
            error: "Authentication failed",
            message: "API token is invalid or expired. Please check your credentials."
          });
        case 403:
          console.error("🚫 Access forbidden - Insufficient permissions");
          return res.status(400).json({
            success: false,
            error: "Access forbidden",
            message: "Token doesn't have sufficient permissions"
          });
        case 404:
          console.error("🔍 API endpoint not found");
          return res.status(400).json({
            success: false,
            error: "API endpoint not found",
            message: "Check your qTest domain URL. Make sure it's correct."
          });
        default:
          return res.status(400).json({
            success: false,
            error: "qTest API error",
            message: `HTTP ${status} error occurred`
          });
      }
    } else if (error.code === 'ECONNREFUSED' || error.code === 'ENOTFOUND') {
      console.error("🌐 Network connection error - Check your qTest domain URL");
      return res.status(400).json({
        success: false,
        error: "Connection error",
        message: "Cannot connect to qTest. Please check your domain URL and internet connection."
      });
    } else if (error.code === 'ECONNABORTED') {
      console.error("⏱️ Request timeout");
      return res.status(400).json({
        success: false,
        error: "Request timeout",
        message: "Request to qTest timed out. Please try again."
      });
    } else {
      console.error("❌ Unexpected Error:", error.message);
      return res.status(400).json({
        success: false,
        error: "Unexpected error",
        message: "An unexpected error occurred: " + error.message
      });
    }
  }
};

// Add this new function to your backend controller (paste.txt file)

// Set a specific link as current and update credential files
exports.setCurrentLink = (req, res) => {
  const { link_name } = req.params;
  
  console.log(`Setting ${link_name} as current link...`);
  
  // First, set all links to is_current = FALSE
  db.query("UPDATE link_table SET is_current = FALSE", (err) => {
    if (err) {
      console.error("Error updating all links to false:", err);
      return res.status(500).json({ 
        success: false, 
        error: "Failed to update settings", 
        details: err.message 
      });
    }
    
    // Then, set the selected link to is_current = TRUE
    db.query(
      "UPDATE link_table SET is_current = TRUE WHERE link_name = ?", 
      [link_name],
      (err, result) => {
        if (err) {
          console.error("Error setting current link:", err);
          return res.status(500).json({ 
            success: false, 
            error: "Failed to set current link", 
            details: err.message 
          });
        }
        
        if (result.affectedRows === 0) {
          return res.status(404).json({ 
            success: false, 
            error: "Link not found" 
          });
        }
        
        // Fetch the updated link data to update credential files
        db.query("SELECT * FROM link_table WHERE link_name = ?", [link_name], (err, results) => {
          if (err) {
            console.error("Error fetching updated link:", err);
            return res.status(500).json({ 
              success: false, 
              error: "Failed to fetch updated link", 
              details: err.message 
            });
          }
          
          if (results.length === 0) {
            return res.status(404).json({ 
              success: false, 
              error: "Link not found after update" 
            });
          }
          
          const setting = results[0];
          
          // Create data directory if it doesn't exist
          fs.mkdir(DATA_DIR, { recursive: true }, (err) => {
            if (err) {
              console.error("Error creating data directory:", err);
              return res.status(500).json({ 
                success: false, 
                error: "Failed to create data directory", 
                details: err.message 
              });
            }
            
            // Update ALM credentials file
            const almJsonData = {
              link_name: setting.link_name,
              almServerUrl: setting.almServerUrl,
              username: setting.username,
              password: setting.password,
              domain: setting.domain,
              project: setting.project
            };
            const almFilePath = path.join(DATA_DIR, "AlmCredentials.json");
            
            fs.writeFile(almFilePath, JSON.stringify(almJsonData, null, 2), (err) => {
              if (err) {
                console.error("Error writing ALM credentials:", err);
                return res.status(500).json({ 
                  success: false, 
                  error: "Failed to write ALM credentials file", 
                  details: err.message 
                });
              }
              
              // Update qTest credentials file
              const qtestJsonData = {
                link_name: setting.link_name,
                qTestDomain: setting.qTestDomain,
                apiToken: setting.apiToken,
                projectId: setting.projectId
              };
              const qtestFilePath = path.join(DATA_DIR, "qTestCredentials.json");
              
              fs.writeFile(qtestFilePath, JSON.stringify(qtestJsonData, null, 2), (err) => {
                if (err) {
                  console.error("Error writing qTest credentials:", err);
                  return res.status(500).json({ 
                    success: false, 
                    error: "Failed to write qTest credentials file", 
                    details: err.message 
                  });
                }
                
                console.log(`✅ Successfully set ${link_name} as current link`);
                
                // Return success response
                res.json({ 
                  success: true,
                  message: `${link_name} is now set as current configuration`,
                  currentLink: setting
                });
              });
            });
          });
        });
      }
    );
  });
};

// Modified getSystemSettings to include is_current status
exports.getSystemSettingsWithCurrent = (req, res) => {
  createTableIfNeeded((err) => {
    if (err) return res.status(500).json({ error: "Failed to create table", details: err.message });
    
    // Order by is_current DESC first (current item first), then by created_at DESC
    db.query("SELECT *, is_current FROM link_table ORDER BY is_current DESC, created_at DESC", (err, results) => {
      if (err) {
        console.error("Database error:", err);
        return res.status(500).json({ error: "Failed to fetch settings", details: err.message });
      }
      
      // Add current status to each result
      const settingsWithStatus = results.map(setting => ({
        ...setting,
        isCurrent: setting.is_current === 1 || setting.is_current === true
      }));
      
      res.json(settingsWithStatus);
    });
  });
};