const axios = require('axios');
const fs = require('fs');
const path = require('path');

// Paths
const CONFIG_PATH = path.join(__dirname, '../../data/AlmCredentials.json');
const OUTPUT_PATH = path.join(__dirname, '../../data/TestDesigndatafile/ALMListTestsValues.json');

// Load ALM config
const loadConfigFromFile = (filePath) => {
    const rawData = fs.readFileSync(filePath);
    return JSON.parse(rawData);
};

// Parse cookies
const parseCookies = (cookieArray) => {
    const cookieMap = {};
    cookieArray.forEach(cookie => {
        const [cookiePair] = cookie.split(';');
        const [name, value] = cookiePair.split('=');
        cookieMap[name.trim()] = value;
    });
    return cookieMap;
};

// Build cookie header
const buildCookieHeader = ({ xsrfToken, sessionCookie, lwssoCookie, almUser, qcSession }) => {
    return `XSRF-TOKEN=${xsrfToken}; JSESSIONID=${sessionCookie}; LWSSO_COOKIE_KEY=${lwssoCookie}; ALM_USER=${almUser}; QCSession=${qcSession}`;
};

// Main fetch function
const fetchListReleasesFields = async () => {
    try {
        const config = loadConfigFromFile(CONFIG_PATH);
        const { almServerUrl, username, password, domain, project } = config;

        const loginUrl = `${almServerUrl}/api/authentication/sign-in`;
        const releaseDataUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/customization/entities/test/lists`;

        const authHeader = 'Basic ' + Buffer.from(`${username}:${password}`).toString('base64');

        // Step 1: Login
        const loginResponse = await axios.post(loginUrl, {}, {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': authHeader
            },
            withCredentials: true
        });

        const cookies = loginResponse.headers['set-cookie'] || [];
        const cookieMap = parseCookies(cookies);

        const {
            'XSRF-TOKEN': xsrfToken,
            'JSESSIONID': sessionCookie,
            'LWSSO_COOKIE_KEY': lwssoCookie,
            'ALM_USER': almUser,
            'QCSession': qcSession
        } = cookieMap;

        // Step 2: Get release data
        if (xsrfToken && sessionCookie) {
            const releaseDataResponse = await axios.get(releaseDataUrl, {
                headers: {
                    'Accept': 'application/json',
                    'Cookie': buildCookieHeader({ xsrfToken, sessionCookie, lwssoCookie, almUser, qcSession })
                }
            });

            console.log("📥 Writing to:", OUTPUT_PATH);
            fs.writeFileSync(OUTPUT_PATH, JSON.stringify(releaseDataResponse.data, null, 2), 'utf8');
            console.log("✅ ALM tests data saved to ListdefectValues.json");

            // Return true to indicate success
            return true;
        } else {
            console.error("❌ Missing authentication tokens from ALM.");
            return false;
        }
    } catch (error) {
        console.error("❌ Failed to fetch ALM list tests:", error.message);
        throw error;
    }
};

module.exports = {
    fetchListReleasesFields
};
