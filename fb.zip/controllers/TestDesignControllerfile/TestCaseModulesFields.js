const axios = require('axios');
const fs = require('fs');
const path = require('path');

// Paths
const CONFIG_PATH = path.join(__dirname, '../../data/AlmCredentials.json');
const OUTPUT_PATH = path.join(__dirname, '../../data/TestDesigndatafile/TestCaseModulesReleases.json');

// Load ALM config
const loadConfigFromFile = (filePath) => {
    try {
        const rawData = fs.readFileSync(filePath);
        return JSON.parse(rawData);
    } catch (error) {
        console.error(`❌ Error loading config from ${filePath}:`, error.message);
        throw new Error(`Failed to load configuration from ${filePath}`);
    }
};

// Parse cookies
const parseCookies = (cookieArray) => {
    const cookieMap = {};
    cookieArray.forEach(cookie => {
        const [cookiePair] = cookie.split(';');
        const [name, value] = cookiePair.split('=');
        cookieMap[name.trim()] = value;
    });
    return cookieMap;
};

// Build cookie header
const buildCookieHeader = ({ xsrfToken, sessionCookie, lwssoCookie, almUser, qcSession }) => {
    return `XSRF-TOKEN=${xsrfToken}; JSESSIONID=${sessionCookie}; LWSSO_COOKIE_KEY=${lwssoCookie}; ALM_USER=${almUser}; QCSession=${qcSession}`;
};

// Main fetch function
// const fetchTestCaseModulesReleases = async () => {
//     try {
//         // Ensure directory exists
//         const dirPath = path.dirname(OUTPUT_PATH);
//         if (!fs.existsSync(dirPath)) {
//             fs.mkdirSync(dirPath, { recursive: true });
//             console.log(`✅ Created directory: ${dirPath}`);
//         }

//         const config = loadConfigFromFile(CONFIG_PATH);
//         const { almServerUrl, username, password, domain, project } = config;

//         const loginUrl = `${almServerUrl}/api/authentication/sign-in`;
//         const releaseDataUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/test-folders`;

//         const authHeader = 'Basic ' + Buffer.from(`${username}:${password}`).toString('base64');

//         // Step 1: Login
//         console.log("🔑 Authenticating with ALM server...");
//         const loginResponse = await axios.post(loginUrl, {}, {
//             headers: {
//                 'Content-Type': 'application/json',
//                 'Authorization': authHeader
//             },
//             withCredentials: true
//         });

//         const cookies = loginResponse.headers['set-cookie'] || [];
//         const cookieMap = parseCookies(cookies);

//         const {
//             'XSRF-TOKEN': xsrfToken,
//             'JSESSIONID': sessionCookie,
//             'LWSSO_COOKIE_KEY': lwssoCookie,
//             'ALM_USER': almUser,
//             'QCSession': qcSession
//         } = cookieMap;

//         // Step 2: Get release data
//         if (xsrfToken && sessionCookie) {
//             console.log("🔍 Fetching TestCaseModules release data...");
//             const releaseDataResponse = await axios.get(releaseDataUrl, {
//                 headers: {
//                     'Accept': 'application/json',
//                     'Cookie': buildCookieHeader({ xsrfToken, sessionCookie, lwssoCookie, almUser, qcSession })
//                 }
//             });

//             console.log("📥 Writing to:", OUTPUT_PATH);
//             fs.writeFileSync(OUTPUT_PATH, JSON.stringify(releaseDataResponse.data, null, 2), 'utf8');
//             console.log("✅ ALM release data saved to TestCaseModulesReleases.json");
            
//             return { success: true, message: "Data fetched and saved successfully" };
//         } else {
//             console.error("❌ Missing authentication tokens from ALM.");
//             return { success: false, message: "Authentication failed - missing tokens" };
//         }
//     } catch (error) {
//         console.error("❌ Failed to fetch ALM releases:", error.message);
//         return { success: false, message: error.message };
//     }
// };


const fetchTestCaseModulesReleases = async () => {
    try {
        const dirPath = path.dirname(OUTPUT_PATH);
        if (!fs.existsSync(dirPath)) {
            fs.mkdirSync(dirPath, { recursive: true });
            console.log(`✅ Created directory: ${dirPath}`);
        }

        const config = loadConfigFromFile(CONFIG_PATH);
        const { almServerUrl, username, password, domain, project } = config;

        const loginUrl = `${almServerUrl}/api/authentication/sign-in`;
        const baseReleaseUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/test-folders`;

        const authHeader = 'Basic ' + Buffer.from(`${username}:${password}`).toString('base64');

        // Step 1: Authenticate
        console.log("🔑 Authenticating with ALM server...");
        const loginResponse = await axios.post(loginUrl, {}, {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': authHeader
            },
            withCredentials: true
        });

        const cookies = loginResponse.headers['set-cookie'] || [];
        const cookieMap = parseCookies(cookies);

        const {
            'XSRF-TOKEN': xsrfToken,
            'JSESSIONID': sessionCookie,
            'LWSSO_COOKIE_KEY': lwssoCookie,
            'ALM_USER': almUser,
            'QCSession': qcSession
        } = cookieMap;

        if (!xsrfToken || !sessionCookie) {
            console.error("❌ Missing authentication tokens from ALM.");
            return { success: false, message: "Authentication failed - missing tokens" };
        }

        const headers = {
            'Accept': 'application/json',
            'Cookie': buildCookieHeader({ xsrfToken, sessionCookie, lwssoCookie, almUser, qcSession })
        };

        // Step 2: Pagination loop to fetch all test folders
        let allEntities = [];
        let startIndex = 1;
        const pageSize = 1000; // max per page (you can reduce if server restricts)
        let fetchedCount = 0;

        console.log("🔍 Fetching TestCaseModules release data (paginated)...");

        while (true) {
            const url = `${baseReleaseUrl}?start-index=${startIndex}&page-size=${pageSize}`;
            const response = await axios.get(url, { headers });

            const entities = response.data?.entities || [];
            if (entities.length === 0) break;

            allEntities.push(...entities);
            fetchedCount += entities.length;

            console.log(`📄 Fetched ${fetchedCount} records so far...`);

            // If less than pageSize returned, we reached the end
            if (entities.length < pageSize) break;

            startIndex += pageSize;
        }

        // Step 3: Save to file
        const finalJson = { entities: allEntities };
        console.log("📥 Writing to:", OUTPUT_PATH);
        fs.writeFileSync(OUTPUT_PATH, JSON.stringify(finalJson, null, 2), 'utf8');
        console.log(`✅ Saved ${allEntities.length} test folders to TestCaseModulesReleases.json`);

        return { success: true, message: "All data fetched and saved successfully" };
    } catch (error) {
        console.error("❌ Failed to fetch ALM releases:", error.message);
        return { success: false, message: error.message };
    }
};


module.exports = {
    fetchTestCaseModulesReleases
};
