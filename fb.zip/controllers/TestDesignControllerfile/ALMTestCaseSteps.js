


const axios = require('axios');
const fs = require('fs');
const path = require('path');
const db = require('../../config/db');

// Paths
const CONFIG_PATH = path.join(__dirname, '../../data/AlmCredentials.json');
const OUTPUT_PATH = path.join(__dirname, '../../data/TestDesigndatafile/TestCaseSteps.json');

const loadConfigFromFile = (filePath) => {
    try {
        const rawData = fs.readFileSync(filePath);
        return JSON.parse(rawData);
    } catch (error) {
        console.error(`❌ Error loading config from ${filePath}:`, error.message);
        throw new Error(`Failed to load configuration from ${filePath}`);
    }
};

const parseCookies = (cookieArray) => {
    const cookieMap = {};
    cookieArray.forEach(cookie => {
        const [cookiePair] = cookie.split(';');
        const [name, value] = cookiePair.split('=');
        cookieMap[name.trim()] = value;
    });
    return cookieMap;
};

const buildCookieHeader = ({ xsrfToken, sessionCookie, lwssoCookie, almUser, qcSession }) => {
    return `XSRF-TOKEN=${xsrfToken}; JSESSIONID=${sessionCookie}; LWSSO_COOKIE_KEY=${lwssoCookie}; ALM_USER=${almUser}; QCSession=${qcSession}`;
};

const fetchTestCaseSteps = async () => {
    try {
        const config = loadConfigFromFile(CONFIG_PATH);
        const { almServerUrl, username, password, domain, project } = config;

        const loginUrl = `${almServerUrl}/api/authentication/sign-in`;
        const authHeader = 'Basic ' + Buffer.from(`${username}:${password}`).toString('base64');

        // Step 1: Authenticate
        console.log("🔑 Authenticating with ALM server...");
        const loginResponse = await axios.post(loginUrl, {}, {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': authHeader
            },
            withCredentials: true
        });

        const cookies = loginResponse.headers['set-cookie'] || [];
        const cookieMap = parseCookies(cookies);
        const {
            'XSRF-TOKEN': xsrfToken,
            'JSESSIONID': sessionCookie,
            'LWSSO_COOKIE_KEY': lwssoCookie,
            'ALM_USER': almUser,
            'QCSession': qcSession
        } = cookieMap;

        if (!xsrfToken || !sessionCookie) {
            console.error("❌ Missing authentication tokens.");
            return { success: false, message: "Authentication failed" };
        }

        // Step 2: Get test IDs from the database
        const [testRows] = await db.promise().query("SELECT id FROM tests");
        const testIds = testRows.map(row => row.id);

        const allDesignSteps = [];

        console.log(`📥 Fetching design steps for ${testIds.length} test cases...`);

        for (const testId of testIds) {
            const stepUrl = `${almServerUrl}/rest/domains/${domain}/projects/${project}/design-steps?query={parent-id[=${testId}]}`;
            try {
                const response = await axios.get(stepUrl, {
                    headers: {
                        'Accept': 'application/json',
                        'Cookie': buildCookieHeader({ xsrfToken, sessionCookie, lwssoCookie, almUser, qcSession })
                    }
                });

                const entities = response.data.entities || [];
                allDesignSteps.push(...entities);
                console.log(`✅ Steps fetched for test ID ${testId} (${entities.length} steps)`);
            } catch (stepErr) {
                console.warn(`⚠️ Failed to fetch steps for test ID ${testId}:`, stepErr.message);
            }
        }

        const finalJson = { entities: allDesignSteps };
        const dirPath = path.dirname(OUTPUT_PATH);
        if (!fs.existsSync(dirPath)) {
            fs.mkdirSync(dirPath, { recursive: true });
        }

        fs.writeFileSync(OUTPUT_PATH, JSON.stringify(finalJson, null, 2), 'utf8');
        console.log(`✅ All design steps saved to ${OUTPUT_PATH}`);

        return { success: true, message: "Filtered steps fetched and saved" };
    } catch (error) {
        console.error("❌ Failed to fetch filtered design steps:", error.message);
        return { success: false, message: error.message };
    }
};

module.exports = {
    fetchTestCaseSteps
};
