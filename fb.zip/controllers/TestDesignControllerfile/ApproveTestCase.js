
const fs = require('fs');
const path = require('path');
const db = require("../../config/db");
const axios = require('axios');

const fetchApproveTestCase = async () => {
  try {
    // Load credentials
    const qTestCredsPath = path.join(__dirname, '../../data/qTestCredentials.json');
    const qTestCreds = JSON.parse(fs.readFileSync(qTestCredsPath, 'utf8'));
   

    const qTestUrl = qTestCreds.qTestDomain;
    const projectId = qTestCreds.projectId;
    const apiToken = qTestCreds.apiToken;

    // Get test cases from database using your existing db connection
    const query = 'SELECT qtest_testcase_id FROM tests WHERE qtest_testcase_id IS NOT NULL';
    
    // Convert callback-based query to Promise
    const rows = await new Promise((resolve, reject) => {
      db.query(query, (err, results) => {
        if (err) {
          reject(err);
        } else {
          resolve(results);
        }
      });
    });

    console.log(`Found ${rows.length} test cases to approve`);

    // Process each test case
    for (const row of rows) {
      const testCaseId = row.qtest_testcase_id;
      const apiUrl = `${qTestUrl}/api/v3/projects/${projectId}/test-cases/${testCaseId}/approve`;
      await approveTestCase(apiUrl, apiToken, testCaseId);
    }

    console.log('All test cases processed successfully');
  } catch (err) {
    console.error('Error in fetchApproveTestCase:', err);
   // console.log(`➡️ Approving URL: ${apiUrl}`);
  }
};

async function approveTestCase(apiUrl, apiToken, testCaseId) {
  try {
    const response = await axios.put(apiUrl, {}, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiToken}`
      }
    });

    console.log(`✅ Approved TestCase ID: ${testCaseId} | Status: ${response.status}`);
  } catch (err) {
    console.error(`❌ Failed to approve TestCase ID: ${testCaseId}`);
 //   console.log(`➡️ Approving URL: ${apiUrl}`);
    console.error(err.response?.data || err.message);
  }
}

module.exports = { fetchApproveTestCase };