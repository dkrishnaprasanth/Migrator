
// const fs = require("fs");
// const path = require("path");
// const axios = require("axios");
// const db = require("../../config/db");

// const insertSampleData = async (req, res) => {
//   try {
//     // First, check if we have current mappings
//     const [columns] = await db.promise().query(
//       "SELECT ep1_name, ep1_type, ep2_field_id FROM Field_mappings WHERE artifact_type='TestCases'"
//     );

//     if (!columns || columns.length === 0) {
//       return res.status(400).json({
//         success: false,
//         message: "No mapping columns found. Please create mappings first."
//       });
//     }

//     // Check if tests table exists, if not create it
//     const [tableExists] = await db.promise().query(
//       "SELECT COUNT(*) as count FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'tests'"
//     );

//     if (tableExists[0].count === 0) {
//       console.log("Tests table doesn't exist. Creating it...");
//       // Import the recreateNewTable function
//       const { recreateNewTable } = require("../TestDesignControllerfile/MappingController");
//       await recreateNewTable();
//     }

//     const jsonFilePath = path.join(__dirname, '../../data/TestDesigndatafile/ALMTests.json');
//     if (!fs.existsSync(jsonFilePath)) {
//       return res.status(404).json({
//         success: false,
//         message: `JSON file not found at: ${jsonFilePath}`
//       });
//     }

//     const jsonData = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'));

//     // Now safe to truncate since we know the table exists
//     //await db.promise().query("TRUNCATE TABLE tests");

//     // First, let's get the structure of the tests table to ensure correct columns
//     const [tableInfo] = await db.promise().query("DESCRIBE tests");
//     const tableColumns = tableInfo.map(column => column.Field);
//     console.log("Table columns:", tableColumns);

//     // Check if required columns exist, if not add them
//     const requiredColumns = ['name', 'has_link', 'has_attachment', 'parent_id', 'last_modified', 'qtest_testcase_id', 'upload_status', 'comments', 'comment_Id', 'cleaned'];

//     for (const column of requiredColumns) {
//       if (!tableColumns.includes(column)) {
//         console.log(`Adding missing column: ${column}`);
//         let columnDef = '';
//         switch (column) {
//           case 'name':
//           case 'has_link':
//           case 'has_attachment':
//           case 'last_modified':
//           case 'upload_status':
//           case 'comments':
//           case 'cleaned':

//             columnDef = 'TEXT';
//             break;
//           case 'parent_id':
//           case 'qtest_testcase_id':
//           case 'comment_Id':
//             columnDef = 'INT';
//             break;
//         }
//         await db.promise().query(`ALTER TABLE tests ADD COLUMN \`${column}\` ${columnDef}`);
//       }
//     }

//     // Refresh table columns after adding missing ones
//     const [updatedTableInfo] = await db.promise().query("DESCRIBE tests");
//     const updatedTableColumns = updatedTableInfo.map(column => column.Field);

//     // Generate the actual columns we'll use for insertion
//     const mappingColumns = columns.map(col =>
//       col.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase());

//     // Combine and filter to only use columns that exist in the table
//     const allColumns = [...mappingColumns, ...requiredColumns].filter(
//       col => updatedTableColumns.includes(col)
//     );

//     console.log("Columns for insertion:", allColumns);

//     // Generate SQL column string with backticks
//     const columnSQL = allColumns.map(col => `\`${col}\``).join(', ');

//     const allRowsToInsert = [];

//     const [existingRows] = await db.promise().query(
//       `SELECT ${['id', ...allColumns].map(col => `\`${col}\``).join(', ')}, upload_status FROM tests`
//     );


//     const existingMap = new Map();
//     existingRows.forEach(row => {
//       // existingMap.set(row.id, {
//       //   last_modified: row.last_modified,
//       //   upload_status: row.upload_status
//       // });

//       existingMap.set(row.id, row); // Store full row for comparison

//     });

//     let insertCount = 0;
//     let updateCount = 0;
//     let skipCount = 0;

//     for (const entity of jsonData.entities) {
//       const rowData = {};

//       // Build row data from field mappings
//       for (const column of columns) {
//         const columnName = column.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
//         const matchingField = entity.Fields.find(field =>
//           field.Name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase() === columnName
//         );

//         if (!matchingField || !matchingField.values || matchingField.values.length === 0) {
//           rowData[columnName] = null;
//         } else {
//           const combinedValue = matchingField.values.map(v => v.value).join(',');
//           switch (column.ep1_type) {
//             case 'Number':
//               rowData[columnName] = isNaN(Number(combinedValue)) ? null : Number(combinedValue);
//               break;
//             case 'Date': {
//               const parsedDate = new Date(combinedValue);
//               rowData[columnName] = isNaN(parsedDate.getTime()) ? null : parsedDate.toISOString().split('T')[0];
//               break;
//             }
//             case 'String':
//             default:
//               rowData[columnName] = combinedValue;
//           }
//         }
//       }

//       // Add required fields (not including 'id')
//       rowData['name'] = entity.Fields.find(f => f.Name === 'name')?.values?.[0]?.value || null;
//       rowData['has_link'] = entity.Fields.find(f => f.Name === 'has-linkage')?.values?.[0]?.value || null;
//       rowData['has_attachment'] = entity.Fields.find(f => f.Name === 'attachment')?.values?.[0]?.value || null;
//       rowData['last_modified'] = entity.Fields.find(f => f.Name === 'last-modified')?.values?.[0]?.value || null;
//       rowData['parent_id'] = entity.Fields.find(f => f.Name === 'parent-id')?.values?.[0]?.value || null;
//       rowData['comments'] = entity.Fields.find(f => f.Name === 'dev-comments')?.values?.[0]?.value || null;
//       rowData['comment_Id'] = null;
//       rowData['cleaned'] = null;


//       const idColumn = columns.find(col => col.ep1_name.toLowerCase() === 'id');
//       if (!idColumn) {
//         return res.status(400).json({
//           success: false,
//           message: `'id' column is not mapped in the UI. Please map 'id' field.`
//         });
//       }

//       const idColumnKey = idColumn.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
//       const recordId = rowData[idColumnKey];

//       if (!recordId) {
//         console.warn(`⚠️ Skipping record with missing ID`);
//         skipCount++;
//         continue;
//       }



//       const existing = existingMap.get(recordId);

//       if (!existing) {
//         // INSERT new record
//         rowData['qtest_testcase_id'] = null;
//         rowData['upload_status'] = null;

//         const insertCols = allColumns.filter(col => col !== 'id');
//         const insertSQL = `INSERT INTO tests (\`${idColumnKey}\`, ${insertCols.map(c => `\`${c}\``).join(', ')}) VALUES (?, ${insertCols.map(() => '?').join(', ')})`;
//         const values = [recordId, ...insertCols.map(col => rowData[col])];

//         await db.promise().query(insertSQL, values);
//         insertCount++;
//       } else {
//         // Compare last_modified
//         const dbLastModified = new Date(existing['last_modified']);
//         const newLastModified = new Date(rowData['last_modified']);
//         const isModified = dbLastModified.getTime() !== newLastModified.getTime();

//         if (isModified) {
//           // Decide new status
//           let newStatus;
//           if (existing.qtest_testcase_id) {
//             newStatus = 'modified'; // Already uploaded → mark as modified
//           } else {
//             newStatus = 'changed'; // Not uploaded yet → mark as changed
//           }

//           // Update (preserve qtest_testcase_id & comment_Id)
//           const updateCols = allColumns.filter(
//             col => col !== idColumnKey && col !== 'qtest_testcase_id' && col !== 'comment_Id'
//           );

//           const updateSQL = `UPDATE tests 
//                        SET ${updateCols.map(col => `\`${col}\` = ?`).join(', ')}, 
//                            upload_status = ? 
//                        WHERE \`${idColumnKey}\` = ?`;
//           const updateValues = [...updateCols.map(col => rowData[col]), newStatus, recordId];

//           await db.promise().query(updateSQL, updateValues);
//           updateCount++;
//         } else {
//           skipCount++;
//         }
//       }
//     }


//     // ✅ Get total count after insert/update (same as releases insert function)
//     const [totalRows] = await db.promise().query("SELECT COUNT(*) as count FROM tests");

//     res.status(200).json({
//       success: true,
//       message: `TestCases processed successfully`,
//       details: {
//         inserted: insertCount,
//         updated: updateCount,
//         skipped: skipCount,
//         totalProcessed: insertCount + updateCount + skipCount
//       },
//       totalCount: totalRows[0].count
//     });


//   } catch (error) {
//     console.error('Error inserting data:', error);
//     res.status(500).json({
//       success: false,
//       message: `Error inserting data: ${error.message}`
//     });
//   }
// };


// const credentials = require("../../data/qTestCredentials.json");


// // Global variable to store migration statistics
// let uploadStats = {
//   total: 0,
//   success: 0,
//   failed: 0,
//   skipped: 0,
//   updated: 0,
//   pending: 0
// };


// const uploadReleaseToQTest = async (payload, releaseId, qtestTestCaseId = null) => {
//   try {
//     const isPut = !!qtestTestCaseId;
//     const url = isPut
//       ? `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/test-cases/${qtestTestCaseId}`
//       : `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/test-cases`;

//     const method = isPut ? 'put' : 'post';

//     const response = await axios({
//       method,
//       url,
//       headers: {
//         "Content-Type": "application/json",
//         Authorization: `Bearer ${credentials.apiToken}`,
//       },
//       data: payload
//     });

//     if (response.status === 200) {
//       await db
//         .promise()
//         .query("UPDATE tests SET upload_status = ?, qtest_testcase_id = ? WHERE id = ?",
//           ["completed", response.data.id || qtestTestCaseId, releaseId]);

//       // uploadStats.success++;
//       // uploadStats.pending--;
//       if (isPut) {
//         uploadStats.updated++;
//       }
//       else {
//         uploadStats.success++;
//       }
//       uploadStats.pending--;

//       return { success: true, qTestId: response.data.id || qtestTestCaseId };
//     } else {
//       await db
//         .promise()
//         .query("UPDATE tests SET upload_status = ? WHERE id = ?", [
//           `failed_${response.status}`,
//           releaseId,
//         ]);

//       uploadStats.failed++;
//       uploadStats.pending--;

//       return { success: false, error: `HTTP Status: ${response.status}` };
//     }
//   } catch (error) {
//     const status = error.response?.status || "unknown_error";
//     const errorMessage = error.response?.data?.message || error.message || "Unknown error";

//     await db
//       .promise()
//       .query("UPDATE tests SET upload_status = ? WHERE id = ?", [
//         `failed_${status}`,
//         releaseId,
//       ]);

//     uploadStats.failed++;
//     uploadStats.pending--;

//     return { success: false, error: errorMessage };
//   }
// };


// const checkColumnExists = async (tableName, columnName) => {
//   try {
//     const [columns] = await db.promise().query(
//       "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?",
//       [tableName, columnName]
//     );
//     return columns.length > 0;
//   } catch (error) {
//     console.error(`Error checking column existence: ${error.message}`);
//     return false;
//   }
// };



// const processAndUploadAlltestcase = async (req, res) => {
//   try {
//     uploadStats = {
//       total: 0,
//       success: 0,
//       failed: 0,
//       skipped: 0,
//       updated: 0,
//       pending: 0
//     };

//     const [tableExists] = await db.promise().query(
//       "SELECT COUNT(*) as count FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'tests'"
//     );

//     if (tableExists[0].count === 0) {
//       return res.status(400).json({
//         success: false,
//         message: "Tests table doesn't exist. Please run insertSampleData first."
//       });
//     }

//     const uploadStatusExists = await checkColumnExists('tests', 'upload_status');
//     if (!uploadStatusExists) {
//       console.log("Adding upload_status column to tests table...");
//       await db.promise().query("ALTER TABLE tests ADD COLUMN upload_status TEXT");
//     }

//     const qtestIdExists = await checkColumnExists('tests', 'qtest_testcase_id');
//     if (!qtestIdExists) {
//       console.log("Adding qtest_testcase_id column to tests table...");
//       await db.promise().query("ALTER TABLE tests ADD COLUMN qtest_testcase_id INT");
//     }

//     const [mappingRow] = await db
//       .promise()
//       .query("SELECT DISTINCT link_name FROM Field_mappings WHERE artifact_type='TestCases'");

//     const currentTable = mappingRow.length > 0 ? mappingRow[0].link_name : null;
//     if (!currentTable) throw new Error("No active mapping table found.");

//     const [mappings] = await db
//       .promise()
//       .query(
//         "SELECT ep1_name, ep1_type, ep2_label, ep2_field_id FROM Field_mappings WHERE  artifact_type = 'TestCases' AND link_name = ?",
//         [currentTable]
//       );

//     console.log(`Found ${mappings.length} field mappings`);

//     //const [releaseRows] = await db.promise().query("SELECT * FROM tests WHERE upload_status IS NULL");

//     const [releaseRows] = await db.promise().query(`
//   SELECT * FROM tests
//   WHERE upload_status IS NULL
//      OR upload_status = 'changed'
//      OR upload_status = 'modified'
//      OR upload_status LIKE 'failed%' 
//      OR upload_status LIKE 'completed' 
// `);


//     uploadStats.total = releaseRows.length;
//     uploadStats.pending = releaseRows.length;

//     if (releaseRows.length === 0) {
//       return res.status(200).json({
//         message: "No tests found to process",
//         counts: uploadStats,
//       });
//     }

//     let counter = 1;
//     const parentIdMap = new Map();

//     for (let row of releaseRows) {

//       if (row.upload_status === 'completed') {
//         console.log(`✅ Skipping TestCase ID ${row.id} — already completed`);
//         uploadStats.skipped++;
//         uploadStats.pending--;
//         continue;

//       }
//       console.log(`🔄 Processing TestCase ${counter}/${uploadStats.total} (ID: ${row.id})`);

//       let testcaseName = `TestCase_${row.id}`;

//       if (row.name && row.name.trim() !== '') {
//         testcaseName = row.name.trim();
//       }

//       console.log(`📝 TestCase name: ${testcaseName}`);

//       const properties = [];

//       for (let mapping of mappings) {
//         const columnName = mapping.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
//         const rawValue = row[columnName];

//         console.log(`🔍 Processing field: ${mapping.ep1_name} (${columnName}) = ${rawValue} (type: ${mapping.ep1_type})`);

//         if (rawValue === null || rawValue === undefined || rawValue === '') {
//           console.log(`⚠️ Skipping empty value for ${columnName}`);
//           continue;
//         }

//         // Skip duplicate field_ids
//         if (properties.some(p => p.field_id === mapping.ep2_field_id)) {
//           console.log(`⚠️ Skipping duplicate field_id ${mapping.ep2_field_id} for ${mapping.ep2_label}`);
//           continue;
//         }

//         if (mapping.ep1_type === "LookupList") {
//           const valuesToCheck = typeof rawValue === 'string' ? rawValue.split(',').map(v => v.trim()) : [rawValue];

//           const [valueMappings] = await db.promise().query(`
//             SELECT ep1_value, ep2_value_id, ep2_value 
//             FROM value_mappings 
//             WHERE ep1_name = ? AND ep2_field_id = ?
//           `, [mapping.ep1_name, mapping.ep2_field_id]);

//           console.log(`🔎 Found ${valueMappings.length} value mappings for ${mapping.ep1_name}`);
//           const matchedEp2Ids = [];
//           const matchedEp2Names = [];

//           valuesToCheck.forEach(value => {
//             const match = valueMappings.find(vm => vm.ep1_value === value);
//             if (match) {
//               matchedEp2Ids.push(match.ep2_value_id);
//               matchedEp2Names.push(match.ep2_value);
//               console.log(`✅ Matched value: ${value} -> ${match.ep2_value_id} (${match.ep2_value})`);
//             } else {
//               console.log(`❌ No match found for value: ${value}`);
//             }
//           });

//           if (matchedEp2Ids.length > 0) {
//             const fieldValue = matchedEp2Ids.length === 1 ? matchedEp2Ids[0] : matchedEp2Ids[0];
//             const fieldValueName = matchedEp2Names.length === 1 ? matchedEp2Names[0] : matchedEp2Names[0];
//             properties.push({
//               field_id: mapping.ep2_field_id,
//               field_name: mapping.ep2_label,
//               field_value: fieldValue,
//               field_value_name: fieldValueName
//             });
//             console.log(`✅ Added LookupList property: ${mapping.ep2_label} = ${fieldValue} with name ${fieldValueName}`);
//           }
//         } else if (mapping.ep1_type === "UsersList") {
//           // Keep existing UsersList logic
//           if (rawValue.includes(',')) {
//             const valueArray = rawValue.split(',').map(v => v.trim());
//             const idArray = [];
//             const nameArray = [];

//             const [qtestReleases] = await db.promise().query("SELECT * FROM qtest_tests");

//             valueArray.forEach(val => {
//               const matched = qtestReleases.find(
//                 r => r.id === mapping.ep2_field_id && r.label_value === val
//               );

//               if (matched) {
//                 idArray.push(matched.value);
//                 nameArray.push(val);
//               }
//             });

//             if (idArray.length > 0) {
//               properties.push({
//                 field_id: mapping.ep2_field_id,
//                 field_name: mapping.ep2_label,
//                 field_value: JSON.stringify(idArray),
//                 field_value_name: JSON.stringify(nameArray)
//               });
//             }
//           } else {
//             const [qtestReleases] = await db.promise().query("SELECT * FROM qtest_tests");
//             const matched = qtestReleases.find(
//               r => r.id === mapping.ep2_field_id && r.label_value === rawValue
//             );

//             if (matched) {
//               properties.push({
//                 field_id: mapping.ep2_field_id,
//                 field_name: mapping.ep2_label,
//                 field_value: matched.value
//               });
//             }
//           }
//         } else {
//           // Handle other field types (String, Number, Date)
//           let processedValue = rawValue;

//           if (mapping.ep1_type === 'Number') {
//             processedValue = isNaN(Number(rawValue)) ? null : Number(rawValue);
//           } else if (mapping.ep1_type === 'Date') {
//             const parsedDate = new Date(rawValue);
//             processedValue = formatDateForQTest(parsedDate);
//           } else if (mapping.ep1_type === 'String') {
//             processedValue = String(rawValue).trim();
//           }

//           if (processedValue !== null && processedValue !== '') {
//             properties.push({
//               field_id: mapping.ep2_field_id,
//               field_name: mapping.ep2_label,
//               field_value: processedValue
//             });
//             console.log(`✅ Added ${mapping.ep1_type} property: ${mapping.ep2_label} = ${processedValue}`);
//           }
//         }
//       }

//       console.log(`📊 Total properties created: ${properties.length}`);

//       // Handle parent_id logic
//       let parentId = null;

//       if (row.parent_id != null && row.parent_id !== '') {
//         try {
//           const cachedId = parentIdMap.get(String(row.parent_id));
//           if (cachedId) {
//             parentId = cachedId;
//           } else {
//             const [moduleRows] = await db
//               .promise()
//               .query("SELECT qTest_TC_ID FROM testcasemodules_releases WHERE ALM_CID = ?", [row.parent_id]);

//             if (moduleRows.length > 0 && moduleRows[0].qTest_TC_ID != null) {
//               parentId = moduleRows[0].qTest_TC_ID;
//               console.log(`✅ Using qTest_TC_ID ${parentId} for test ${row.name}`);
//             } else {
//               console.warn(`⚠️ No qTest_TC_ID found for parent_id ${row.parent_id}`);
//             }
//           }
//         } catch (err) {
//           console.error(`❌ Error resolving parent_id from testcasemodules_releases: ${err.message}`);
//         }
//       }

//       // Skip testcase with invalid name
//       if (!testcaseName || testcaseName.trim() === '' || testcaseName === 'TestCase_') {
//         console.error(`❌ Skipping testcase with invalid name: ${row.id}`);
//         await db.promise().query("UPDATE tests SET upload_status = ? WHERE id = ?", ['failed_no_name', row.id]);
//         uploadStats.skipped++;
//         uploadStats.pending--;
//         continue;
//       }

//       const singlePayload = {
//         name: testcaseName.trim(),
//         properties,
//         ...(parentId && { parent_id: parentId })
//       };

//       console.log(`📋 Final payload:`, JSON.stringify(singlePayload, null, 2));

//       const outputPath = path.join(__dirname, "../../data/TestDesigndatafile/TestsfinalPayload.json");
//       fs.writeFileSync(outputPath, JSON.stringify(singlePayload, null, 2), "utf8");

//       //const uploadResult = await uploadReleaseToQTest(singlePayload, row.id);

//       let uploadResult;

//       if (row.upload_status === 'completed') {
//         console.log(`✅ Skipping TestCase ID ${row.id} — already completed`);
//         uploadStats.skipped++;
//         uploadStats.pending--;
//         continue;
//       }

//       if (row.upload_status === 'modified' && row.qtest_testcase_id) {
//         // PUT for modified record
//         uploadResult = await uploadReleaseToQTest(singlePayload, row.id, row.qtest_testcase_id);
//       } else {
//         // POST for new or failed record
//         uploadResult = await uploadReleaseToQTest(singlePayload, row.id, null);
//       }


//       if (!uploadResult.success) {
//         console.error(`❌ Upload failed for TestCase ${testcaseName}: ${uploadResult.error}`);
//       } else {
//         console.log(`✅ Successfully uploaded TestCase ${testcaseName} with ID ${uploadResult.qTestId}`);
//         parentIdMap.set(String(row.id), uploadResult.qTestId);
//       }

//       counter++;
//       await new Promise(resolve => setTimeout(resolve, 1000));
//     }

//     res.status(200).json({
//       message: "Migration completed",
//       counts: uploadStats,
//     });
//   } catch (error) {
//     console.error("❌ Error processing tests:", error.message);
//     res.status(500).json({ message: "Migration failed", error: error.message });
//   }
// };

// const getMigrationStatus = async (req, res) => {
//   try {
//     // const [totalCount] = await db.promise().query("SELECT COUNT(*) as count FROM tests");
//     // const [completedCount] = await db.promise().query("SELECT COUNT(*) as count FROM tests WHERE upload_status = 'completed'");
//     // const [failedCount] = await db.promise().query("SELECT COUNT(*) as count FROM tests WHERE upload_status LIKE 'failed%'");
//     // const [pendingCount] = await db.promise().query("SELECT COUNT(*) as count FROM tests WHERE upload_status IS NULL OR upload_status = 'pending'");

//     // res.json({
//     //   counts: {
//     //     total: totalCount[0].count,
//     //     success: completedCount[0].count,
//     //     failed: failedCount[0].count,
//     //     pending: pendingCount[0].count
//     //   }
//     // });

//     res.json({ counts: uploadStats });


//   } catch (error) {
//     console.error("❌ Error getting test case migration status:", error.message);
//     res.status(500).json({
//       message: "Error getting test case migration status",
//       error: error.message
//     });
//   }
// };


// module.exports = {
//   insertSampleData,
//   processAndUploadAlltestcase,
//   getMigrationStatus,
// };



 
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const db = require("../../config/db");
 
const insertSampleData = async (req, res) => {
  try {
    // First, check if we have current mappings
    const [columns] = await db.promise().query(
      "SELECT ep1_name, ep1_type, ep2_field_id FROM Field_mappings WHERE artifact_type='TestCases'"
    );
 
    if (!columns || columns.length === 0) {
      return res.status(400).json({
        success: false,
        message: "No mapping columns found. Please create mappings first."
      });
    }
 
    // Check if tests table exists, if not create it
    const [tableExists] = await db.promise().query(
      "SELECT COUNT(*) as count FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'tests'"
    );
 
    if (tableExists[0].count === 0) {
      console.log("Tests table doesn't exist. Creating it...");
      // Import the recreateNewTable function
      const { recreateNewTable } = require("../TestDesignControllerfile/MappingController");
      await recreateNewTable();
    }
 
    const jsonFilePath = path.join(__dirname, '../../data/TestDesigndatafile/ALMTests.json');
    if (!fs.existsSync(jsonFilePath)) {
      return res.status(404).json({
        success: false,
        message: `JSON file not found at: ${jsonFilePath}`
      });
    }
 
    const jsonData = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'));
 
    // Now safe to truncate since we know the table exists
    //await db.promise().query("TRUNCATE TABLE tests");
 
    // First, let's get the structure of the tests table to ensure correct columns
    const [tableInfo] = await db.promise().query("DESCRIBE tests");
    const tableColumns = tableInfo.map(column => column.Field);
    console.log("Table columns:", tableColumns);
 
    // Check if required columns exist, if not add them
    const requiredColumns = ['name', 'has_link', 'has_attachment', 'parent_id', 'last_modified', 'qtest_testcase_id', 'upload_status', 'comments', 'comment_Id', 'cleaned'];
 
    for (const column of requiredColumns) {
      if (!tableColumns.includes(column)) {
        console.log(`Adding missing column: ${column}`);
        let columnDef = '';
        switch (column) {
          case 'name':
          case 'has_link':
          case 'has_attachment':
          case 'last_modified':
          case 'upload_status':
          case 'comments':
          case 'cleaned':
 
            columnDef = 'TEXT';
            break;
          case 'parent_id':
          case 'qtest_testcase_id':
          case 'comment_Id':
            columnDef = 'INT';
            break;
        }
        await db.promise().query(`ALTER TABLE tests ADD COLUMN \`${column}\` ${columnDef}`);
      }
    }
 
    // Refresh table columns after adding missing ones
    const [updatedTableInfo] = await db.promise().query("DESCRIBE tests");
    const updatedTableColumns = updatedTableInfo.map(column => column.Field);
 
    // Generate the actual columns we'll use for insertion
    const mappingColumns = columns.map(col =>
      col.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase());
 
    // Combine and filter to only use columns that exist in the table
    const allColumns = [...mappingColumns, ...requiredColumns].filter(
      col => updatedTableColumns.includes(col)
    );
 
    console.log("Columns for insertion:", allColumns);
 
    // Generate SQL column string with backticks
    const columnSQL = allColumns.map(col => `\`${col}\``).join(', ');
 
    const allRowsToInsert = [];
 
    const [existingRows] = await db.promise().query(
      `SELECT ${['id', ...allColumns].map(col => `\`${col}\``).join(', ')}, upload_status FROM tests`
    );
 
 
    const existingMap = new Map();
    existingRows.forEach(row => {
      // existingMap.set(row.id, {
      //   last_modified: row.last_modified,
      //   upload_status: row.upload_status
      // });
 
      existingMap.set(row.id, row); // Store full row for comparison
 
    });
 
    let insertCount = 0;
    let updateCount = 0;
    let skipCount = 0;
 
    for (const entity of jsonData.entities) {
      const rowData = {};
 
      // Build row data from field mappings
      for (const column of columns) {
        const columnName = column.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
        const matchingField = entity.Fields.find(field =>
          field.Name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase() === columnName
        );
 
        if (!matchingField || !matchingField.values || matchingField.values.length === 0) {
          rowData[columnName] = null;
        } else {
          const combinedValue = matchingField.values.map(v => v.value).join(',');
          switch (column.ep1_type) {
            case 'Number':
              rowData[columnName] = isNaN(Number(combinedValue)) ? null : Number(combinedValue);
              break;
            case 'Date': {
              const parsedDate = new Date(combinedValue);
              rowData[columnName] = isNaN(parsedDate.getTime()) ? null : parsedDate.toISOString().split('T')[0];
              break;
            }
            case 'String':
            default:
              rowData[columnName] = combinedValue;
          }
        }
      }
 
      // Add required fields (not including 'id')
      rowData['name'] = entity.Fields.find(f => f.Name === 'name')?.values?.[0]?.value || null;
      rowData['has_link'] = entity.Fields.find(f => f.Name === 'has-linkage')?.values?.[0]?.value || null;
      rowData['has_attachment'] = entity.Fields.find(f => f.Name === 'attachment')?.values?.[0]?.value || null;
      rowData['last_modified'] = entity.Fields.find(f => f.Name === 'last-modified')?.values?.[0]?.value || null;
      rowData['parent_id'] = entity.Fields.find(f => f.Name === 'parent-id')?.values?.[0]?.value || null;
      rowData['comments'] = entity.Fields.find(f => f.Name === 'dev-comments')?.values?.[0]?.value || null;
      rowData['comment_Id'] = null;
      rowData['cleaned'] = null;
 
 
      const idColumn = columns.find(col => col.ep1_name.toLowerCase() === 'id');
      if (!idColumn) {
        return res.status(400).json({
          success: false,
          message: `'id' column is not mapped in the UI. Please map 'id' field.`
        });
      }
 
      const idColumnKey = idColumn.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
      const recordId = rowData[idColumnKey];
 
      if (!recordId) {
        console.warn(`⚠️ Skipping record with missing ID`);
        skipCount++;
        continue;
      }
 
 
 
      const existing = existingMap.get(recordId);
 
      if (!existing) {
        // INSERT new record
        rowData['qtest_testcase_id'] = null;
        rowData['upload_status'] = null;
 
        const insertCols = allColumns.filter(col => col !== 'id');
        const insertSQL = `INSERT INTO tests (\`${idColumnKey}\`, ${insertCols.map(c => `\`${c}\``).join(', ')}) VALUES (?, ${insertCols.map(() => '?').join(', ')})`;
        const values = [recordId, ...insertCols.map(col => rowData[col])];
 
        await db.promise().query(insertSQL, values);
        insertCount++;
      } else {
        // Compare last_modified
        const dbLastModified = new Date(existing['last_modified']);
        const newLastModified = new Date(rowData['last_modified']);
        const isModified = dbLastModified.getTime() !== newLastModified.getTime();
 
        if (isModified) {
          // Decide new status
          let newStatus;
          if (existing.qtest_testcase_id) {
            newStatus = 'modified'; // Already uploaded → mark as modified
          } else {
            newStatus = 'changed'; // Not uploaded yet → mark as changed
          }
 
          // Update (preserve qtest_testcase_id & comment_Id)
          const updateCols = allColumns.filter(
            col => col !== idColumnKey && col !== 'qtest_testcase_id' && col !== 'comment_Id'
          );
 
          const updateSQL = `UPDATE tests
                       SET ${updateCols.map(col => `\`${col}\` = ?`).join(', ')},
                           upload_status = ?
                       WHERE \`${idColumnKey}\` = ?`;
          const updateValues = [...updateCols.map(col => rowData[col]), newStatus, recordId];
 
          await db.promise().query(updateSQL, updateValues);
          updateCount++;
        } else {
          skipCount++;
        }
      }
    }
 
 
    // ✅ Get total count after insert/update (same as releases insert function)
    const [totalRows] = await db.promise().query("SELECT COUNT(*) as count FROM tests");
 
    res.status(200).json({
      success: true,
      message: `TestCases processed successfully`,
      details: {
        inserted: insertCount,
        updated: updateCount,
        skipped: skipCount,
        totalProcessed: insertCount + updateCount + skipCount
      },
      totalCount: totalRows[0].count
    });
 
 
  } catch (error) {
    console.error('Error inserting data:', error);
    res.status(500).json({
      success: false,
      message: `Error inserting data: ${error.message}`
    });
  }
};
 
 
const credentials = require("../../data/qTestCredentials.json");
 
 
// Global variable to store migration statistics
let uploadStats = {
  total: 0,
  success: 0,
  failed: 0,
  skipped: 0,
  updated: 0,
  pending: 0
};
 
 
const uploadReleaseToQTest = async (payload, releaseId, qtestTestCaseId = null) => {
  try {
    const isPut = !!qtestTestCaseId;
    const url = isPut
      ? `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/test-cases/${qtestTestCaseId}`
      : `${credentials.qTestDomain}/api/v3/projects/${credentials.projectId}/test-cases`;
 
    const method = isPut ? 'put' : 'post';
 
    const response = await axios({
      method,
      url,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${credentials.apiToken}`,
      },
      data: payload
    });
 
    if (response.status === 200) {
      await db
        .promise()
        .query("UPDATE tests SET upload_status = ?, qtest_testcase_id = ? WHERE id = ?",
          ["completed", response.data.id || qtestTestCaseId, releaseId]);
 
      // uploadStats.success++;
      // uploadStats.pending--;
      if (isPut) {
        uploadStats.updated++;
      }
      else {
        uploadStats.success++;
      }
      uploadStats.pending--;
 
      return { success: true, qTestId: response.data.id || qtestTestCaseId };
    } else {
      await db
        .promise()
        .query("UPDATE tests SET upload_status = ? WHERE id = ?", [
          `failed_${response.status}`,
          releaseId,
        ]);
 
      uploadStats.failed++;
      uploadStats.pending--;
 
      return { success: false, error: `HTTP Status: ${response.status}` };
    }
  } catch (error) {
    const status = error.response?.status || "unknown_error";
    const errorMessage = error.response?.data?.message || error.message || "Unknown error";
 
    await db
      .promise()
      .query("UPDATE tests SET upload_status = ? WHERE id = ?", [
        `failed_${status}`,
        releaseId,
      ]);
 
    uploadStats.failed++;
    uploadStats.pending--;
 
    return { success: false, error: errorMessage };
  }
};
 
 
const checkColumnExists = async (tableName, columnName) => {
  try {
    const [columns] = await db.promise().query(
      "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?",
      [tableName, columnName]
    );
    return columns.length > 0;
  } catch (error) {
    console.error(`Error checking column existence: ${error.message}`);
    return false;
  }
};
 
 
 
const processAndUploadAlltestcase = async (req, res) => {
  try {
    uploadStats = {
      total: 0,
      success: 0,
      failed: 0,
      skipped: 0,
      updated: 0,
      pending: 0
    };
 
    const [tableExists] = await db.promise().query(
      "SELECT COUNT(*) as count FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'tests'"
    );
 
    if (tableExists[0].count === 0) {
      return res.status(400).json({
        success: false,
        message: "Tests table doesn't exist. Please run insertSampleData first."
      });
    }
 
    const uploadStatusExists = await checkColumnExists('tests', 'upload_status');
    if (!uploadStatusExists) {
      console.log("Adding upload_status column to tests table...");
      await db.promise().query("ALTER TABLE tests ADD COLUMN upload_status TEXT");
    }
 
    const qtestIdExists = await checkColumnExists('tests', 'qtest_testcase_id');
    if (!qtestIdExists) {
      console.log("Adding qtest_testcase_id column to tests table...");
      await db.promise().query("ALTER TABLE tests ADD COLUMN qtest_testcase_id INT");
    }
 
    const [mappingRow] = await db
      .promise()
      .query("SELECT DISTINCT link_name FROM Field_mappings WHERE artifact_type='TestCases'");
 
    const currentTable = mappingRow.length > 0 ? mappingRow[0].link_name : null;
    if (!currentTable) throw new Error("No active mapping table found.");
 
    const [mappings] = await db
      .promise()
      .query(
        "SELECT ep1_name, ep1_type, ep2_label, ep2_field_id FROM Field_mappings WHERE  artifact_type = 'TestCases' AND link_name = ?",
        [currentTable]
      );
 
    console.log(`Found ${mappings.length} field mappings`);
 
    //const [releaseRows] = await db.promise().query("SELECT * FROM tests WHERE upload_status IS NULL");
 
    const [releaseRows] = await db.promise().query(`
  SELECT * FROM tests
  WHERE upload_status IS NULL
     OR upload_status = 'changed'
     OR upload_status = 'modified'
     OR upload_status LIKE 'failed%'
     OR upload_status LIKE 'completed'
`);
 
 
    uploadStats.total = releaseRows.length;
    uploadStats.pending = releaseRows.length;
 
    if (releaseRows.length === 0) {
      return res.status(200).json({
        message: "No tests found to process",
        counts: uploadStats,
      });
    }
 
    let counter = 1;
    const parentIdMap = new Map();
 
    for (let row of releaseRows) {
 
      if (row.upload_status === 'completed') {
        console.log(`✅ Skipping TestCase ID ${row.id} — already completed`);
        uploadStats.skipped++;
        uploadStats.pending--;
        continue;
 
      }
      console.log(`🔄 Processing TestCase ${counter}/${uploadStats.total} (ID: ${row.id})`);
 
      let testcaseName = `TestCase_${row.id}`;
 
      if (row.name && row.name.trim() !== '') {
        testcaseName = row.name.trim();
      }
 
      console.log(`📝 TestCase name: ${testcaseName}`);
 
      const properties = [];
 
      for (let mapping of mappings) {
        const columnName = mapping.ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
        const rawValue = row[columnName];
 
        console.log(`🔍 Processing field: ${mapping.ep1_name} (${columnName}) = ${rawValue} (type: ${mapping.ep1_type})`);
 
        if (rawValue === null || rawValue === undefined || rawValue === '') {
          console.log(`⚠️ Skipping empty value for ${columnName}`);
          continue;
        }
 
        // Skip duplicate field_ids
        if (properties.some(p => p.field_id === mapping.ep2_field_id)) {
          console.log(`⚠️ Skipping duplicate field_id ${mapping.ep2_field_id} for ${mapping.ep2_label}`);
          continue;
        }
 
        if (mapping.ep1_type === "LookupList") {
          const valuesToCheck = typeof rawValue === 'string' ? rawValue.split(',').map(v => v.trim()) : [rawValue];
 
          const [valueMappings] = await db.promise().query(`
            SELECT ep1_value, ep2_value_id, ep2_value
            FROM value_mappings
            WHERE ep1_name = ? AND ep2_field_id = ?
          `, [mapping.ep1_name, mapping.ep2_field_id]);
 
          console.log(`🔎 Found ${valueMappings.length} value mappings for ${mapping.ep1_name}`);
          const matchedEp2Ids = [];
          const matchedEp2Names = [];
 
          valuesToCheck.forEach(value => {
            const match = valueMappings.find(vm => vm.ep1_value === value);
            if (match) {
              matchedEp2Ids.push(match.ep2_value_id);
              matchedEp2Names.push(match.ep2_value);
              console.log(`✅ Matched value: ${value} -> ${match.ep2_value_id} (${match.ep2_value})`);
            } else {
              console.log(`❌ No match found for value: ${value}`);
            }
          });
 
          if (matchedEp2Ids.length > 0) {
            const fieldValue = matchedEp2Ids.length === 1 ? matchedEp2Ids[0] : matchedEp2Ids[0];
            const fieldValueName = matchedEp2Names.length === 1 ? matchedEp2Names[0] : matchedEp2Names[0];
            properties.push({
              field_id: mapping.ep2_field_id,
              field_name: mapping.ep2_label,
              field_value: fieldValue,
              field_value_name: fieldValueName
            });
            console.log(`✅ Added LookupList property: ${mapping.ep2_label} = ${fieldValue} with name ${fieldValueName}`);
          }
        } 
        // else if (mapping.ep1_type === "UsersList") {
        //   // Keep existing UsersList logic
        //   if (rawValue.includes(',')) {
        //     const valueArray = rawValue.split(',').map(v => v.trim());
        //     const idArray = [];
        //     const nameArray = [];
 
        //     const [qtestReleases] = await db.promise().query("SELECT * FROM qtest_tests");
 
        //     valueArray.forEach(val => {
        //       const matched = qtestReleases.find(
        //         r => r.id === mapping.ep2_field_id && r.label_value === val
        //       );
 
        //       if (matched) {
        //         idArray.push(matched.value);
        //         nameArray.push(val);
        //       }
        //     });
 
        //     if (idArray.length > 0) {
        //       properties.push({
        //         field_id: mapping.ep2_field_id,
        //         field_name: mapping.ep2_label,
        //         field_value: JSON.stringify(idArray),
        //         field_value_name: JSON.stringify(nameArray)
        //       });
        //     }
        //   } else {
        //     const [qtestReleases] = await db.promise().query("SELECT * FROM qtest_tests");
        //     const matched = qtestReleases.find(
        //       r => r.id === mapping.ep2_field_id && r.label_value === rawValue
        //     );
 
        //     if (matched) {
        //       properties.push({
        //         field_id: mapping.ep2_field_id,
        //         field_name: mapping.ep2_label,
        //         field_value: matched.value
        //       });
        //     }
        //   }
        // } 
         else if (mapping.ep1_type === "UsersList") {
  const valuesToCheck = typeof rawValue === 'string' 
    ? rawValue.split(',').map(v => v.trim()) 
    : [rawValue];

  for (const value of valuesToCheck) {
    // Query users table to match the Name column
    const [userMatch] = await db.promise().query(`
      SELECT qtest_id, first_name 
      FROM users 
      WHERE Name = ?
      LIMIT 1
    `, [value]);

    if (userMatch.length > 0) {
      const { qtest_id, first_name } = userMatch[0];

      properties.push({
        field_id: mapping.ep2_field_id,
        field_name: mapping.ep2_label,
        field_value: qtest_id,
        field_value_name: first_name
      });

      console.log(`✅ Matched user: ${value} -> ${qtest_id} (${first_name})`);
    } else {
      console.log(`❌ No match found in users table for: ${value}`);
    }
  }
}

        else {
          // Handle other field types (String, Number, Date)
          let processedValue = rawValue;
 
          if (mapping.ep1_type === 'Number') {
            processedValue = isNaN(Number(rawValue)) ? null : Number(rawValue);
          } else if (mapping.ep1_type === 'Date') {
            const parsedDate = new Date(rawValue);
            processedValue = formatDateForQTest(parsedDate);
          } else if (mapping.ep1_type === 'String') {
            processedValue = String(rawValue).trim();
          }
 
          if (processedValue !== null && processedValue !== '') {
            properties.push({
              field_id: mapping.ep2_field_id,
              field_name: mapping.ep2_label,
              field_value: processedValue
            });
            console.log(`✅ Added ${mapping.ep1_type} property: ${mapping.ep2_label} = ${processedValue}`);
          }
        }
      }
 
      console.log(`📊 Total properties created: ${properties.length}`);
 
      // Handle parent_id logic
      let parentId = null;
 
      if (row.parent_id != null && row.parent_id !== '') {
        try {
          const cachedId = parentIdMap.get(String(row.parent_id));
          if (cachedId) {
            parentId = cachedId;
          } else {
            const [moduleRows] = await db
              .promise()
              .query("SELECT qTest_TC_ID FROM testcasemodules_releases WHERE ALM_CID = ?", [row.parent_id]);
 
            if (moduleRows.length > 0 && moduleRows[0].qTest_TC_ID != null) {
              parentId = moduleRows[0].qTest_TC_ID;
              console.log(`✅ Using qTest_TC_ID ${parentId} for test ${row.name}`);
            } else {
              console.warn(`⚠️ No qTest_TC_ID found for parent_id ${row.parent_id}`);
            }
          }
        } catch (err) {
          console.error(`❌ Error resolving parent_id from testcasemodules_releases: ${err.message}`);
        }
      }
 
      // Skip testcase with invalid name
      if (!testcaseName || testcaseName.trim() === '' || testcaseName === 'TestCase_') {
        console.error(`❌ Skipping testcase with invalid name: ${row.id}`);
        await db.promise().query("UPDATE tests SET upload_status = ? WHERE id = ?", ['failed_no_name', row.id]);
        uploadStats.skipped++;
        uploadStats.pending--;
        continue;
      }
 
      const singlePayload = {
        name: testcaseName.trim(),
        properties,
        ...(parentId && { parent_id: parentId })
      };
 
      console.log(`📋 Final payload:`, JSON.stringify(singlePayload, null, 2));
 
      const outputPath = path.join(__dirname, "../../data/TestDesigndatafile/TestsfinalPayload.json");
      fs.writeFileSync(outputPath, JSON.stringify(singlePayload, null, 2), "utf8");
 
      //const uploadResult = await uploadReleaseToQTest(singlePayload, row.id);
 
      let uploadResult;
 
      if (row.upload_status === 'completed') {
        console.log(`✅ Skipping TestCase ID ${row.id} — already completed`);
        uploadStats.skipped++;
        uploadStats.pending--;
        continue;
      }
 
      if (row.upload_status === 'modified' && row.qtest_testcase_id) {
        // PUT for modified record
        uploadResult = await uploadReleaseToQTest(singlePayload, row.id, row.qtest_testcase_id);
      } else {
        // POST for new or failed record
        uploadResult = await uploadReleaseToQTest(singlePayload, row.id, null);
      }
 
 
      if (!uploadResult.success) {
        console.error(`❌ Upload failed for TestCase ${testcaseName}: ${uploadResult.error}`);
      } else {
        console.log(`✅ Successfully uploaded TestCase ${testcaseName} with ID ${uploadResult.qTestId}`);
        parentIdMap.set(String(row.id), uploadResult.qTestId);
      }
 
      counter++;
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
 
    res.status(200).json({
      message: "Migration completed",
      counts: uploadStats,
    });
  } catch (error) {
    console.error("❌ Error processing tests:", error.message);
    res.status(500).json({ message: "Migration failed", error: error.message });
  }
};
 
const getMigrationStatus = async (req, res) => {
  try {
    // const [totalCount] = await db.promise().query("SELECT COUNT(*) as count FROM tests");
    // const [completedCount] = await db.promise().query("SELECT COUNT(*) as count FROM tests WHERE upload_status = 'completed'");
    // const [failedCount] = await db.promise().query("SELECT COUNT(*) as count FROM tests WHERE upload_status LIKE 'failed%'");
    // const [pendingCount] = await db.promise().query("SELECT COUNT(*) as count FROM tests WHERE upload_status IS NULL OR upload_status = 'pending'");
 
    // res.json({
    //   counts: {
    //     total: totalCount[0].count,
    //     success: completedCount[0].count,
    //     failed: failedCount[0].count,
    //     pending: pendingCount[0].count
    //   }
    // });
 
    res.json({ counts: uploadStats });
 
 
  } catch (error) {
    console.error("❌ Error getting test case migration status:", error.message);
    res.status(500).json({
      message: "Error getting test case migration status",
      error: error.message
    });
  }
};
 

const getTestCasesCount = async (req, res) => {
  try {
    const jsonFilePath = path.join(__dirname, "../../data/TestDesigndatafile/ALMTests.json");

    if (!fs.existsSync(jsonFilePath)) {
      return res.status(404).json({ success: false, message: "Requirements JSON not found" });
    }

    const jsonData = JSON.parse(fs.readFileSync(jsonFilePath, "utf8"));
    const totalCount = jsonData.entities?.length || 0;

    res.json({ totalCount });
  } catch (error) {
    console.error("❌ Error in getTestCasesCount:", error);
    res.status(500).json({ error: "Failed to fetch testcases count" });
  }
};
module.exports = {
  insertSampleData,
  processAndUploadAlltestcase,
  getMigrationStatus,
  getTestCasesCount
};
 
 