

const db = require("../../config/db");
const fs = require("fs");
const path = require("path");
const axios = require("axios");

// ------------------------------
// Load qTest Credentials
// ------------------------------
const loadQTestCredentials = () => {
  const credPath = path.join(__dirname, '../../data/qTestCredentials.json');
  const raw = fs.readFileSync(credPath, "utf-8");
  const parsed = JSON.parse(raw);
  return {
    domain: parsed.qTestDomain,
    token: parsed.apiToken,
    projectId: parsed.projectId
  };
};

// ------------------------------
// Read and Validate JSON
// ------------------------------
const loadTestJsonAndValidate = async () => {
  const jsonFilePath = path.join(__dirname, "../../data/TestDesigndatafile/TestCaseSteps.json");

  try {
    const rawData = fs.readFileSync(jsonFilePath, "utf-8");
    if (!rawData) {
      console.error("❌ JSON file is empty.");
      return [];
    }

    const parsed = JSON.parse(rawData);
    if (!parsed.entities || !Array.isArray(parsed.entities)) {
      console.error("❌ Unexpected JSON structure:", parsed);
      return [];
    }

    const transformedData = parsed.entities.map((entity) => {
      const fieldMap = {};
      entity.Fields.forEach(field => {
        const name = field.Name;
        const value = field.values?.[0]?.value || null;
        fieldMap[name] = value;
      });

      return {
        id: fieldMap["id"] || null,
        name: fieldMap["name"] || null,
        has_params: fieldMap["has-params"] || null,
        link_test: fieldMap["link-test"] || null,
        description: fieldMap["description"] || null,
        expected: fieldMap["expected"] || null,
        last_modified: fieldMap["last-modified"] || null,
        parent_id: fieldMap["parent-id"] || null,
        attachment: fieldMap["attachment"] || null,
        step_order: fieldMap["step-order"] || null
      };
    });

    return transformedData;
  } catch (err) {
    console.error("❌ Error reading/parsing JSON file:", err);
    return [];
  }
};

// ------------------------------
// Create Table
// ------------------------------
const createTestCaseStepsTable = async () => {
  return new Promise((resolve, reject) => {
    //const dropQuery = `DROP TABLE IF EXISTS alm_testcase_steps`;
    const createQuery = `
      CREATE TABLE IF NOT EXISTS alm_testcase_steps (
        id INT PRIMARY KEY,
        name VARCHAR(255),
        has_params VARCHAR(10),
        link_test INT,
        description TEXT,
        expected TEXT,
        last_modified TIMESTAMP,
        parent_id INT,
        attachment TEXT,
        step_order INT,
        qtest_tc_step_id INT DEFAULT NULL,
        upload_status TEXT,
        attach_status TEXT
      )
    `;

    // db.query(dropQuery, (dropErr) => {
    //   if (dropErr) return reject(dropErr);
    db.query(createQuery, (createErr) => {
      if (createErr) return reject(createErr);
      resolve();
    });
    //});
  });
};


const insertDataTestCaseStepsFromJson = async () => {
  try {
    const jsonData = await loadTestJsonAndValidate();
    if (!jsonData || jsonData.length === 0) return false;

    // Load existing IDs from DB
    const [existingRows] = await db.promise().query("SELECT id FROM alm_testcase_steps");
    const existingIds = new Set(existingRows.map(row => row.id));

    let inserted = 0;
    let skipped = 0;

    for (const item of jsonData) {
      if (existingIds.has(Number(item.id))) {
        skipped++;
        continue; // Skip existing
      }

      await db.promise().query(
        `INSERT INTO alm_testcase_steps 
        (id, name, has_params, link_test, description, expected, last_modified, parent_id, attachment, step_order, qtest_tc_step_id, upload_status,attach_status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          item.id || null,
          item.name || null,
          item.has_params || null,
          item.link_test || null,
          item.description || null,
          item.expected || null,
          item.last_modified || null,
          item.parent_id || null,
          item.attachment || null,
          item.step_order || null,
          null,
          'pending',
          null
        ]
      );
      inserted++;
    }

    console.log(`✅ Steps Inserted: ${inserted}, Skipped (already exists): ${skipped}`);
    return true;
  } catch (err) {
    console.error("❌ Error inserting steps:", err);
    return false;
  }
};


const decodeHtmlEntities = (str) => {
  return str.replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'");
};

const stripHtml = (html) => html.replace(/<[^>]*>/g, '').trim();

// ------------------------------
// Parameter Replacement
// ------------------------------
const extractParameters = (text) => {
  const regex = /<<<(.*?)>>>/g;
  const params = [];
  let match;
  while ((match = regex.exec(text)) !== null) {
    params.push(match[1].trim());
  }
  return params;
};

const validateAndReplaceParameters = async (text, stepId) => {
  const decodedText = decodeHtmlEntities(text);
  const regex = /<<<\s*(.*?)\s*>>>/g;
  const params = [];
  let match;
  while ((match = regex.exec(decodedText)) !== null) {
    params.push(match[1]);
  }

  let transformedText = decodedText;
  for (const param of params) {
    const [rows] = await db.promise().query(
      "SELECT * FROM parameters WHERE name = ?",
      [param]
    );

    if (rows.length === 0 || !rows[0].qTest_Params_id) {
      return {
        isValid: false,
        errorMsg: `Parameter \"${param}\" in step ID ${stepId} is not mapped in qTest.`,
      };
    }

    const paramRegex = new RegExp(`<<<\s*${param}\s*>>>`, 'g');
    transformedText = transformedText.replace(paramRegex, `[~${param}]`);
  }

  return { isValid: true, transformedText };
};

const extractCalledTestCaseName = (html) => {
  const decoded = decodeHtmlEntities(html);
  const match = decoded.match(/<([^<>]+)>/);
  return match ? match[1] : '';
};

const uploadTestStepsToQTest = async (req, res) => {
  const { domain, token, projectId } = loadQTestCredentials();
  const payloadFile = path.join(__dirname, "../../data/TestDesigndatafile/testcasesteppayload.json");
  try {

    // ✅ Skip if all steps are completed
    const [remainingSteps] = await db.promise().query(
      "SELECT COUNT(*) AS count FROM alm_testcase_steps WHERE upload_status IS NULL OR upload_status != 'completed'"
    );

    if (remainingSteps[0].count === 0) {
      return res.status(200).json({
        success: true,
        message: "✅ All test steps are already uploaded."
      });
    }


    // const [allSteps] = await db.promise().query("SELECT * FROM alm_testcase_steps ORDER BY parent_id, step_order ASC");

    // ✅ Fetch only steps not yet completed
    const [allSteps] = await db.promise().query(
      "SELECT * FROM alm_testcase_steps WHERE upload_status IS NULL OR upload_status != 'completed' ORDER BY parent_id, step_order ASC"
    );


    const stepsByParent = allSteps.reduce((acc, step) => {
      if (!acc[step.parent_id]) acc[step.parent_id] = [];
      acc[step.parent_id].push(step);
      return acc;
    }, {});

    for (const parentId in stepsByParent) {
      const steps = stepsByParent[parentId];
      const [testCaseRows] = await db.promise().query("SELECT * FROM tests WHERE id = ?", [parentId]);
      if (testCaseRows.length === 0) continue;
      const qTestTestCaseId = testCaseRows[0].qtest_testcase_id;

      const stepPayload = [];

      for (const step of steps) {
        if (step.link_test) {
          const [linkedTests] = await db.promise().query("SELECT qtest_testcase_id FROM tests WHERE id = ?", [step.link_test]);
          if (linkedTests.length === 0 || !linkedTests[0].qtest_testcase_id) {
            await db.promise().query(`UPDATE alm_testcase_steps SET upload_status = ? WHERE id = ?`, [`failed: linked test not found`, step.id]);
            continue;
          }

          const decoded = decodeHtmlEntities(step.description || '');
          const match = decoded.match(/&lt;([^>]+)&gt;/);
          const extractedName = match ? match[1].trim() : `Called Test Case - ${step.link_test}`;

          stepPayload.push({
            description: extractedName,
            expected: "",
            called_test_case: {
              id: linkedTests[0].qtest_testcase_id,
              approved: true
            }
          });

          continue;
        }

        let rawDescription = step.description || "";
        let rawExpected = step.expected || "";

        if (step.has_params === 'Y') {
          const descResult = await validateAndReplaceParameters(rawDescription, step.id);
          const expResult = await validateAndReplaceParameters(rawExpected, step.id);
          if (!descResult.isValid || !expResult.isValid) {
            await db.promise().query(`UPDATE alm_testcase_steps SET upload_status = ? WHERE id = ?`, [`failed: ${descResult.errorMsg || expResult.errorMsg}`, step.id]);
            continue;
          }
          rawDescription = descResult.transformedText;
          rawExpected = expResult.transformedText;
        }

        const descriptionText = stripHtml(decodeHtmlEntities(rawDescription));
        const expectedText = stripHtml(decodeHtmlEntities(rawExpected));

        stepPayload.push({
          description: descriptionText,
          expected: expectedText
        });
      }

      if (stepPayload.length === 0) continue;

      const finalPayload = { test_steps: stepPayload };
      fs.writeFileSync(payloadFile, JSON.stringify(finalPayload, null, 2), "utf-8");

      const response = await axios.put(
        `${domain}/api/v3/projects/${projectId}/test-cases/${qTestTestCaseId}/`,
        finalPayload,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
          validateStatus: () => true,
        }
      );

      if (response.status === 200 || response.status === 201) {
        // const returnedSteps = response.data.test_steps || [];
        const returnedSteps = response?.data?.test_steps || [];


        for (let i = 0; i < steps.length; i++) {
          const step = steps[i];
          const returned = returnedSteps[i];

          if (returned && returned.id) {
            await db.promise().query(
              `UPDATE alm_testcase_steps SET qtest_tc_step_id = ?, upload_status = ? WHERE id = ?`,
              [returned.id, 'completed', step.id]
            );
          } else {
            await db.promise().query(
              `UPDATE alm_testcase_steps SET upload_status = ? WHERE id = ?`,
              ['completed (no step id returned)', step.id]
            );
          }
        }

        console.log(`✅ Steps for test case ${parentId} uploaded.`);
      } else {
        for (const step of steps) {
          await db.promise().query(
            `UPDATE alm_testcase_steps SET upload_status = ? WHERE id = ?`,
            [`failed: upload_status ${response.status}`, step.id]
          );
        }
        console.error(`❌ Upload failed for test case ${parentId}: upload_status ${response.status}`);
      }
    }

    res.status(201).json({ success: true, message: "Batch upload complete." });
  } catch (err) {
    console.error("❌ Unexpected error:", err);
    res.status(500).json({ success: false, message: err.message });
  }
};

const getTestCaseStepsCount = async (req, res) => {
  try {
    const jsonFilePath = path.join(__dirname, "../../data/TestDesigndatafile/TestCaseSteps.json");

    if (!fs.existsSync(jsonFilePath)) {
      return res.status(404).json({ success: false, message: "Test case steps JSON not found" });
    }

    const jsonData = JSON.parse(fs.readFileSync(jsonFilePath, "utf8"));
    const totalCount = jsonData.entities?.length || 0;

    res.json({ totalCount });
  } catch (error) {
    console.error("❌ Error in getTestCasesStepsCount:", error);
    res.status(500).json({ error: "Failed to fetch testcase steps count" });
  }
};

module.exports = {
  createTestCaseStepsTable,
  insertDataTestCaseStepsFromJson,
  getTestCaseStepsCount,
  uploadTestStepsToQTest
};
