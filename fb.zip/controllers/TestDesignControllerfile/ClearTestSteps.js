
// const fs = require('fs');
// const path = require('path');
// const axios = require('axios');
// const util = require('util');
// const db = require('../../../config/db');

// const query = util.promisify(db.query).bind(db);

// const run = async () => {
//   try {
//     // Load qTest credentials
//     const credentialsPath = path.join(__dirname, '../../../data/qTestCredentials.json');
//     const { qTestDomain, projectId, apiToken } = JSON.parse(fs.readFileSync(credentialsPath, 'utf8'));

//     // Get all qTest Test Case IDs from `tests` table
//     const rows = await query('SELECT qtest_testcase_id FROM tests WHERE qtest_testcase_id IS NOT NULL');

//     for (const row of rows) {
//       const testCaseId = row.qtest_testcase_id;
//       console.log(`📥 Processing Test Case ID: ${testCaseId}`);

//       while (true) {
//         const fetchUrl = `${qTestDomain}/api/v3/projects/${projectId}/test-cases/${testCaseId}/test-steps`;

//         let steps = [];
//         try {
//           const response = await axios.get(fetchUrl, {
//             headers: {
//               Authorization: `Bearer ${apiToken}`,
//               'Content-Type': 'application/json',
//             },
//           });

//           steps = response.data;
//         } catch (error) {
//           console.error(`❌ Failed to fetch steps for Test Case ${testCaseId}:`, error.response?.data || error.message);
//           break;
//         }

//         if (steps.length === 0) {
//           console.log(`✅ All steps deleted for Test Case ID: ${testCaseId}`);
//           break;
//         }

//         const stepId = steps[0].id; // Always delete the first step
//         const deleteUrl = `${qTestDomain}/api/v3/projects/${projectId}/test-cases/${testCaseId}/test-steps/${stepId}`;

//         try {
//           console.log(`🗑️ Deleting step ID: ${stepId}`);
//           await axios.delete(deleteUrl, {
//             headers: {
//               Authorization: `Bearer ${apiToken}`,
//               'Content-Type': 'application/json',
//             },
//           });
//           console.log(`✅ Deleted step ${stepId}`);
//         } catch (err) {
//           console.error(`❌ Error deleting step ${stepId}:`, err.response?.data || err.message);
//           break;
//         }
//       }
//     }

//     console.log('🎉 Finished deleting all steps from test cases.');
//   } catch (err) {
//     console.error('❌ Fatal error:', err.message);
//   } finally {
//     db.end();
//   }
// };

// run();

const fs = require('fs');
const path = require('path');
const axios = require('axios');
const util = require('util');
const db = require('../../config/db');
 
const query = util.promisify(db.query).bind(db);
 
const run = async () => {
  try {
    // Load qTest credentials
    const credentialsPath = path.join(__dirname, '../../data/qTestCredentials.json');
    const { qTestDomain, projectId, apiToken } = JSON.parse(fs.readFileSync(credentialsPath, 'utf8'));
 
const rows = await query(
  'SELECT id, qtest_testcase_id FROM tests WHERE qtest_testcase_id IS NOT NULL AND cleaned IS NULL'
);
 
    for (const row of rows) {
      const { id, qtest_testcase_id: testCaseId } = row;
      console.log(`📥 Processing Test Case ID: ${testCaseId}`);
 
      while (true) {
        const fetchUrl = `${qTestDomain}/api/v3/projects/${projectId}/test-cases/${testCaseId}/test-steps`;
 
        let steps = [];
        try {
          const response = await axios.get(fetchUrl, {
            headers: {
              Authorization: `Bearer ${apiToken}`,
              'Content-Type': 'application/json',
            },
          });
 
          steps = response.data;
        } catch (error) {
          console.error(`❌ Failed to fetch steps for Test Case ${testCaseId}:`, error.response?.data || error.message);
          break;
        }
 
        if (steps.length === 0) {
          console.log(`✅ All steps deleted for Test Case ID: ${testCaseId}`);
 
          // ✅ Mark the test case as cleaned in the DB
          try {
            await query('UPDATE tests SET cleaned = "yes" WHERE id = ?', [id]);
            console.log(`📝 Updated 'cleaned' status for Test Case ID: ${testCaseId}`);
          } catch (updateErr) {
            console.error(`❌ Failed to update cleaned status for Test Case ID: ${testCaseId}:`, updateErr.message);
          }
 
          break;
        }
 
        const stepId = steps[0].id;
        const deleteUrl = `${qTestDomain}/api/v3/projects/${projectId}/test-cases/${testCaseId}/test-steps/${stepId}`;
 
        try {
          console.log(`🗑️ Deleting step ID: ${stepId}`);
          await axios.delete(deleteUrl, {
            headers: {
              Authorization: `Bearer ${apiToken}`,
              'Content-Type': 'application/json',
            },
          });
          console.log(`✅ Deleted step ${stepId}`);
        } catch (err) {
          console.error(`❌ Error deleting step ${stepId}:`, err.response?.data || err.message);
          break;
        }
      }
    }
 
    console.log('🎉 Finished deleting all steps from test cases.');
  } catch (err) {
    console.error('❌ Fatal error:', err.message);
  }
  // } finally {
  //   db.end();
  // }
};
 
 
module.exports = { run };
//run();
 