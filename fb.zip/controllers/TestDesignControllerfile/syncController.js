

const fs = require("fs");
const path = require("path");
const axios = require("axios");
const https = require("https");
const db = require("../../config/db");

const CONFIG_PATH = path.join(__dirname, "../../data/AlmCredentials.json");

const loadConfig = () => {
  const raw = fs.readFileSync(CONFIG_PATH);
  return JSON.parse(raw);
};

const parseCookies = (cookieArray) => {
  const cookieMap = {};
  cookieArray.forEach(cookie => {
    const [cookiePair] = cookie.split(";");
    const [name, value] = cookiePair.split("=");
    cookieMap[name.trim()] = value;
  });
  return cookieMap;
};

const buildCookieHeader = ({ xsrfToken, sessionCookie, lwssoCookie, almUser, qcSession }) => {
  return `XSRF-TOKEN=${xsrfToken}; JSESSIONID=${sessionCookie}; LWSSO_COOKIE_KEY=${lwssoCookie}; ALM_USER=${almUser}; QCSession=${qcSession}`;
};

const getAlmSession = async () => {
  const config = loadConfig();
  const { almServerUrl, username, password } = config;

  const loginUrl = `${almServerUrl}/api/authentication/sign-in?login-form-required=y`;
  const authHeader = "Basic " + Buffer.from(`${username}:${password}`).toString("base64");

  const loginResponse = await axios.post(loginUrl, {}, {
    headers: {
      "Content-Type": "application/json",
      Authorization: authHeader
    },
    withCredentials: true
  });

  const cookies = loginResponse.headers["set-cookie"] || [];
  const cookieMap = parseCookies(cookies);

  return {
    baseUrl: almServerUrl,
    domain: config.domain,
    project: config.project,
    link_name: config.link_name || "",
    cookieHeader: buildCookieHeader({
      xsrfToken: cookieMap["XSRF-TOKEN"],
      sessionCookie: cookieMap["JSESSIONID"],
      lwssoCookie: cookieMap["LWSSO_COOKIE_KEY"],
      almUser: cookieMap["ALM_USER"],
      qcSession: cookieMap["QCSession"]
    })
  };
};

const fetchTestById = async (testId, session) => {
  const httpsAgent = new https.Agent({ rejectUnauthorized: false });
  const url = `${session.baseUrl}/rest/domains/${session.domain}/projects/${session.project}/tests/${testId}`;

  const response = await axios.get(url, {
    httpsAgent,
    headers: {
      Accept: "application/json",
      Cookie: session.cookieHeader
    }
  });

  return response.data;
};

const synctest = async (req, res) => {
  try {
    const session = await getAlmSession();

    const [mappings] = await db.promise().query(
      "SELECT ep1_name, ep1_type, ep2_field_id FROM Field_mappings WHERE artifact_type = 'TestCases' AND link_name = ?",
      [session.link_name]
    );

    const [existingTests] = await db.promise().query(`SELECT id FROM tests`);
    const existingTestIds = new Set(existingTests.map(row => row.id));

    const [testInstances] = await db.promise().query(`SELECT DISTINCT test_id FROM testinstance`);

    let insertedCount = 0;

    for (const { test_id: testId } of testInstances) {
      if (existingTestIds.has(testId)) continue;

      console.log(`\u{1F4E5} Fetching test ${testId} from ALM...`);
      const entity = await fetchTestById(testId, session);
      if (!entity || !entity.Fields) continue;

      const rowData = {};
      const fieldMap = new Map(entity.Fields.map(f => [f.Name.toLowerCase(), f]));

      for (const { ep1_name, ep1_type } of mappings) {
        const field = fieldMap.get(ep1_name.toLowerCase());
        const colName = ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();

        if (!field || !field.values?.length || !field.values[0]?.value) {
          rowData[colName] = null;
        } else {
          const value = field.values.map(v => v.value).join(",");
          switch (ep1_type) {
            case "Number":
              rowData[colName] = isNaN(Number(value)) ? null : Number(value);
              break;
            case "Date":
              const parsed = new Date(value);
              rowData[colName] = isNaN(parsed.getTime()) ? null : parsed.toISOString().split("T")[0];
              break;
            case "String":
            case "Memo":
            default:
              rowData[colName] = value;
          }
        }
      }

      rowData["id"] = testId;
      rowData["name"] = fieldMap.get("name")?.values?.[0]?.value || null;
      rowData["has_link"] = fieldMap.get("has-linkage")?.values?.[0]?.value || null;
      rowData["has_attachment"] = fieldMap.get("attachment")?.values?.[0]?.value || null;
      rowData["last_modified"] = fieldMap.get("last-modified")?.values?.[0]?.value || null;
      rowData["parent_id"] = fieldMap.get("parent-id")?.values?.[0]?.value || null;
      rowData["qtest_testcase_id"] = null;
      rowData["upload_status"] = null;

      const columns = Object.keys(rowData).map(col => `\`${col}\``).join(", ");
      const values = Object.values(rowData);
      const placeholders = values.map(() => "?").join(", ");

      console.log("\u2714\uFE0F Prepared row keys:", Object.keys(rowData));
      await db.promise().query(`INSERT INTO tests (${columns}) VALUES (${placeholders})`, values);
      insertedCount++;
    }

    res.status(200).json({
      success: true,
      message: `${insertedCount} missing test(s) inserted successfully`
    });

  } catch (err) {
    console.error("\u274C Sync error:", err.message);
    res.status(500).json({ success: false, message: err.message });
  }
};

module.exports = { synctest };
