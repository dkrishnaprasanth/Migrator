
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const https = require("https");
const db = require("../../config/db");
 
const CONFIG_PATH = path.join(__dirname, "../../data/AlmCredentials.json");
const { fetchTestCaseStepsByIds, insertTestStepsToDB } = require("../../controllers/TestDesignControllerfile/MissingTestCaseSteps");
 
 
const loadConfig = () => {
  const raw = fs.readFileSync(CONFIG_PATH);
  return JSON.parse(raw);
};
 
const parseCookies = (cookieArray) => {
  const cookieMap = {};
  cookieArray.forEach(cookie => {
    const [cookiePair] = cookie.split(";");
    const [name, value] = cookiePair.split("=");
    cookieMap[name.trim()] = value;
  });
  return cookieMap;
};
 
const buildCookieHeader = ({ xsrfToken, sessionCookie, lwssoCookie, almUser, qcSession }) => {
  return `XSRF-TOKEN=${xsrfToken}; JSESSIONID=${sessionCookie}; LWSSO_COOKIE_KEY=${lwssoCookie}; ALM_USER=${almUser}; QCSession=${qcSession}`;
};
 
const getAlmSession = async () => {
  const config = loadConfig();
  const { almServerUrl, username, password } = config;
 
  const loginUrl = `${almServerUrl}/api/authentication/sign-in?login-form-required=y`;
  const authHeader = "Basic " + Buffer.from(`${username}:${password}`).toString("base64");
 
  const loginResponse = await axios.post(loginUrl, {}, {
    headers: {
      "Content-Type": "application/json",
      Authorization: authHeader
    },
    withCredentials: true
  });
 
  const cookies = loginResponse.headers["set-cookie"] || [];
  const cookieMap = parseCookies(cookies);
 
  return {
    baseUrl: almServerUrl,
    domain: config.domain,
    project: config.project,
    link_name: config.link_name || "",
    cookieHeader: buildCookieHeader({
      xsrfToken: cookieMap["XSRF-TOKEN"],
      sessionCookie: cookieMap["JSESSIONID"],
      lwssoCookie: cookieMap["LWSSO_COOKIE_KEY"],
      almUser: cookieMap["ALM_USER"],
      qcSession: cookieMap["QCSession"]
    })
  };
};
 
const fetchTestById = async (testId, session) => {
  const httpsAgent = new https.Agent({ rejectUnauthorized: false });
  const url = `${session.baseUrl}/rest/domains/${session.domain}/projects/${session.project}/tests/${testId}`;
 
  const response = await axios.get(url, {
    httpsAgent,
    headers: {
      Accept: "application/json",
      Cookie: session.cookieHeader
    }
  });
 
  return response.data;
};
 
const synctestfromsteps = async (req, res) => {
  try {
    const session = await getAlmSession();
 
    const [mappings] = await db.promise().query(
      "SELECT ep1_name, ep1_type, ep2_field_id FROM Field_mappings WHERE artifact_type = 'TestCases' AND link_name = ?",
      [session.link_name]
    );
 
    const [existingTests] = await db.promise().query(`SELECT id FROM tests`);
    const existingTestIds = new Set(existingTests.map(row => row.id));
 
    const [testInstances] = await db.promise().query(`SELECT DISTINCT link_test FROM alm_testcase_steps`);
 
    let insertedCount = 0;
 
    for (const { link_test: testId } of testInstances) {
      if (existingTestIds.has(testId)) continue;
 
      console.log(`\u{1F4E5} Fetching test ${testId} from ALM...`);
      const entity = await fetchTestById(testId, session);
      if (!entity || !entity.Fields) continue;
 
      const rowData = {};
      const fieldMap = new Map(entity.Fields.map(f => [f.Name.toLowerCase(), f]));
 
      for (const { ep1_name, ep1_type } of mappings) {
        const field = fieldMap.get(ep1_name.toLowerCase());
        const colName = ep1_name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
 
        if (!field || !field.values?.length || !field.values[0]?.value) {
          rowData[colName] = null;
        } else {
          const value = field.values.map(v => v.value).join(",");
          switch (ep1_type) {
            case "Number":
              rowData[colName] = isNaN(Number(value)) ? null : Number(value);
              break;
            case "Date":
              const parsed = new Date(value);
              rowData[colName] = isNaN(parsed.getTime()) ? null : parsed.toISOString().split("T")[0];
              break;
            case "String":
            case "Memo":
            default:
              rowData[colName] = value;
          }
        }
      }
 
      rowData["id"] = testId;
      rowData["name"] = fieldMap.get("name")?.values?.[0]?.value || null;
      rowData["has_link"] = fieldMap.get("has-linkage")?.values?.[0]?.value || null;
      rowData["has_attachment"] = fieldMap.get("attachment")?.values?.[0]?.value || null;
      rowData["last_modified"] = fieldMap.get("last-modified")?.values?.[0]?.value || null;
      rowData["parent_id"] = fieldMap.get("parent-id")?.values?.[0]?.value || null;
      rowData["qtest_testcase_id"] = null;
      rowData["upload_status"] = null;
 
      const columns = Object.keys(rowData).map(col => `\`${col}\``).join(", ");
      const values = Object.values(rowData);
      const placeholders = values.map(() => "?").join(", ");
 
      console.log("\u2714\uFE0F Prepared row keys:", Object.keys(rowData));
      await db.promise().query(`INSERT INTO tests (${columns}) VALUES (${placeholders})`, values);
      insertedCount++;
    }
 
    res.status(200).json({
      success: true,
      message: `${insertedCount} missing test(s) inserted successfully`
    });
 
  } catch (err) {
    console.error("\u274C Sync error:", err.message);
    res.status(500).json({ success: false, message: err.message });
  }
};
 
 
const syncMissingTestsAndStepsRecursive = async (req, res) => {
  try {
    const session = await getAlmSession();
 
    // Load field mappings for TestCases
    const [mappings] = await db.promise().query(
      "SELECT ep1_name, ep1_type, ep2_field_id FROM Field_mappings WHERE artifact_type = 'TestCases' AND link_name = ?",
      [session.link_name]
    );
 
    // Get all columns from the tests table
    const [columnsInfo] = await db.promise().query("SHOW COLUMNS FROM tests");
    const dbColumns = new Set(columnsInfo.map(col => col.Field));
 
    const insertedTests = new Set();
    const skippedTestIds = new Set();
    const failedTestCases = [];
    const failedTestSteps = [];
 
    let round = 1;
 
    while (true) {
      console.log(`\n🔁 Recursion Round ${round++}`);
 
      const [existingTests] = await db.promise().query("SELECT id FROM tests");
      const existingIds = new Set(existingTests.map(row => row.id));
 
      const [linkTests] = await db.promise().query(
        "SELECT DISTINCT link_test FROM alm_testcase_steps WHERE link_test IS NOT NULL"
      );
 
      const missingTestIds = linkTests
        .map(row => row.link_test)
        .filter(
          id =>
            !existingIds.has(id) &&
            !skippedTestIds.has(id) &&
            id !== null &&
            id !== undefined &&
            id !== 0
        );
 
      if (missingTestIds.length === 0) {
        console.log("✅ All linked test cases are resolved.");
        break;
      }
 
      let triedThisRound = 0;
      let insertedThisRound = 0;
 
      for (const testId of missingTestIds) {
        if (testId === 0) {
  console.warn("⚠️ Skipping invalid test ID 0 (default placeholder)");
  skippedTestIds.add(0);
  continue;
}
 
        triedThisRound++;
 
        let entity;
        try {
          entity = await fetchTestById(testId, session);
        } catch (err) {
          failedTestCases.push({
            id: testId,
            name: null,
            reason:
              err.response?.status === 404
                ? "❌ Test not found in ALM (404)"
                : `❌ Fetch failed: ${err.message}`
          });
          skippedTestIds.add(testId);
          continue;
        }
 
        if (!entity?.Fields) {
          failedTestCases.push({
            id: testId,
            name: null,
            reason: "❌ Test found in ALM but has no fields"
          });
          skippedTestIds.add(testId);
          continue;
        }
 
        try {
          // Prepare row data with mapping validation
          const rowData = {};
          const fieldMap = new Map(entity.Fields.map(f => [f.Name.toLowerCase(), f]));
 
          for (const { ep1_name, ep1_type } of mappings) {
            const field = fieldMap.get(ep1_name.toLowerCase());
            const colName = ep1_name.replace(/[^a-zA-Z0-9_]/g, "_").toLowerCase();
 
            if (!dbColumns.has(colName)) {
              throw new Error(`❌ Column '${colName}' is missing in 'tests' table`);
            }
 
            if (!field?.values?.[0]?.value) {
              rowData[colName] = null;
            } else {
              const value = field.values.map(v => v.value).join(",");
              rowData[colName] =
                ep1_type === "Number"
                  ? Number(value) || null
                  : ep1_type === "Date"
                    ? new Date(value).toISOString().split("T")[0]
                    : value;
            }
          }
 
          if (dbColumns.has("id")) rowData["id"] = testId;
          if (dbColumns.has("name"))
            rowData["name"] = fieldMap.get("name")?.values?.[0]?.value || null;
          if (dbColumns.has("has_link"))
            rowData["has_link"] =
              fieldMap.get("has-linkage")?.values?.[0]?.value || null;
          if (dbColumns.has("has_attachment"))
            rowData["has_attachment"] =
              fieldMap.get("attachment")?.values?.[0]?.value || null;
          if (dbColumns.has("last_modified"))
            rowData["last_modified"] =
              fieldMap.get("last-modified")?.values?.[0]?.value || null;
          if (dbColumns.has("parent_id"))
            rowData["parent_id"] =
              fieldMap.get("parent-id")?.values?.[0]?.value || null;
          if (dbColumns.has("qtest_testcase_id")) rowData["qtest_testcase_id"] = null;
          if (dbColumns.has("upload_status")) rowData["upload_status"] = null;
 
          const columns = Object.keys(rowData)
            .map(c => `\`${c}\``)
            .join(", ");
          const values = Object.values(rowData);
          const placeholders = values.map(() => "?").join(", ");
 
          await db
            .promise()
            .query(`INSERT INTO tests (${columns}) VALUES (${placeholders})`, values);
 
          insertedTests.add(testId);
          insertedThisRound++;
 
          console.log(`🟢 Inserted test ID: ${testId}`);
        } catch (err) {
          failedTestCases.push({
            id: testId,
            name: null,
            reason: err.message
          });
          skippedTestIds.add(testId);
          console.warn(`⚠️ Failed to insert test ID ${testId}: ${err.message}`);
        }
      }
 
      if (triedThisRound > 0 && insertedThisRound === 0) {
        throw new Error(
          "❌ All test inserts failed in this round (e.g. due to schema mismatch or fetch errors). Stopping to avoid infinite loop."
        );
      }
 
      if (insertedTests.size > 0) {
        console.log("📥 Fetching steps for newly inserted test cases...");
        //const steps = await fetchTestCaseStepsByIds([...insertedTests], session);
 
        const filteredTestIds = [...insertedTests].filter(id => id !== 0);
if (filteredTestIds.length > 0) {
  const steps = await fetchTestCaseStepsByIds(filteredTestIds, session);
 
  const foundParentIds = new Set(
    steps.map(s => s.Fields.find(f => f.Name === "parent-id")?.values?.[0]?.value)
  );
 
  for (const testId of filteredTestIds) {
    if (!foundParentIds.has(String(testId))) {
      failedTestSteps.push({
        parent_id: testId,
        reason: "❌ No steps found in ALM for this test case"
      });
    }
  }
 
  await insertTestStepsToDB(steps);
}
insertedTests.clear();
 
 
        // const foundParentIds = new Set(
        //   steps.map(s => s.Fields.find(f => f.Name === "parent-id")?.values?.[0]?.value)
        // );
 
        // for (const testId of insertedTests) {
        //   if (!foundParentIds.has(String(testId))) {
        //     failedTestSteps.push({
        //       parent_id: testId,
        //       reason: "❌ No steps found in ALM for this test case"
        //     });
        //   }
        // }
 
        // await insertTestStepsToDB(steps);
        // insertedTests.clear();
      }
    }
 
    res.status(200).json({
      success: true,
      message: "✅ Test sync completed.",
      missingTestCases: failedTestCases,
      missingTestSteps: failedTestSteps
    });
  } catch (error) {
    console.error("❌ Recursive sync error:", error.message);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};
 
 
module.exports = { synctestfromsteps, syncMissingTestsAndStepsRecursive };