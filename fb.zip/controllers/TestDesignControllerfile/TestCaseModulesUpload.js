const fs = require('fs');
const path = require('path');
const axios = require('axios');
const db = require("../../config/db");


async function main() {
  try {
    // Load credentials
    const credentialsPath = path.join(__dirname, '../../data/qTestCredentials.json');
    const credentialsData = fs.readFileSync(credentialsPath, 'utf-8');
    const config = JSON.parse(credentialsData);
    
    const qTestDomain = config.qTestDomain;
    const apiToken = config.apiToken;
    const projectId = config.projectId;
    
    // Load modules from DB
    let modules = await getModulesFromDb();
    if (!modules || modules.length === 0) {
      console.log("No modules found to upload");
      return { success: false, message: "No modules found to upload" };
    }

    console.log(`Found ${modules.length} modules to process`);

    // Track qTest IDs for parent/child mapping
    const qTestParentMap = new Map();
    const notProcessed = new Set(modules.map(m => m.qTest_Order));

    // Keep retrying until all are processed or no progress
    let lastCount = -1;
    while (notProcessed.size !== 0 && lastCount !== notProcessed.size) {
      lastCount = notProcessed.size;
      for (const module of modules) {
        if (!notProcessed.has(module.qTest_Order)) continue;

        let qtestParentId = null;

        // Parent module logic
        if (module.ALM_PID !== 0) {
          qtestParentId = qTestParentMap.get(module.ALM_PID);
          if (!qtestParentId) continue;
        }

        const payload = {
          name: module.Name || "Unnamed Module",
          description: module.Description || ""
        };

        try {
          // Save current payload for debug
          const jiraCredentialsPath = path.join(__dirname, '../../data/TestDesigndatafile/TestCaseModulesReleasesfield.json');
          fs.writeFileSync(jiraCredentialsPath, JSON.stringify(payload, null, 2), 'utf-8');

          let response;
          if (module.ALM_PID === 0) {
            console.log(`Creating root module: ${module.Name}`);
            response = await axios.post(
              `${qTestDomain}/api/v3/projects/${projectId}/modules`,
              payload,
              {
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': `Bearer ${apiToken}`
                }
              }
            );
          } else {
            console.log(`Creating child module: ${module.Name} under parent ID ${qtestParentId}`);
            response = await axios.post(
              `${qTestDomain}/api/v3/projects/${projectId}/modules?parentId=${qtestParentId}`,
              payload,
              {
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': `Bearer ${apiToken}`
                }
              }
            );
          }

          const newQtestId = response.data.id;
          console.log(`✅ Created module ${module.Name} → qTest ID: ${newQtestId}`);

          // Map and update DB
          qTestParentMap.set(module.ALM_CID, newQtestId);
          await updateModuleWithQtestId(module.qTest_Order, newQtestId, qtestParentId);
          await updateModuleStatus(module.qTest_Order, 'completed', response.status);

          notProcessed.delete(module.qTest_Order);

          const responsePath = path.join(__dirname, '../../data/TestDesigndatafile/TestModules.json');
          fs.writeFileSync(responsePath, JSON.stringify(response.data, null, 2), 'utf-8');

        } catch (error) {
          console.error(`❌ Error creating module ${module.Name}: ${error.message}`);
          const responseCode = error.response?.status || 500;
          await updateModuleStatus(module.qTest_Order, 'failed', responseCode);
        }
      }
    }

    if (notProcessed.size === 0) {
      console.log('✅ All modules uploaded successfully');
      return { success: true, message: "completed" };
    } else {
      console.log(`⚠️ Some modules couldn't be uploaded: ${Array.from(notProcessed).join(', ')}`);
      return { success: false, message: "Some modules could not be uploaded", notProcessed: Array.from(notProcessed) };
    }

  } catch (error) {
    console.error('❌ Fatal Error:', error.message);
    return { success: false, message: error.message };
  }
}

// Load modules from DB
async function getModulesFromDb() {
  return new Promise((resolve, reject) => {
    db.query(
      "SELECT * FROM Testcasemodules_releases ORDER BY qTest_Order ASC", 
      (err, results) => {
        if (err) return reject(err);
        resolve(results);
      }
    );
  });
}

// Update qTest ID and parent ID
async function updateModuleWithQtestId(qTest_Order, qTest_TC_ID, qTest_TC_PID) {
  return new Promise((resolve, reject) => {
    db.query(
      "UPDATE Testcasemodules_releases SET qTest_TC_ID = ?, qTest_TC_PID = ? WHERE qTest_Order = ?",
      [qTest_TC_ID, qTest_TC_PID, qTest_Order],
      (err, result) => {
        if (err) return reject(err);
        resolve(result);
      }
    );
  });
}

// Update upload status and response code
async function updateModuleStatus(qTest_Order, status, responseCode) {
  return new Promise((resolve, reject) => {
    db.query(
      "UPDATE Testcasemodules_releases SET upload_status = ?, response_code = ? WHERE qTest_Order = ?",
      [status, responseCode, qTest_Order],
      (err, result) => {
        if (err) return reject(err);
        resolve(result);
      }
    );
  });
}

module.exports = { main };
