const fs = require('fs');
const path = require('path');
const axios = require('axios');
const db = require('../../config/db').promise();
 
const CONFIG_PATH = path.join(__dirname, '../../data/ALMcredentials.json');
const OUTPUT_PATH = path.join(__dirname, '../../data/LinksDataFile/RequirementToTestCaseLink.json');
 
function loadJSON(filePath) {
  return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
}
 
function getCookieValue(setCookieHeaders, name) {
  for (const header of setCookieHeaders || []) {
    const parts = header.split(';')[0].split('=');
    if (parts[0] === name) return parts[1];
  }
  return null;
}
 
function getFieldValue(fields, name) {
  for (const field of fields) {
    if (field.Name === name && Array.isArray(field.values) && field.values.length > 0) {
      return field.values[0].value;
    }
  }
  return null;
}
 
function parseIntSafe(val) {
  const parsed = parseInt(val);
  return isNaN(parsed) ? 0 : parsed;
}
 
// ✅ Step 1: Fetch data from ALM and save to file
async function fetchReqToTestFromALM() {
  const almConfig = loadJSON(CONFIG_PATH);
 
  const authUrl = `${almConfig.almServerUrl}/api/authentication/sign-in`;
  const encodedAuth = Buffer.from(`${almConfig.username}:${almConfig.password}`).toString('base64');
 
  const authResponse = await axios.post(authUrl, {}, {
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Basic ${encodedAuth}`
    },
    withCredentials: true
  });
 
  const cookies = authResponse.headers['set-cookie'];
  const cookieHeader = [
    `XSRF-TOKEN=${getCookieValue(cookies, 'XSRF-TOKEN')}`,
    `JSESSIONID=${getCookieValue(cookies, 'JSESSIONID')}`,
    `LWSSO_COOKIE_KEY=${getCookieValue(cookies, 'LWSSO_COOKIE_KEY')}`,
    `ALM_USER=${getCookieValue(cookies, 'ALM_USER')}`,
    `QCSession=${getCookieValue(cookies, 'QCSession')}`
  ].join('; ');
 
  const dataUrl = `${almConfig.almServerUrl}/rest/domains/${almConfig.domain}/projects/${almConfig.project}/requirement-coverages`;
  const response = await axios.get(dataUrl, {
    headers: {
      'Cookie': cookieHeader,
      'Accept': 'application/json'
    }
  });
 
  fs.writeFileSync(OUTPUT_PATH, JSON.stringify(response.data, null, 2));
}
 
// ✅ Step 2: Read file and insert into DB
async function insertReqToTestToDB() {
  const raw = fs.readFileSync(OUTPUT_PATH, 'utf-8');
  const json = JSON.parse(raw);
  const entities = json.entities || [];
 
  await db.execute('DROP TABLE IF EXISTS ReqToTestLink');
  await db.execute(`
    CREATE TABLE IF NOT EXISTS ReqToTestLink (
      id INT PRIMARY KEY,
      test_id INT,
      req_id INT,
      entity_type TEXT,
      link_status TEXT
    )
  `);
 
  for (const entity of entities) {
    const fields = entity.Fields;
    const id = getFieldValue(fields, 'id');
    const reqId = getFieldValue(fields, 'requirement-id');
    const testId = getFieldValue(fields, 'test-id');
    const entityType = getFieldValue(fields, 'entity-type');
 
    if (id && reqId && testId) {
      await db.execute(
        'INSERT INTO ReqToTestLink (id, req_id, test_id, entity_type) VALUES (?, ?, ?, ?)',
        [parseIntSafe(id), parseIntSafe(reqId), parseIntSafe(testId), entityType]
      );
    }
  }
}
 
// ✅ Step 3: Combined function for router
const runReqToTestSync = async (req, res) =>
 {
  try {
    await fetchReqToTestFromALM();
    await insertReqToTestToDB();
    res.json({ message: '✅ Requirement to Test link data synced from ALM and inserted into DB.' });
  } catch (err) {
    console.error('❌ Error in sync:', err.message);
    res.status(500).json({ error: err.message });
  }
};
 
// ✅ Export
module.exports = { runReqToTestSync };
 
 