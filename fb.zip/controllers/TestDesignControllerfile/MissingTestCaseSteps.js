const axios = require("axios");
const path = require("path");
const db = require("../../config/db");

// Helper: Fetch test case steps from ALM for given test IDs
const fetchTestCaseStepsByIds = async (testIds, session) => {
  const allDesignSteps = [];

  for (const testId of testIds) {
    const stepUrl = `${session.baseUrl}/rest/domains/${session.domain}/projects/${session.project}/design-steps?query={parent-id[=${testId}]}`;
    try {
      const response = await axios.get(stepUrl, {
        headers: {
          Accept: "application/json",
          Cookie: session.cookieHeader
        }
      });
      const entities = response.data?.entities || [];
      console.log(`📥 Test ID ${testId}: Fetched ${entities.length} step(s)`);
      allDesignSteps.push(...entities);
    } catch (err) {
      console.warn(`⚠️ Failed to fetch steps for test ID ${testId}: ${err.message}`);
    }
  }

  return allDesignSteps;
};

// Helper: Insert ALM test steps into `alm_testcase_steps` table
const insertTestStepsToDB = async (entities = []) => {
  if (!entities.length) {
    console.log("⚠️ No test steps to insert.");
    return;
  }

  const steps = entities.map(entity => {
    const fieldMap = {};
    entity.Fields.forEach(field => {
      fieldMap[field.Name] = field.values?.[0]?.value || null;
    });

    return [
      parseInt(fieldMap["id"]),
      fieldMap["name"],
      fieldMap["has-params"],
      fieldMap["link-test"] ? parseInt(fieldMap["link-test"]) : null,
      fieldMap["description"],
      fieldMap["expected"],
      fieldMap["parent-id"] ? parseInt(fieldMap["parent-id"]) : null,
      fieldMap["attachment"],
      fieldMap["step-order"] ? parseInt(fieldMap["step-order"]) : null,
      null, 
      null  
    ];
  });

  await db.promise().query(
    `INSERT IGNORE INTO alm_testcase_steps
     (id, name, has_params, link_test, description, expected, parent_id, attachment, step_order, qtest_tc_step_id, upload_status)
     VALUES ?`,
    [steps]
  );

  console.log(`✅ Inserted ${steps.length} test step(s) into alm_testcase_steps`);
};

module.exports = {
  fetchTestCaseStepsByIds,
  insertTestStepsToDB
};
