
const axios = require("axios");
const fs = require("fs");
const path = require("path");
const https = require("https");
const dbRaw = require("../../config/db");
const db = dbRaw.promise();

const CONFIG_PATH = path.join(__dirname, "../../data/AlmCredentials.json");
const almConfig = JSON.parse(fs.readFileSync(CONFIG_PATH, "utf-8"));

const getFieldValue = (fields, fieldName, fallback = null) => {
  const field = fields.find(f => f.Name === fieldName);
  const values = field?.values;
  if (!values || values.length === 0 || values[0].value === undefined || values[0].value === null) {
    console.warn(`⚠️ Field '${fieldName}' is missing or null, using fallback: ${fallback}`);
    return fallback;
  }
  return values[0].value;
};

const parseCookies = (cookieArray) => {
  const cookieMap = {};
  cookieArray.forEach(cookie => {
    const [cookiePair] = cookie.split(';');
    const [name, value] = cookiePair.split('=');
    cookieMap[name.trim()] = value;
  });
  return cookieMap;
};

const buildCookieHeader = ({ xsrfToken, sessionCookie, lwssoCookie, almUser, qcSession }) => {
  return `XSRF-TOKEN=${xsrfToken}; JSESSIONID=${sessionCookie}; LWSSO_COOKIE_KEY=${lwssoCookie}; ALM_USER=${almUser}; QCSession=${qcSession}`;
};

const getALMCookies = async () => {
  const { almServerUrl, username, password } = almConfig;
  const loginUrl = `${almServerUrl}/api/authentication/sign-in`;
  const authHeader = 'Basic ' + Buffer.from(`${username}:${password}`).toString('base64');

  const loginResponse = await axios.post(loginUrl, {}, {
    headers: {
      'Content-Type': 'application/json',
      'Authorization': authHeader
    },
    withCredentials: true,
    httpsAgent: new https.Agent({ rejectUnauthorized: false })
  });

  const cookies = loginResponse.headers['set-cookie'] || [];
  const cookieMap = parseCookies(cookies);

  const {
    'XSRF-TOKEN': xsrfToken,
    'JSESSIONID': sessionCookie,
    'LWSSO_COOKIE_KEY': lwssoCookie,
    'ALM_USER': almUser,
    'QCSession': qcSession
  } = cookieMap;

  if (!xsrfToken || !sessionCookie) {
    throw new Error("Missing required session cookies from ALM.");
  }

  return buildCookieHeader({ xsrfToken, sessionCookie, lwssoCookie, almUser, qcSession });
};

const fetchAndInsertRequirementById = async (reqId, cookieHeader, fieldMappings, visited = new Set()) => {
  if (visited.has(reqId)) return false;
  visited.add(reqId);

  const { domain, project, almServerUrl } = almConfig;
  const url = `${almServerUrl}/rest/domains/${domain}/projects/${project}/requirements/${reqId}`;

  try {
    const response = await axios.get(url, {
      headers: { Accept: "application/json", Cookie: cookieHeader },
      httpsAgent: new https.Agent({ rejectUnauthorized: false })
    });

    const entityFields = response.data?.Fields;
    if (!entityFields) return false;

    const id = getFieldValue(entityFields, "id", reqId);
    if (!id) return false;

    const reservedFields = {
      id,
      name: getFieldValue(entityFields, "name"),
      parent_id: getFieldValue(entityFields, "parent-id"),
      type_id: getFieldValue(entityFields, "type-id"),
      link: null,
      attachment: null,
      qtest_requirement_id: null,
      uplode_status: null
    };

    const columnNames = [];
    const values = [];

    for (const mapping of fieldMappings) {
      const fieldName = mapping.ep1_name;
      const safeColName = fieldName.replace(/[^a-zA-Z0-9_]/g, "_").toLowerCase();
      if (!Object.hasOwn(reservedFields, safeColName)) {
        columnNames.push(safeColName);
        values.push(getFieldValue(entityFields, fieldName));
      }
    }

    for (const [key, val] of Object.entries(reservedFields)) {
      columnNames.push(key);
      values.push(val);
    }

    const placeholders = new Array(columnNames.length).fill("?").join(", ");
    const sql = `INSERT INTO requirement (${columnNames.map(c => `\`${c}\``).join(", ")}) VALUES (${placeholders})`;
    await db.query(sql, values);

    // recursively insert parent if not exists
    const parentId = reservedFields.parent_id;
    if (parentId) {
      const [[exists] = []] = await db.query("SELECT id FROM requirement WHERE id = ?", [parentId]);
      if (!exists) await fetchAndInsertRequirementById(parentId, cookieHeader, fieldMappings, visited);
    }

    return true;
  } catch (err) {
    console.warn(`⚠️ Failed to fetch/insert req_id ${reqId}:`, err.message);
    return false;
  }
};

const syncRequirements = async (req, res) => {
  try {
    const { link_name } = almConfig;
    const [fieldMappings] = await db.query(
      `SELECT ep1_name FROM Field_mappings WHERE artifact_type = 'Requirement' AND link_name = ?`,
      [link_name]
    );
    if (!fieldMappings.length) return res.status(400).json({ success: false, message: "No field mappings found." });

    const [testRows] = await db.query("SELECT id FROM tests");
    const testIds = testRows.map(row => row.id);

    const [linkRows] = await db.query(
      "SELECT DISTINCT req_id FROM reqtotestlink WHERE test_id IN (?)",
      [testIds]
    );
    const reqIdsToCheck = linkRows.map(row => row.req_id);

    const [existingReqs] = await db.query("SELECT id FROM requirement WHERE id IN (?)", [reqIdsToCheck]);
    const existingReqIds = new Set(existingReqs.map(row => row.id));
    const missingReqIds = reqIdsToCheck.filter(id => !existingReqIds.has(id));

    const cookieHeader = await getALMCookies();
    const insertedIds = [];
    const visited = new Set();

    for (const reqId of missingReqIds) {
      const success = await fetchAndInsertRequirementById(reqId, cookieHeader, fieldMappings, visited);
      if (success) insertedIds.push(reqId);
    }

    return res.status(200).json({
      success: true,
      message: `✅ Inserted ${insertedIds.length} requirements and their parent hierarchy.`
    });

  } catch (err) {
    console.error("❌ Unexpected error:", err);
    return res.status(500).json({ success: false, message: err.message });
  }
};

module.exports = {syncRequirements};
