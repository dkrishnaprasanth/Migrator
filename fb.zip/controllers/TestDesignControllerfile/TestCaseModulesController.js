const db = require("../../config/db");
const fs = require("fs");
const path = require("path");
const { fetchTestCaseModulesReleases } = require("../../controllers/TestDesignControllerfile/TestCaseModulesFields");
const { main } = require("../../controllers/TestDesignControllerfile/TestCaseModulesUpload");

// ------------------------------
// Read and Validate JSON
// ------------------------------
const loadTestJsonAndValidate = async () => {
  const jsonFilePath = path.join(__dirname, "../../data/TestDesigndatafile/TestCaseModulesReleases.json");

  try {
    const rawData = fs.readFileSync(jsonFilePath, "utf-8");
    if (!rawData) {
      console.error("❌ JSON file is empty.");
      return [];
    }

    const parsed = JSON.parse(rawData);
    if (!parsed.entities || !Array.isArray(parsed.entities)) {
      console.error("❌ Unexpected JSON structure:", parsed);
      return [];
    }

    const transformedData = parsed.entities.map(entity => {
      const fieldMap = {};
      entity.Fields.forEach(field => {
        const name = field.Name;
        const value = field.values && field.values.length > 0 ? field.values[0].value : null;
        fieldMap[name] = value;
      });

      return {
        ALM_PID: fieldMap["parent-id"] || null,
        ALM_CID: fieldMap["id"] || null,
        Name: fieldMap["name"] || null,
        Description: fieldMap["description"] || null,
        last_modified: fieldMap["last-modified"] || null,
        qTest_TC_ID: null,
        qTest_TC_PID: null,
        qTest_Order: null
      };
    });

    transformedData.forEach((item, index) => {
      item.qTest_Order = index + 1;
    });

    return transformedData;
  } catch (err) {
    console.error("❌ Error reading/parsing JSON file:", err);
    return [];
  }
};

// ------------------------------
// Create Table
// ------------------------------
const createTestCaseModulesTable = async () => {
  return new Promise((resolve, reject) => {
    // const dropQuery = `DROP TABLE IF EXISTS Testcasemodules_releases`;
    const createQuery = `
      CREATE TABLE IF NOT EXISTS Testcasemodules_releases (
        ALM_PID INT ,
        ALM_CID INT PRIMARY KEY,
        Name VARCHAR(255),
        Description TEXT,
        last_modified TIMESTAMP,
        qTest_TC_ID INT,
        qTest_TC_PID INT,
        qTest_Order INT,
        upload_status VARCHAR(255),
        response_code INT
      )
    `;

    // db.query(dropQuery, (dropErr) => {
    //   if (dropErr) return reject(dropErr);

    db.query(createQuery, (createErr) => {
      if (createErr) return reject(createErr);
      resolve();
    });
    //});
  });
};




// const insertDataTestCaseModulesFromJson = async () => {
//   try {
//     const jsonData = await loadTestJsonAndValidate();
//     if (!jsonData || jsonData.length === 0) return false;

//     let inserted = 0, skipped = 0;

//     for (const item of jsonData) {
//       // Check if ALM_CID already exists
//       const [existingRows] = await db.promise().query(
//         "SELECT 1 FROM Testcasemodules_releases WHERE ALM_CID = ?",
//         [item.ALM_CID]
//       );

//       if (existingRows.length > 0) {
//         // Skip if record already exists
//         skipped++;
//         continue;
//       }

//       // Insert only new records
//       await db.promise().query(
//         `INSERT INTO Testcasemodules_releases
//          (ALM_PID, ALM_CID, Name, Description, last_modified, qTest_TC_ID, qTest_TC_PID, qTest_Order, upload_status)
//          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
//         [
//           item.ALM_PID,
//           item.ALM_CID,
//           item.Name,
//           item.Description,
//           item.last_modified,
//           item.qTest_TC_ID,
//           item.qTest_TC_PID,
//           item.qTest_Order,
//           'pending'
//         ]
//       );
//       inserted++;
//     }

//     console.log(`✅ Inserted: ${inserted}, Skipped: ${skipped}`);
//     return true;
//   } catch (err) {
//     console.error("❌ Error in insertDataFromJson:", err);
//     return false;
//   }
// };





// ------------------------------
// Init
// ------------------------------

const insertDataTestCaseModulesFromJson = async () => {
  try {
    const jsonData = await loadTestJsonAndValidate();
    if (!jsonData || jsonData.length === 0) return { inserted: 0, skipped: 0, total: 0 };
 
    let inserted = 0, skipped = 0;
 
    for (const item of jsonData) {
      const [existingRows] = await db.promise().query(
        "SELECT 1 FROM Testcasemodules_releases WHERE ALM_CID = ?",
        [item.ALM_CID]
      );
 
      if (existingRows.length > 0) {
        skipped++;
        continue;
      }
 
      await db.promise().query(
        `INSERT INTO Testcasemodules_releases
         (ALM_PID, ALM_CID, Name, Description, last_modified, qTest_TC_ID, qTest_TC_PID, qTest_Order, upload_status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          item.ALM_PID,
          item.ALM_CID,
          item.Name,
          item.Description,
          item.last_modified,
          item.qTest_TC_ID,
          item.qTest_TC_PID,
          item.qTest_Order,
          'pending'
        ]
      );
      inserted++;
    }
 
    const total = inserted + skipped;
 
    // 👇 key change: inserted is always the total
    return { inserted: total, skipped, total };
  } catch (err) {
    console.error("❌ Error in insertDataFromJson:", err);
    return { inserted: 0, skipped: 0, total: 0, error: err.message };
  }
};
 

const initTestCaseModules = async () => {
  try {
    console.log("🚀 Fetching fields...");
    await fetchTestCaseModulesReleases();
    console.log("✅ Fetch done.");
    await createTestCaseModulesTable();
    await insertDataTestCaseModulesFromJson();
  } catch (err) {
    console.error("❌ Initialization failed:", err);
    process.exit(1);
  }
};

// ------------------------------
// Get Data in Order
// ------------------------------
const getReleasesTestCaseModulesData = (req, res) => {
  db.query("SELECT * FROM Testcasemodules_releases ORDER BY qTest_Order ASC", (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};

// ------------------------------
// Insert via API with Order Maintenance
// ------------------------------
const insertReleasesTestCaseModulesData = (req, res) => {
  const releaseData = req.body;

  if (!Array.isArray(releaseData) || releaseData.length === 0) {
    return res.status(400).json({ message: "Invalid input." });
  }

  // Get the current maximum order value
  db.query("SELECT MAX(qTest_Order) AS maxOrder FROM Testcasemodules_releases", (err, results) => {
    if (err) return res.status(500).json({ error: err.message });

    let startOrder = results[0].maxOrder || 0;

    const values = releaseData.map(item => {
      startOrder++;
      return [
        item.ALM_PID,
        item.ALM_CID,
        item.Name,
        item.Description,
        item.last_modified,
        item.qTest_TC_ID,
        item.qTest_TC_PID,
        startOrder
      ];
    });

    db.query(
      `INSERT INTO Testcasemodules_releases (ALM_PID, ALM_CID, Name, Description,last_modified, qTest_TC_ID, qTest_TC_PID, qTest_Order) VALUES ?`,
      [values],
      (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.status(201).json({ message: `${result.affectedRows} records added in order.` });
      }
    );
  });
};

// const uploadTestCaseModulesToQTest = async (req, res) => {
//   try {
//     // Check if there's data in the table
//     const [countResult] = await db.promise().query("SELECT COUNT(*) AS count FROM Testcasemodules_releases");
//     if (countResult[0].count === 0) {
//       return res.status(400).json({ 
//         success: false, 
//         message: "No modules data found. Please load data before uploading." 
//       });
//     }

//     // Check if any qTest_TC_IDs already exist
//     const [existingIds] = await db.promise().query(
//       "SELECT COUNT(*) AS count FROM Testcasemodules_releases WHERE qTest_TC_ID IS NOT NULL"
//     );
//     if (existingIds[0].count > 0) {
//       return res.status(400).json({ 
//         success: false, 
//         message: "Some modules already have qTest IDs assigned. Please refresh data before uploading again." 
//       });
//     }

//     // Begin upload
//     console.log("⏳ Starting upload to qTest...");
//     const result = await main();  // Assume this sets qTest_TC_IDs in DB

//     // After upload, check if all rows got qTest_TC_ID
//     const [missingIds] = await db.promise().query(
//       "SELECT COUNT(*) AS missing FROM Testcasemodules_releases WHERE qTest_TC_ID IS NULL"
//     );

//     if (missingIds[0].missing === 0) {
//       const statusMessage = result.message || "Successfully uploaded to qTest";
//       await db.promise().query(
//         "UPDATE Testcasemodules_releases SET upload_status = ?",
//         [statusMessage]
//       );
//     } 
//   } catch (error) {
//     console.error("❌ Upload failed:", error);
//     return res.status(500).json({ success: false, message: error.message });
//   }
// };

const uploadTestCaseModulesToQTest = async (req, res) => {
  try {
    // Check if there's data in the table
    const [countResult] = await db.promise().query("SELECT COUNT(*) AS count FROM Testcasemodules_releases");
    if (countResult[0].count === 0) {
      return res.status(400).json({
        success: false,
        message: "No modules data found. Please load data before uploading."
      });
    }

    // // Check if any qTest_TC_IDs already exist
    // const [existingIds] = await db.promise().query(
    //   "SELECT COUNT(*) AS count FROM Testcasemodules_releases WHERE qTest_TC_ID IS NOT NULL"
    // );
    // if (existingIds[0].count > 0) {
    //   return res.status(400).json({ 
    //     success: false, 
    //     message: "Some modules already have qTest IDs assigned. Please refresh data before uploading again." 
    //   });
    // } 

    // Step 2: Check if all are already uploaded
    const [remaining] = await db.promise().query(
      "SELECT COUNT(*) AS count FROM Testcasemodules_releases WHERE upload_status != 'completed' OR upload_status IS NULL"
    );

    if (remaining[0].count === 0) {
      return res.status(200).json({
        success: true,
        message: "✅ All test case modules are already uploaded."
      });
    }

    // Begin upload
    console.log("⏳ Starting upload to qTest...");
    const result = await main();  // Assume this sets qTest_TC_IDs in DB

    // After upload, check if all rows got qTest_TC_ID
    const [missingIds] = await db.promise().query(
      "SELECT COUNT(*) AS missing FROM Testcasemodules_releases WHERE qTest_TC_ID IS NULL"
    );

    if (missingIds[0].missing === 0) {
      const statusMessage = result.message || "Successfully uploaded to qTest";
      await db.promise().query(
        "UPDATE Testcasemodules_releases SET upload_status = ?",
        [statusMessage]
      );
    }

    // ✅ Send response after everything is done
    return res.status(200).json({
      success: true,
      message: "✅ Test Case Modules uploaded successfully to qTest."
    });

  } catch (error) {
    console.error("❌ Upload failed:", error);
    return res.status(500).json({ success: false, message: error.message });
  }
};




const getModulesWithQTestIds = (req, res) => {
  db.query(
    "SELECT * FROM Testcasemodules_releases WHERE qTest_TC_ID IS NOT NULL ORDER BY qTest_Order ASC",
    (err) => {
      if (err) return res.status(500).json({ error: err.message });
    }
  );
};

const getTestCaseModulesCount = async (req, res) => {
  try {
    const jsonFilePath = path.join(__dirname, "../../data/TestDesigndatafile/TestCaseModulesReleases.json");

    if (!fs.existsSync(jsonFilePath)) {
      return res.status(404).json({ success: false, message: "Requirements JSON not found" });
    }

    const jsonData = JSON.parse(fs.readFileSync(jsonFilePath, "utf8"));
    const totalCount = jsonData.entities?.length || 0;

    res.json({ totalCount });
  } catch (error) {
    console.error("❌ Error in getTestCaseModulesCount:", error);
    res.status(500).json({ error: "Failed to fetch test case modules count" });
  }
};
// ------------------------------
// Export
// ------------------------------
module.exports = {
  initTestCaseModules,
  createTestCaseModulesTable,
  insertDataTestCaseModulesFromJson,
  getReleasesTestCaseModulesData,
  insertReleasesTestCaseModulesData,
  uploadTestCaseModulesToQTest,
  getModulesWithQTestIds,
  getTestCaseModulesCount
};
