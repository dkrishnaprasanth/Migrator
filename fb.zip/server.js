const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");


// RELEASES ROUTER FILE:
const almreleasesfields = require("./routes/ReleasesRoutersfile/ALMReleasesFields");
const almreleasesfieldsRouter = require('./routes/ReleasesRoutersfile/ALMReleasesFieldsRouter');

const Releases = require('./routes/ReleasesRoutersfile/ALMReleases');

const qTestReleasesfield = require('./routes/ReleasesRoutersfile/qTestReleasesFields');
const qtestReleasesfieldsRouter = require("./routes/ReleasesRoutersfile/qTestReleasesFieldsRouter");

const MappingReleases = require ("./routes/ReleasesRoutersfile/MappingReleases");
const MappingReleasesRouter = require("./routes/ReleasesRoutersfile/MappingReleasesRouter");

const listReleasesValues = require('./routes/ReleasesRoutersfile/ALMListReleaseValuesFields');
const listReleasesValuesRouter = require("./routes/ReleasesRoutersfile/ALMListReleaseValuesFieldsRouter");

// REQUIREMENT ROUTER FILE:
const requirementfields = require('./routes/RequirementRoutersfile/ALMRequirementFields');
const requirementfieldsRouter = require("./routes/RequirementRoutersfile/ALMRequirementFieldsRouter");


const qtestrequirement = require('./routes/RequirementRoutersfile/qTestRequirementFields');
const  qtestrequirementRouter = require("./routes/RequirementRoutersfile/qTestRequirementFieldsRouter");

const requirement = require('./routes/RequirementRoutersfile/ALMRequirement');

const MappingRequirementRouter = require("./routes/RequirementRoutersfile/MappingRequirementRouter");
const MappingRequirement = require ("./routes/RequirementRoutersfile/MappingRequirement");

const listReleasesRouter = require('./routes/RequirementRoutersfile/ALMListRequirementValueFieldsRouter');
const listRoutes = require("./routes/RequirementRoutersfile/ALMListRequirementValueFieldsControllerRoutes");


// TEST CASES ROUTER FILE:
const testcasemodulesfieleds = require("./routes/TestDesignRoutersfile/TestCaseModulesFieldsRoute")
const testcasemodules = require("./routes/TestDesignRoutersfile/TestCaseModulesRoute")


const almtestcasefields = require("./routes/TestDesignRoutersfile/ALMTestsFields");
const almtestcasefieldsRouter = require('./routes/TestDesignRoutersfile/ALMTestsFieldsRouter');

const almtestcase = require('./routes/TestDesignRoutersfile/ALMTests');

const qTesttestcasefield = require('./routes/TestDesignRoutersfile/qTestTestsFields');
const qtesttestcasefieldsRouter = require("./routes/TestDesignRoutersfile/qTestTestsFieldsRouter");

const uploadtestcase = require ("./routes/TestDesignRoutersfile/MappingTests");
const MappingtestcaseRouter = require("./routes/TestDesignRoutersfile/MappingTestsRouter");

const listtestcaseValues = require('./routes/TestDesignRoutersfile/ALMListTestsValuesFields');
const listtestcaseValuesRouter = require("./routes/TestDesignRoutersfile/ALMListTestsValuesFieldsRouter");

const AlmTestcaseStepsRouter = require("./routes/TestDesignRoutersfile/TestCaseStepsRouter");
const AlmTestcaseStepsControllerRouter = require ('./routes/TestDesignRoutersfile/TestCaseStepsControllerRouter');

const ApproveTestCaseRouter = require ('./routes/TestDesignRoutersfile/ApproveTestCaseRouter.js');

//clear test steps
const ClearTestcaseStepRoute = require('./routes/TestDesignRoutersfile/ClearTestcaseStepRoute.js');
//missingtestcases-and-test case steps
 
const MissingTestCaseAndStepsRoutes = require("./routes/TestDesignRoutersfile/MissingTestCasesAndStepsRouter.js");

//DEFECTS ROUTER FILE:
 
const almdefectsfields = require("./routes/DefectsRoutersfile/ALMDefectsFields");
const almdefectsfieldsRouter = require('./routes/DefectsRoutersfile/ALMDefectsFieldsRouter');

const qtestdefectsfields = require("./routes/DefectsRoutersfile/qTestDefectsFields");
const qtestdefectsfieldsRouter = require('./routes/DefectsRoutersfile/qTestDefectsFieldsRouter');

const Defects = require('./routes/DefectsRoutersfile/ALMDefects');

const MappingDefects = require ("./routes/DefectsRoutersfile/MappingDefects");
const MappingDefectsRouter = require("./routes/DefectsRoutersfile/MappingDefectsRouter");

const listdefectsRouter = require('./routes/DefectsRoutersfile/ALMListDefectValuesFields');
const defectsRoutes = require("./routes/DefectsRoutersfile/ALMListDefectValuesFieldsRouter");

//PARAMETER ROUTER FILE:

const almparameterfields = require("./routes/ParameterRouterfile/ALMParameterConnectionRouter");

// TESTEXECUTION ROUTER FILE:

// TEST SET FIELDS:

const almtestsetfieldsRouter = require ("./routes/TestExecutionRouterfile/ALMTestSetRouter/ALMTestSetFieldsRouter");
const almtestsetfieldscontrollerRouter = require ("./routes/TestExecutionRouterfile/ALMTestSetRouter/ALMTestSetFieldsControllerRouter.js");

const testsetRouter = require ("./routes/TestExecutionRouterfile/ALMTestSetRouter/ALMTestSetRouter.js"); 

const qtestTestSetFieldsRouter = require ("./routes/TestExecutionRouterfile/ALMTestSetRouter/QtestTestSetFieldsRouter.js");
const qtestTestSetFieldsControllerRouter = require ("./routes/TestExecutionRouterfile/ALMTestSetRouter/QtestTestSetFieldsControllerRouter.js");

const MappingTestSetRouter = require ("./routes/TestExecutionRouterfile/ALMTestSetRouter/MappingTestSetRouter.js");
const MappingTestSetControllerRouter = require ("./routes/TestExecutionRouterfile/ALMTestSetRouter/MappingTestSetControllerRouter.js");

const listTestSetValuesRouter = require ("./routes/TestExecutionRouterfile/ALMTestSetRouter/ALMTestSetListValueFieldsRouter.js");
const listTestSetValuesControllerRouter = require ("./routes/TestExecutionRouterfile/ALMTestSetRouter/ALMTestSetListValueFieldControllerRouter.js");

//TEST SET FOLDER:

const almtestsetfolder = require("./routes/TestExecutionRouterfile/ALMTestSetFolderRouter/ALMTestSetConnectionRouter.js");

// TEST INSTANCE FIELDS:

const almtestinstancefieldsRouter = require ("./routes/TestExecutionRouterfile/ALMTestInstanceRouter/AlmTestInstanceFieldsRouter.js");
const almtestinstancefieldscontrollerRouter = require ("./routes/TestExecutionRouterfile/ALMTestInstanceRouter/AlmTestInstanceFieldsControllerRouter.js");

const testinstanceRouter = require ("./routes/TestExecutionRouterfile/ALMTestInstanceRouter/AlmTestInstance.js"); 

const qtestTestinstanceFieldsRouter = require ("./routes/TestExecutionRouterfile/ALMTestInstanceRouter/QtestTestInstanceFields.js");
const qtestTestinstanceFieldsControllerRouter = require ("./routes/TestExecutionRouterfile/ALMTestInstanceRouter/QtestTestInstanceFieldsRouter.js");

const MappingTestinstanceRouter = require ("./routes/TestExecutionRouterfile/ALMTestInstanceRouter/MappingTestInstanceRouter.js");
const MappingTestinstanceControllerRouter = require ("./routes/TestExecutionRouterfile/ALMTestInstanceRouter/MappingTestInstanceControllerRouter.js");

const listTestinstanceValuesRouter = require ("./routes/TestExecutionRouterfile/ALMTestInstanceRouter/AlmTestInstanceListValueFieldsRouter.js");
const listTestinstanceValuesControllerRouter = require ("./routes/TestExecutionRouterfile/ALMTestInstanceRouter/AlmTestInstanceListValueFieldsControllerRouter.js");

//TESTLOG ROUTER FILE:

 const almtestlogfields = require("./routes/TestExecutionRouterfile/ALMTestLog/ALMTestLogConnectionRouter.js");


// SETTINGS ROUTER FILE:

const almSettingsRoutes = require('./routes/settingsRouter');

//Field Validation
const FieldValidate = require("./routes/FieldValidationRouteFile/FieldValidateRoute.js");
 
//LoadMapping
const LoadMapping=require("./routes/LoadMappingRouteFile/LoadMappingRoute.js")


//LinkReleaseToRequirement
const ReleaseToReqLink=require("./routes/LinkRoute/LinkRelToReqRoute.js");

//LinkRequirementToTestCase
const RequirementToTestCaseLink=require("./routes/LinkRoute/LinkReqToTestcaseRoute.js");

//DefectLinking
const defectLinkRoutes = require('./routes/LinkRoute/DefectsLinkRoute.js');


const reportingRoutes = require('./routes/reporting');


///attachments
const RequirementAttachmentRouter = require('./routes/AttachmentsRoute/RequirementRoute.js');

const TestCaseAttachmentsRouter = require('./routes/AttachmentsRoute/TestCaseRoute.js');

const TestCaseStepAttachmentsRouter = require('./routes/AttachmentsRoute/TestCaseStepRoute.js');

const DefectAttachmentsRouter = require('./routes/AttachmentsRoute/DefectRoute.js');

const TestLogAttachmentsRouter = require('./routes/AttachmentsRoute/TestLogRoute.js');

const TestLogStepAttachmentsRouter = require('./routes/AttachmentsRoute/TestLogStepRoute.js');

// Custom Filter Routes

const filterRoutes = require('./routes/CustomFilterRouter/filterRoutes.js');

const logRoutes = require('./routes/logRoutes.js');





//users migration files

const user= require('./routes/UserRoute/pathroute.js');

const app = express();
const PORT = 5550;

app.use(cors());
app.use(bodyParser.json());

// RELEASES FILE:
app.use('/api/alm', almreleasesfields);
app.use("/api/alm", almreleasesfieldsRouter);

app.use('/api/alm',Releases);

app.use('/api/qtest',qTestReleasesfield);
app.use("/api", qtestReleasesfieldsRouter );

app.use('/api/releasesupload', MappingReleases);
app.use("/api", MappingReleasesRouter);

app.use('/api/alm',listReleasesValues);
app.use("/api/alm", listReleasesValuesRouter);

//TEST CASES FILE:
app.use("/api/testcasemodulefieleds",testcasemodulesfieleds );
app.use("/api/test",testcasemodules );

app.use('/api/alm', almtestcasefields);
app.use("/api/alm", almtestcasefieldsRouter);

app.use('/api/alm',almtestcase);

app.use('/api/qtest',qTesttestcasefield );
app.use("/api/qtest", qtesttestcasefieldsRouter );

app.use("/api/testcaseupload", uploadtestcase );
app.use("/api", MappingtestcaseRouter);

app.use('/api/alm',listtestcaseValues );
app.use("/api/alm", listtestcaseValuesRouter);

app.use('/api', AlmTestcaseStepsRouter );
app.use("/api", AlmTestcaseStepsControllerRouter);

app.use("/api",ApproveTestCaseRouter );

app.use('/api', ClearTestcaseStepRoute);
//REQUIREMENT FILE:
app.use('/api', requirementfields);
app.use("/api", requirementfieldsRouter);

app.use('/api', qtestrequirement);
app.use("/api", qtestrequirementRouter);

app.use('/api/alm', requirement);

app.use("/api", MappingRequirementRouter);
app.use('/api/requirementupload', MappingRequirement);

app.use('/api/alm',listReleasesRouter  );
app.use("/api/alm", listRoutes);


//DEFECTS
app.use('/api', almdefectsfields);
app.use("/api", almdefectsfieldsRouter);

app.use('/api/qtest', qtestdefectsfields);
app.use("/api", qtestdefectsfieldsRouter);

app.use('/api/alm',Defects);

app.use('/api/alm', listdefectsRouter);
app.use("/api/alm", defectsRoutes);

app.use('/api/defectsupload', MappingDefects);
app.use("/api", MappingDefectsRouter);

//PARAMETER :

app.use('/api/parameters', almparameterfields);

// TESTEXECUTION:

// TEST SET FIELDS:
app.use('/api/alm', almtestsetfieldsRouter);
app.use('/api/alm', almtestsetfieldscontrollerRouter);

app.use('/api/alm', testsetRouter);

app.use('/api/qtest', qtestTestSetFieldsRouter);
app.use('/api', qtestTestSetFieldsControllerRouter);

app.use('/api/testsetupload', MappingTestSetRouter);
app.use('/api', MappingTestSetControllerRouter);

app.use('/api/alm', listTestSetValuesRouter);
app.use('/api/alm', listTestSetValuesControllerRouter);


// TEST INSTANCE FIELDS:
app.use('/api/alm',  almtestinstancefieldsRouter);
app.use('/api/alm', almtestinstancefieldscontrollerRouter );

app.use('/api/alm', testinstanceRouter );


app.use('/api/qtest', qtestTestinstanceFieldsRouter);
app.use('/api', qtestTestinstanceFieldsControllerRouter);

app.use('/api/testinstanceupload', MappingTestinstanceRouter);
app.use('/api', MappingTestinstanceControllerRouter );

app.use('/api/alm', listTestinstanceValuesRouter);
app.use('/api/alm', listTestinstanceValuesControllerRouter);

// TEST SET FOLDER:
app.use('/api', almtestsetfolder);

//TEST LOG FIELDS:

 app.use('/api', almtestlogfields);

// SETTINGS:
app.use('/api/settings', almSettingsRoutes);


//Field Validation
app.use('/api', FieldValidate);

//LoadMapping
 app.use('/api', LoadMapping);


  //LinkReleaseToRequirement
 app.use('/api',ReleaseToReqLink);

 //LinkRequirementToTestCase
 app.use('/api',RequirementToTestCaseLink);

 //DefectLinking
 app.use('/api', defectLinkRoutes);
 

  ///missing test case and test case steps
 app.use("/api/testdesign", MissingTestCaseAndStepsRoutes );


 app.use('/api/reporting', reportingRoutes);


  // Custom Filter Routes
 app.use('/api', filterRoutes);
 
 app.use('/api', logRoutes);

//login and register

 

 //users
 app.use('/api', user);
 
 //attachments
    app.use('/api/attach', RequirementAttachmentRouter);
    app.use('/api/attach', TestCaseAttachmentsRouter);
    app.use('/api/attach', TestCaseStepAttachmentsRouter);
    app.use('/api/attach', DefectAttachmentsRouter);
    app.use('/api/attach', TestLogAttachmentsRouter);
    app.use('/api/attach', TestLogStepAttachmentsRouter);

app.listen(PORT, () => {
    console.log(` Server running on http://localhost:${PORT}`);
});

