const mysql = require("mysql2");

const db = mysql.createConnection({
    host: "localhost",
    user: "root", 
    password: "Nikhil@123", 
    database: "migrate", 
    port: 3306,
});

db.connect((err) => {
    if (err) {
        console.error(" Error connecting to MySQL:", err);
        return;
    }
    console.log(" Connected to MySQL");
});

module.exports = db;



////----------------------------------------------------------------------


// // ======================
// // db.js
// // ======================

// const fs = require('fs');
// const path = require('path');
// const mysql = require('mysql2');

// // ======================
// // Logger Configuration
// // ======================

// // Toggle logging
// const ENABLE_LOGGING = true;

// // Logs directory in project root
// const LOG_DIR = path.join(__dirname, '..', 'logs');
// const MAX_FILE_SIZE = 50 * 1024; // 50KB

// let fileIndex = 1;
// let currentLogFilePath;
// let currentLogStream;
// let failedLogStream;

// if (ENABLE_LOGGING) {
//     if (!fs.existsSync(LOG_DIR)) {
//         fs.mkdirSync(LOG_DIR);
//     }

//     currentLogFilePath = path.join(LOG_DIR, `log_${fileIndex}.txt`);
//     currentLogStream = fs.createWriteStream(currentLogFilePath, { flags: 'a' });
//     failedLogStream = fs.createWriteStream(path.join(LOG_DIR, 'failed_log.txt'), { flags: 'a' });

//     function getTimeStamp() {
//         return new Date().toISOString();
//     }

//     function createNewStream() {
//         fileIndex++;
//         currentLogFilePath = path.join(LOG_DIR, `log_${fileIndex}.txt`);
//         return fs.createWriteStream(currentLogFilePath, { flags: 'a' });
//     }

//     function logToFile(message, type = 'success') {
//         const logMessage = `[${getTimeStamp()}] ${message}\n`;

//         if (type === 'fail') {
//             failedLogStream.write(logMessage);
//             return;
//         }

//         currentLogStream.write(logMessage, () => {
//             // ✅ Safe check before reading file size
//             if (fs.existsSync(currentLogFilePath)) {
//                 const { size } = fs.statSync(currentLogFilePath);
//                 if (size > MAX_FILE_SIZE) {
//                     currentLogStream.end();
//                     currentLogStream = createNewStream();
//                 }
//             }
//         });
//     }

//     // Override console.log
//     const originalConsoleLog = console.log;
//     console.log = function (...args) {
//         const combined = args.map(String).join(' ');
//         originalConsoleLog(...args);
//         logToFile(combined);
//     };

//     // Custom fail log
//     console.fail = function (...args) {
//         const combined = args.map(String).join(' ');
//         originalConsoleLog(...args);
//         logToFile(combined, 'fail');
//     };
// }

// // ======================
// // MySQL Database Connection
// // ======================
// const db = mysql.createConnection({
//     host: "localhost",
//     user: "root",
//     password: "Anitha@123",
//     database: "demo_1",
//     port: 3305,
// });

// db.connect((err) => {
//     if (err) {
//         console.fail("Error connecting to MySQL:", err);
//         return;
//     }
//     console.log("Connected to MySQL");
// });

// // Export db connection
// module.exports = db;
