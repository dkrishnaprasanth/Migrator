import React, { useState, useEffect } from 'react';
import Topbar from './Topbar';
import Sidebar from "./Sidebar";

const ReportingPage = () => {
  const [schemas, setSchemas] = useState([]);
  const [selectedSchema, setSelectedSchema] = useState('');
  const [activeTab, setActiveTab] = useState('releases'); // Set default tab
  const [releasesData, setReleasesData] = useState({
    summary: null,
    statusBreakdown: [],
    allData: [],
    pagination: {}
  });
  const [requirementsData, setRequirementsData] = useState({
    summary: null,
    statusBreakdown: [],
    allData: [],
    pagination: {}
  });

  const [testcaseData, setTestcaseData] = useState({
    summary: null,
    statusBreakdown: [],
    allData: [],
    pagination: {}
  });


  const [testcasefolderData, setTestcasefolderData] = useState({
    summary: null,
    statusBreakdown: [],
    allData: [],
    pagination: {}
  });

  const [parametersData, setParametersData] = useState({
    summary: null,
    statusBreakdown: [],
    allData: [],
    pagination: {}
  });

  const [testcasestepsData, setTestCaseStepsData] = useState({
    summary: null,
    statusBreakdown: [],
    allData: [],
    pagination: {}
  });

  const [testsetfolderData, setTestsetFolderData] = useState({
    summary: null,
    statusBreakdown: [],
    allData: [],
    pagination: {}
  });

  const [testsetData, setTestsetData] = useState({
    summary: null,
    statusBreakdown: [],
    allData: [],
    pagination: {}
  });

  const [testinstanceData, setTestinstanceData] = useState({
    summary: null,
    statusBreakdown: [],
    allData: [],
    pagination: {}
  });

  const [testlogData, setTestlogData] = useState({
    summary: null,
    statusBreakdown: [],
    allData: [],
    pagination: {}
  });

  const [defectsData, setDefectsData] = useState({
    summary: null,
    statusBreakdown: [],
    allData: [],
    pagination: {}
  });

  //linking-----------

  const [releasetoreqlinkData, setReleaseToReqLinkData] = useState({
    summary: null,
    statusBreakdown: [],
    allData: [],
    pagination: {}
  });

  const [reqtotestlinkData, setReqToTestLinkData] = useState({
    summary: null,
    statusBreakdown: [],
    allData: [],
    pagination: {}
  });

  const [defectslinksData, setDefectsLinksData] = useState({
    summary: null,
    statusBreakdown: [],
    allData: [],
    pagination: {}
  });


  const [currentPage, setCurrentPage] = useState(1);
  const [loading, setLoading] = useState(false); // Don't start loading initially
  const [error, setError] = useState(null);
  const [exportLoading, setExportLoading] = useState(false);
  const [schemaLoading, setSchemaLoading] = useState(true);
  const [availableTables, setAvailableTables] = useState([]);

  const API_BASE_URL = 'http://localhost:5550/api/reporting';

  // Colors for pie chart
  const COLORS = ['#10B981', '#EF4444', '#F59E0B', '#8B5CF6'];

  useEffect(() => {
    fetchSchemas();
  }, []);

  const fetchSchemas = async () => {
    setSchemaLoading(true);
    try {
      const res = await fetch(`${API_BASE_URL}/schemas`);
      if (!res.ok) {
        throw new Error('Failed to fetch schemas');
      }
      const data = await res.json();
      if (data.success) {
        setSchemas(data.schemas);
      } else {
        throw new Error(data.message || 'Failed to fetch schemas');
      }
    } catch (err) {
      console.error('Failed to fetch schemas', err);
      setError('Failed to load schemas. Please check if the backend server is running.');
    } finally {
      setSchemaLoading(false);
    }
  };

  // Only fetch data when schema is selected and user clicks generate report
  useEffect(() => {
    if (selectedSchema && activeTab) {
      fetchAllData();
    }
  }, [currentPage, activeTab, selectedSchema]);

  const fetchAllData = async () => {
    if (!selectedSchema || !activeTab) return;

    setLoading(true);
    setError(null);

    try {
      if (activeTab === 'releases') {
        await fetchReleasesData();
      } else if (activeTab === 'requirement') {
        await fetchRequirementsData();
      } else if (activeTab === 'testcasemodules_releases') {
        await fetchTestcasefolderData();
      } else if (activeTab === 'tests') {
        await fetchTestcaseData();
      } else if (activeTab === 'parameters') {
        await fetchParametersData();
      } else if (activeTab === 'alm_testcase_steps') {
        await fetchTestCaseStepsData();
      } else if (activeTab === 'testsetfolder') {
        await fetchTestsetfolderData();
      } else if (activeTab === 'testset') {
        await fetchTestsetData();
      } else if (activeTab === 'testinstance') {
        await fetchTestinstanceData();
      } else if (activeTab === 'testlogs') {
        await fetchTestlogsData();
      } else if (activeTab === 'defects') {
        await fetchDefectsData();
      }



      //------Link-----------

      else if (activeTab === 'releasetoreqlink') {
        await fetchReleasetoReqLinkData();
      } else if (activeTab === 'reqtotestlink') {
        await fetchReqtoTestLinkData();
      } else if (activeTab === 'defectslinks') {
        await fetchDefectsLinksData();
      }

    } catch (err) {
      setError('Failed to fetch data. Please check if the backend server is running.');
      console.error('Error fetching data:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchReleasesData = async () => {
    try {
      const [summaryResponse, statusResponse, allResponse] = await Promise.all([
        fetch(`${API_BASE_URL}/summary?schema=${selectedSchema}`),
        fetch(`${API_BASE_URL}/status-breakdown?schema=${selectedSchema}`),
        fetch(`${API_BASE_URL}/all-releases?schema=${selectedSchema}&page=${currentPage}&limit=10`)
      ]);

      if (!summaryResponse.ok || !statusResponse.ok || !allResponse.ok) {
        throw new Error('One or more requests failed');
      }

      const [summaryData, statusData, allData] = await Promise.all([
        summaryResponse.json(),
        statusResponse.json(),
        allResponse.json()
      ]);

      if (summaryData.success && statusData.success && allData.success) {
        setReleasesData({
          summary: summaryData.summary,
          statusBreakdown: statusData.data,
          allData: allData.data,
          pagination: allData.pagination
        });
      } else {
        throw new Error('Invalid response format');
      }
    } catch (err) {
      throw new Error('Failed to fetch releases data');
    }
  };

  const fetchRequirementsData = async () => {
    try {
      const [summaryResponse, statusResponse, allResponse] = await Promise.all([
        fetch(`${API_BASE_URL}/requirement/summary?schema=${selectedSchema}`),
        fetch(`${API_BASE_URL}/requirement/status-breakdown?schema=${selectedSchema}`),
        fetch(`${API_BASE_URL}/requirement/all-requirement?schema=${selectedSchema}&page=${currentPage}&limit=10`)
      ]);

      if (!summaryResponse.ok || !statusResponse.ok || !allResponse.ok) {
        throw new Error('One or more requests failed');
      }

      const [summaryData, statusData, allData] = await Promise.all([
        summaryResponse.json(),
        statusResponse.json(),
        allResponse.json()
      ]);

      if (summaryData.success && statusData.success && allData.success) {
        setRequirementsData({
          summary: summaryData.summary,
          statusBreakdown: statusData.data,
          allData: allData.data,
          pagination: allData.pagination
        });
      } else {
        throw new Error('Invalid response format');
      }
    } catch (err) {
      throw new Error('Failed to fetch requirement data');
    }
  };


  const fetchTestcaseData = async () => {
    try {
      // Fetch tests summary data
      const summaryResponse = await fetch(`${API_BASE_URL}/tests/summary?schema=${selectedSchema}`);
      const summaryData = await summaryResponse.json();

      // Fetch tests status breakdown
      const statusResponse = await fetch(`${API_BASE_URL}/tests/status-breakdown?schema=${selectedSchema}`);
      const statusData = await statusResponse.json();

      // Fetch all tests with pagination
      const allResponse = await fetch(`${API_BASE_URL}/tests/all-tests?schema=${selectedSchema}&page=${currentPage}&limit=10`);
      const allData = await allResponse.json();

      if (summaryData.success && statusData.success && allData.success) {
        setTestcaseData({
          summary: summaryData.summary,
          statusBreakdown: statusData.data,
          allData: allData.data,
          pagination: allData.pagination
        });
      }
    } catch (err) {
      throw new Error('Failed to fetch tests data');
    }
  };

  const fetchTestcasefolderData = async () => {
    try {
      // Fetch tests summary data
      const summaryResponse = await fetch(`${API_BASE_URL}/testcasemodules_releases/summary?schema=${selectedSchema}`);
      const summaryData = await summaryResponse.json();

      // Fetch tests status breakdown
      const statusResponse = await fetch(`${API_BASE_URL}/testcasemodules_releases/status-breakdown?schema=${selectedSchema}`);
      const statusData = await statusResponse.json();

      // Fetch all tests with pagination
      const allResponse = await fetch(`${API_BASE_URL}/testcasemodules_releases/all-testcasemodules_releases?schema=${selectedSchema}&page=${currentPage}&limit=10`);
      const allData = await allResponse.json();

      if (summaryData.success && statusData.success && allData.success) {
        setTestcasefolderData({
          summary: summaryData.summary,
          statusBreakdown: statusData.data,
          allData: allData.data,
          pagination: allData.pagination
        });
      }
    } catch (err) {
      throw new Error('Failed to fetch testcasemodules_releases data');
    }
  };


  const fetchParametersData = async () => {
    try {
      // Fetch defects summary data
      const summaryResponse = await fetch(`${API_BASE_URL}/parameters/summary?schema=${selectedSchema}`);
      const summaryData = await summaryResponse.json();

      // Fetch defects status breakdown
      const statusResponse = await fetch(`${API_BASE_URL}/parameters/status-breakdown?schema=${selectedSchema}`);
      const statusData = await statusResponse.json();

      // Fetch all defects with pagination
      const allResponse = await fetch(`${API_BASE_URL}/parameters/all-parameters?schema=${selectedSchema}&page=${currentPage}&limit=10`);
      const allData = await allResponse.json();

      if (summaryData.success && statusData.success && allData.success) {
        setParametersData({
          summary: summaryData.summary,
          statusBreakdown: statusData.data,
          allData: allData.data,
          pagination: allData.pagination
        });
      }
    } catch (err) {
      throw new Error('Failed to fetch ParametersData data');
    }
  };


  const fetchTestCaseStepsData = async () => {
    try {
      // Fetch defects summary data
      const summaryResponse = await fetch(`${API_BASE_URL}/alm_testcase_steps/summary?schema=${selectedSchema}`);
      const summaryData = await summaryResponse.json();

      // Fetch defects status breakdown
      const statusResponse = await fetch(`${API_BASE_URL}/alm_testcase_steps/status-breakdown?schema=${selectedSchema}`);
      const statusData = await statusResponse.json();

      // Fetch all defects with pagination
      const allResponse = await fetch(`${API_BASE_URL}/alm_testcase_steps/all-alm_testcase_steps?schema=${selectedSchema}&page=${currentPage}&limit=10`);
      const allData = await allResponse.json();

      if (summaryData.success && statusData.success && allData.success) {
        setTestCaseStepsData({
          summary: summaryData.summary,
          statusBreakdown: statusData.data,
          allData: allData.data,
          pagination: allData.pagination
        });
      }
    } catch (err) {
      throw new Error('Failed to fetch  TestCaseSteps data');
    }
  };

  const fetchTestsetfolderData = async () => {
    try {
      // Fetch testset summary data
      const summaryResponse = await fetch(`${API_BASE_URL}/testsetfolder/summary?schema=${selectedSchema}`);
      const summaryData = await summaryResponse.json();

      // Fetch testset status breakdown
      const statusResponse = await fetch(`${API_BASE_URL}/testsetfolder/status-breakdown?schema=${selectedSchema}`);
      const statusData = await statusResponse.json();

      // Fetch all testset with pagination
      const allResponse = await fetch(`${API_BASE_URL}/testsetfolder/all-testsetfolder?schema=${selectedSchema}&page=${currentPage}&limit=10`);
      const allData = await allResponse.json();

      if (summaryData.success && statusData.success && allData.success) {
        setTestsetFolderData({
          summary: summaryData.summary,
          statusBreakdown: statusData.data,
          allData: allData.data,
          pagination: allData.pagination
        });
      }
    } catch (err) {
      throw new Error('Failed to fetch testset data');
    }
  };

  const fetchTestsetData = async () => {
    try {
      // Fetch testset summary data
      const summaryResponse = await fetch(`${API_BASE_URL}/testset/summary?schema=${selectedSchema}`);
      const summaryData = await summaryResponse.json();

      // Fetch testset status breakdown
      const statusResponse = await fetch(`${API_BASE_URL}/testset/status-breakdown?schema=${selectedSchema}`);
      const statusData = await statusResponse.json();

      // Fetch all testset with pagination
      const allResponse = await fetch(`${API_BASE_URL}/testset/all-testset?schema=${selectedSchema}&page=${currentPage}&limit=10`);
      const allData = await allResponse.json();

      if (summaryData.success && statusData.success && allData.success) {
        setTestsetData({
          summary: summaryData.summary,
          statusBreakdown: statusData.data,
          allData: allData.data,
          pagination: allData.pagination
        });
      }
    } catch (err) {
      throw new Error('Failed to fetch testset data');
    }
  };

  const fetchTestinstanceData = async () => {
    try {
      // Fetch testinstance summary data
      const summaryResponse = await fetch(`${API_BASE_URL}/testinstance/summary?schema=${selectedSchema}`);
      const summaryData = await summaryResponse.json();

      // Fetch testinstance status breakdown
      const statusResponse = await fetch(`${API_BASE_URL}/testinstance/status-breakdown?schema=${selectedSchema}`);
      const statusData = await statusResponse.json();

      // Fetch all testinstance with pagination
      const allResponse = await fetch(`${API_BASE_URL}/testinstance/all-testinstance?schema=${selectedSchema}&page=${currentPage}&limit=10`);
      const allData = await allResponse.json();

      if (summaryData.success && statusData.success && allData.success) {
        setTestinstanceData({
          summary: summaryData.summary,
          statusBreakdown: statusData.data,
          allData: allData.data,
          pagination: allData.pagination
        });
      }
    } catch (err) {
      throw new Error('Failed to fetch testinstance data');
    }
  };

  const fetchTestlogsData = async () => {
    try {
      // Fetch testlogs summary data
      const summaryResponse = await fetch(`${API_BASE_URL}/testlogs/summary?schema=${selectedSchema}`);
      const summaryData = await summaryResponse.json();

      // Fetch testlogs status breakdown
      const statusResponse = await fetch(`${API_BASE_URL}/testlogs/status-breakdown?schema=${selectedSchema}`);
      const statusData = await statusResponse.json();

      // Fetch all testlogs with pagination
      const allResponse = await fetch(`${API_BASE_URL}/testlogs/all-testlogs?schema=${selectedSchema}&page=${currentPage}&limit=10`);
      const allData = await allResponse.json();

      if (summaryData.success && statusData.success && allData.success) {
        setTestlogData({
          summary: summaryData.summary,
          statusBreakdown: statusData.data,
          allData: allData.data,
          pagination: allData.pagination
        });
      }
    } catch (err) {
      throw new Error('Failed to fetch testlogs data');
    }
  };

  const fetchDefectsData = async () => {
    try {
      // Fetch defects summary data
      const summaryResponse = await fetch(`${API_BASE_URL}/defects/summary?schema=${selectedSchema}`);
      const summaryData = await summaryResponse.json();

      // Fetch defects status breakdown
      const statusResponse = await fetch(`${API_BASE_URL}/defects/status-breakdown?schema=${selectedSchema}`);
      const statusData = await statusResponse.json();

      // Fetch all defects with pagination
      const allResponse = await fetch(`${API_BASE_URL}/defects/all-defects?schema=${selectedSchema}&page=${currentPage}&limit=10`);
      const allData = await allResponse.json();

      if (summaryData.success && statusData.success && allData.success) {
        setDefectsData({
          summary: summaryData.summary,
          statusBreakdown: statusData.data,
          allData: allData.data,
          pagination: allData.pagination
        });
      }
    } catch (err) {
      throw new Error('Failed to fetch defects data');
    }
  };

  const fetchReleasetoReqLinkData = async () => {
    try {
      // Fetch defects summary data
      const summaryResponse = await fetch(`${API_BASE_URL}/releasetoreqlink/summary?schema=${selectedSchema}`);
      const summaryData = await summaryResponse.json();

      // Fetch defects status breakdown
      const statusResponse = await fetch(`${API_BASE_URL}/releasetoreqlink/status-breakdown?schema=${selectedSchema}`);
      const statusData = await statusResponse.json();

      // Fetch all defects with pagination
      const allResponse = await fetch(`${API_BASE_URL}/releasetoreqlink/all-releasetoreqlink?schema=${selectedSchema}&page=${currentPage}&limit=10`);
      const allData = await allResponse.json();

      if (summaryData.success && statusData.success && allData.success) {
        setReleaseToReqLinkData({
          summary: summaryData.summary,
          statusBreakdown: statusData.data,
          allData: allData.data,
          pagination: allData.pagination
        });
      }
    } catch (err) {
      throw new Error('Failed to fetch defects data');
    }
  };

  const fetchReqtoTestLinkData = async () => {
    try {
      // Fetch defects summary data
      const summaryResponse = await fetch(`${API_BASE_URL}/reqtotestlink/summary?schema=${selectedSchema}`);
      const summaryData = await summaryResponse.json();

      // Fetch defects status breakdown
      const statusResponse = await fetch(`${API_BASE_URL}/reqtotestlink/status-breakdown?schema=${selectedSchema}`);
      const statusData = await statusResponse.json();

      // Fetch all defects with pagination
      const allResponse = await fetch(`${API_BASE_URL}/reqtotestlink/all-reqtotestlink?schema=${selectedSchema}&page=${currentPage}&limit=10`);
      const allData = await allResponse.json();

      if (summaryData.success && statusData.success && allData.success) {
        setReqToTestLinkData({
          summary: summaryData.summary,
          statusBreakdown: statusData.data,
          allData: allData.data,
          pagination: allData.pagination
        });
      }
    } catch (err) {
      throw new Error('Failed to fetch defects data');
    }
  };

  const fetchDefectsLinksData = async () => {
    try {
      // Fetch defects summary data
      const summaryResponse = await fetch(`${API_BASE_URL}/defectslinks/summary?schema=${selectedSchema}`);
      const summaryData = await summaryResponse.json();

      // Fetch defects status breakdown
      const statusResponse = await fetch(`${API_BASE_URL}/defectslinks/status-breakdown?schema=${selectedSchema}`);
      const statusData = await statusResponse.json();

      // Fetch all defects with pagination
      const allResponse = await fetch(`${API_BASE_URL}/defectslinks/all-defectslinks?schema=${selectedSchema}&page=${currentPage}&limit=10`);
      const allData = await allResponse.json();

      if (summaryData.success && statusData.success && allData.success) {
        setDefectsLinksData({
          summary: summaryData.summary,
          statusBreakdown: statusData.data,
          allData: allData.data,
          pagination: allData.pagination
        });
      }
    } catch (err) {
      throw new Error('Failed to fetch defects data');
    }
  };

  const handleTabChange = (tab) => {
    setActiveTab(tab);
    setCurrentPage(1);
  };

  const handleSchemaChange = async (schema) => {
    setSelectedSchema(schema);
    setCurrentPage(1);

    // Reset all data states
    setReleasesData({
      summary: null,
      statusBreakdown: [],
      allData: [],
      pagination: {}
    });
    setRequirementsData({
      summary: null,
      statusBreakdown: [],
      allData: [],
      pagination: {}
    });
    setTestcasefolderData({
      summary: null,
      statusBreakdown: [],
      allData: [],
      pagination: {}
    });
    setTestcaseData({
      summary: null,
      statusBreakdown: [],
      allData: [],
      pagination: {}
    });
    setParametersData({
      summary: null,
      statusBreakdown: [],
      allData: [],
      pagination: {}
    });
    setTestsetFolderData({
      summary: null,
      statusBreakdown: [],
      allData: [],
      pagination: {}
    });
    setTestsetData({
      summary: null,
      statusBreakdown: [],
      allData: [],
      pagination: {}
    });
    setTestinstanceData({
      summary: null,
      statusBreakdown: [],
      allData: [],
      pagination: {}
    });
    setTestlogData({
      summary: null,
      statusBreakdown: [],
      allData: [],
      pagination: {}
    });

    setDefectsData({
      summary: null,
      statusBreakdown: [],
      allData: [],
      pagination: {}
    });

    //--------Link--------

    setReleaseToReqLinkData({
      summary: null,
      statusBreakdown: [],
      allData: [],
      pagination: {}
    });
    setReqToTestLinkData({
      summary: null,
      statusBreakdown: [],
      allData: [],
      pagination: {}
    });
    setDefectsLinksData({
      summary: null,
      statusBreakdown: [],
      allData: [],
      pagination: {}
    });

    // Reset table availability
    setAvailableTables([]);
    setActiveTab('');

    // Fetch available tables for this schema
    if (schema) {
      try {
        const res = await fetch(`http://localhost:5550/api/reporting/available-tables?schema=${schema}`);
        const data = await res.json();
        if (data.success) {
          setAvailableTables(data.tables);

          // Auto-select first tab if needed
          if (data.tables.length > 0) {
            setActiveTab(data.tables[0]); // releases, requirement, etc.
          }
        }
      } catch (err) {
        console.error('Failed to fetch available tables', err);
      }
    }
  };


  const handleExport = async () => {
    if (!activeTab) return;

    setExportLoading(true);

    try {
      let exportTable = '';
      if (activeTab === 'releases') {
        exportTable = 'releases';
      } else if (activeTab === 'requirement') {
        exportTable = 'requirement';
      } else if (activeTab === 'testcasemodules_releases') {
        exportTable = 'testcasemodules_releases';
      } else if (activeTab === 'tests') {
        exportTable = 'tests';
      } else if (activeTab === 'parameters') {
        exportTable = 'parameters';
      } else if (activeTab === 'testsetfolder') {
        exportTable = 'testsetfolder';
      } else if (activeTab === 'testset') {
        exportTable = 'testset';
      } else if (activeTab === 'testinstance') {
        exportTable = 'testinstance';
      } else if (activeTab === 'testlogs') {
        exportTable = 'testlogs';
      } else if (activeTab === 'defects') {
        exportTable = 'defects';
      }

      //------link---------

      else if (activeTab === 'releasetoreqlink') {
        exportTable = 'releasetoreqlink';
      } else if (activeTab === 'reqtotestlink') {
        exportTable = 'reqtotestlink';
      } else if (activeTab === 'defectslinks') {
        exportTable = 'defectslinks';
      }

      const response = await fetch(`http://localhost:5550/api/reporting/export/${exportTable}?schema=${selectedSchema}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        },
      });

      if (!response.ok) {
        throw new Error('Failed to export data');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `${exportTable}_export.xlsx`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);

    } catch (error) {
      alert('❌ Failed to download file.');
      console.error('Export error:', error);
    } finally {
      setExportLoading(false);
    }
  };

  const handleExportErrors = async () => {
  if (!activeTab) return;
 
  setExportLoading(true);
 
  try {
    let exportTable = '';
    if (activeTab === 'releases') {
      exportTable = 'releases';
    } else if (activeTab === 'requirement') {
      exportTable = 'requirement';
    } else if (activeTab === 'testcasemodules_releases') {
      exportTable = 'testcasemodules_releases';
    } else if (activeTab === 'tests') {
      exportTable = 'tests';
    } else if (activeTab === 'parameters') {
      exportTable = 'parameters';
    } else if (activeTab === 'testsetfolder') {
      exportTable = 'testsetfolder';
    } else if (activeTab === 'testset') {
      exportTable = 'testset';
    } else if (activeTab === 'testinstance') {
      exportTable = 'testinstance';
    } else if (activeTab === 'testlogs') {
      exportTable = 'testlogs';
    } else if (activeTab === 'defects') {
      exportTable = 'defects';
    }
 
    //------link---------
    else if (activeTab === 'releasetoreqlink') {
      exportTable = 'releasetoreqlink';
    } else if (activeTab === 'reqtotestlink') {
      exportTable = 'reqtotestlink';
    } else if (activeTab === 'defectslinks') {
      exportTable = 'defectslinks';
    }
 
    const response = await fetch(`http://localhost:5550/api/reporting/export-errors/${exportTable}?schema=${selectedSchema}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      },
    });
 
    if (!response.ok) {
      throw new Error('Failed to export error data');
    }
 
    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${exportTable}_errors_export.xlsx`);
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.URL.revokeObjectURL(url);
 
  } catch (error) {
    alert('❌ Failed to download error file.');
    console.error('Export error (errors only):', error);
  } finally {
    setExportLoading(false);
  }
};

  const formatNumber = (num) => {
    return num ? num.toLocaleString() : '0';
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Success':
        return 'bg-green-100 text-green-800';
      case 'Failed':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getCurrentData = () => {
    if (activeTab === 'releases') {
      return releasesData;
    } else if (activeTab === 'requirement') {
      return requirementsData;
    } else if (activeTab === 'testcasemodules_releases') {
      return testcasefolderData;
    } else if (activeTab === 'tests') {
      return testcaseData;
    } else if (activeTab === 'parameters') {
      return parametersData;
    } else if (activeTab === 'alm_testcase_steps') {
      return testcasestepsData;
    } else if (activeTab === 'testsetfolder') {
      return testsetfolderData;
    } else if (activeTab === 'testset') {
      return testsetData;
    } else if (activeTab === 'testinstance') {
      return testinstanceData;
    } else if (activeTab === 'testlogs') {
      return testlogData;
    } else if (activeTab === 'defects') {
      return defectsData;
    }

    //-----link---------

    else if (activeTab === 'releasetoreqlink') {
      return releasetoreqlinkData;
    } else if (activeTab === 'reqtotestlink') {
      return reqtotestlinkData;
    } else if (activeTab === 'defectslinks') {
      return defectslinksData;
    }
    return { summary: null, statusBreakdown: [], allData: [], pagination: {} };
  };

  const getCurrentPagination = () => {
    return getCurrentData().pagination;
  };

  // FIXED: Changed from 'total_requirements' to 'total_requirement' for singular form
  const getTotalFieldName = () => {
    if (activeTab === 'releases') {
      return 'total_releases';
    } else if (activeTab === 'requirement') {
      return 'total_requirement'; // Changed from 'total_requirements' to 'total_requirement'
    } else if (activeTab === 'testcasemodules_releases') {
      return 'total_testcasemodules_releases';
    } else if (activeTab === 'tests') {
      return 'total_tests';
    } else if (activeTab === 'parameters') {
      return 'total_parameters';
    } else if (activeTab === 'alm_testcase_steps') {
      return 'total_alm_testcase_steps';
    } else if (activeTab === 'testsetfolder') {
      return 'total_testsetfolder';
    } else if (activeTab === 'testset') {
      return 'total_testset';
    } else if (activeTab === 'testinstance') {
      return 'total_testinstance';
    } else if (activeTab === 'testlogs') {
      return 'total_testlogs';
    } else if (activeTab === 'defects') {
      return 'total_defects';
    }

    //---link------------

    else if (activeTab === 'releasetoreqlink') {
      return 'total_releasetoreqlink';
    } else if (activeTab === 'reqtotestlink') {
      return 'total_reqtotestlink';
    } else if (activeTab === 'defectslinks') {
      return 'total_defectslinks';
    }
    return 'total';
  };

  const getQTestIdFieldName = (item) => {
    if (activeTab === 'releases') {
      return item.id || 'N/A';
    } else if (activeTab === 'requirement') {
      return item.id || 'N/A';
    } else if (activeTab === 'testcasemodules_releases') {
      return item.ALM_PID || 'N/A';
    }
    else if (activeTab === 'tests') {
      return item.id || 'N/A';
    } else if (activeTab === 'parameters') {
      return item.id || 'N/A';
    } else if (activeTab === 'alm_testcase_steps') {
      return item.id || 'N/A';
    } else if (activeTab === 'testsetfolder') {
      return item.id || 'N/A';
    } else if (activeTab === 'testset') {
      return item.id || 'N/A';
    } else if (activeTab === 'testinstance') {
      return item.id || 'N/A';
    } else if (activeTab === 'testlogs') {
      return item.id || 'N/A';
    } else if (activeTab === 'defects') {
      return item.id || 'N/A';
    }

    //--link------------

    else if (activeTab === 'releasetoreqlink') {
      return item.id || 'N/A';
    } else if (activeTab === 'reqtotestlink') {
      return item.id || 'N/A';
    } else if (activeTab === 'defectslinks') {
      return item.id || 'N/A';
    }

    return 'N/A';
  };

  // FIXED: Changed from 'requirement' to 'Requirements' for proper display
  const getDisplayTabName = () => {
    if (activeTab === 'releases') {
      return 'Releases';
    } else if (activeTab === 'requirement') {
      return 'Requirements'; // Changed from 'requirement' to 'Requirements'
    } else if (activeTab === 'testcasemodules_releases') {
      return 'TestcaseModules';
    } else if (activeTab === 'tests') {
      return 'Tests';
    } else if (activeTab === 'parameters') {
      return 'parameters';
    } else if (activeTab === 'alm_testcase_steps') {
      return 'TestCaseSteps';
    } else if (activeTab === 'testsetfolder') {
      return 'testsetfolder';
    } else if (activeTab === 'testset') {
      return 'Testset';
    } else if (activeTab === 'testinstance') {
      return 'TestInstance';
    } else if (activeTab === 'testlogs') {
      return 'Testlog';
    } else if (activeTab === 'defects') {
      return 'Defects';
    }

    //-----------link-------------

    else if (activeTab === 'releasetoreqlink') {
      return 'ReleaseToReqlink';
    } else if (activeTab === 'reqtotestlink') {
      return 'ReqToTestlink';
    } else if (activeTab === 'defectslinks') {
      return 'DefectsLinks';
    }
    return 'Items';
  };

  const getTableHeaderName = () => {
    if (activeTab === 'releases') {
      return 'QTest Release ID';
    } else if (activeTab === 'requirement') {
      return 'QTest Requirement ID';
    } else if (activeTab === 'testcasemodules_releases') {
      return 'QTest testcasemodules_releases ID';
    } else if (activeTab === 'tests') {
      return 'QTest Test ID';
    } else if (activeTab === 'parameters') {
      return 'QTest Parameters ID';
    } else if (activeTab === 'alm_testcase_steps') {
      return 'QTest TestCaseSteps ID';
    } else if (activeTab === 'testsetfolder') {
      return 'QTest testsetfolder ID';
    } else if (activeTab === 'testset') {
      return 'QTest Testset ID';
    } else if (activeTab === 'testinstance') {
      return 'QTest TestInstance ID';
    } else if (activeTab === 'testlogs') {
      return 'QTest Testlog ID';
    } else if (activeTab === 'defects') {
      return 'QTest Defect ID';
    }

    //-----LINK------------

    else if (activeTab === 'releasetoreqlink') {
      return 'QTest ReleaseToReqlink ID';
    } else if (activeTab === 'reqtotestlink') {
      return 'QTest ReqToTestlink ID';
    } else if (activeTab === 'defectslinks') {
      return 'QTest DefectsLinks ID';
    }
    return 'QTest ID';
  };



  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const renderPagination = () => {
    const pagination = getCurrentPagination();
    if (!pagination || pagination.totalPages <= 1) return null;

    const pages = [];
    const maxPagesToShow = 5;
    const startPage = Math.max(1, currentPage - Math.floor(maxPagesToShow / 2));
    const endPage = Math.min(pagination.totalPages, startPage + maxPagesToShow - 1);

    for (let i = startPage; i <= endPage; i++) {
      pages.push(
        <button
          key={i}
          onClick={() => handlePageChange(i)}
          className={`px-3 py-2 mx-1 rounded ${i === currentPage
            ? 'bg-blue-600 text-white'
            : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
        >
          {i}
        </button>
      );
    }

    return (
      <div className="flex justify-between items-center mt-4">
        <div className="text-sm text-gray-700">
          Showing {((currentPage - 1) * 10) + 1} to {Math.min(currentPage * 10, pagination.totalCount)} of {pagination.totalCount} results
        </div>
        <div className="flex items-center">
          <button
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
            className="px-3 py-2 mx-1 rounded bg-gray-200 text-gray-700 hover:bg-gray-300 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Previous
          </button>
          {pages}
          <button
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === pagination.totalPages}
            className="px-3 py-2 mx-1 rounded bg-gray-200 text-gray-700 hover:bg-gray-300 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Next
          </button>
        </div>
      </div>
    );
  };

  // Schema selection loading
  if (schemaLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading schemas...</p>
        </div>
      </div>
    );
  }

  // Main loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading {getDisplayTabName()} data...</p>
        </div>
      </div>
    );
  }

  const currentData = getCurrentData();

  if (
    currentData.summary &&
    currentData.summary[getTotalFieldName()] !== undefined &&
    currentData.summary.success_records !== undefined &&
    currentData.summary.failed_records === undefined
  ) {
    const total = currentData.summary[getTotalFieldName()];
    const success = currentData.summary.success_records;
    currentData.summary.failed_records = total - success >= 0 ? total - success : 0;
  }


  return (
    <div className="min-h-screen bg-gray-100">
      {/* Schema Selection Screen */}
      {!selectedSchema ? (

        <>

          {/* Sidebar */}
          <Sidebar />
          {/* Topbar */}
          <Topbar />
          <div className="flex items-center justify-center min-h-screen px-4">
            <div className="bg-white rounded-2xl shadow-md p-10 w-full max-w-md text-center border border-gray-200">
              <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">Reporting Dashboard</h1>
              <p className="text-gray-500 mt-2">Select a schema to begin</p>

              <div className="mt-6 text-left">
                <label className="text-sm font-medium text-gray-700">Schema</label>
                <select
                  className="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  value={selectedSchema}
                  onChange={(e) => handleSchemaChange(e.target.value)}
                >
                  <option value="">-- Select Schema --</option>
                  {schemas.map((schema) => (
                    <option key={schema} value={schema}>
                      {schema}
                    </option>
                  ))}
                </select>
              </div>

              <div className="mt-8 flex justify-center">
                <svg className="w-20 h-20 text-blue-500" fill="none" stroke="currentColor" strokeWidth={1.5} viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m0-4h.01M21 12c0 4.97-4.03 9-9 9s-9-4.03-9-9 4.03-9 9-9 9 4.03 9 9z" />
                </svg>
              </div>
            </div>
          </div>
        </>

      ) : (
        <>
          {/* Dashboard Header */}
          <div className="bg-white border-b shadow-sm sticky top-0 z-10">
            <div className="max-w-7xl mx-auto px-4 py-5 sm:px-6 lg:px-8 flex flex-wrap sm:flex-nowrap items-center justify-between gap-4">
              <div>
                <h2 className="text-2xl font-bold text-gray-800">Reporting Dashboard</h2>
                <p className="text-sm text-gray-500">Schema: <span className="font-semibold text-blue-600">{selectedSchema}</span></p>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => handleSchemaChange('')}
                  className="flex items-center gap-2 bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-md text-sm shadow-sm"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                  </svg>
                  Change Schema
                </button>

                <button
                  onClick={handleExport}
                  disabled={exportLoading || !currentData.allData.length}
                  className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md text-sm shadow-sm disabled:opacity-50"
                >
                  {exportLoading ? (
                    <>
                      <div className="animate-spin h-4 w-4 border-b-2 border-white rounded-full" />
                      Exporting...
                    </>
                  ) : (
                    <>
                      <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                      </svg>
                      Export {getDisplayTabName()}
                    </>
                  )}
                </button>
 <button
                  onClick={handleExportErrors}
                  disabled={exportLoading || !currentData.allData.length}
                  className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md text-sm shadow-sm disabled:opacity-50"
                >
                  {exportLoading ? (
                    <>
                      <div className="animate-spin h-4 w-4 border-b-2 border-white rounded-full" />
                      Exporting...
                    </>
                  ) : (
                    <>
                      <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                      </svg>
                      Export Errorfile {getDisplayTabName()}
                    </>
                  )}
                </button>
                <button
                  onClick={fetchAllData}
                  className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm shadow-sm"
                >
                  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                  </svg>
                  Refresh
                </button>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="max-w-7xl mx-auto px-4 mt-6">
            <div className="flex flex-wrap gap-3 bg-white p-4 rounded-lg shadow-sm border">
              {[
                { id: 'releases', label: 'Releases' },
                { id: 'requirement', label: 'Requirements' },
                { id: 'testcasemodules_releases', label: 'Test Case Modules' },
                { id: 'tests', label: 'Test Cases' },
                { id: 'parameters', label: 'Parameters' },
                { id: 'alm_testcase_steps', label: 'Test Case Steps' },
                { id: 'testsetfolder', label: 'Test Set Folder' },
                { id: 'testset', label: 'Test Set' },
                { id: 'testinstance', label: 'Test Instance' },
                { id: 'testlogs', label: 'Testlogs' },
                { id: 'defects', label: 'Defects' },
                { id: 'releasetoreqlink', label: 'ReleaseToReqlink' },
                { id: 'reqtotestlink', label: 'ReqToTestlink' },
                { id: 'defectslinks', label: 'DefectsLinks' }
              ].filter(tab => availableTables.includes(tab.id)).map(tab => (
                <button
                  key={tab.id}
                  onClick={() => handleTabChange(tab.id)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all border
                ${activeTab === tab.id
                      ? 'bg-blue-100 text-blue-700 border-blue-400'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200 border-transparent'
                    }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Content */}
          <div className="max-w-7xl mx-auto px-4 py-10 space-y-8">
            {/* Error Alert */}
            {error && (
              <div className="bg-red-50 text-red-700 border border-red-200 rounded-lg p-4 flex items-center justify-between">
                <span>{error}</span>
                <button
                  onClick={fetchAllData}
                  className="text-sm font-medium bg-red-100 text-red-800 px-3 py-1.5 rounded hover:bg-red-200"
                >
                  Retry
                </button>
              </div>
            )}

            {/* Summary Cards */}
            {currentData.summary && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {[
                  { title: `Total ${getDisplayTabName()}`, value: formatNumber(currentData.summary[getTotalFieldName()]), color: 'bg-blue-500' },
                  { title: 'Success Records', value: formatNumber(currentData.summary.success_records), color: 'bg-green-500' },
                  { title: 'Failed Records', value: formatNumber(currentData.summary.failed_records || 0), color: 'bg-red-500' },
                  { title: 'Success Rate', value: `${currentData.summary.success_percentage}%`, color: 'bg-purple-500' }
                ].map((card, idx) => (
                  <div key={idx} className="flex items-center space-x-4 bg-white rounded-lg shadow p-4">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white ${card.color}`}>
                      {card.title.includes('Rate') ? '%' : <span className="font-bold text-lg">✓</span>}
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">{card.title}</p>
                      <p className="text-lg font-semibold text-gray-900">{card.value}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Data Table */}
            {currentData.allData.length > 0 && (
              <div className="bg-white rounded-lg shadow overflow-x-auto">
                <table className="min-w-full text-sm divide-y divide-gray-200">
                  <thead className="bg-gray-50 text-gray-600">
                    <tr>
                      <th className="text-left px-6 py-3">ALM ID</th>
                      <th className="text-left px-6 py-3">Migration Status</th>
                      <th className="text-left px-6 py-3">Result</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {currentData.allData.map((item, index) => (
                      <tr key={index} className="hover:bg-gray-50">
                        <td className="px-6 py-4 font-medium text-gray-800">{getQTestIdFieldName(item)}</td>
                        <td className="px-6 py-4 text-gray-700">
                          {item.upload_status === 'completed' ? 'completed' : item.Status_Params || 'completed'}
                        </td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(item.result_status)}`}>
                            {item.result_status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {renderPagination()}
              </div>
            )}
            

            {/* No Data */}
            {!loading && !error && currentData.allData.length === 0 && (
              <div className="text-center py-10">
                <p className="text-lg font-medium text-gray-600">No {getDisplayTabName()} Found</p>
                <p className="text-sm text-gray-400 mt-1">Try refreshing or check another schema</p>
                <button
                  onClick={fetchAllData}
                  className="mt-4 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 text-sm rounded shadow"
                >
                  Refresh Data
                </button>
              </div>
            )}
          </div>
        </>
      )}
    </div>

  );
};

export default ReportingPage;