import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import Topbar from "./Topbar";
import { CheckCircle, AlertCircle, Eye } from 'lucide-react';
import { IoClose, IoAdd, IoSettings, IoTrashOutline, IoWarningOutline, IoCloseOutline, IoGitBranch, IoCheckboxOutline, IoSwapHorizontal } from "react-icons/io5";
import * as XLSX from "xlsx";

// Custom Components

const Button = ({ children, variant = "default", onClick, className = "" }) => {
  const baseClasses = "inline-flex items-center px-4 py-2 rounded-md font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2";
  const variantClasses = {
    default: "bg-blue-600 text-white hover:bg-blue-700 focus:ring-blue-500",
    outline: "border border-gray-300 bg-white text-gray-700 hover:bg-gray-50 focus:ring-blue-500"
  };
  return (
    <button onClick={onClick} className={`${baseClasses} ${variantClasses[variant]} ${className}`}>
      {children}
    </button>
  );
};


const SettingsPage = () => {
  // Helper functions for localStorage
  const saveToStorage = (key, value) => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      console.log(`Saved ${key}:`, value);
    } catch (error) {
      console.error(`Error saving ${key}:`, error);
    }
  };

  const loadFromStorage = (key, defaultValue) => {
    try {
      const saved = localStorage.getItem(key);
      if (saved) {
        const parsed = JSON.parse(saved);
        console.log(`Loaded ${key}:`, parsed);
        return parsed;
      }
    } catch (error) {
      console.error(`Error loading ${key}:`, error);
    }
    return defaultValue;
  };

  // Initialize state from localStorage or defaults
  const [systemSettings, setSystemSettings] = useState(() => {
    return loadFromStorage('settingsFormData', {
      almServerUrl: "",
      username: "",
      password: "",
      domain: "",
      project: "",
      qTestDomain: "",
      apiToken: "",
      projectId: "",
    });
  });

  const [status, setStatus] = useState('idle'); // idle | validating | success | failed
  const [report, setReport] = useState(null);
  const [showReport, setShowReport] = useState(false);
  const [fieldStats, setFieldStats] = useState({ total: 0, passed: 0, failed: 0 });
  const [showDownloadOptions, setShowDownloadOptions] = useState(false);

  const validateFields = async () => {
    setStatus('validating');
    try {
      const res = await axios.get('http://localhost:5550/api/validate-fields');
      const report = res.data.report;

      if (res.data.success && Array.isArray(report)) {
        setReport(report);

        let totalFields = 0;
        let totalFailed = 0;

        report.forEach(link => {
          Object.values(link.artifacts || {}).forEach(artifact => {
            artifact.mapped_fields.forEach(field => {
              totalFields++;
              if (field.status === 'fail') totalFailed++;
            });
          });
        });

        setFieldStats({
          total: totalFields,
          failed: totalFailed,
          passed: totalFields - totalFailed
        });

        setStatus(totalFailed > 0 ? 'failed' : 'success');
      } else {
        setReport([]);
        setStatus('failed');
      }
    } catch (err) {
      console.error('Validation error:', err);
      setReport([]);
      setStatus('failed');
    }
  };

  //Download csv field validation report

  function generateCSVFromReport(report) {
    const headers = ['Link Name', 'ALM Domain', 'ALM Project', 'qTest Project ID', 'Artifact', 'ALM Field', 'ALM Type', 'qTest Field', 'qTest Type', 'Status'];
    const rows = [headers];

    report.forEach(link => {
      const { link_name, domain, project, projectId, artifacts } = link;

      Object.entries(artifacts).forEach(([artifact, data]) => {
        data.mapped_fields.forEach(field => {
          rows.push([
            link_name,
            domain,
            project,
            projectId,
            artifact,
            field.alm_field,
            field.alm_type,
            field.qtest_field,
            field.qtest_type,
            field.status
          ]);
        });
      });
    });
    return rows.map(row => row.map(val => `"${val}"`).join(',')).join('\n');
  }

  //xlsx download field validation report

  function generateXLSXFromReport(report, filename = 'FieldValidationReport') {
    const rows = [];

    report.forEach(link => {
      const { link_name, domain, project, projectId, artifacts } = link;

      Object.entries(artifacts).forEach(([artifact, data]) => {
        data.mapped_fields.forEach(field => {
          rows.push({
            'Link Name': link_name,
            'ALM Domain': domain,
            'ALM Project': project,
            'qTest Project ID': projectId,
            'Artifact': artifact,
            'ALM Field': field.alm_field,
            'ALM Type': field.alm_type,
            'qTest Field': field.qtest_field,
            'qTest Type': field.qtest_type,
            'Status': field.status
          });
        });
      });
    });

    const worksheet = XLSX.utils.json_to_sheet(rows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Validation Report');

    XLSX.writeFile(workbook, `${filename}.xlsx`);
  }

  const [currentStep, setCurrentStep] = useState(() => {
    return loadFromStorage('currentStep', 1);
  });

  const [validationStatus, setValidationStatus] = useState(() => {
    return loadFromStorage('validationStatus', {
      alm: false,
      qtest: false
    });
  });

  // Add save status to track if credentials are saved
  const [saveStatus, setSaveStatus] = useState(() => {
    return loadFromStorage('saveStatus', { alm: false, qtest: false });
  });

  const [savedSettings, setSavedSettings] = useState([]);
  const [selectedSettingId, setSelectedSettingId] = useState(() => {
    return loadFromStorage('selectedSettingId', null);
  });

  const [statusMessage, setStatusMessage] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  // Save modal state
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [linkName, setLinkName] = useState("");
  const [nameExists, setNameExists] = useState(false);
  const [checkingName, setCheckingName] = useState(false);

  // New state for sidebar and current mode
  const [selectedLinkName, setSelectedLinkName] = useState(null);
  const [isEditingMode, setIsEditingMode] = useState(false); // false = viewing, true = creating new

  // Save to localStorage whenever state changes
  useEffect(() => {
    saveToStorage('settingsFormData', systemSettings);
  }, [systemSettings]);

  useEffect(() => {
    saveToStorage('currentStep', currentStep);
  }, [currentStep]);

  useEffect(() => {
    saveToStorage('validationStatus', validationStatus);
  }, [validationStatus]);

  useEffect(() => {
    saveToStorage('saveStatus', saveStatus);
  }, [saveStatus]);

  useEffect(() => {
    if (selectedSettingId) {
      saveToStorage('selectedSettingId', selectedSettingId);
    }
  }, [selectedSettingId]);

  // Fetch saved settings on mount
  useEffect(() => {
    fetchSavedSettings();
  }, []);

  // Check if name exists when user types
  useEffect(() => {
    if (linkName.trim().length > 0) {
      const timeoutId = setTimeout(() => {
        checkNameExists(linkName.trim());
      }, 500);

      return () => clearTimeout(timeoutId);
    } else {
      setNameExists(false);
    }
  }, [linkName]);

  const checkNameExists = async (name) => {
    setCheckingName(true);
    try {
      const response = await axios.get(`http://localhost:5550/api/settings/check-name/${encodeURIComponent(name)}`);
      setNameExists(response.data.exists);
    } catch (err) {
      console.error("Error checking name:", err);
      setNameExists(false);
    } finally {
      setCheckingName(false);
    }
  };

  const handleAddNewLink = () => {
    // Clear the form
    setSystemSettings({
      almServerUrl: "",
      username: "",
      password: "",
      domain: "",
      project: "",
      qTestDomain: "",
      apiToken: "",
      projectId: "",
    });

    setSelectedLinkName(null);
    setIsEditingMode(true); // Set to creating mode
    setCurrentStep(1);
    setValidationStatus({ alm: false, qtest: false });
    setSaveStatus({ alm: false, qtest: false });

    setStatusMessage({
      type: "info",
      message: "Ready to create new settings configuration"
    });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    console.log(`Input changed: ${name} = ${value}`);

    // Update state immediately
    setSystemSettings(prev => {
      const newSettings = { ...prev, [name]: value };
      console.log('Updated settings:', newSettings);

      // Also save immediately to localStorage
      saveToStorage('settingsFormData', newSettings);

      return newSettings;
    });

    // Reset validation and save status when fields change
    if (['almServerUrl', 'username', 'password', 'domain', 'project'].includes(name)) {
      setValidationStatus(prev => ({ ...prev, alm: false }));
      setSaveStatus(prev => ({ ...prev, alm: false }));
    } else if (['qTestDomain', 'apiToken', 'projectId'].includes(name)) {
      setValidationStatus(prev => ({ ...prev, qtest: false }));
      setSaveStatus(prev => ({ ...prev, qtest: false }));
    }
  };

  // New function to save temporary ALM credentials
  const handleSaveTempAlm = async () => {
    try {
      setStatusMessage({ type: "info", message: "Saving ALM credentials temporarily..." });

      const almFields = {
        almServerUrl: systemSettings.almServerUrl,
        username: systemSettings.username,
        password: systemSettings.password,
        domain: systemSettings.domain,
        project: systemSettings.project
      };

      // Check if all required fields are filled
      if (!almFields.almServerUrl || !almFields.username || !almFields.password || !almFields.domain || !almFields.project) {
        setStatusMessage({
          type: "error",
          message: "Please fill in all ALM fields before saving."
        });
        return;
      }

      const response = await axios.post("http://localhost:5550/api/settings/save-temp-alm", almFields);

      if (response.data.success) {
        setStatusMessage({
          type: "success",
          message: "ALM credentials saved temporarily!"
        });
        setSaveStatus(prev => ({ ...prev, alm: true }));
      } else {
        setStatusMessage({
          type: "error",
          message: "Failed to save ALM credentials: " + response.data.message
        });
        setSaveStatus(prev => ({ ...prev, alm: false }));
      }
    } catch (err) {
      console.error("Save temp ALM error:", err);
      setSaveStatus(prev => ({ ...prev, alm: false }));
      setStatusMessage({
        type: "error",
        message: "Failed to save ALM credentials: " + (err.response?.data?.message || err.message)
      });
    }
  };

  // New function to save temporary qTest credentials
  const handleSaveTempQtest = async () => {
    try {
      setStatusMessage({ type: "info", message: "Saving qTest credentials temporarily..." });

      const qtestFields = {
        qTestDomain: systemSettings.qTestDomain,
        apiToken: systemSettings.apiToken,
        projectId: systemSettings.projectId
      };

      // Check if all required fields are filled
      if (!qtestFields.qTestDomain || !qtestFields.apiToken || !qtestFields.projectId) {
        setStatusMessage({
          type: "error",
          message: "Please fill in all qTest fields before saving."
        });
        return;
      }

      const response = await axios.post("http://localhost:5550/api/settings/save-temp-qtest", qtestFields);

      if (response.data.success) {
        setStatusMessage({
          type: "success",
          message: "qTest credentials saved temporarily!"
        });
        setSaveStatus(prev => ({ ...prev, qtest: true }));
      } else {
        setStatusMessage({
          type: "error",
          message: "Failed to save qTest credentials: " + response.data.message
        });
        setSaveStatus(prev => ({ ...prev, qtest: false }));
      }
    } catch (err) {
      console.error("Save temp qTest error:", err);
      setSaveStatus(prev => ({ ...prev, qtest: false }));
      setStatusMessage({
        type: "error",
        message: "Failed to save qTest credentials: " + (err.response?.data?.message || err.message)
      });
    }
  };

  const openSaveModal = () => {
    setShowSaveModal(true);
    setLinkName("");
    setNameExists(false);
  };

  const closeSaveModal = () => {
    setShowSaveModal(false);
    setLinkName("");
    setNameExists(false);
  };

  const handleSave = async () => {
    if (nameExists) {
      setStatusMessage({
        type: "error",
        message: "This name already exists. Please choose a different name.",
      });
      return;
    }

    try {
      const savePayload = {
        ...systemSettings,
        link_name: linkName
      };

      await axios.post("http://localhost:5550/api/settings/settings", savePayload);
      setStatusMessage({
        type: "success",
        message: "New settings saved successfully!",
      });

      closeSaveModal();
      fetchSavedSettings();

      // Update the selected link name and set to viewing mode
      setSelectedLinkName(linkName);
      setIsEditingMode(false);
    } catch (err) {
      console.error("Save error:", err);

      if (err.response && err.response.status === 409) {
        setStatusMessage({
          type: "error",
          message: err.response.data.error || "A setting with this name already exists. Please choose a different name."
        });
      } else {
        setStatusMessage({
          type: "error",
          message: "Failed to save settings"
        });
      }
    }
  };

  const handleAlmValidate = async () => {
    // Check if ALM credentials are saved first
    if (!saveStatus.alm) {
      setStatusMessage({
        type: "error",
        message: "Please save ALM credentials first before validating."
      });
      return;
    }

    try {
      setStatusMessage({ type: "info", message: "Validating ALM connection..." });

      const almFields = {
        almServerUrl: systemSettings.almServerUrl,
        username: systemSettings.username,
        password: systemSettings.password,
        domain: systemSettings.domain,
        project: systemSettings.project
      };

      const response = await axios.post("http://localhost:5550/api/settings/validate-alm", almFields);

      if (response.data.success) {
        setStatusMessage({ type: "success", message: "ALM connection validated successfully!" });
        setValidationStatus(prev => ({ ...prev, alm: true }));
      } else {
        setStatusMessage({ type: "error", message: "ALM connection validation failed: " + response.data.message });
        setValidationStatus(prev => ({ ...prev, alm: false }));
      }
    } catch (err) {
      console.error("Validation error:", err);
      setStatusMessage({
        type: "error",
        message: "Failed to validate ALM connection: " + (err.response?.data?.message || err.message)
      });
      setValidationStatus(prev => ({ ...prev, alm: false }));
    }
  };

  const handleQtestValidate = async () => {
    // Check if qTest credentials are saved first
    if (!saveStatus.qtest) {
      setStatusMessage({
        type: "error",
        message: "Please save qTest credentials first before validating."
      });
      return;
    }

    try {
      setStatusMessage({ type: "info", message: "Validating qTest connection..." });

      const qtestFields = {
        qTestDomain: systemSettings.qTestDomain,
        apiToken: systemSettings.apiToken,
        projectId: systemSettings.projectId
      };

      console.log("Sending validation request:", qtestFields);

      const response = await axios.post("http://localhost:5550/api/settings/validate-qtest", qtestFields);

      console.log("Validation response:", response.data);

      if (response.data.success) {
        setStatusMessage({
          type: "success",
          message: response.data.message || "qTest connection validated successfully!"
        });
        setValidationStatus(prev => ({ ...prev, qtest: true }));
      } else {
        setStatusMessage({
          type: "error",
          message: response.data.message || "qTest connection validation failed"
        });
        setValidationStatus(prev => ({ ...prev, qtest: false }));
      }
    } catch (err) {
      console.error("Validation error:", err);

      let errorMessage = "Network error occurred";

      if (err.response && err.response.data) {
        errorMessage = err.response.data.message || err.response.data.error || "Server error occurred";
      } else if (err.message) {
        errorMessage = err.message;
      }

      setStatusMessage({
        type: "error",
        message: errorMessage
      });
      setValidationStatus(prev => ({ ...prev, qtest: false }));
    }
  };

  const goToNextStep = () => {
    setCurrentStep(2);
  };

  const goToPreviousStep = () => {
    setCurrentStep(1);
  };

  const clearAllData = () => {
    // Clear localStorage
    localStorage.removeItem('settingsFormData');
    localStorage.removeItem('selectedSettingId');
    localStorage.removeItem('currentStep');
    localStorage.removeItem('validationStatus');
    localStorage.removeItem('saveStatus');

    // Reset state
    setSystemSettings({
      almServerUrl: "",
      username: "",
      password: "",
      domain: "",
      project: "",
      qTestDomain: "",
      apiToken: "",
      projectId: "",
    });
    setSelectedSettingId(null);
    setCurrentStep(1);
    setValidationStatus({ alm: false, qtest: false });
    setSaveStatus({ alm: false, qtest: false });

    setStatusMessage({
      type: "success",
      message: "Form cleared successfully!"
    });
  };

  const [currentLinkName, setCurrentLinkName] = useState(null);

  // Modified fetchSavedSettings to get current status
  const fetchSavedSettings = async () => {
    setIsLoading(true);
    try {
      const res = await axios.get("http://localhost:5550/api/settings/settings");
      const settingsArray = Array.isArray(res.data) ? res.data : res.data?.settings || [];
      setSavedSettings(settingsArray);

      // Find and set the current link
      const currentSetting = settingsArray.find(setting => setting.is_current === 1 || setting.is_current === true);
      if (currentSetting) {
        setCurrentLinkName(currentSetting.link_name);
      }
    } catch (err) {
      console.error("Fetch error:", err);
      setStatusMessage({
        type: "error",
        message: "Failed to fetch saved settings",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // New function to set a link as current
  const setLinkAsCurrent = async (linkName) => {
    try {
      setStatusMessage({ type: "info", message: `Setting ${linkName} as current...` });

      const response = await axios.put(`http://localhost:5550/api/settings/set-current/${encodeURIComponent(linkName)}`);

      if (response.data.success) {
        setCurrentLinkName(linkName);

        // Update the savedSettings state to reflect the change
        setSavedSettings(prev =>
          prev.map(setting => ({
            ...setting,
            is_current: setting.link_name === linkName ? true : false,
            isCurrent: setting.link_name === linkName
          }))
        );

        setStatusMessage({
          type: "success",
          message: `${linkName} is now set as current configuration`
        });

        // Optionally load the settings data too
        loadSettingsData(linkName);

      } else {
        setStatusMessage({
          type: "error",
          message: response.data.error || "Failed to set as current"
        });
      }
    } catch (err) {
      console.error("Error setting current link:", err);
      setStatusMessage({
        type: "error",
        message: "Failed to set as current: " + (err.response?.data?.message || err.message)
      });
    }
  };

  // Modified loadSettingsData to also set as current
  const loadSettingsData = async (linkName, setAsCurrent = false) => {
    try {
      setStatusMessage({ type: "info", message: "Loading settings..." });

      const response = await axios.get(`http://localhost:5550/api/settings/settings/${encodeURIComponent(linkName)}`);
      const settingData = response.data;

      // Update the form with loaded data
      setSystemSettings({
        almServerUrl: settingData.almServerUrl || "",
        username: settingData.username || "",
        password: settingData.password || "",
        domain: settingData.domain || "",
        project: settingData.project || "",
        qTestDomain: settingData.qTestDomain || "",
        apiToken: settingData.apiToken || "",
        projectId: settingData.projectId || "",
      });

      setSelectedLinkName(linkName);
      setIsEditingMode(false);
      setCurrentStep(1);

      // Reset validation and save status when loading different settings
      setValidationStatus({ alm: false, qtest: false });
      setSaveStatus({ alm: false, qtest: false });

      // If setAsCurrent is true, also set this link as current
      if (setAsCurrent) {
        await setLinkAsCurrent(linkName);
      } else {
        setStatusMessage({
          type: "success",
          message: `Loaded settings for "${linkName}"`
        });
      }

    } catch (err) {
      console.error("Error loading settings:", err);
      setStatusMessage({
        type: "error",
        message: "Failed to load settings data"
      });
    }
  };



  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [settingToDelete, setSettingToDelete] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // FIXED: Corrected deleteSettings function for axios
  const deleteSettings = async (linkName) => {
    setIsDeleting(true);
    try {
      console.log('Attempting to delete:', linkName); // Debug log

      // Fixed: Using axios.delete correctly
      const response = await axios.delete(`http://localhost:5550/api/settings/settings/${linkName}`, {
        headers: {
          'Content-Type': 'application/json',
        },
      });

      // Fixed: With axios, response data is directly available in response.data
      const result = response.data;

      // Fixed: Check response status correctly for axios
      if (response.status === 200) {
        // Show success message
        setShowDeleteModal(false);
        setSettingToDelete(null);

        // Success notification
        alert(`✅ Settings '${linkName}' deleted successfully and stored in history!`);

        // Refresh the settings list
        fetchSavedSettings(); // Call your existing function to reload settings

        // If the deleted setting was current, clear current selection
        if (currentLinkName === linkName) {
          setCurrentLinkName('');
          setSelectedLinkName('');
        }

      } else {
        alert(`❌ Error: ${result.error || 'Failed to delete settings'}`);
      }
    } catch (error) {
      console.error('Delete error:', error);

      // Better error handling for axios
      if (error.response) {
        // Server responded with error status
        const errorMessage = error.response.data?.error || error.response.data?.message || 'Server error';
        alert(`❌ Error: ${errorMessage}`);
        console.log('Server error response:', error.response.data);
      } else if (error.request) {
        // Request was made but no response received
        alert('❌ Network error: Unable to connect to server');
        console.log('Network error:', error.request);
      } else {
        // Something else happened
        alert('❌ Failed to delete settings. Please try again.');
        console.log('Unexpected error:', error.message);
      }
    } finally {
      setIsDeleting(false);
    }
  };

  // Handle delete icon click
  const handleDeleteClick = (setting, event) => {
    event.stopPropagation();
    setSettingToDelete(setting);
    setShowDeleteModal(true);
  };

  // Confirm delete
  const confirmDelete = () => {
    if (settingToDelete) {
      deleteSettings(settingToDelete.link_name);
    }
  };

  // Cancel delete
  const cancelDelete = () => {
    setShowDeleteModal(false);
    setSettingToDelete(null);
  };

return (
    <>
      <Topbar />
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-gray-100 flex">
        {/* Sidebar */}
        <div className="w-72 bg-white shadow-2xl mt-16 h-screen-minus-24 overflow-y-auto border-r border-gray-100">

          {/* Header Section */}
          <div className="p-6 border-b border-gray-100 bg-gradient-to-r from-slate-50 to-blue-50">
            <h3 className="text-xl font-bold text-gray-800 flex items-center">
              <IoSettings className="mr-3 text-blue-600" size={24} />
              Configuration Panel
            </h3>
            <p className="text-sm text-gray-500 mt-1">Manage your system settings</p>
          </div>

          <div className="p-6">

            {/* Add New Link Button */}
            <button
              onClick={handleAddNewLink}
              className="w-full mb-6 bg-gradient-to-r from-blue-600 to-blue-700 text-white px-4 py-3 rounded-xl hover:from-blue-700 hover:to-blue-800 flex items-center justify-center font-medium transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 focus:outline-none focus:ring-4 focus:ring-blue-200"
            >
              <IoAdd className="mr-2" size={20} />
              Create New File
            </button>

            {/* Settings List */}
            <div className="space-y-3">
              {savedSettings.map((setting) => (
                <div key={setting.link_name} className="group relative">
                  <button
                    onClick={() => {
                      loadSettingsData(setting.link_name);
                      setLinkAsCurrent(setting.link_name);
                    }}
                    className={`w-full text-left p-4 rounded-xl border-2 transition-all duration-300 transform hover:-translate-y-0.5 focus:outline-none focus:ring-4 ${selectedLinkName === setting.link_name
                        ? "bg-gradient-to-r from-blue-50 to-blue-100 border-blue-300 text-blue-900 shadow-lg scale-[1.02] focus:ring-blue-200"
                        : "bg-white border-gray-200 hover:bg-gradient-to-r hover:from-gray-50 hover:to-slate-50 hover:border-gray-300 hover:shadow-md focus:ring-gray-200"
                      }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="font-semibold text-sm flex items-center">
                          <span className={`${selectedLinkName === setting.link_name ? 'text-blue-800' : 'text-gray-800'}`}>
                            {setting.link_name}
                          </span>
                          {(setting.is_current === 1 || setting.is_current === true || currentLinkName === setting.link_name) && (
                            <span className="ml-2 inline-flex items-center bg-gradient-to-r from-green-100 to-emerald-100 text-green-700 px-2.5 py-1 rounded-full text-xs font-medium border border-green-200 shadow-sm">
                              <IoCheckboxOutline className="mr-1" size={12} />
                              Active
                            </span>
                          )}
                        </div>
                        <div className={`text-xs mt-1 ${selectedLinkName === setting.link_name ? 'text-blue-600' : 'text-gray-500'}`}>
                          Configuration Settings
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        {selectedLinkName === setting.link_name && (
                          <div className="w-2 h-2 bg-blue-600 rounded-full animate-pulse shadow-lg"></div>
                        )}

                        {/* Delete Icon */}
                        <button
                          onClick={(e) => handleDeleteClick(setting, e)}
                          className="p-2 rounded-lg text-gray-400 hover:text-red-500 hover:bg-red-50 transition-all duration-200 opacity-0 group-hover:opacity-100 focus:opacity-100 focus:outline-none focus:ring-2 focus:ring-red-200 transform hover:scale-110"
                          title={`Delete ${setting.link_name}`}
                        >
                          <IoTrashOutline size={16} />
                        </button>
                      </div>
                    </div>
                  </button>
                </div>
              ))}
            </div>

            {/* Delete Confirmation Modal */}
            {showDeleteModal && (
              <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
                <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full transform transition-all">
                  {/* Modal Header */}
                  <div className="flex items-center justify-between p-6 border-b border-gray-200">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-red-100 rounded-full">
                        <IoWarningOutline className="text-red-600" size={24} />
                      </div>
                      <h3 className="text-lg font-semibold text-gray-900">Confirm Delete</h3>
                    </div>
                    <button
                      onClick={cancelDelete}
                      className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                    >
                      <IoCloseOutline size={20} className="text-gray-500" />
                    </button>
                  </div>

                  {/* Modal Body */}
                  <div className="p-6">
                    <p className="text-gray-700 mb-4">
                      Are you sure you want to delete the settings configuration:
                    </p>
                    <div className="bg-gray-50 rounded-lg p-3 mb-4">
                      <p className="font-semibold text-gray-800">"{settingToDelete?.link_name}"</p>
                      <p className="text-sm text-gray-600 mt-1">
                        {settingToDelete?.is_current ? "⚠️ This is currently the active configuration" : "Configuration Settings"}
                      </p>
                    </div>
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                      <p className="text-sm text-blue-800">
                        <strong>Note:</strong> The deleted data will be safely stored in delete history and can be restored later if needed.
                      </p>
                    </div>
                  </div>

                  {/* Modal Footer */}
                  <div className="flex space-x-3 p-6 border-t border-gray-200">
                    <button
                      onClick={cancelDelete}
                      disabled={isDeleting}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors disabled:opacity-50"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={confirmDelete}
                      disabled={isDeleting}
                      className="flex-1 px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                    >
                      {isDeleting ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2"></div>
                          Deleting...
                        </>
                      ) : (
                        'Delete'
                      )}
                    </button>
                  </div>
                </div>
              </div>
            )}

          </div>
        </div>


        {/* Main Content */}
        <div className="flex-1 p-8 mt-16">
          <div className="max-w-5xl mx-auto">
            {/* Header Section */}
            <div className="mb-8">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h1 className="text-4xl font-bold text-gray-900 mb-2">
                    {isEditingMode ? "Create New Configuration" :
                      selectedLinkName ? `Configuration: ${selectedLinkName}` : "System Configuration"}
                  </h1>
                  <p className="text-gray-600 text-lg">
                    {isEditingMode ? "Set up a new system integration configuration" :
                      selectedLinkName ? "View and manage your selected configuration" :
                        "Configure your ALM and qTest system connections"}
                  </p>
                </div>

                {/* Main Action Buttons - Fixed Size */}
                <div className="flex gap-3">
                  <Link
                    to="/dashboard"
                    className="bg-gradient-to-r from-purple-600 to-purple-700 text-white px-6 py-3 rounded-lg hover:from-purple-700 hover:to-purple-800 flex items-center font-medium transition-all duration-200 shadow-md hover:shadow-lg min-w-[140px] justify-center"
                  >
                    <IoGitBranch className="mr-2" size={18} />
                    Mapping
                  </Link>

                  <button
                    onClick={validateFields}
                    className="bg-gradient-to-r from-green-600 to-green-700 text-white px-6 py-3 rounded-lg hover:from-green-700 hover:to-green-800 flex items-center font-medium transition-all duration-200 shadow-md hover:shadow-lg min-w-[160px] justify-center"
                  >
                    <IoCheckboxOutline className="mr-2" size={18} />
                    Field Validation
                  </button>

                  <Link
                    to="/migrate"
                    className="bg-gradient-to-r from-orange-600 to-orange-700 text-white px-6 py-3 rounded-lg hover:from-orange-700 hover:to-orange-800 flex items-center font-medium transition-all duration-200 shadow-md hover:shadow-lg min-w-[120px] justify-center"
                  >
                    <IoSwapHorizontal className="mr-2" size={18} />
                    Migrate
                  </Link>
                </div>
              </div>

              {/* Field Validation Status Bar - Compact Design */}
              {(status === 'validating' || status === 'success' || status === 'failed') && (
                <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6 mb-6">
                  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                    
                    {/* Status and Stats Section */}
                    <div className="flex flex-col sm:flex-row sm:items-center gap-4 flex-1">
                      
                      {/* Loading State */}
                      {status === 'validating' && (
                        <div className="flex items-center">
                          <div className="animate-spin rounded-full h-6 w-6 border-2 border-blue-600 border-t-transparent mr-3"></div>
                          <span className="text-blue-600 font-medium">Validating fields...</span>
                        </div>
                      )}

                      {/* Success/Failed State */}
                      {(status === 'success' || status === 'failed') && (
                        <div className="flex items-center">
                          {status === 'success' ? (
                            <CheckCircle className="text-green-600 mr-2" size={24} />
                          ) : (
                            <AlertCircle className="text-red-600 mr-2" size={24} />
                          )}
                          <div className="flex flex-col">
                            <span className={`font-semibold ${status === 'success' ? 'text-green-700' : 'text-red-700'}`}>
                              {status === 'success' ? 'Validation Completed Successfully' : 'Validation Issues Found'}
                            </span>
                            <span className="text-sm text-gray-600">
                              Total: <span className="font-medium">{fieldStats.total}</span> | 
                              Passed: <span className="font-medium text-green-600">{fieldStats.passed}</span> | 
                              Failed: <span className="font-medium text-red-600">{fieldStats.failed}</span>
                            </span>
                          </div>
                        </div>
                      )}

                      {/* Progress Bar */}
                      {(status === 'success' || status === 'failed') && fieldStats.total > 0 && (
                        <div className="flex-1 max-w-xs">
                          <div className="bg-gray-200 rounded-full h-3 overflow-hidden">
                            <div className="h-full flex">
                              <div 
                                className="bg-green-500 transition-all duration-300"
                                style={{ width: `${(fieldStats.passed / fieldStats.total) * 100}%` }}
                              ></div>
                              <div 
                                className="bg-red-500 transition-all duration-300"
                                style={{ width: `${(fieldStats.failed / fieldStats.total) * 100}%` }}
                              ></div>
                            </div>
                          </div>
                          <div className="text-xs text-gray-500 mt-1 text-center">
                            {Math.round((fieldStats.passed / fieldStats.total) * 100)}% Success Rate
                          </div>
                        </div>
                      )}
                    </div>

                    {/* View Report Button */}
                    {(status === 'success' || status === 'failed') && (
                      <button
                        onClick={() => setShowReport(true)}
                        className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-4 py-2 rounded-lg hover:from-blue-700 hover:to-blue-800 flex items-center font-medium transition-all duration-200 shadow-md hover:shadow-lg text-sm whitespace-nowrap"
                      >
                        <Eye className="mr-2" size={16} />
                        View Report
                      </button>
                    )}
                  </div>
                </div>
              )}

              {/* Status message */}
              {statusMessage && (
                <div className={`p-4 rounded-lg border-l-4 ${statusMessage.type === "success"
                  ? "bg-green-50 border-green-400 text-green-800" :
                  statusMessage.type === "error"
                    ? "bg-red-50 border-red-400 text-red-800" :
                    "bg-blue-50 border-blue-400 text-blue-800"
                  }`}>
                  <p className="font-medium">{statusMessage.message}</p>
                </div>
              )}
            </div>

            {/* Field Validation Report Modal */}
            {showReport && (
              <div className="fixed inset-0 z-50 bg-black bg-opacity-50 flex items-center justify-center p-4">
                <div className="bg-white rounded-2xl shadow-2xl max-w-6xl w-full h-[85vh] flex flex-col">
                  
                  {/* Modal Header */}
                  <div className="flex items-center justify-between p-6 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-indigo-50">
                    <div className="flex items-center">
                      <div className="p-2 bg-blue-100 rounded-lg mr-3">
                        <IoCheckboxOutline className="text-blue-600" size={24} />
                      </div>
                      <div>
                        <h2 className="text-2xl font-bold text-gray-900">Field Validation Report</h2>
                        <p className="text-sm text-gray-600">Detailed analysis of field mappings</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => setShowReport(false)}
                      className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                    >
                      <IoClose size={24} className="text-gray-500" />
                    </button>
                  </div>

                  {/* Download Section */}
                  <div className="p-6 border-b border-gray-200 bg-gray-50">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <span className="text-sm font-medium text-gray-700">Export Options:</span>
                        <div className="relative">
                          <button
                            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm flex items-center"
                            onClick={() => setShowDownloadOptions(!showDownloadOptions)}
                          >
                            <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                            </svg>
                            Download Report
                          </button>

                          {showDownloadOptions && (
                            <div className="absolute top-full mt-2 left-0 bg-white border rounded-lg shadow-lg z-50 min-w-[200px]">
                              <button
                                onClick={() => {
                                  const filename = window.prompt("Enter file name for CSV (without extension):", "FieldValidationReport");
                                  if (filename) {
                                    const csv = generateCSVFromReport(report);
                                    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
                                    const url = URL.createObjectURL(blob);
                                    const link = document.createElement('a');
                                    link.href = url;
                                    link.setAttribute('download', `${filename}.csv`);
                                    link.click();
                                    setShowDownloadOptions(false);
                                  }
                                }}
                                className="block w-full px-4 py-3 text-sm text-left hover:bg-gray-50 border-b border-gray-100 flex items-center"
                              >
                                <span className="mr-2">📄</span> Download as CSV
                              </button>

                              <button
                                onClick={() => {
                                  const filename = window.prompt("Enter file name for XLSX (without extension):", "FieldValidationReport");
                                  if (filename) {
                                    generateXLSXFromReport(report, filename);
                                    setShowDownloadOptions(false);
                                  }
                                }}
                                className="block w-full px-4 py-3 text-sm text-left hover:bg-gray-50 flex items-center"
                              >
                                <span className="mr-2">📊</span> Download as XLSX
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      <div className="text-sm text-gray-600">
                        <span className="font-medium">{fieldStats.total}</span> total fields analyzed
                      </div>
                    </div>
                  </div>

                  {/* Report Content */}
                  <div className="flex-1 overflow-y-auto p-6">
                    <div className="space-y-6">
                      {report && report.map((link, index) => (
                        <div key={index} className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">
                          
                          {/* Link Header */}
                          <div className="bg-gradient-to-r from-purple-50 to-blue-50 p-4 border-b border-gray-200">
                            <h3 className="text-lg font-semibold text-purple-700 flex items-center">
                              <span className="p-1 bg-purple-100 rounded-lg mr-3">🔗</span>
                              {link.link_name}
                            </h3>
                            <div className="text-sm text-gray-600 mt-2 grid grid-cols-1 md:grid-cols-3 gap-4">
                              <div><span className="font-medium">ALM Domain:</span> {link.domain}</div>
                              <div><span className="font-medium">ALM Project:</span> {link.project}</div>
                              <div><span className="font-medium">qTest Project ID:</span> {link.projectId}</div>
                            </div>
                          </div>

                          {/* Artifacts */}
                          <div className="p-4">
                            {Object.entries(link.artifacts).map(([artifact, data]) => (
                              <div key={artifact} className="mb-6 last:mb-0">
                                <h4 className="font-semibold text-gray-800 mb-3 flex items-center">
                                  <span className="p-1 bg-gray-100 rounded mr-2">📋</span>
                                  {artifact}
                                  <span className="ml-2 text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">
                                    {data.mapped_fields.length} fields
                                  </span>
                                </h4>
                                
                                <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
                                  {data.mapped_fields.map((field, i) => (
                                    <div 
                                      key={i} 
                                      className={`p-4 rounded-lg border-l-4 ${
                                        field.status === 'pass' 
                                          ? 'bg-green-50 border-green-400 border-l-green-500' 
                                          : 'bg-red-50 border-red-400 border-l-red-500'
                                      }`}
                                    >
                                      <div className="space-y-2">
                                        <div className="flex justify-between items-start">
                                          <div className="flex-1">
                                            <p className="text-sm">
                                              <span className="font-medium text-gray-700">ALM:</span> 
                                              <span className="ml-1">{field.alm_field}</span>
                                              <span className="text-gray-500 text-xs ml-1">({field.alm_type})</span>
                                            </p>
                                            <p className="text-sm">
                                              <span className="font-medium text-gray-700">qTest:</span> 
                                              <span className="ml-1">{field.qtest_field}</span>
                                              <span className="text-gray-500 text-xs ml-1">({field.qtest_type})</span>
                                            </p>
                                          </div>
                                          <div className={`px-2 py-1 rounded text-xs font-medium ${
                                            field.status === 'pass' 
                                              ? 'bg-green-100 text-green-800' 
                                              : 'bg-red-100 text-red-800'
                                          }`}>
                                            {field.status === 'pass' ? '✓ Match' : '✗ Mismatch'}
                                          </div>
                                        </div>
                                        {field.status === 'fail' && (
                                          <p className="text-red-600 text-xs mt-2 font-medium">
                                            ⚠️ Field type mismatch detected
                                          </p>
                                        )}
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Step indicator */}
            <div className="mb-8">
              <div className="flex bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
                <div className={`flex-1 text-center p-4 font-semibold transition-all duration-200 ${currentStep === 1
                  ? "bg-blue-600 text-white"
                  : "bg-gray-50 text-gray-600 hover:bg-gray-100"
                  }`}>
                  <div className="flex items-center justify-center">
                    <span className={`w-6 h-6 rounded-full flex items-center justify-center text-sm mr-2 ${currentStep === 1 ? "bg-white text-blue-600" : "bg-gray-300 text-gray-600"
                      }`}>
                      1
                    </span>
                    ALM Credentials
                  </div>
                </div>
                <div className={`flex-1 text-center p-4 font-semibold transition-all duration-200 ${currentStep === 2
                  ? "bg-blue-600 text-white"
                  : "bg-gray-50 text-gray-600 hover:bg-gray-100"
                  }`}>
                  <div className="flex items-center justify-center">
                    <span className={`w-6 h-6 rounded-full flex items-center justify-center text-sm mr-2 ${currentStep === 2 ? "bg-white text-blue-600" : "bg-gray-300 text-gray-600"
                      }`}>
                      2
                    </span>
                    qTest Credentials
                  </div>
                </div>
              </div>
            </div>

            {/* ALM Settings Form - Show in Step 1 */}
            {currentStep === 1 && (
              <div className="bg-white shadow-lg rounded-xl border border-gray-200 overflow-hidden">
                <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-6">
                  <h3 className="text-2xl font-bold">ALM System Configuration</h3>
                  <p className="text-blue-100 mt-1">Configure your Application Lifecycle Management system connection</p>
                </div>

                <div className="p-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="md:col-span-2">
                      <label className="block text-sm font-semibold text-gray-700 mb-2">ALM Server URL</label>
                      <input
                        type="text"
                        name="almServerUrl"
                        value={systemSettings.almServerUrl}
                        onChange={handleInputChange}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                        placeholder="https://your-alm-server.com"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">Username</label>
                      <input
                        type="text"
                        name="username"
                        value={systemSettings.username}
                        onChange={handleInputChange}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                        placeholder="Enter username"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">Password</label>
                      <input
                        type="password"
                        name="password"
                        value={systemSettings.password}
                        onChange={handleInputChange}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                        placeholder="Enter password"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">Domain</label>
                      <input
                        type="text"
                        name="domain"
                        value={systemSettings.domain}
                        onChange={handleInputChange}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                        placeholder="Enter domain"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">Project</label>
                      <input
                        type="text"
                        name="project"
                        value={systemSettings.project}
                        onChange={handleInputChange}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                        placeholder="Enter project name"
                      />
                    </div>
                  </div>

                 <div className="flex gap-4 mt-8 pt-6 border-t border-gray-200">
                    <button
                      onClick={handleSaveTempAlm}
                      className="bg-gradient-to-r from-green-600 to-green-700 text-white px-6 py-3 rounded-lg hover:from-green-700 hover:to-green-800 font-medium transition-all duration-200 shadow-md hover:shadow-lg"
                    >
                      Save Credentials
                    </button>

                    <button
                      onClick={handleAlmValidate}
                      disabled={!saveStatus.alm}
                      className={`px-6 py-3 rounded-lg font-medium transition-all duration-200 ${saveStatus.alm
                        ? "bg-gradient-to-r from-blue-600 to-blue-700 text-white hover:from-blue-700 hover:to-blue-800 shadow-md hover:shadow-lg"
                        : "bg-gray-300 text-gray-500 cursor-not-allowed"
                        }`}
                    >
                      Validate Connection
                    </button>

                    <button
                      onClick={goToNextStep}
                      disabled={!validationStatus.alm}
                      className={`px-6 py-3 rounded-lg font-medium transition-all duration-200 ml-auto ${validationStatus.alm
                        ? "bg-gradient-to-r from-purple-600 to-purple-700 text-white hover:from-purple-700 hover:to-purple-800 shadow-md hover:shadow-lg"
                        : "bg-gray-300 text-gray-500 cursor-not-allowed"
                        }`}
                    >
                      Next Step →
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* qTest Settings Form - Show in Step 2 */}
            {currentStep === 2 && (
              <div className="bg-white shadow-lg rounded-xl border border-gray-200 overflow-hidden">
                <div className="bg-gradient-to-r from-green-600 to-green-700 text-white p-6">
                  <h3 className="text-2xl font-bold">qTest System Configuration</h3>
                  <p className="text-green-100 mt-1">Configure your qTest system connection and API settings</p>
                </div>

                <div className="p-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="md:col-span-2">
                      <label className="block text-sm font-semibold text-gray-700 mb-2">qTest Domain</label>
                      <input
                        type="text"
                        name="qTestDomain"
                        value={systemSettings.qTestDomain}
                        onChange={handleInputChange}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
                        placeholder="your-company.qtestnet.com"
                      />
                    </div>

                    <div className="md:col-span-2">
                      <label className="block text-sm font-semibold text-gray-700 mb-2">API Token</label>
                      <input
                        type="text"
                        name="apiToken"
                        value={systemSettings.apiToken}
                        onChange={handleInputChange}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
                        placeholder="Enter your qTest API token"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">Project ID</label>
                      <input
                        type="text"
                        name="projectId"
                        value={systemSettings.projectId}
                        onChange={handleInputChange}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
                        placeholder="Enter project ID"
                      />
                    </div>
                  </div>

                  <div className="flex gap-4 mt-8 pt-6 border-t border-gray-200">
                    <button
                      onClick={goToPreviousStep}
                      className="bg-gradient-to-r from-gray-600 to-gray-700 text-white px-6 py-3 rounded-lg hover:from-gray-700 hover:to-gray-800 font-medium transition-all duration-200 shadow-md hover:shadow-lg"
                    >
                      ← Previous Step
                    </button>

                    <button
                      onClick={handleSaveTempQtest}
                      className="bg-gradient-to-r from-green-600 to-green-700 text-white px-6 py-3 rounded-lg hover:from-green-700 hover:to-green-800 font-medium transition-all duration-200 shadow-md hover:shadow-lg"
                    >
                      Save Credentials
                    </button>

                    <button
                      onClick={handleQtestValidate}
                      disabled={!saveStatus.qtest}
                      className={`px-6 py-3 rounded-lg font-medium transition-all duration-200 ${saveStatus.qtest
                        ? "bg-gradient-to-r from-blue-600 to-blue-700 text-white hover:from-blue-700 hover:to-blue-800 shadow-md hover:shadow-lg"
                        : "bg-gray-300 text-gray-500 cursor-not-allowed"
                        }`}
                    >
                      Validate Connection
                    </button>

                    <button
                      onClick={openSaveModal}
                      disabled={!(validationStatus.alm && validationStatus.qtest)}
                      className={`px-6 py-3 rounded-lg font-medium transition-all duration-200 ml-auto ${validationStatus.alm && validationStatus.qtest
                        ? "bg-gradient-to-r from-purple-600 to-purple-700 text-white hover:from-purple-700 hover:to-purple-800 shadow-md hover:shadow-lg"
                        : "bg-gray-300 text-gray-500 cursor-not-allowed"
                        }`}
                    >
                      Save Configuration
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Save Modal */}
            {showSaveModal && (
              <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                <div className="bg-white rounded-xl shadow-2xl p-8 max-w-md w-full mx-4">
                  <h3 className="text-2xl font-bold text-gray-900 mb-6">Save Configuration</h3>

                  <div className="mb-6">
                    <label className="block text-sm font-semibold text-gray-700 mb-3">Configuration Name</label>
                    <input
                      type="text"
                      value={linkName}
                      onChange={(e) => setLinkName(e.target.value)}
                      className={`w-full p-3 border rounded-lg focus:ring-2 focus:border-transparent transition-all duration-200 ${nameExists ? 'border-red-500 focus:ring-red-500' : 'border-gray-300 focus:ring-blue-500'
                        }`}
                      placeholder="Enter a unique name for this configuration"
                      autoFocus
                    />

                    {checkingName && (
                      <p className="text-blue-600 text-sm mt-2 flex items-center">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600 mr-2"></div>
                        Checking availability...
                      </p>
                    )}

                    {nameExists && !checkingName && (
                      <p className="text-red-600 text-sm mt-2">⚠️ This name already exists. Please choose a different name.</p>
                    )}

                    {linkName.trim().length > 0 && !nameExists && !checkingName && (
                      <p className="text-green-600 text-sm mt-2">✓ Name is available!</p>
                    )}
                  </div>

                  <div className="flex justify-end gap-3">
                    <button
                      onClick={closeSaveModal}
                      className="bg-gray-200 text-gray-800 px-6 py-3 rounded-lg hover:bg-gray-300 font-medium transition-all duration-200"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleSave}
                      disabled={!linkName.trim() || nameExists || checkingName}
                      className={`px-6 py-3 rounded-lg font-medium transition-all duration-200 ${linkName.trim() && !nameExists && !checkingName
                        ? "bg-gradient-to-r from-blue-600 to-blue-700 text-white hover:from-blue-700 hover:to-blue-800 shadow-md hover:shadow-lg"
                        : "bg-gray-300 text-gray-500 cursor-not-allowed"
                        }`}
                    >
                      Save Configuration
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default SettingsPage;