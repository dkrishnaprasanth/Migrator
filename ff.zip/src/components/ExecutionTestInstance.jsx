import React, { useEffect, useState, useRef } from "react";
import Sidebar from "./Sidebar";
import Topbar from "./Topbar";
import axios from "axios";
import { DndProvider, useDrag, useDrop } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { IoCloseSharp } from "react-icons/io5";



import ReactDOM from 'react-dom';

const FIELD_TYPE = "FIELD";

// DraggableField component (for source fields)
const DraggableField = ({ field, onUnmap }) => {
  const [showDropdown, setShowDropdown] = useState(false);
  const [listValues, setListValues] = useState([]);
  const [loadingValues, setLoadingValues] = useState(false);
  const [showValuePopup, setShowValuePopup] = useState(false);
  const dropdownRef = useRef(null);

  const [{ isDragging }, dragRef] = useDrag({
    type: FIELD_TYPE,
    item: { ...field, listValues }, // Include listValues in drag item
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });

  const fetchListValues = async () => {
    if (!field.listId) return;
    setLoadingValues(true);
    try {
      const response = await axios.get(
        `http://localhost:5550/api/alm/testinstance-list-values/${field.listId}`
      );
      setListValues(response.data);
      // Update field with listValues for mapping - this ensures values are available during save
      field.listValues = response.data;
    } catch (error) {
      console.error("Error fetching list values:", error);
      toast.error("Failed to load list values");
    } finally {
      setLoadingValues(false);
    }
  };

  // Auto-fetch list values when component mounts if listId exists
  useEffect(() => {
    if (field.listId && !field.listValues) {
      fetchListValues();
    }
  }, [field.listId]);

  const toggleDropdown = async (e) => {
    e.stopPropagation();
    if (field.listId) {
      if (!showDropdown && listValues.length === 0) {
        await fetchListValues();
      }
      setShowDropdown((prev) => !prev);
    }
  };

  const handleValueClick = (selectedValue) => {
    setShowDropdown(false);
    setShowValuePopup(true);
    field.selectedValue = selectedValue;
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setShowDropdown(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <>
      <div
        ref={dragRef}
        className={`p-2 m-1 rounded cursor-move transition-all flex justify-between items-center ${isDragging
          ? "opacity-50"
          : field.isMapped
            ? "bg-blue-500 text-white"
            : "bg-white text-black"
          }`}
      >
        <div className="flex items-center gap-2 w-full">
          <div className="relative flex-1">
            <span
              className="cursor-pointer flex items-center"
              onClick={toggleDropdown}
            >
              {field.label}
              {field.listId && (
                <ChevronIcon showDropdown={showDropdown} />
              )}
            </span>

            {showDropdown && (
              <div
                ref={dropdownRef}
                className="absolute left-0 top-full mt-1 w-full min-w-[200px] bg-white border border-gray-200 rounded-md shadow-lg z-50"
              >
                <div className="py-1 max-h-60 overflow-y-auto">
                  {loadingValues ? (
                    <LoadingSpinner />
                  ) : listValues.length > 0 ? (
                    listValues.map((value, idx) => (
                      <div
                        key={idx}
                        className="px-4 py-2 hover:bg-gray-100 cursor-pointer text-gray-800"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleValueClick(value);
                        }}
                      >
                        {value.value}
                      </div>
                    ))
                  ) : (
                    <div className="px-4 py-2 text-gray-500">No values found</div>
                  )}
                </div>
              </div>
            )}
          </div>

          {field.isMapped && (
            <UnmapButton onClick={() => onUnmap(field)} />
          )}
        </div>
      </div>

      {showValuePopup && (
        <ValuePopup
          field={field}
          onClose={() => setShowValuePopup(false)}
        />
      )}
    </>
  );
};

// DroppableField component (for target fields)
const DroppableField = ({
  field,
  index,
  handleDrop,
  targetFields = [],
  setTargetFields,
  setCurrentLoadedMapping,
  setIsModalOpen,
  fetchSavedMappings,
  fetchAlmFields,
  fetchQTestFields,
  setValueMappingsTemp,
   valueMappingsTemp
}) => {
  const [showDropdown, setShowDropdown] = useState(false);
  const [showValuePopup, setShowValuePopup] = useState(false);
  const dropdownRef = useRef(null);

  const [, ref] = useDrop({
    accept: FIELD_TYPE,
    drop: (draggedField) => {
      handleDrop(index, draggedField);

      if (draggedField.listId && field.allowed_values?.length > 0) {
        setShowValuePopup(true);
      }
    },
  });

  const toggleDropdown = (e) => {
    e.stopPropagation();
    if (field.allowed_values?.length > 0) {
      setShowDropdown(!showDropdown);
    }
  };

  const handleValueClick = (selectedValue) => {
    setShowDropdown(false);
    field.selectedValue = selectedValue;
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setShowDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <>
      <div
        ref={ref}
        className={`relative p-2 m-1 rounded flex justify-between items-center ${field.mappedTo ? "bg-blue-500 text-white" : "bg-white text-black"
          }`}
      >
        <div className="flex items-center gap-2">
          {field.required === 1 && <RequiredFieldIndicator />}

          <div className="relative flex-1">
            <span
              className="cursor-pointer flex items-center"
              onClick={toggleDropdown}
            >
              {field.label}
              {field.allowed_values?.length > 0 && (
                <ChevronIcon showDropdown={showDropdown} />
              )}
            </span>

            {showDropdown && field.allowed_values?.length > 0 && (
              <div
                ref={dropdownRef}
                className="absolute left-0 top-full mt-1 w-full min-w-[200px] bg-white border border-gray-200 rounded-md shadow-lg z-50"
              >
                <div className="py-1 max-h-60 overflow-y-auto">
                  {field.allowed_values.map((value, idx) => (
                    <div
                      key={idx}
                      className="px-4 py-2 hover:bg-gray-100 cursor-pointer text-gray-800"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleValueClick(value);
                      }}
                    >
                      {value.label_value} ({value.value})
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center">
          ➝{" "}
          {field.mappedTo ? (
            <span className="font-semibold ml-2">
              {field.mappedTo.label}
              {/* Show temp mapping indicator */}
              {field.tempMappings && (
                <></>
              )}
            </span>
          ) : (
            <span className="text-red-500 ml-2">Unmapped</span>
          )}

          {field.mappedTo?.listId && field.allowed_values?.length > 0 && (
            <button
              onClick={() => setShowValuePopup(true)}
              className="ml-2 px-2 py-1 text-xs bg-green-500 text-white rounded hover:bg-green-600"
            >
              Show Values
            </button>
          )}
        </div>
      </div>

      {showValuePopup &&
        field.mappedTo &&
        field.mappedTo.listId &&
        field.allowed_values?.length > 0 && (
          <ValueMappingPopup
            sourceField={field.mappedTo}
            targetField={field}
            targetFields={targetFields}
            setTargetFields={setTargetFields}
            onClose={() => setShowValuePopup(false)}
            setCurrentLoadedMapping={setCurrentLoadedMapping}
            setIsModalOpen={setIsModalOpen}
            fetchSavedMappings={fetchSavedMappings}
            fetchAlmFields={fetchAlmFields}
            fetchQTestFields={fetchQTestFields}
            setValueMappingsTemp={setValueMappingsTemp}
            valueMappingsTemp={valueMappingsTemp}  // ✅ ADD THIS
          />

        )}
    </>
  );
};

// Helper Components (unchanged)
const ChevronIcon = ({ showDropdown }) => (
  <svg
    className={`w-4 h-4 ml-1 transition-transform ${showDropdown ? "rotate-180" : ""}`}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
  </svg>
);

const LoadingSpinner = () => (
  <div className="flex justify-center p-2">
    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-500"></div>
  </div>
);

const UnmapButton = ({ onClick }) => (
  <button
    onClick={onClick}
    className="text-red-500 hover:text-red-700 ml-2"
  >
    ✖
  </button>
);

const RequiredFieldIndicator = () => (
  <div className="relative" title="Required Field">
    <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
    <div className="absolute inset-0 w-2 h-2 bg-red-400 rounded-full animate-ping opacity-75" />
  </div>
);

// Popup Components
const ValuePopup = ({ field, onClose }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">Field Value</h3>
          <CloseButton onClick={onClose} />
        </div>

        <div className="mb-4">
          <p className="text-sm text-gray-600 mb-2">Field: {field.label}</p>
          {field.selectedValue && (
            <div className="bg-gray-100 p-3 rounded">
              <p className="font-medium">{field.selectedValue.value}</p>
            </div>
          )}
        </div>

        <button
          onClick={onClose}
          className="w-full bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600"
        >
          Close
        </button>
      </div>
    </div>
  );
};

const ValueMappingPopup = ({
  sourceField,
  targetField,
  onClose,
  targetFields,
  setTargetFields,
  setValueMappingsTemp,
  valueMappingsTemp,
  currentLoadedMapping // Add this prop to show the link_name
}) => {
  const [sourceValues, setSourceValues] = useState([]);
  const [targetValues, setTargetValues] = useState([]);
  const [loadingSource, setLoadingSource] = useState(false);
  const [mappings, setMappings] = useState({});
  const [selectedSource, setSelectedSource] = useState(null);
  const [selectedTarget, setSelectedTarget] = useState(null);
  const [tempSaved, setTempSaved] = useState(false);
  const [isLoadedFromDB, setIsLoadedFromDB] = useState(false);
  const [linkName, setLinkName] = useState(''); // Add state for link name

  // ✅ Enhanced initialization to handle loaded configurations and link name
  useEffect(() => {
    const initializePopup = async () => {
      console.log("🔄 Initializing ValueMappingPopup...");
      console.log("📊 Target field:", targetField);
      console.log("📊 Source field:", sourceField);
      console.log("🔗 Current loaded mapping:", currentLoadedMapping);
      
      // Set link name from current loaded mapping
      if (currentLoadedMapping) {
        setLinkName(currentLoadedMapping);
        console.log("🔗 Link name set to:", currentLoadedMapping);
      }

      // Load target values immediately
      loadTargetValues();

      // Load source values and handle existing mappings
      await fetchSourceValues();

      // ✅ Priority 1: Check if target field has valueMappings (from loaded config)
      if (targetField.valueMappings && Object.keys(targetField.valueMappings).length > 0) {
        console.log("✅ Loading existing value mappings from targetField:", targetField.valueMappings);
        setMappings(targetField.valueMappings);
        setTempSaved(true);
        setIsLoadedFromDB(true);
        console.log("✅ Loaded from database configuration");
      } 
      // ✅ Priority 2: Check valueMappingsTemp for unsaved changes
      else {
        const tempMatch = valueMappingsTemp?.find(
          entry => entry.targetField.id === targetField.id
        );
        if (tempMatch && tempMatch.mappings && Object.keys(tempMatch.mappings).length > 0) {
          console.log("✅ Loaded mappings from valueMappingsTemp:", tempMatch.mappings);
          setMappings(tempMatch.mappings);
          setTempSaved(true);
          setIsLoadedFromDB(false);
          console.log("✅ Loaded from temporary memory");
        } else {
          console.log("⚠️ No existing value mappings found - starting fresh");
          setMappings({});
          setTempSaved(false);
          setIsLoadedFromDB(false);
        }
      }
    };

    initializePopup();
  }, [targetField, sourceField, valueMappingsTemp, currentLoadedMapping]);

  const fetchSourceValues = async () => {
    if (!sourceField.listId) {
      console.warn("No listId found for source field");
      return;
    }

    setLoadingSource(true);
    try {
      // ✅ First check if source field already has listValues loaded
      if (sourceField.listValues && Array.isArray(sourceField.listValues) && sourceField.listValues.length > 0) {
        console.log("✅ Using pre-loaded source values:", sourceField.listValues);
        setSourceValues(sourceField.listValues);
      } else {
        // Fetch from API if not already loaded
        console.log("🔄 Fetching source values from API for listId:", sourceField.listId);
        const response = await axios.get(
          `http://localhost:5550/api/alm/testinstance-list-values/${sourceField.listId}`
        );
        console.log("✅ Fetched source values from API:", response.data);
        setSourceValues(response.data);

        // ✅ Update the source field with loaded values for future use
        sourceField.listValues = response.data;
      }
    } catch (error) {
      console.error("❌ Error fetching source values:", error);
      toast.error("Failed to load source values");
    } finally {
      setLoadingSource(false);
    }
  };

  const loadTargetValues = () => {
    if (targetField.allowed_values && Array.isArray(targetField.allowed_values)) {
      console.log("✅ Loading target values:", targetField.allowed_values);
      setTargetValues(targetField.allowed_values);
    } else {
      console.warn("⚠️ No allowed_values found for target field");
    }
  };

  const handleSourceSelect = (value) => {
    setSelectedSource(value);
    setSelectedTarget(null);
    console.log("🔍 Selected source value:", value);
  };

  const handleTargetSelect = (value) => {
    setSelectedTarget(value);
    if (selectedSource) {
      // ✅ Enhanced mapping creation with proper target value structure
      const newMapping = {
        value: value.value,
        label_value: value.label_value
      };
      
      setMappings(prev => ({
        ...prev,
        [selectedSource.value]: newMapping
      }));
      
      console.log(`✅ Created mapping: ${selectedSource.value} → ${value.label_value}`);
      setSelectedSource(null);
      setSelectedTarget(null);
      setTempSaved(false); // Mark as unsaved since user made changes
      setIsLoadedFromDB(false); // No longer from DB after user changes
    }
  };

  const saveTemporarily = () => {
    if (Object.keys(mappings).length === 0) {
      toast.error("Please create at least one value mapping before saving!");
      return;
    }

    console.log("💾 Saving mappings temporarily:", mappings);

    // ✅ Update target fields state
    const updatedTargetFields = targetFields.map(field => {
      if (field.id === targetField.id && field.mappedTo) {
        return {
          ...field,
          valueMappings: mappings,
          tempMappings: true
        };
      }
      return field;
    });

    if (typeof setTargetFields === 'function') {
      setTargetFields(updatedTargetFields);
      console.log("✅ Updated targetFields state");
    }

    if (typeof setValueMappingsTemp === 'function') {
      setValueMappingsTemp(prev => [
        ...prev.filter(entry => entry.targetField.id !== targetField.id),
        {
          sourceField,
          targetField,
          mappings
        }
      ]);
    }

    setTempSaved(true);
    toast.success("Mappings saved temporarily in memory!");
  };

  const deleteMappingPair = (sourceVal) => {
    const newMappings = { ...mappings };
    delete newMappings[sourceVal];
    setMappings(newMappings);
    setTempSaved(false); // Mark as unsaved since user made changes
  };

  // ✅ Helper function to find target value display info
  const getTargetValueDisplay = (targetValue) => {
    if (typeof targetValue === 'object' && targetValue.label_value) {
      return targetValue.label_value;
    }

    // If targetValue is just a string/number, try to find the full object
    const fullTargetValue = targetValues.find(tv =>
      tv.value === targetValue || tv.label_value === targetValue
    );

    return fullTargetValue ? fullTargetValue.label_value : targetValue;
  };

  // ✅ Helper to get mapping statistics
  const getMappingStats = () => {
    const totalMappings = Object.keys(mappings).length;
    const sourceCount = sourceValues.length;
    const targetCount = targetValues.length;
    return { totalMappings, sourceCount, targetCount };
  };

  const stats = getMappingStats();

  return ReactDOM.createPortal(
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-5xl w-full mx-4 max-h-[85vh] overflow-y-auto">
        
        {/* ✅ Enhanced Header with Link Name Display */}
        <div className="flex justify-between items-start mb-4">
          <div className="flex-1">
            <h3 className="text-xl font-semibold text-gray-800 mb-2">Value Mapping Configuration</h3>
            
            {/* ✅ Link Name Display */}
            {linkName && (
              <div className="mb-3 p-3 bg-blue-50 border-l-4 border-blue-400 rounded-md">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
                  <span className="text-blue-800 font-medium text-sm">
                    Configuration: <span className="font-bold">{linkName}</span>
                  </span>
                </div>
              </div>
            )}

            {/* ✅ Field Mapping Info */}
            <div className="text-sm text-gray-600 mb-2">
              <span className="font-medium text-blue-600">{sourceField.label}</span>
              <span className="mx-2">→</span>
              <span className="font-medium text-green-600">{targetField.label}</span>
            </div>

            {/* ✅ Mapping Statistics */}
            <div className="text-xs text-gray-500">
              {stats.totalMappings} mappings created | {stats.sourceCount} source values | {stats.targetCount} target values
            </div>
          </div>
          
          <CloseButton onClick={onClose} />
        </div>

        {/* ✅ Enhanced status indicator */}
        {tempSaved && (
          <div className="mb-4 p-3 bg-gradient-to-r from-yellow-50 to-yellow-100 border border-yellow-300 rounded-lg">
            <div className="flex items-center">
              <div className="w-2 h-2 bg-yellow-500 rounded-full mr-3 animate-pulse"></div>
              <div className="flex-1">
                <span className="text-yellow-800 text-sm font-medium">
                  {isLoadedFromDB
                    ? "✅ Loaded from saved configuration - mappings are active and ready to use"
                    : "💾 Mappings saved temporarily in memory - remember to save your configuration"
                  }
                </span>
              </div>
            </div>
          </div>
        )}

        {/* ✅ Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* ✅ ALM Source Side */}
          <div className="bg-blue-50 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-semibold text-blue-700 flex items-center">
                <span className="w-3 h-3 bg-blue-500 rounded-full mr-2"></span>
                ALM Field: {sourceField.label}
              </h4>
              <span className="text-xs bg-blue-200 text-blue-700 px-2 py-1 rounded">
                {sourceValues.length} values
              </span>
            </div>
            
            {loadingSource ? (
              <div className="flex justify-center items-center py-8">
                <LoadingSpinner />
                <span className="ml-2 text-sm text-gray-600">Loading source values...</span>
              </div>
            ) : sourceValues.length > 0 ? (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {sourceValues.map((value, idx) => {
                  const isMapped = mappings.hasOwnProperty(value.value);
                  const isSelected = selectedSource?.value === value.value;
                  
                  return (
                    <div
                      key={`source-${idx}-${value.value}`}
                      className={`p-3 border rounded-lg cursor-pointer transition-all duration-200 ${
                        isSelected
                          ? "bg-blue-200 border-blue-500 shadow-md transform scale-[1.02]"
                          : isMapped
                          ? "bg-blue-100 border-blue-300 opacity-75"
                          : "bg-white hover:bg-blue-100 border-gray-200 hover:border-blue-300"
                      }`}
                      onClick={() => handleSourceSelect(value)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="font-medium text-sm text-gray-800">{value.value}</div>
                          <div className="text-xs text-gray-500">ID: {value.id}</div>
                        </div>
                        {isMapped && (
                          <div className="w-2 h-2 bg-green-500 rounded-full ml-2" title="Already mapped"></div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center text-gray-500 italic p-8 border-2 border-dashed border-gray-200 rounded-lg">
                <div className="text-2xl mb-2">📝</div>
                <div>No source values available</div>
              </div>
            )}
          </div>

          {/* ✅ qTest Target Side */}
          <div className="bg-green-50 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-semibold text-green-700 flex items-center">
                <span className="w-3 h-3 bg-green-500 rounded-full mr-2"></span>
                qTest Field: {targetField.label}
              </h4>
              <span className="text-xs bg-green-200 text-green-700 px-2 py-1 rounded">
                {targetValues.length} values
              </span>
            </div>
            
            {targetValues.length > 0 ? (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {targetValues.map((value, idx) => {
                  const isSelected = selectedTarget?.value === value.value;
                  const isUsedInMapping = Object.values(mappings).some(
                    mapping => mapping.value === value.value
                  );
                  
                  return (
                    <div
                      key={`target-${idx}-${value.value}`}
                      className={`p-3 border rounded-lg cursor-pointer transition-all duration-200 ${
                        isSelected
                          ? "bg-green-200 border-green-500 shadow-md transform scale-[1.02]"
                          : isUsedInMapping
                          ? "bg-green-100 border-green-300 opacity-75"
                          : "bg-white hover:bg-green-100 border-gray-200 hover:border-green-300"
                      }`}
                      onClick={() => handleTargetSelect(value)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="font-medium text-sm text-gray-800">{value.label_value}</div>
                          <div className="text-xs text-gray-500">Value: {value.value}</div>
                        </div>
                        {isUsedInMapping && (
                          <div className="w-2 h-2 bg-blue-500 rounded-full ml-2" title="Used in mapping"></div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center text-gray-500 italic p-8 border-2 border-dashed border-gray-200 rounded-lg">
                <div className="text-2xl mb-2">🎯</div>
                <div>No target values available</div>
              </div>
            )}
          </div>
        </div>

        {/* ✅ Enhanced Mappings Section */}
        <div className="mt-6 pt-4 border-t-2 border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-semibold text-gray-800 flex items-center">
              <span className="w-3 h-3 bg-purple-500 rounded-full mr-2"></span>
              Created Value Mappings
            </h4>
            <span className="text-xs bg-purple-100 text-purple-700 px-3 py-1 rounded-full">
              {Object.keys(mappings).length} mappings
            </span>
          </div>
          
          <div className="text-sm text-gray-600 mb-3 p-2 bg-gray-50 rounded border-l-4 border-gray-400">
            💡 <strong>Instructions:</strong> Click on a source value (blue), then click on a target value (green) to create a mapping
          </div>

          {Object.keys(mappings).length > 0 ? (
            <div className="space-y-3">
              {Object.entries(mappings).map(([sourceVal, targetVal], index) => (
                <div key={`mapping-${index}-${sourceVal}`} 
                     className="flex items-center gap-3 p-3 bg-gradient-to-r from-blue-50 to-green-50 rounded-lg border border-gray-200 hover:shadow-md transition-shadow">
                  
                  <div className="flex-1 flex items-center gap-3">
                    <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                      {sourceVal}
                    </span>
                    
                    <div className="flex items-center">
                      <div className="w-8 h-0.5 bg-gray-400"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full mx-1"></div>
                      <div className="w-8 h-0.5 bg-gray-400"></div>
                    </div>
                    
                    <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                      {getTargetValueDisplay(targetVal)}
                    </span>
                  </div>
                  
                  <button
                    onClick={() => deleteMappingPair(sourceVal)}
                    className="w-8 h-8 flex items-center justify-center text-red-500 hover:text-red-700 hover:bg-red-50 rounded-full transition-colors"
                    title="Remove this mapping"
                  >
                    ✖
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center text-gray-500 p-8 border-2 border-dashed border-gray-200 rounded-lg bg-gray-50">
              <div className="text-3xl mb-3">🔗</div>
              <div className="text-sm">
                <div className="font-medium mb-1">No mappings created yet</div>
                <div>Start by clicking a source value, then click a target value to create your first mapping</div>
              </div>
            </div>
          )}
        </div>

        {/* ✅ Enhanced Action Buttons */}
        <div className="flex gap-3 mt-6 pt-4 border-t">
          <button
            onClick={onClose}
            className="flex-1 bg-gray-500 text-white py-3 px-4 rounded-lg hover:bg-gray-600 transition-colors font-medium"
          >
            Close
          </button>
          <button
            onClick={saveTemporarily}
            className={`flex-1 py-3 px-4 rounded-lg font-medium transition-colors ${
              Object.keys(mappings).length === 0
                ? "bg-gray-300 text-gray-500 cursor-not-allowed"
                : "bg-yellow-500 text-white hover:bg-yellow-600"
            }`}
            disabled={Object.keys(mappings).length === 0}
          >
            {tempSaved ? "Update Mappings" : "Save"}
          </button>
        </div>
      </div>
    </div>,
    document.getElementById("portal-root")
  );
};

const CloseButton = ({ onClick }) => (
  <button onClick={onClick} className="text-gray-500 hover:text-gray-700">
    ✖
  </button>
);

const ExecutionTestInstance = () => {

  const [valueMappingsTemp, setValueMappingsTemp] = useState([]);
  
  const [almListValue, setAlmListValue] = useState([]);
  const [sourceFields, setSourceFields] = useState([]);
  const [targetFields, setTargetFields] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [tableName, setTableName] = useState("");
  const [isLoadConfigModalOpen, setIsLoadConfigModalOpen] = useState(false);
  const [savedMappings, setSavedMappings] = useState([]);
  const [selectedMapping, setSelectedMapping] = useState("");
  const [currentLoadedMapping, setCurrentLoadedMapping] = useState("");
  const [almLoading, setAlmLoading] = useState(false);
  const [qtestLoading, setQtestLoading] = useState(false);
  const [almResult, setAlmResult] = useState(null);
  const [qtestResult, setQtestResult] = useState(null);
  const [almError, setAlmError] = useState(null);
  const [qtestError, setQtestError] = useState(null);
  const [isVisible, setIsVisible] = useState(true);
  const [successfulMapping, setSuccessfulMapping] = useState(0);
  const [isListConfigModalOpen, setIsListConfigModalOpen] = useState(false);



  const [pollingInterval, setPollingInterval] = useState(null);
  const [currentProcessingIndex, setCurrentProcessingIndex] = useState(0);

  // Updated state for settings
  const [almSettings, setAlmSettings] = useState({ domain: "", project: "" });
  const [qtestSettings, setQtestSettings] = useState({ projectId: "" });
  const [linkName, setLinkName] = useState({ linkname: "" });


    // Updated fetchAlmSettings to get only current settings
    const fetchAlmSettings = async () => {
      setAlmLoading(true);
      try {
        const res = await axios.get("http://localhost:5550/api/settings/settings");
        console.log("Fetched ALM Settings:", res.data);
  
        let currentSettings = null;
  
        // Find the current settings from the array
        if (Array.isArray(res.data)) {
          currentSettings = res.data.find(setting =>
            setting.is_current === 1 ||
            setting.is_current === true ||
            setting.is_current === "1"
          );
        } else if (res.data && (res.data.is_current === 1 || res.data.is_current === true)) {
          currentSettings = res.data;
        }
  
        if (currentSettings) {
          setAlmSettings({
            domain: currentSettings.domain || "",
            project: currentSettings.project || "",
          });
        } else {
          // No current settings found
          setAlmSettings({ domain: "", project: "" });
          console.log("No current ALM settings found");
        }
      } catch (err) {
        console.error("ALM Fetch error:", err);
        setStatusMessage({
          type: "error",
          message: "Failed to fetch ALM settings",
        });
        setAlmSettings({ domain: "", project: "" });
      } finally {
        setAlmLoading(false);
      }
    };
  
    // Updated fetchQtestSettings to get only current settings
    const fetchQtestSettings = async () => {
      setQtestLoading(true);
      try {
        const res = await axios.get("http://localhost:5550/api/settings/settings");
        console.log("Fetched qTest Settings:", res.data);
  
        let currentSettings = null;
  
        // Find the current settings from the array
        if (Array.isArray(res.data)) {
          currentSettings = res.data.find(setting =>
            setting.is_current === 1 ||
            setting.is_current === true ||
            setting.is_current === "1"
          );
        } else if (res.data && (res.data.is_current === 1 || res.data.is_current === true)) {
          currentSettings = res.data;
        }
  
        if (currentSettings) {
          setQtestSettings({
            projectId: currentSettings.projectId || "",
          });
        } else {
          // No current settings found
          setQtestSettings({ projectId: "" });
          console.log("No current qTest settings found");
        }
      } catch (err) {
        console.error("qTest Fetch error:", err);
        setStatusMessage({
          type: "error",
          message: "Failed to fetch qTest settings",
        });
        setQtestSettings({ projectId: "" });
      } finally {
        setQtestLoading(false);
      }
    };
  

  // ✅ Fixed: Combined function to fetch both settings in one call
  const fetchCurrentSettings = async () => {
    setAlmLoading(true);
    setQtestLoading(true);

    try {
      const res = await axios.get("http://localhost:5550/api/settings/settings");
      console.log("Fetched Current Settings:", res.data);

      let currentSettings = null;

      if (Array.isArray(res.data)) {
        currentSettings = res.data.find(setting =>
          setting.is_current === 1 ||
          setting.is_current === true ||
          setting.is_current === "1"
        );
      } else if (res.data && (res.data.is_current === 1 || res.data.is_current === true)) {
        currentSettings = res.data;
      }

      if (currentSettings) {
        setAlmSettings({
          domain: currentSettings.domain || "",
          project: currentSettings.project || "",
        });

        setQtestSettings({
          projectId: currentSettings.projectId || "",
        });

        setLinkName({
          linkname: currentSettings.linkname || currentSettings.link_name || "",
        });

        console.log("Current settings loaded:", currentSettings.link_name);
      } else {
        setAlmSettings({ domain: "", project: "" });
        setQtestSettings({ projectId: "" });
        setLinkName({ linkname: "" });

        setStatusMessage({
          type: "warning",
          message: "No current configuration found. Please set a configuration as current in Settings.",
        });
      }
    } catch (err) {
      console.error("Settings Fetch error:", err);
      setStatusMessage({
        type: "error",
        message: "Failed to fetch current settings",
      });
      setAlmSettings({ domain: "", project: "" });
      setQtestSettings({ projectId: "" });
      setLinkName({ linkname: "" });
    } finally {
      setAlmLoading(false);
      setQtestLoading(false);
    }
  };

  // ✅ Fixed: Only use one useEffect for fetching settings

   // Option 1: Separate calls
    useEffect(() => {
      fetchAlmSettings();
      fetchQtestSettings();
    }, []);

  useEffect(() => {
    fetchCurrentSettings();
  }, []);

  const fetchAlmListValue = async () => {
    setIsLoading(true);
    try {
      const responselist = await axios.get("http://localhost:5550/api/alm/get-almtestinstance-list-db");

      // More robust data extraction
      const responseData = responselist.data?.data || responselist.data || [];

      if (Array.isArray(responseData)) {
        setAlmListValue(
          responseData.map((field) => ({
            ...field,
            isMapped: false,
          }))
        );
        // toast.success("ALM Fields refreshed and loaded successfully!");
      } else {
        console.error("Expected array but got:", responseData);
        toast.error("Invalid ALM list response format");
      }
    } catch (error) {
      toast.error("Failed to refresh and load ALM fields");
      console.error("Error fetching ALM fields:", error);
    } finally {
      setIsLoading(false);
    }
  };
  const fetchAlmFields = async () => {
    setIsLoading(true);
    try {
      const response = await axios.get("http://localhost:5550/api/alm/get-testinstance");

      if (Array.isArray(response.data.data)) {
        setSourceFields(
          response.data.data.map((field) => ({
            ...field,
            isMapped: false,
          }))
        );
        // toast.success("ALM Fields loaded successfully!");
      } else {
        console.error("Expected array but got:", response.data);
        toast.error("Invalid ALM fields response format");
      }
    } catch (error) {
      toast.error("Failed to load ALM fields");
      console.error("Error fetching ALM fields:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFetchAlmData = async () => {
    try {
      setAlmLoading(true);
      setAlmError(null);
      setAlmResult(null);

      const response = await axios.get('http://localhost:5550/api/alm/testinstancefield');
      setAlmResult(response.data);
      toast.success(response.data.message || "ALM data fetched successfully!");
      console.log('ALM data fetched successfully:', response.data);

      try {
        const releasesResponse = await axios.get("http://localhost:5550/api/alm/listtestinstancevalue");
        console.log('Releases data fetched successfully:', releasesResponse.data);
      } catch (releaseErr) {
        console.warn('Could not fetch releases data:', releaseErr.message);
      }
      await fetchAlmFields();
      await fetchAlmListValue();
    } catch (err) {
      setAlmError(err.message || 'Failed to fetch ALM data');
      toast.error(err.message || 'Failed to fetch ALM data');
      console.error('Error fetching ALM data:', err);
    } finally {
      setAlmLoading(false);
    }
  };


  //===============qTest data============

  const fetchQTestFields = async () => {
    setIsLoading(true);
    try {
   
        const dataResponse = await axios.get("http://localhost:5550/api/qtest_testinstance_data");

        if (dataResponse.data && dataResponse.data.length > 0) {
          setTargetFields(
            dataResponse.data.map((field) => ({
              ...field,
              isMapped: false,
            }))
          );
          // toast.success(`Successfully loaded ${dataResponse.data.length} qTest fields!`);
        } else {
          toast.warn("No qTest data available after refresh.");
        }
     
    } catch (error) {
      console.error("Error refreshing/fetching qTest fields:", error);
      toast.error(error.response?.data?.error || "Failed to load qTest fields");
    } finally {
      setIsLoading(false);
    }
  };

  const handleFetchqTestData = async () => {
    try {
      setQtestLoading(true);
      setQtestError(null);
      setQtestResult(null);

      const response = await axios.get('http://localhost:5550/api/qtest/qtesttestinstancefield');
      setQtestResult(response.data);

      if (response.data.success === false) {
        toast.warn(response.data.message || "qTest API returned no data");
      } else {
        toast.success(response.data.message || "qTest data fetched successfully!");
      }

      await fetchQTestFields();
    } catch (err) {
      setQtestError(err.message || 'Failed to fetch qTest data');
      toast.error(err.response?.data?.error || err.message || 'Failed to fetch qTest data');
      console.error('Error fetching qTest data:', err);
    } finally {
      setQtestLoading(false);
    }
  };

  const fetchSavedMappings = async () => {
    try {
      setSelectedMapping("");

      const response = await axios.get("http://localhost:5550/api/fetch-alltestinstance-table-names");

      if (response.data && response.data.tables && response.data.tables.length > 0) {
        setSavedMappings(response.data.tables);
        // toast.success("Saved mappings loaded successfully");
      } else {
        setSavedMappings([]);
        toast.info("No saved mappings found");
      }
    } catch (error) {
      console.error("Error fetching saved mappings:", error);
      setSavedMappings([]);

      if (error.response && error.response.status !== 404) {
        toast.error("Failed to load saved mappings");
      } else {
        console.log("API endpoint not found, check your routes");
        toast.error("API endpoint not found, check server routes");
      }
    }
  };

  const handleDrop = (index, draggedField) => {
    if (targetFields.some((field) => field.mappedTo?.label === draggedField.label)) {
      toast.error("This ALM field is already mapped!");
      return;
    }
    if (targetFields[index].mappedTo) {
      toast.error("This qTest field is already mapped!");
      return;
    }

    const updatedTargetFields = [...targetFields];
    updatedTargetFields[index] = { ...updatedTargetFields[index], mappedTo: draggedField };
    setTargetFields(updatedTargetFields);

    const updatedSourceFields = sourceFields.map((field) =>
      field.label === draggedField.label ? { ...field, isMapped: true } : field
    );
    setSourceFields(updatedSourceFields);

    updateMappingCount(updatedTargetFields);
  };

  const handleUnmap = (field) => {
    const updatedTargetFields = targetFields.map((targetField) =>
      targetField.mappedTo?.label === field.label
        ? { ...targetField, mappedTo: null }
        : targetField
    );
    setTargetFields(updatedTargetFields);

    const updatedSourceFields = sourceFields.map((sourceField) =>
      sourceField.label === field.label
        ? { ...sourceField, isMapped: false }
        : sourceField
    );
    setSourceFields(updatedSourceFields);

    updateMappingCount(updatedTargetFields);
  };

  const updateMappingCount = (fields) => {
    const count = fields.filter(field => field.mappedTo).length;
    setSuccessfulMapping(count);
  };

  const saveToJson = async () => {
    const mappedData = targetFields
      .filter((field) => field.mappedTo)
      .map((field) => ({
        ep1_name: field.mappedTo.name || "",
        ep1_label: field.mappedTo.label || "",
        ep1_physical_name: field.mappedTo.physicalName || "",
        ep1_type: field.mappedTo.type || "",
        ep2_field_id: field.id ? field.id.toString() : "",
        ep2_label: field.label || "",
        ep2_type: field.attribute_type || "",
        artifact_type: "TestInstance"
      }));

    if (mappedData.length === 0) {
      toast.warn("No valid mappings to save!");
      return;
    }

    const autoTableName = `mapping_${new Date().toISOString().slice(0, 19).replace(/[:-]/g, '').replace('T', '_')}`;

    try {
      console.log("Sending mappings:", mappedData);

      const response = await axios.post("http://localhost:5550/api/mappingstestinstance", {
        mappings: mappedData,
        tableName: autoTableName
      }, {
        headers: { "Content-Type": "application/json" },
        timeout: 10000
      });

      toast.success(response.data.message || "Mappings saved successfully!");
      setCurrentLoadedMapping(autoTableName);
      setIsModalOpen(false);
      setTableName("");
      fetchSavedMappings();
      fetchAlmFields();
      fetchQTestFields();

    } catch (error) {
      console.error("Mapping save error:", error);
      if (error.response) {
        const errorMessage = error.response.data.message || error.response.data.error || `Error: ${error.response.status}`;
        toast.error(errorMessage);
      } else if (error.request) {
        toast.error("No response received from server. Please check your connection.");
      } else {
        toast.error("An unexpected error occurred while saving the mappings.");
      }
    }
  };


  const savePermanently = async () => {
    if (valueMappingsTemp.length === 0) {
      toast.info("No value mappings to save!");
      return;
    }

    const valueMappedData = [];

    valueMappingsTemp.forEach(({ sourceField, targetField, mappings }) => {
      Object.entries(mappings).forEach(([almValue, qTestValue]) => {
        valueMappedData.push({
          ep1_name: sourceField.name || "",
          ep1_label: sourceField.label || "",
          ep1_value: almValue,
          ep1_type: sourceField.type || "",
          ep2_field_id: targetField.id ? targetField.id.toString() : "",
          ep2_label: targetField.label || "",
          ep2_value: qTestValue.label_value,
          ep2_value_id: qTestValue.value,
          ep2_type: targetField.attribute_type || "",
          artifact_type: "TestInstance",
          value_mappings: JSON.stringify({ [almValue]: qTestValue })
        });
      });
    });

    try {
      const autoTableName = `mapping_${new Date().toISOString().slice(0, 19).replace(/[:-]/g, '').replace('T', '_')}`;

      const response = await axios.post("http://localhost:5550/api/testinstance-valuemappings", {
        mappings: valueMappedData,       // ✅ Corrected key
        tableName: autoTableName
      }, {
        headers: { "Content-Type": "application/json" },
        timeout: 10000
      });


      toast.success(response.data.message || "Value mappings saved permanently!");
      setCurrentLoadedMapping(autoTableName);
      setIsModalOpen(false);
      setTableName("");
      fetchSavedMappings();
      fetchAlmFields();
      fetchQTestFields();
    } catch (error) {
      console.error("Permanent mapping save error:", error);
      if (error.response) {
        toast.error(error.response.data.message || `Error: ${error.response.status}`);
      } else if (error.request) {
        toast.error("No response from server. Check connection.");
      } else {
        toast.error("Unexpected error while saving permanently.");
      }
    }
  };

const LoadConfigModal = () => {
    const [savedMappings, setSavedMappings] = useState([]);
    const [filteredMappings, setFilteredMappings] = useState([]);
    const [selectedMapping, setSelectedMapping] = useState("");
    const [selectedArtifactTypes, setSelectedArtifactTypes] = useState([]);
    const [availableArtifactTypes, setAvailableArtifactTypes] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    // Fetch saved mappings when the modal opens
    useEffect(() => {
      fetchSavedMappingsData();
    }, []);

    // Filter mappings when artifact type changes
    useEffect(() => {
      if (selectedMapping) {
        fetchArtifactTypesForSelectedMapping();
      }
    }, [selectedMapping]);

    // Reset artifact types when mapping changes
    useEffect(() => {
      setSelectedArtifactTypes([]);
    }, [selectedMapping]);

    const fetchSavedMappingsData = async () => {
      setLoading(true);
      setError(null);

      try {
        setSelectedMapping("");
        setSelectedArtifactTypes([]);

        const response = await axios.get("http://localhost:5550/api/fetch-alltestinstance-table-names");

        console.log("API Response:", response.data);

        if (response.data && response.data.tables && response.data.tables.length > 0) {
          console.log("Saved mappings found:", response.data.tables);

          const uniqueMappings = response.data.tables.filter((mapping, index, self) =>
            index === self.findIndex(m => m.tableName === mapping.tableName)
          );

          console.log("Unique mappings after deduplication:", uniqueMappings);
          setSavedMappings(uniqueMappings);
          setFilteredMappings(uniqueMappings);
        } else {
          console.log("No saved mappings in response:", response.data);
          setSavedMappings([]);
          setFilteredMappings([]);
          setAvailableArtifactTypes([]);
          toast.info("No saved mappings found in the database");
        }
      } catch (error) {
        console.error("Error fetching saved mappings:", error);

        if (error.response) {
          setError(`Server error: ${error.response.status} - ${error.response.data?.message || 'Unknown error'}`);
        } else if (error.request) {
          setError("Network error: Server not responding. Please check your connection.");
        } else {
          setError(`Error: ${error.message}`);
        }

        setSavedMappings([]);
        setFilteredMappings([]);
        setAvailableArtifactTypes([]);
        toast.error("Failed to load saved mappings");
      } finally {
        setLoading(false);
      }
    };

    const fetchArtifactTypesForSelectedMapping = async () => {
      if (!selectedMapping) {
        setAvailableArtifactTypes([]);
        return;
      }

      try {
        const response = await axios.get(`http://localhost:5550/api/mappingstestinstance/${selectedMapping}`);
        if (response.data && Array.isArray(response.data)) {
          const artifactTypesSet = new Set();

          response.data.forEach(mapping => {
            if (mapping.artifact_type && mapping.artifact_type.trim() !== '') {
              artifactTypesSet.add(mapping.artifact_type);
            }
          });

          const uniqueArtifactTypes = Array.from(artifactTypesSet).sort();
          setAvailableArtifactTypes(uniqueArtifactTypes);
          console.log(`Available artifact types for ${selectedMapping}:`, uniqueArtifactTypes);
        }
      } catch (error) {
        console.error("Error fetching artifact types for selected mapping:", error);
        setAvailableArtifactTypes([]);
      }
    };

    const handleArtifactTypeChange = (type) => {
      setSelectedArtifactTypes(prev => {
        if (prev.includes(type)) {
          return prev.filter(t => t !== type);
        } else {
          return [...prev, type];
        }
      });
    };

    const handleSelectAllArtifactTypes = () => {
      if (selectedArtifactTypes.length === availableArtifactTypes.length) {
        setSelectedArtifactTypes([]);
      } else {
        setSelectedArtifactTypes([...availableArtifactTypes]);
      }
    };

    const loadMappingConfig = async () => {
      if (!selectedMapping) {
        toast.error("Please select a mapping configuration");
        return;
      }

      try {
        setLoading(true);

        if (sourceFields.length === 0 || targetFields.length === 0) {
          toast.info("Loading fields first...");
          await Promise.all([fetchAlmFields(), fetchQTestFields()]);
        }

        const response = await axios.get(`http://localhost:5550/api/mappingstestinstance/${selectedMapping}`);

        if (response.data && Array.isArray(response.data)) {
          const mappings = response.data;
          console.log("🔍 Raw mappings from API:", mappings);

          // Filter mappings by selected artifact types if any are selected
          const filteredMappingsData = selectedArtifactTypes.length > 0
            ? mappings.filter(mapping => selectedArtifactTypes.includes(mapping.artifact_type))
            : mappings;

          console.log("🔍 Filtered mappings:", filteredMappingsData);

          const resetSourceFields = sourceFields.map(field => ({ ...field, isMapped: false }));
          const resetTargetFields = targetFields.map(field => ({
            ...field,
            mappedTo: null,
            valueMappings: null,
            tempMappings: false
          }));

          const updatedSourceFields = [...resetSourceFields];
          const updatedTargetFields = [...resetTargetFields];

          // ✅ Enhanced processing with proper value mapping loading
          for (const mapping of filteredMappingsData) {
            console.log("🔍 Processing mapping:", {
              ep1_label: mapping.ep1_label,
              ep2_label: mapping.ep2_label,
              value_mappings: mapping.value_mappings
            });

            const sourceIndex = updatedSourceFields.findIndex(field =>
              field.label === mapping.ep1_label
            );

            const targetIndex = updatedTargetFields.findIndex(field =>
              field.id?.toString() === mapping.ep2_field_id?.toString() ||
              field.label === mapping.ep2_label
            );

            if (sourceIndex !== -1 && targetIndex !== -1) {
              const sourceField = updatedSourceFields[sourceIndex];
              sourceField.isMapped = true;

              // ✅ Load list values for source field if it has listId
              if (sourceField.listId && !sourceField.listValues) {
                try {
                  console.log(`🔄 Loading list values for source field: ${sourceField.label} (listId: ${sourceField.listId})`);
                  const listResponse = await axios.get(
                    `http://localhost:5550/api/alm/testinstance-list-values/${sourceField.listId}`
                  );
                  sourceField.listValues = listResponse.data;
                  console.log(`✅ Successfully loaded ${listResponse.data.length} list values for: ${sourceField.label}`);
                } catch (error) {
                  console.warn(`❌ Failed to load list values for ${sourceField.label}:`, error);
                }
              } else if (sourceField.listValues) {
                console.log(`✅ Source field ${sourceField.label} already has list values loaded`);
              }

              const updatedTarget = {
                ...updatedTargetFields[targetIndex],
                mappedTo: sourceField,
              };

              // ✅ Process and restore value-level mappings if present
              if (mapping.value_mappings && mapping.value_mappings !== '{}' && mapping.value_mappings !== '' && mapping.value_mappings !== null) {
                try {
                  let parsedMappings;

                  if (typeof mapping.value_mappings === "string") {
                    parsedMappings = JSON.parse(mapping.value_mappings);
                  } else {
                    parsedMappings = mapping.value_mappings;
                  }

                  console.log("🔍 Parsed value mappings:", parsedMappings);

                  // ✅ Only set value mappings if they contain actual mappings
                  if (parsedMappings && Object.keys(parsedMappings).length > 0) {
                    updatedTarget.valueMappings = parsedMappings;
                    updatedTarget.tempMappings = true;

                    console.log(`✅ Restored ${Object.keys(parsedMappings).length} value mappings for ${updatedTarget.label}:`, parsedMappings);

                    // ✅ Update the temporary value mappings state for popup display
                    if (typeof setValueMappingsTemp === 'function') {
                      setValueMappingsTemp(prev => {
                        // Remove any existing entry for this target field
                        const filtered = prev.filter(entry => entry.targetField.id !== updatedTarget.id);
                        return [
                          ...filtered,
                          {
                            sourceField: sourceField,
                            targetField: updatedTarget,
                            mappings: parsedMappings
                          }
                        ];
                      });
                      console.log("✅ Updated valueMappingsTemp state");
                    }
                  } else {
                    console.log("⚠️ No value mappings found or empty mappings object");
                  }
                } catch (err) {
                  console.warn("❌ Failed to parse value mappings for", updatedTarget.label, ":", err);
                }
              } else {
                console.log("⚠️ No value mappings data found for", updatedTarget.label);
              }

              updatedTargetFields[targetIndex] = updatedTarget;
            } else {
              console.warn("⚠️ Could not find matching source or target field for mapping:", {
                ep1_label: mapping.ep1_label,
                ep2_label: mapping.ep2_label,
                sourceIndex,
                targetIndex
              });
            }
          }

          // ✅ Update the state with the new mappings
          setSourceFields(updatedSourceFields);
          setTargetFields(updatedTargetFields);

          // Set this as the current loaded mapping
          setCurrentLoadedMapping(selectedMapping);

          // Update the mapping count
          updateMappingCount(updatedTargetFields);

          // Close the modal
          setIsLoadConfigModalOpen(false);

          const typeInfo = selectedArtifactTypes.length > 0
            ? ` (${selectedArtifactTypes.join(', ')} types)`
            : '';

          // ✅ Enhanced success message with mapping details
          const valueMappingCount = updatedTargetFields.filter(field => field.valueMappings).length;
          const fieldMappingCount = updatedTargetFields.filter(field => field.mappedTo).length;

          let successMessage = `Mapping "${selectedMapping}"${typeInfo} loaded successfully!`;
          if (valueMappingCount > 0) {
            successMessage += ` Loaded ${fieldMappingCount} field mappings with ${valueMappingCount} value mappings.`;
          }

          toast.success(successMessage);
          console.log("✅ Configuration loaded successfully with value mappings");

          // Try to set the current table
          try {
            await axios.post("http://localhost:5550/api/set-current-table", {
              tableName: selectedMapping
            });
            console.log("✅ Current table updated successfully");
          } catch (setTableError) {
            console.warn("⚠️ Could not update current table:", setTableError.message);
          }
        } else {
          toast.error("Invalid mapping data received");
        }
      } catch (error) {
        console.error("❌ Error loading mapping:", error);
        toast.error(`Error loading mapping: ${error.message}`);
      } finally {
        setLoading(false);
      }
    };

    const hasMappings = Array.isArray(savedMappings) && savedMappings.length > 0;
    const hasArtifactTypes = Array.isArray(availableArtifactTypes) && availableArtifactTypes.length > 0 && selectedMapping;

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white p-6 rounded-lg shadow-xl w-96 max-h-[80vh] overflow-y-auto">
          
           <div className="flex justify-between items-center mb-4">
    <h2 className="text-xl font-bold">Load Configuration</h2>
    <button
      type="button"
      onClick={() => setIsLoadConfigModalOpen(false)}
      className="bg-gray-300 text-black p-2 rounded hover:bg-gray-400 transition-colors"
    >
      <IoCloseSharp />
    </button>
  </div>
          {loading ? (
            <div className="flex justify-center items-center py-4">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
              <span className="ml-2">Loading...</span>
            </div>
          ) : error ? (
            <div className="mb-4">
              <p className="text-red-500 text-sm">{error}</p>
              <button
                onClick={fetchSavedMappingsData}
                className="mt-2 bg-blue-500 text-white p-2 rounded w-full"
              >
                Retry
              </button>
            </div>
          ) : (
            <>
              {hasMappings ? (
                <>
                  <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Select Mapping Configuration:
                    </label>
                    <select
                      value={selectedMapping}
                      onChange={(e) => setSelectedMapping(e.target.value)}
                      className="w-full p-2 border rounded focus:outline-none focus:ring focus:border-blue-500"
                    >
                      <option value="">Select a saved mapping</option>
                      {savedMappings.map((mapping, index) => (
                        <option key={`${mapping.tableName}-${index}`} value={mapping.tableName}>
                          {mapping.tableName} {mapping.isCurrent ? "(Current)" : ""}
                        </option>
                      ))}
                    </select>
                  </div>

                  {hasArtifactTypes && (
                    <div className="mb-4">
                      <div className="flex justify-between items-center mb-2">
                        <label className="block text-sm font-medium text-gray-700">
                          Filter by Artifact Type:
                        </label>
                        <button
                          type="button"
                          onClick={handleSelectAllArtifactTypes}
                          className="text-xs text-blue-600 hover:text-blue-800 underline"
                        >
                          {selectedArtifactTypes.length === availableArtifactTypes.length ? 'Deselect All' : 'Select All'}
                        </button>
                      </div>
                      <div className="border rounded p-3 max-h-32 overflow-y-auto bg-gray-50">
                        {availableArtifactTypes.map((type, index) => (
                          <div key={`${type}-${index}`} className="flex items-center mb-2 last:mb-0">
                            <input
                              type="checkbox"
                              id={`artifact-type-${type}-${index}`}
                              checked={selectedArtifactTypes.includes(type)}
                              onChange={() => handleArtifactTypeChange(type)}
                              className="mr-2 h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                            />
                            <label
                              htmlFor={`artifact-type-${type}-${index}`}
                              className="text-sm text-gray-700 cursor-pointer flex-1"
                            >
                              {type}
                            </label>
                          </div>
                        ))}
                      </div>
                      {selectedArtifactTypes.length > 0 && (
                        <p className="text-xs text-gray-600 mt-1">
                          {selectedArtifactTypes.length} of {availableArtifactTypes.length} types selected
                        </p>
                      )}
                    </div>
                  )}

                  {selectedArtifactTypes.length > 0 && selectedMapping && (
                    <div className="mb-4 p-2 bg-blue-50 border border-blue-200 rounded">
                      <p className="text-sm text-blue-700">
                        <strong>Selected Configuration:</strong> {selectedMapping}
                      </p>
                      <p className="text-sm text-blue-700">
                        <strong>Selected Types:</strong> {selectedArtifactTypes.join(', ')}
                      </p>
                      {selectedArtifactTypes.includes('Release') && (
                        <p className="text-sm text-green-600 mt-1">
                          <strong>Note:</strong> Only release-specific fields will be displayed
                        </p>
                      )}
                    </div>
                  )}

                  <div className="flex justify-between">
                    <button
                      onClick={loadMappingConfig}
                      disabled={!selectedMapping}
                      className="bg-green-500 text-white p-2 rounded disabled:opacity-50"
                    >
                      Load Configuration
                    </button>
                  </div>
                </>
              ) : (
                <>
                  <p className="text-center mb-4 text-gray-600">
                    No saved mappings found in the database.
                  </p>
                  <div className="flex flex-col gap-2">
                    <button
                      onClick={fetchSavedMappingsData}
                      className="w-full bg-blue-500 text-white p-2 rounded"
                    >
                      Refresh
                    </button>
                    <button
                      onClick={() => setIsLoadConfigModalOpen(false)}
                      className="w-full bg-gray-300 text-black p-2 rounded"
                    >
                      Close
                    </button>
                  </div>
                </>
              )}
            </>
          )}
        </div>
      </div>
    );
};


  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.scrollY;
      if (scrollTop > 100) {
        setIsVisible(false);
      } else {
        setIsVisible(true);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);


  const fetchMigrationStatus = async () => {
    try {
      const response = await axios.get('http://localhost:5550/api/testinstanceupload/migrationtestinstance-status');

      if (response.data && response.data.counts) {
        setMigrationStats(response.data.counts);
        const { total, success, failed } = response.data.counts;
        setCurrentProcessingIndex(success + failed + 1);
      }

    } catch (err) {
      console.error('Error fetching migration status:', err);
      // Don't show toast for status fetch errors as they might be frequent
    }
  };

  useEffect(() => {
    return () => {
      if (pollingInterval) {
        clearInterval(pollingInterval);
      }
    };
  }, [pollingInterval]);

  const ListConfigModal = ({ setIsListConfigModalOpen }) => {
    const [selectedTargetField, setSelectedTargetField] = useState("");
    const [almLoading, setAlmLoading] = useState(false);
    const [sourceListFields, setSourceListFields] = useState([]);
    const [targetFields, setTargetFields] = useState([]);
    const [selectedAlmField, setSelectedAlmField] = useState(null);
    const [uploading, setUploading] = useState(false);
    const [uploadSuccess, setUploadSuccess] = useState(false);

    const updateMappingCount = (updatedTargetFields) => {
      const mappedCount = updatedTargetFields.filter(field => field.mappedTo).length;
    };

    const fetchAlmListFields = async () => {
      setAlmLoading(true);
      try {
        const response = await axios.get("http://localhost:5550/api/alm/get-testinstance");

        if (Array.isArray(response.data.data)) {
          setSourceListFields(
            response.data.data.map((field) => ({
              ...field,
              isMapped: false,
            }))
          );
          toast.success("ALM Fields loaded successfully!");
        } else {
          console.error("Expected array but got:", response.data);
          toast.error("Invalid ALM fields response format");
        }
      } catch (error) {
        toast.error("Failed to load ALM fields");
        console.error("Error fetching ALM fields:", error);
      } finally {
        setIsLoading(false);
      }
    };

    const handleMapFromList = (sourceField) => {
      if (!selectedTargetField) {
        toast.error("Please select a qTest field first");
        return;
      }

      if (sourceListFields.find(field => field.label === sourceField.label)?.isMapped) {
        toast.error("This ALM field is already mapped!");
        return;
      }

      const targetIndex = targetFields.findIndex(field => field.label === selectedTargetField);
      if (targetIndex === -1) {
        toast.error("Selected qTest field not found!");
        return;
      }

      if (targetFields[targetIndex].mappedTo) {
        toast.error("This qTest field is already mapped!");
        return;
      }

      const updatedTargetFields = [...targetFields];
      updatedTargetFields[targetIndex] = {
        ...updatedTargetFields[targetIndex],
        mappedTo: sourceField,
      };
      setTargetFields(updatedTargetFields);

      const updatedSourceListFields = sourceListFields.map((field) =>
        field.label === sourceField.label ? { ...field, isMapped: true } : field
      );
      setSourceListFields(updatedSourceListFields);

      updateMappingCount(updatedTargetFields);
      toast.success(`Mapped ${sourceField.label} to ${selectedTargetField}`);
    };

    const handleUnmap = (sourceField) => {
      const targetIndex = targetFields.findIndex(field => field.mappedTo?.label === sourceField.label);

      if (targetIndex !== -1) {
        const updatedTargetFields = [...targetFields];
        updatedTargetFields[targetIndex] = {
          ...updatedTargetFields[targetIndex],
          mappedTo: null
        };
        setTargetFields(updatedTargetFields);

        const updatedSourceListFields = sourceListFields.map((field) =>
          field.label === sourceField.label ? { ...field, isMapped: false } : field
        );
        setSourceListFields(updatedSourceListFields);

        updateMappingCount(updatedTargetFields);
        toast.info(`Unmapped ${sourceField.label}`);
      }
    };

    const handleCreateField = async (field) => {
      setUploading(true);
      setUploadSuccess(false);

      try {
        toast.info(`Creating field for: ${field.label}`);
        const createResponse = await axios.post('http://localhost:5550/api/alm/create-testinstance-field', {
          physicalName: field.physicalName
        });

        setSelectedAlmField(createResponse.data.data);
        toast.success(`JSON file created successfully for: ${field.label}`);

        const uploadResponse = await axios.post('http://localhost:5550/api/alm/upload-json-to-qtesttestinstance');
        setUploadSuccess(true);
        toast.success(`Field has been uploaded to qTest successfully!`);
        console.log("Upload response:", uploadResponse.data);

      } catch (error) {
        setUploadSuccess(false);
        if (error.response && error.response.data) {
          toast.error(`Error: ${error.response.data.error || 'Upload failed'}`);
        } else {
          toast.error(`Operation failed: ${error.message}`);
        }
        console.error("Error in create/upload process:", error);
      } finally {
        setUploading(false);
      }
    };

    const DisplaySelectedField = () => {
      if (!selectedAlmField) return null;

      return (
        <div className="mt-4 p-3 bg-blue-50 rounded-md">
          <h3 className="font-bold">Field Details:</h3>
          <p><span className="font-semibold">Label:</span> {selectedAlmField.label}</p>
          <p><span className="font-semibold">Data Type:</span> {selectedAlmField.data_type}</p>
          <p><span className="font-semibold">Required:</span> {selectedAlmField.required ? 'Yes' : 'No'}</p>
          <p><span className="font-semibold">Active:</span> {selectedAlmField.is_active ? 'Yes' : 'No'}</p>

          {uploadSuccess && (
            <div className="mt-2 p-2 bg-green-100 text-green-700 rounded">
              ✅ Successfully uploaded to qTest!
            </div>
          )}
        </div>
      );
    };

    const DraggableFieldWithCreate = ({ field, onUnmap }) => {
      return (
        <div className="flex items-center justify-between bg-white p-2 mb-2 rounded shadow">
          <div className="flex-1 truncate">
            {field.label} {field.isMapped && <span className="text-green-500">(Mapped)</span>}
          </div>
          <div className="flex space-x-2">
            {field.isMapped ? (
              <button
                onClick={() => onUnmap(field)}
                className="bg-red-500 hover:bg-red-700 text-white text-xs px-2 py-1 rounded"
              >
                Unmap
              </button>
            ) : (
              <button
                onClick={() => handleCreateField(field)}
                disabled={uploading}
                className={`${uploading ? "bg-gray-400" : "bg-green-500 hover:bg-green-700"
                  } text-white text-xs px-2 py-1 rounded flex items-center`}
              >
                {uploading ? (
                  <>

                    Processing...
                  </>
                ) : (
                  "Create"
                )}
              </button>
            )}
          </div>
        </div>
      );
    };

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 ">
        <div className="bg-white p-6 rounded-lg shadow-xl w-3/4 max-w-xl max-h-[80vh] overflow-y-auto">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">ALM Fields Configuration</h2>
            <button
              onClick={() => setIsListConfigModalOpen(false)}
              className="bg-red-500 text-white p-2 rounded-md"
            >
              <IoCloseSharp />
            </button>
          </div>

          <div className="mt-4">
            <button
              onClick={fetchAlmListFields}
              disabled={almLoading}
              className="bg-blue-500 hover:bg-blue-700 text-white py-1.5 px-4 rounded text-sm md:text-base w-full"
            >
              {almLoading ? (
                <>

                  Fetching...
                </>
              ) : (
                sourceListFields.length > 0 ? `ALM Fields Loaded: ${sourceListFields.length}` : "Load ALM Fields"
              )}
            </button>
          </div>

          <div className="bg-gray-200 shadow-md p-3 rounded w-full text-base font-semibold mt-4">
            <div className="max-h-[50vh] overflow-y-auto">
              {sourceListFields.length > 0 ? (
                sourceListFields.map((field) => (
                  <DraggableFieldWithCreate
                    key={field.id || field.physicalName}
                    field={field}
                    onUnmap={handleUnmap}
                  />
                ))
              ) : (
                <p className="text-gray-600 p-2">Click "Load ALM Fields" to begin.</p>
              )}
            </div>
          </div>

          {DisplaySelectedField()}
        </div>
      </div>
    );
  };

  return (
    <div>

      {/* Sidebar */}
      <Sidebar />
      {/* Topbar */}
      <Topbar />

      <DndProvider backend={HTML5Backend}>
        <div className="lg:mt-[60px] mt-[110px] lg:ml-[290px] space-y-6 p-4 lg:p-8 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
  {/* Header Section */}
  <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
    <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
      <div className="space-y-2">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
            </svg>
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Mapping : Test Runs</h1>
            
          </div>
        </div>
        <p className="text-slate-500 text-sm">Map ALM fields to qTest fields for seamless data synchronization</p>
      </div>
      
      <div className="flex flex-wrap gap-3">
        <button
          onClick={() => setIsLoadConfigModalOpen(true)}
          className="flex items-center gap-2 bg-white border border-slate-300 hover:border-slate-400 text-slate-700 px-4 py-2.5 rounded-lg transition-all hover:shadow-md"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10" />
          </svg>
          Load Preset
        </button>
        <button
          onClick={() => setIsListConfigModalOpen(true)}
          className="flex items-center gap-2 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white px-4 py-2.5 rounded-lg transition-all shadow-sm hover:shadow-md"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
          Create Custom Fields
        </button>
      </div>
    </div>

    {isListConfigModalOpen && (
      <div className="mt-6 p-4 bg-slate-50 rounded-lg border border-slate-200">
        <ListConfigModal setIsListConfigModalOpen={setIsListConfigModalOpen} />
      </div>
    )}
  </div>

  {/* Configuration Status Cards */}
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
    {(almSettings.domain || almSettings.project) && (
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
            <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
            </svg>
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-slate-900 mb-2">ALM Configuration</h3>
            <div className="space-y-1">
              <p className="text-sm text-slate-600">
                <span className="font-medium">Domain:</span> {almSettings.domain}
              </p>
              <p className="text-sm text-slate-600">
                <span className="font-medium">Project:</span> {almSettings.project}
              </p>
            </div>
          </div>
        </div>
      </div>
    )}

    {qtestSettings.projectId && (
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
            <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
            </svg>
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-slate-900 mb-2">qTest Configuration</h3>
            <p className="text-sm text-slate-600">
              <span className="font-medium">Project ID:</span> {qtestSettings.projectId}
            </p>
          </div>
        </div>
      </div>
    )}

    {linkName.linkname && (
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
            <svg className="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
            </svg>
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-slate-900 mb-2">Link Configuration</h3>
            <p className="text-sm text-slate-600">
              <span className="font-medium">Name:</span> {linkName.linkname}
            </p>
          </div>
        </div>
      </div>
    )}

    {!almSettings.domain && !almSettings.project && !qtestSettings.projectId && (
      <div className="col-span-full bg-white rounded-xl shadow-sm border border-amber-200 p-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center flex-shrink-0">
            <svg className="w-6 h-6 text-amber-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.732-.833-2.5 0L4.732 15.5c-.77.833.192 2.5 1.732 2.5z" />
            </svg>
          </div>
          <div>
            <h3 className="font-semibold text-slate-900 mb-1">Configuration Required</h3>
            <p className="text-slate-600">Please configure your ALM and qTest settings before proceeding with field mapping.</p>
          </div>
        </div>
      </div>
    )}
  </div>

  {/* Save Mapping Button */}
  <div className="flex justify-end">
    <button
      onClick={async () => {
        await saveToJson();
        await savePermanently();
      }}
      disabled={
        isLoading ||
        almLoading ||
        qtestLoading ||
        targetFields.filter(f => f.mappedTo).length === 0 ||
        targetFields.some(f => f.required === 1 && !f.mappedTo)
      }
      className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 disabled:from-slate-300 disabled:to-slate-400 text-white font-semibold py-3 px-6 rounded-lg shadow-sm hover:shadow-md transition-all duration-200 disabled:cursor-not-allowed"
    >
      <span className="flex items-center justify-center gap-2">
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3-3m0 0l-3 3m3-3v12" />
        </svg>
        Save Mapping ({successfulMapping})
        {targetFields.some(f => f.required === 1 && !f.mappedTo) && (
          <span className="text-xs bg-red-500 px-2 py-1 rounded-full ml-2">
            {targetFields.filter(f => f.required === 1 && !f.mappedTo).length} required
          </span>
        )}
      </span>
    </button>
  </div>

  {/* Field Mapping Grid */}
  <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
    {/* ALM Fields Section */}
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-6">
        <h2 className="text-xl font-semibold text-white flex items-center gap-3">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
          </svg>
          ALM Fields
          {sourceFields.length > 0 && (
            <span className="text-xs bg-blue-500 px-2 py-1 rounded-full">
              {sourceFields.length} fields
            </span>
          )}
        </h2>
      </div>

      <div className="p-6">
        <button
          onClick={() => {
            handleFetchAlmData()
          }}
          disabled={almLoading || isLoading}
          className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 disabled:from-slate-300 disabled:to-slate-400 text-white font-semibold py-3 px-6 rounded-lg shadow-sm hover:shadow-md transition-all duration-200 disabled:cursor-not-allowed mb-6"
        >
          {almLoading ? (
            <div className="flex items-center justify-center gap-3">
              <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent"></div>
              <span>Loading ALM Fields...</span>
            </div>
          ) : (
            <div className="flex items-center justify-center gap-2">
              {sourceFields.length > 0 ? (
                <>
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <span>Fields Loaded ({sourceFields.length})</span>
                </>
              ) : (
                <>
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                  </svg>
                  <span>Load ALM Fields</span>
                </>
              )}
            </div>
          )}
        </button>

        <div className="max-h-96 overflow-y-auto space-y-2 pr-2">
          {sourceFields.map((field) => (
            <DraggableField
              key={field.label}
              field={field}
              onUnmap={handleUnmap}
            />
          ))}
          {sourceFields.length === 0 && !almLoading && (
            <div className="text-center py-8 text-slate-500">
              <svg className="w-12 h-12 mx-auto mb-3 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
              </svg>
              <p>No ALM fields loaded</p>
              <p className="text-sm">Click "Load ALM Fields" to fetch available fields</p>
            </div>
          )}
        </div>
      </div>
    </div>

    {/* qTest Fields Section */}
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
      <div className="bg-gradient-to-r from-green-600 to-emerald-600 p-6">
        <h2 className="text-xl font-semibold text-white flex items-center gap-3">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
          </svg>
          qTest Fields
          {targetFields.length > 0 && (
            <div className="flex gap-2">
              <span className="text-xs bg-green-500 px-2 py-1 rounded-full">
                {targetFields.length} fields
              </span>
              {targetFields.filter(field => field.required === 1).length > 0 && (
                <span className="text-xs bg-red-500 px-2 py-1 rounded-full">
                  {targetFields.filter(field => field.required === 1).length} required
                </span>
              )}
            </div>
          )}
        </h2>
      </div>

      <div className="p-6">
        <button
          onClick={handleFetchqTestData}
          disabled={qtestLoading || isLoading}
          className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 disabled:from-slate-300 disabled:to-slate-400 text-white font-semibold py-3 px-6 rounded-lg shadow-sm hover:shadow-md transition-all duration-200 disabled:cursor-not-allowed mb-6"
        >
          {qtestLoading ? (
            <div className="flex items-center justify-center gap-3">
              <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent"></div>
              <span>Loading qTest Fields...</span>
            </div>
          ) : (
            <div className="flex items-center justify-center gap-2">
              {targetFields.length > 0 ? (
                <>
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <span>Fields Loaded ({targetFields.length})</span>
                </>
              ) : (
                <>
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                  </svg>
                  <span>Load qTest Fields</span>
                </>
              )}
            </div>
          )}
        </button>

        <div className="max-h-96 overflow-y-auto space-y-2 pr-2">
          {targetFields.map((field, index) => (
            <DroppableField
              key={field.label}
              field={field}
              index={index}
              handleDrop={handleDrop}
              targetFields={targetFields}
              setValueMappingsTemp={setValueMappingsTemp}
            />
          ))}
          {targetFields.length === 0 && !qtestLoading && (
            <div className="text-center py-8 text-slate-500">
              <svg className="w-12 h-12 mx-auto mb-3 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
              </svg>
              <p>No qTest fields loaded</p>
              <p className="text-sm">Click "Load qTest Fields" to fetch available fields</p>
            </div>
          )}
        </div>
      </div>
    </div>
  </div>
</div>

        {/* Modals */}
        {isModalOpen && <SaveMappingModal />}
        {isLoadConfigModalOpen && <LoadConfigModal />}
        <ToastContainer position="top-right" autoClose={3000} />
      </DndProvider>
    </div>
  );
};

export default ExecutionTestInstance;



