

import React, { useState, useEffect } from "react";
import {
  Menu as MenuIcon,
  Dashboard,
  ShoppingCart,
  BarChart,
  Description,
  Layers,
  ExpandMore,
  ExpandLess
} from "@mui/icons-material";
import { useNavigate, useLocation } from "react-router-dom";
import { FaUserCircle } from "react-icons/fa";

const NAVIGATION = [
  {
    segment: "almToQtest",
    title: "ALM to qTest",
    icon: <Dashboard />,
    children: [
      {
        segment: "testplan",
        title: "Test Plan",
        icon: <BarChart />,
        children: [
          { segment: "release", title: "Release", icon: <Description />, hasApiCalls: true },
          // { segment: "build", title: "Build", icon: <Description />, hasApiCalls: true },
        ],
      },
      {
        segment: "requirements",
        title: "Requirements",
        icon: <Layers />,
        children: [
          // { segment: "modules", title: "Modules", icon: <Description />, hasApiCalls: true },
          { segment: "requirement", title: "Requirement", icon: <Description />, hasApiCalls: true },
        ],
      },
      {
        segment: "testdesign",
        title: "Test Design",
        icon: <BarChart />,
        children: [
          // { segment: "test-case-modules", title: "Test Case Modules", icon: <Description />, hasApiCalls: true },
          { segment: "test-case", title: "Test Case", icon: <Description />, hasApiCalls: true },
        ],
      },
      {
        segment: "testExecution",
        title: "Test Execution",
        icon: <BarChart />,
        children: [
          { segment: "test-suite", title: "Test Suite", icon: <Description />, hasApiCalls: true },
          { segment: "test-run", title: "Test Run", icon: <Description />, hasApiCalls: true },
        ],
      },
      {
        segment: "dashboarddefects",
        title: "Defects",
        icon: <ShoppingCart />,
        hasApiCalls: true
      },
    ],
  },
  {
    segment: "Users",
    title: "User Migration",
    icon: <FaUserCircle />,
    hasApiCalls: true
  },
  {
    segment: "migrate",
    title: "Migrate",
    icon: <BarChart />,
    hasApiCalls: true
  },
  {
    segment: "reporting",
    title: "Reporting",
    icon: <Layers />,
    hasApiCalls: true
  },
  {
  segment: "link",
  title: "Link",
  icon: <BarChart />,
  hasApiCalls: false
}
];

// Props interface for the Sidebar component
const Sidebar = ({ onApiCall }) => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [openDropdown, setOpenDropdown] = useState({});
  const [userData, setUserData] = useState({ userName: "", Email: "" });
  const [activePath, setActivePath] = useState("");

  const navigate = useNavigate();
  const location = useLocation();

  // Function to trigger API calls through props - FORCE CALL EVERY TIME
  const handleApiCalls = async (segment) => {
    if (onApiCall && typeof onApiCall === 'function') {
      console.log(`Triggering API calls for: ${segment}`);
      try {
        // Force API call regardless of current state
        await onApiCall(segment, true); // Pass true to force the call
      } catch (error) {
        console.error('Error in API calls:', error);
      }
    }
  };

  // Function to find a menu item by path
  const findMenuItemByPath = (path) => {
    const cleanPath = path.startsWith('/') ? path.substring(1) : path;
    let results = { item: null, parent: null, grandparent: null };

    for (const item of NAVIGATION) {
      if (item.segment === cleanPath) {
        results.item = item;
        return results;
      }

      if (item.children) {
        for (const child of item.children) {
          if (child.segment === cleanPath) {
            results.item = child;
            results.parent = item;
            return results;
          }

          if (child.children) {
            for (const grandchild of child.children) {
              if (grandchild.segment === cleanPath) {
                results.item = grandchild;
                results.parent = child;
                results.grandparent = item;
                return results;
              }
            }
          }
        }
      }
    }

    return results;
  };

  // Set active path when location changes
  useEffect(() => {
    setActivePath(location.pathname.startsWith('/') ? location.pathname.substring(1) : location.pathname);
  }, [location.pathname]);

  // Load user data on component mount
  useEffect(() => {
    const user = localStorage.getItem("user");
    if (user) {
      const parsedUser = JSON.parse(user);
      setUserData({
        userName: parsedUser.userName || "",
        Email: parsedUser.Email || "",
      });
    } else {
      navigate("/");
    }
  }, [navigate]);

  // Load and set open dropdown states from localStorage
  useEffect(() => {
    const storedOpenDropdowns = localStorage.getItem("openDropdowns");
    if (storedOpenDropdowns) {
      try {
        setOpenDropdown(JSON.parse(storedOpenDropdowns));
      } catch (error) {
        console.error("Error parsing stored dropdowns:", error);
        localStorage.removeItem("openDropdowns");
      }
    }
  }, []);

  // Auto-expand dropdowns based on current path
  useEffect(() => {
    const currentPath = location.pathname;
    const { parent, grandparent } = findMenuItemByPath(currentPath.startsWith('/') ? currentPath.substring(1) : currentPath);

    if (parent || grandparent) {
      const newState = { ...openDropdown };
      if (parent) newState[parent.segment] = true;
      if (grandparent) newState[grandparent.segment] = true;

      localStorage.setItem("openDropdowns", JSON.stringify(newState));
      setOpenDropdown(newState);
    }
  }, [location.pathname]);

  const handleToggleDropdown = (segment) => {
    const newState = {
      ...openDropdown,
      [segment]: !openDropdown[segment]
    };

    localStorage.setItem("openDropdowns", JSON.stringify(newState));
    setOpenDropdown(newState);
  };


const handleNavigation = async (path, hasApiCalls = true) => {
  console.log(` hasApiCalls: ${hasApiCalls} - Navigating to ${path} `);

  try {
    if (hasApiCalls) {
      console.log(`Triggering API calls for ${path}...`);
        handleApiCalls(path);
      console.log(`API calls completed for ${path}`);
    }
    
    // Navigate after API call completes (or immediately if no API calls)
    navigate(`/${path}`);
    setActivePath(path);
    console.log(`Navigation completed to ${path}`);
    
  } catch (error) {
    console.error('API call failed:', error);
    // Still navigate even if API call fails (optional - you can remove this if you don't want navigation on API failure)
    navigate(`/${path}`);
    setActivePath(path);
  }
};

  const isActive = (segment) => {
    return activePath === segment;
  };

  const isInActivePath = (segment) => {
    const { item, parent, grandparent } = findMenuItemByPath(activePath);
    return segment === activePath ||
      (parent && parent.segment === segment) ||
      (grandparent && grandparent.segment === segment);
  };

  return (
    <div className="flex">
      {/* Sidebar */}
      <div
        className={`fixed top-0 left-0 z-40 h-screen w-72 bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 text-white transition-transform duration-300 ease-in-out backdrop-blur-sm border-r border-slate-700/50
        ${mobileOpen ? "translate-x-0" : "-translate-x-full"} sm:translate-x-0 shadow-2xl`}
      >
        {/* Sidebar Background Overlay */}
        {/* <div className="absolute inset-0 bg-gradient-to-br from-blue-900/5 via-transparent to-purple-900/5 pointer-events-none "></div> */}


        {/* User Info */}
        <div className="relative px-6 py-4 border-b border-slate-700/30 lg:mt-20">
          <div className="flex items-center space-x-4 p-4 bg-gradient-to-r from-slate-800/40 to-slate-700/40 rounded-xl backdrop-blur-sm border border-slate-600/30 shadow-lg">
            <div className="relative">
              <FaUserCircle size={40} className="text-slate-300" />
              <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-slate-800 shadow-sm"></div>
            </div>
            <div className="text-left flex-1 min-w-0">
              <p className="text-sm font-semibold text-white truncate">{userData.userName}</p>
              <p className="text-xs text-slate-400 truncate">{userData.Email}</p>
            </div>
          </div>
        </div>

        {/* Navigation Menu */}
        <div className="relative px-4 py-4 overflow-y-auto h-[calc(100vh-200px)] scrollbar-thin scrollbar-track-slate-800 scrollbar-thumb-slate-600">
          <ul className="space-y-2">
            {NAVIGATION.map((item) => (
              <li key={item.segment}>
                <div
                  className={`group flex items-center justify-between p-3 rounded-xl cursor-pointer transition-all duration-300 ease-in-out relative overflow-hidden
                  ${isInActivePath(item.segment)
                      ? "bg-gradient-to-r from-blue-600/80 to-purple-600/80 text-white shadow-lg shadow-blue-500/25 border border-blue-500/30"
                      : "hover:bg-gradient-to-r hover:from-slate-700/60 hover:to-slate-600/60 hover:shadow-lg hover:shadow-slate-900/20 border border-transparent hover:border-slate-600/30"
                    }`}
                  onClick={() => {
                    if (!item.children) {
                      handleNavigation(item.segment, item.hasApiCalls);
                    } else {
                      handleToggleDropdown(item.segment);
                    }
                  }}
                >
                  {/* Active indicator */}
                  {isInActivePath(item.segment) && (
                    <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-blue-400 to-purple-400 rounded-r-full"></div>
                  )}

                  <div className="flex items-center space-x-3 relative z-10">
                    <div className={`p-2 rounded-lg transition-all duration-300 ${isInActivePath(item.segment)
                        ? "bg-white/20 text-white shadow-sm"
                        : "bg-slate-700/50 text-slate-300 group-hover:bg-slate-600/50 group-hover:text-white"
                      }`}>
                      {item.icon}
                    </div>
                    <span className={`font-medium transition-colors duration-300 ${isInActivePath(item.segment) ? "text-white" : "text-slate-200 group-hover:text-white"
                      }`}>
                      {item.title}
                    </span>
                  </div>

                  {item.children && (
                    <div className={`p-1 rounded-lg transition-all duration-300 ${isInActivePath(item.segment) ? "bg-white/20" : "bg-slate-700/50 group-hover:bg-slate-600/50"
                      }`}>
                      {openDropdown[item.segment] ? <ExpandLess className="text-sm" /> : <ExpandMore className="text-sm" />}
                    </div>
                  )}
                </div>

                {/* First-Level Dropdown */}
                {item.children && openDropdown[item.segment] && (
                  <div className="mt-2 ml-4 space-y-1 animate-in slide-in-from-top-2 duration-300">
                    {item.children.map((child) => (
                      <div key={child.segment}>
                        <div
                          className={`group flex items-center justify-between p-2.5 rounded-lg cursor-pointer transition-all duration-300 border
                          ${isInActivePath(child.segment)
                              ? "bg-gradient-to-r from-blue-500/60 to-purple-500/60 text-white shadow-md border-blue-400/30"
                              : "bg-slate-800/40 hover:bg-slate-700/60 text-slate-300 hover:text-white border-slate-600/20 hover:border-slate-500/40"
                            }`}
                          onClick={() => {
                            if (!child.children) {
                              handleNavigation(child.segment, child.hasApiCalls);
                            } else {
                              handleToggleDropdown(child.segment);
                            }
                          }}
                        >
                          <div className="flex items-center space-x-3">
                            <div className={`p-1.5 rounded-md transition-all duration-300 ${isInActivePath(child.segment)
                                ? "bg-white/20 text-white"
                                : "bg-slate-600/30 text-slate-400 group-hover:bg-slate-500/40 group-hover:text-white"
                              }`}>
                              {child.icon}
                            </div>
                            <span className="text-sm font-medium">{child.title}</span>
                          </div>
                          {child.children && (
                            <div className={`p-1 rounded transition-all duration-300 ${isInActivePath(child.segment) ? "bg-white/20" : "bg-slate-600/30 group-hover:bg-slate-500/40"
                              }`}>
                              {openDropdown[child.segment] ? <ExpandLess className="text-xs" /> : <ExpandMore className="text-xs" />}
                            </div>
                          )}
                        </div>

                        {/* Second-Level Dropdown */}
                        {child.children && openDropdown[child.segment] && (
                          <div className="mt-1 ml-6 space-y-1 animate-in slide-in-from-top-2 duration-300">
                            {child.children.map((subChild) => (
                              <div
                                key={subChild.segment}
                                className={`flex items-center space-x-3 p-2 rounded-lg cursor-pointer transition-all duration-300 border
                                ${isActive(subChild.segment)
                                    ? "bg-gradient-to-r from-blue-400/50 to-purple-400/50 text-white shadow-sm border-blue-300/30"
                                    : "bg-slate-800/30 hover:bg-slate-700/50 text-slate-400 hover:text-white border-slate-600/10 hover:border-slate-500/30"
                                  }`}
                                onClick={() => handleNavigation(subChild.segment, subChild.hasApiCalls)}
                              >
                                <div className={`p-1 rounded transition-all duration-300 ${isActive(subChild.segment)
                                    ? "bg-white/20 text-white"
                                    : "bg-slate-600/20 text-slate-500 hover:bg-slate-500/30 hover:text-white"
                                  }`}>
                                  {subChild.icon}
                                </div>
                                <span className="text-sm">{subChild.title}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Mobile Overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-sm sm:hidden z-30 transition-opacity duration-300"
          onClick={() => setMobileOpen(false)}
        ></div>
      )}

      {/* Enhanced Mobile Topbar */}
      <div className="fixed top-0 lg:hidden md:hidden xl:hidden 2xl:hidden left-0 w-full bg-white/95 backdrop-blur-md shadow-lg border-b border-slate-200/50 flex items-center justify-between px-6 py-4 z-50">
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-all duration-300 shadow-sm hover:shadow-md focus:outline-none focus:ring-2 focus:ring-blue-500/20"
        >
          <MenuIcon className="w-5 h-5" />
        </button>
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center shadow-sm">
            <Dashboard className="text-white text-sm" />
          </div>
          <h1 className="text-lg font-bold bg-gradient-to-r from-slate-700 to-slate-900 bg-clip-text text-transparent">
            M2M Portal
          </h1>
        </div>
        <div className="w-10"></div> {/* Spacer for centering */}
      </div>
    </div>
  );
};

export default Sidebar;