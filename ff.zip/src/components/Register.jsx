import React, { useState } from 'react';
import axios from 'axios';
import { Eye, EyeOff, User, Mail, Lock, ArrowRight, CheckCircle, AlertCircle, Loader, Database, Server, RefreshCw, GitBranch, Zap, Code } from 'lucide-react';
import logo from '../assets/image.jpg';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';

const Register = () => {
    const [registerData, setRegisterData] = useState({
        userName: '',
        Email: '',
        Password: '',
        confirmPassword: ''
    });
    const [showPassword, setShowPassword] = useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [errors, setErrors] = useState({});
    const [isSuccess, setIsSuccess] = useState(false);
    const navigate = useNavigate();

    // Validation functions
    const validateEmail = (email) => {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    };

    const validatePassword = (password) => {
        return password.length >= 8 && /(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(password);
    };

    const validateForm = () => {
        const newErrors = {};
        
        if (!registerData.userName.trim()) {
            newErrors.userName = 'Username is required';
        } else if (registerData.userName.length < 3) {
            newErrors.userName = 'Username must be at least 3 characters';
        }
        
        if (!registerData.Email.trim()) {
            newErrors.Email = 'Email is required';
        } else if (!validateEmail(registerData.Email)) {
            newErrors.Email = 'Please enter a valid email address';
        }
        
        if (!registerData.Password) {
            newErrors.Password = 'Password is required';
        } else if (!validatePassword(registerData.Password)) {
            newErrors.Password = 'Password must be 8+ characters with uppercase, lowercase, and number';
        }
        
        if (!registerData.confirmPassword) {
            newErrors.confirmPassword = 'Please confirm your password';
        } else if (registerData.Password !== registerData.confirmPassword) {
            newErrors.confirmPassword = 'Passwords do not match';
        }
        
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleRegisterChange = (e) => {
        const { name, value } = e.target;
        setRegisterData(prev => ({ ...prev, [name.trim()]: value }));
        
        // Clear error when user starts typing
        if (errors[name]) {
            setErrors(prev => ({ ...prev, [name]: '' }));
        }
    };

    const handleRegisterSubmit = async (e) => {
        e.preventDefault();
        
        if (!validateForm()) return;
        
        if (registerData.Password !== registerData.confirmPassword) {
            toast.error("Passwords do not match!");
            return;
        }
        
        setIsLoading(true);
        
        try {
            const response = await axios.post('https://newdatabackend.onrender.com/api/auth/register', {
                userName: registerData.userName,
                Email: registerData.Email,
                Password: registerData.Password
            });
            
            if (response && response.data) {
                console.log('Registration successful:', response.data);
                toast.success('Registration successful');
                setIsSuccess(true);
                setRegisterData({ userName: '', Email: '', Password: '', confirmPassword: '' });
                setTimeout(() => {
                    navigate('/'); 
                }, 2000);
            }
        } catch (error) {
            console.error('Error during registration:', error.response?.data);
            toast.error('Registration failed: ' + (error.response?.data?.msg || 'An error occurred'));
            setErrors({ submit: 'Registration failed. Please try again.' });
        } finally {
            setIsLoading(false);
        }
    };

    const getPasswordStrength = (password) => {
        if (password.length === 0) return { strength: 0, text: '' };
        if (password.length < 6) return { strength: 1, text: 'Weak', color: 'bg-red-500' };
        if (password.length < 8 || !validatePassword(password)) return { strength: 2, text: 'Medium', color: 'bg-yellow-500' };
        return { strength: 3, text: 'Strong', color: 'bg-green-500' };
    };

    const passwordStrength = getPasswordStrength(registerData.Password);

    if (isSuccess) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 relative overflow-hidden">
                {/* Migration Success Animation */}
                <div className="absolute inset-0">
                    <div className="absolute top-20 left-20 w-64 h-64 bg-green-400 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
                    <div className="absolute top-40 right-20 w-64 h-64 bg-emerald-400 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse delay-1000"></div>
                    
                    {/* Data flow lines */}
                    <div className="absolute top-1/4 left-0 w-full h-px bg-gradient-to-r from-transparent via-green-400 to-transparent opacity-30 animate-pulse"></div>
                    <div className="absolute top-3/4 left-0 w-full h-px bg-gradient-to-r from-transparent via-emerald-400 to-transparent opacity-30 animate-pulse delay-1000"></div>
                </div>

                <div className="relative bg-white/95 backdrop-blur-sm p-8 rounded-2xl shadow-2xl text-center max-w-sm w-full mx-4 border border-white/10">
                    <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                        <CheckCircle className="w-8 h-8 text-white animate-bounce" />
                    </div>
                    <h2 className="text-2xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent mb-2">Migration Complete! 🚀</h2>
                    <p className="text-gray-600 mb-6">Account created successfully. Redirecting to dashboard...</p>
                    <div className="w-8 h-8 border-4 border-green-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 relative overflow-hidden p-4">
            {/* Tech Migration Background Animation */}
            <div className="absolute inset-0">
                {/* Data flow visualization */}
                <div className="absolute top-20 left-20 w-80 h-80 bg-cyan-400 rounded-full mix-blend-multiply filter blur-xl opacity-15 animate-pulse"></div>
                <div className="absolute top-40 right-20 w-72 h-72 bg-blue-400 rounded-full mix-blend-multiply filter blur-xl opacity-15 animate-pulse delay-1000"></div>
                <div className="absolute -bottom-8 left-40 w-80 h-80 bg-indigo-400 rounded-full mix-blend-multiply filter blur-xl opacity-15 animate-pulse delay-2000"></div>
                
                {/* Tech elements floating */}
                <div className="absolute top-24 left-1/4 opacity-20 animate-float">
                    <Database className="w-6 h-6 text-cyan-300" />
                </div>
                <div className="absolute top-1/3 right-1/4 opacity-20 animate-float" style={{ animationDelay: '1s' }}>
                    <Server className="w-8 h-8 text-blue-300" />
                </div>
                <div className="absolute bottom-1/4 right-1/3 opacity-20 animate-float" style={{ animationDelay: '2s' }}>
                    <GitBranch className="w-5 h-5 text-indigo-300" />
                </div>
                <div className="absolute top-1/2 left-1/4 opacity-20 animate-float" style={{ animationDelay: '3s' }}>
                    <RefreshCw className="w-6 h-6 text-purple-300" />
                </div>
                <div className="absolute bottom-1/3 left-1/3 opacity-20 animate-float" style={{ animationDelay: '4s' }}>
                    <Code className="w-7 h-7 text-teal-300" />
                </div>
                
                {/* Data transfer lines */}
                <div className="absolute top-1/4 left-0 w-full h-px bg-gradient-to-r from-transparent via-cyan-300 to-transparent opacity-20 animate-pulse"></div>
                <div className="absolute top-1/2 left-0 w-full h-px bg-gradient-to-r from-transparent via-blue-300 to-transparent opacity-20 animate-pulse delay-1000"></div>
                <div className="absolute top-3/4 left-0 w-full h-px bg-gradient-to-r from-transparent via-indigo-300 to-transparent opacity-20 animate-pulse delay-2000"></div>
                
                {/* Vertical data streams */}
                <div className="absolute top-0 left-1/4 w-px h-32 bg-gradient-to-b from-transparent via-cyan-300 to-transparent opacity-20 animate-pulse"></div>
                <div className="absolute top-1/3 right-1/4 w-px h-40 bg-gradient-to-b from-transparent via-blue-300 to-transparent opacity-20 animate-pulse delay-1000"></div>
                
                {/* Migration dots */}
                <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-cyan-400 rounded-full opacity-60 animate-ping"></div>
                <div className="absolute top-1/3 right-1/3 w-1.5 h-1.5 bg-blue-400 rounded-full opacity-60 animate-ping delay-700"></div>
                <div className="absolute bottom-1/4 left-1/3 w-1 h-1 bg-indigo-400 rounded-full opacity-60 animate-ping delay-1000"></div>
                <div className="absolute top-1/2 right-1/2 w-2 h-2 bg-teal-400 rounded-full opacity-40 animate-ping delay-1500"></div>
                
                {/* Binary data effect */}
                <div className="absolute top-16 right-16 text-cyan-300 opacity-10 font-mono text-xs animate-pulse">
                    01010101
                </div>
                <div className="absolute bottom-16 left-16 text-blue-300 opacity-10 font-mono text-xs animate-pulse delay-1000">
                    11001100
                </div>
            </div>

            {/* Fixed Form Container - No hover effects to prevent blinking */}
            <div className="relative bg-white/95 backdrop-blur-sm p-6 rounded-2xl shadow-2xl w-full max-w-sm border border-white/10">
                {/* Migration Tool Logo */}
                <div className="flex justify-center mb-4">
                    <div className="relative">
                        <div className="w-16 h-16 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-xl shadow-lg p-0.5 flex items-center justify-center">
                            <div className="w-full h-full bg-white rounded-lg p-1 flex items-center justify-center">
                                <img 
                                    src={logo} 
                                    alt="Migrate 2 Modernize Logo" 
                                    className="w-full h-full rounded object-contain"
                                    onError={(e) => {
                                        e.target.style.display = 'none';
                                        e.target.nextSibling.style.display = 'flex';
                                    }}
                                />
                                <div className="w-full h-full bg-gradient-to-r from-cyan-500 to-blue-600 rounded hidden items-center justify-center">
                                    <RefreshCw className="w-6 h-6 text-white" />
                                </div>
                            </div>
                        </div>
                        <div className="absolute -top-1 -right-1 w-4 h-4 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full flex items-center justify-center">
                            <Zap className="w-2 h-2 text-white" />
                        </div>
                    </div>
                </div>

                <div className="text-center mb-6">
                    <h1 className="text-2xl font-bold bg-gradient-to-r from-cyan-600 via-blue-600 to-indigo-600 bg-clip-text text-transparent mb-1">
                        Register as Member
                    </h1>
                    <p className="text-gray-600 text-sm">Start your migration journey with us</p>
                </div>

                <div className="space-y-4">
                    {/* Username Field */}
                    <div className="group">
                        <div className="relative">
                            <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 transition-colors duration-300 group-focus-within:text-cyan-600" />
                            <input
                                type="text"
                                name="userName"
                                placeholder="Username"
                                value={registerData.userName}
                                onChange={handleRegisterChange}
                                className={`w-full pl-10 pr-3 py-3 bg-gray-50 border-2 rounded-xl focus:ring-2 focus:ring-cyan-100 focus:border-cyan-500 transition-all duration-300 outline-none text-gray-800 placeholder-gray-500 text-sm ${
                                    errors.userName ? 'border-red-500 bg-red-50' : 'border-gray-200 focus:border-cyan-500'
                                }`}
                            />
                        </div>
                        {errors.userName && (
                            <p className="mt-1 text-xs text-red-600 flex items-center gap-1">
                                <AlertCircle className="w-3 h-3" />
                                {errors.userName}
                            </p>
                        )}
                    </div>

                    {/* Email Field */}
                    <div className="group">
                        <div className="relative">
                            <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 transition-colors duration-300 group-focus-within:text-cyan-600" />
                            <input
                                type="email"
                                name="Email"
                                placeholder="Email address"
                                value={registerData.Email}
                                onChange={handleRegisterChange}
                                className={`w-full pl-10 pr-3 py-3 bg-gray-50 border-2 rounded-xl focus:ring-2 focus:ring-cyan-100 focus:border-cyan-500 transition-all duration-300 outline-none text-gray-800 placeholder-gray-500 text-sm ${
                                    errors.Email ? 'border-red-500 bg-red-50' : 'border-gray-200 focus:border-cyan-500'
                                }`}
                            />
                        </div>
                        {errors.Email && (
                            <p className="mt-1 text-xs text-red-600 flex items-center gap-1">
                                <AlertCircle className="w-3 h-3" />
                                {errors.Email}
                            </p>
                        )}
                    </div>

                    {/* Password Field */}
                    <div className="group">
                        <div className="relative">
                            <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 transition-colors duration-300 group-focus-within:text-cyan-600" />
                            <input
                                type={showPassword ? 'text' : 'password'}
                                name="Password"
                                placeholder="Password"
                                value={registerData.Password}
                                onChange={handleRegisterChange}
                                className={`w-full pl-10 pr-10 py-3 bg-gray-50 border-2 rounded-xl focus:ring-2 focus:ring-cyan-100 focus:border-cyan-500 transition-all duration-300 outline-none text-gray-800 placeholder-gray-500 text-sm ${
                                    errors.Password ? 'border-red-500 bg-red-50' : 'border-gray-200 focus:border-cyan-500'
                                }`}
                            />
                            <button
                                type="button"
                                onClick={() => setShowPassword(!showPassword)}
                                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-cyan-600 transition-colors duration-300 focus:outline-none"
                            >
                                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </button>
                        </div>
                        
                        {/* Password Strength */}
                        {registerData.Password && (
                            <div className="mt-2">
                                <div className="flex gap-0.5 mb-1">
                                    {[1, 2, 3].map((level) => (
                                        <div
                                            key={level}
                                            className={`h-1 flex-1 rounded-full transition-all duration-500 ${
                                                level <= passwordStrength.strength
                                                    ? passwordStrength.color
                                                    : 'bg-gray-200'
                                            }`}
                                        />
                                    ))}
                                </div>
                                <p className="text-xs text-gray-600">
                                    <span className="font-medium">{passwordStrength.text}</span>
                                </p>
                            </div>
                        )}
                        
                        {errors.Password && (
                            <p className="mt-1 text-xs text-red-600 flex items-center gap-1">
                                <AlertCircle className="w-3 h-3" />
                                {errors.Password}
                            </p>
                        )}
                    </div>

                    {/* Confirm Password Field */}
                    <div className="group">
                        <div className="relative">
                            <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 transition-colors duration-300 group-focus-within:text-cyan-600" />
                            <input
                                type={showConfirmPassword ? 'text' : 'password'}
                                name="confirmPassword"
                                placeholder="Confirm password"
                                value={registerData.confirmPassword}
                                onChange={handleRegisterChange}
                                className={`w-full pl-10 pr-10 py-3 bg-gray-50 border-2 rounded-xl focus:ring-2 focus:ring-cyan-100 focus:border-cyan-500 transition-all duration-300 outline-none text-gray-800 placeholder-gray-500 text-sm ${
                                    errors.confirmPassword ? 'border-red-500 bg-red-50' : 'border-gray-200 focus:border-cyan-500'
                                }`}
                            />
                            <button
                                type="button"
                                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-cyan-600 transition-colors duration-300 focus:outline-none"
                            >
                                {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </button>
                        </div>
                        {errors.confirmPassword && (
                            <p className="mt-1 text-xs text-red-600 flex items-center gap-1">
                                <AlertCircle className="w-3 h-3" />
                                {errors.confirmPassword}
                            </p>
                        )}
                    </div>

                    {/* Submit Error */}
                    {errors.submit && (
                        <p className="text-xs text-red-600 text-center flex items-center justify-center gap-1">
                            <AlertCircle className="w-3 h-3" />
                            {errors.submit}
                        </p>
                    )}

                    {/* Submit Button */}
                    <button
                        type="button"
                        onClick={handleRegisterSubmit}
                        disabled={isLoading}
                        className="w-full bg-gradient-to-r from-cyan-600 via-blue-600 to-indigo-600 text-white py-3 px-4 rounded-xl font-bold shadow-xl hover:shadow-2xl hover:from-cyan-500 hover:to-indigo-500 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 group relative overflow-hidden"
                    >
                        <div className="relative flex items-center gap-2">
                            {isLoading ? (
                                <>
                                    <RefreshCw className="w-4 h-4 animate-spin" />
                                    Migrating Account...
                                </>
                            ) : (
                                <>
                                    Register
                                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-300" />
                                </>
                            )}
                        </div>
                    </button>
                </div>

                {/* Footer */}
                <div className="mt-6 text-center">
                    <p className="text-gray-600 text-sm">
                        Already migrated?{' '}
                        <button 
                            onClick={() => navigate('/')}                            
                            className="text-cyan-600 hover:text-cyan-700 font-bold hover:underline transition-all duration-300"
                        >
                            Sign in
                        </button>
                    </p>
                </div>
            </div>

            {/* Custom CSS for floating animation */}
            <style jsx>{`
                @keyframes float {
                    0%, 100% { transform: translateY(0px) rotate(0deg); }
                    50% { transform: translateY(-8px) rotate(2deg); }
                }
                .animate-float {
                    animation: float 4s ease-in-out infinite;
                }
            `}</style>
        </div>
    );
};

export default Register;

// import React, { useState } from 'react';
// import axios from 'axios';
// import 'tailwindcss/tailwind.css';
// import logo from '../assets/image.jpg';
// import { ToastContainer, toast } from 'react-toastify';
// import 'react-toastify/dist/ReactToastify.css';
// import { useNavigate } from 'react-router-dom';
// import { HiOutlineEye, HiOutlineEyeOff } from 'react-icons/hi';
// import img from '../assets/vision.jpg'

// const Register = () => {
//     const [registerData, setRegisterData] = useState({ userName: '', Email: '', Password: '', confirmPassword: '' });
//     const [showPassword, setShowPassword] = useState(false);
//     const [showConfirmPassword, setShowConfirmPassword] = useState(false);
//     const navigate = useNavigate();

//     const handleRegisterChange = (e) => {
//         setRegisterData({ ...registerData, [e.target.name.trim()]: e.target.value });
//     };

//     const handleRegisterSubmit = async (e) => {
//         e.preventDefault();
//         if (registerData.Password !== registerData.confirmPassword) {
//             toast.error("Passwords do not match!");
//             return;
//         }
//         try {
//             const response = await axios.post('https://newdatabackend.onrender.com/api/auth/register', {
//                 userName: registerData.userName,
//                 Email: registerData.Email,
//                 Password: registerData.Password
//             });
//             if (response && response.data) {
//                 console.log('Registration successful:', response.data);
//                 toast.success('Registration successful');
//                 setRegisterData({ userName: '', Email: '', Password: '', confirmPassword: '' });
//                 setTimeout(() => {
//                     navigate('/'); 
//                 }, 2000); 
//             }
//         } catch (error) {
//             console.error('Error during registration:', error.response?.data);
//             toast.error('Registration failed: ' + (error.response?.data?.msg || 'An error occurred'));
//         }
//     };

//     return (
//         <>
//             <div className="flex flex-col items-center justify-center min-h-screen bg-white p-4 md:p-8 relative overflow-hidden">
//                 <img src={img} alt="" className='relative w-full h-screen z-0 '/>
//                 <div className="absolute inset-0 flex md:flex-row rounded-lg overflow-hidden w-full max-w-md bg-white shadow-xl ml-[550px] h-[580px] mt-28">
//                     <div className="flex flex-col items-center justify-center p-6 md:p-10 w-full mb-8 md:mb-0">
//                         <img src={logo} alt="Logo" className="w-24 mx-auto" />
//                         <h2 className="text-center text-primary text-lg md:text-2xl mt-6 font-semibold">Register as member</h2>
//                         <input
//                             type="text"
//                             name="userName"
//                             placeholder="Username"
//                             className="border-b mb-4 p-4 w-full md:w-3/4 outline-none text-center"
//                             value={registerData.userName}
//                             onChange={handleRegisterChange}
//                         />
//                         <input
//                             type="email"
//                             name="Email"
//                             placeholder="Email"
//                             className="border-b mb-4 p-4 w-full md:w-3/4 outline-none text-center"
//                             value={registerData.Email}
//                             onChange={handleRegisterChange}
//                         />
//                         <div className="relative w-full md:w-3/4">
//                             <input
//                                 type={showPassword ? 'text' : 'password'}
//                                 name="Password"
//                                 placeholder="Password"
//                                 className="border-b mb-4 p-4 w-full outline-none text-center pr-10"
//                                 value={registerData.Password}
//                                 onChange={handleRegisterChange}
//                             />
//                             <div className="absolute inset-y-0 right-0 pr-3 flex items-center cursor-pointer" onClick={() => setShowPassword(!showPassword)}>
//                                 {showPassword ? <HiOutlineEyeOff className="text-gray-500" /> : <HiOutlineEye className="text-gray-500" />}
//                             </div>
//                         </div>
//                         <div className="relative w-full md:w-3/4">
//                             <input
//                                 type={showConfirmPassword ? 'text' : 'password'}
//                                 name="confirmPassword"
//                                 placeholder="Confirm Password"
//                                 className="border-b mb-4 p-4 w-full outline-none text-center pr-10"
//                                 value={registerData.confirmPassword}
//                                 onChange={handleRegisterChange}
//                             />
//                             <div className="absolute inset-y-0 right-0 pr-3 flex items-center cursor-pointer" onClick={() => setShowConfirmPassword(!showConfirmPassword)}>
//                                 {showConfirmPassword ? <HiOutlineEyeOff className="text-gray-500" /> : <HiOutlineEye className="text-gray-500" />}
//                             </div>
//                         </div>
//                         <button onClick={handleRegisterSubmit} className="bg-orange-500 hover:bg-orange-600 text-white py-2 px-4  w-full md:w-3/4">
//                             Register
//                         </button>
//                     </div>
//                 </div>
//             </div>

//             <ToastContainer />
//         </>
//     );
// };

// export default Register;




