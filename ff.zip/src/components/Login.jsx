// import React, { useState } from 'react';
// import axios from 'axios';
// import 'tailwindcss/tailwind.css';
// import logo from '../assets/image.jpg';
// import img from '../assets/s2_logo_2-removebg-preview.png';
// import { ToastContainer, toast } from 'react-toastify';
// import 'react-toastify/dist/ReactToastify.css';
// import { useNavigate } from 'react-router-dom';
// import { HiOutlineEye, HiOutlineEyeOff } from 'react-icons/hi';


// const Login = () => {
//   const [loginData, setLoginData] = useState({ usernameOrEmail: '', Password: '' });
//   const [forgotPasswordEmail, setForgotPasswordEmail] = useState('');
//   const [resetPasswordData, setResetPasswordData] = useState({ token: '', newPassword: '' });
//   const [isForgotPasswordModalOpen, setForgotPasswordModalOpen] = useState(false);
//   const [isResetPasswordFormOpen, setResetPasswordFormOpen] = useState(false);
//   const [showPassword, setShowPassword] = useState(false);
//   const [showNewPassword, setShowNewPassword] = useState(false);
//   const navigate = useNavigate();

//   const handleLoginChange = (e) => {
//     setLoginData({ ...loginData, [e.target.name]: e.target.value });
//   };

//   const handleForgotPasswordChange = (e) => {
//     setForgotPasswordEmail(e.target.value);
//   };

//   const handleResetPasswordChange = (e) => {
//     setResetPasswordData({ ...resetPasswordData, [e.target.name]: e.target.value });
//   };

//   const togglePasswordVisibility = () => {
//     setShowPassword(!showPassword);
//   };

//   const toggleNewPasswordVisibility = () => {
//     setShowNewPassword(!showNewPassword);
//   };

//   const handleLoginSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       const response = await axios.post('https://newdatabackend.onrender.com/api/auth/login', loginData);
//       if (response && response.data) {
//         console.log('Login successful:', response.data);
//         toast.success('Login successful');

//         const { token, user } = response.data;

//         // Save the token and user details in localStorage
//         localStorage.setItem('token', token);
//         localStorage.setItem('user', JSON.stringify(user)); 
//         setLoginData({ usernameOrEmail: '', Password: '' });

//         // Navigate to the dashboard page after successful login
//         navigate('/settings');
//       }
//     } catch (error) {
//       console.error('Error during login:', error.response?.data);
//       toast.error('Login failed: ' + (error.response?.data?.msg || 'An error occurred'));
//     }
//   };

//   const handleForgotPasswordSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       const response = await axios.post('https://newdatabackend.onrender.com/api/auth/forgot-password', { Email: forgotPasswordEmail });
//       if (response && response.data) {
//         console.log('Password reset email sent:', response.data);
//         toast.success('Password reset email sent');
//         setForgotPasswordEmail('');
//         setForgotPasswordModalOpen(false);
//         setResetPasswordFormOpen(true);
//       }
//     } catch (error) {
//       console.error('Error during password reset request:', error.response?.data);
//       toast.error('Error: ' + (error.response?.data?.msg || 'An error occurred'));
//     }
//   };

//   const handleResetPasswordSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       const response = await axios.post('https://newdatabackend.onrender.com/api/auth/reset-password', resetPasswordData);
//       if (response && response.data) {
//         console.log('Password reset successful:', response.data);
//         toast.success('Password reset successful');
//         setResetPasswordData({ token: '', newPassword: '' });
//         setResetPasswordFormOpen(false);
//       }
//     } catch (error) {
//       console.error('Error during password reset:', error.response?.data);
//       toast.error('Error: ' + (error.response?.data?.msg || 'An error occurred'));
//     }
//   };

//   return (
//     <>
//       <div className="flex items-center justify-center min-h-screen bg-[#0B0B3B] p-4">
//         <img src={img} alt=""className='mb-[490px]  '/>
//         <div className="w-full max-w-sm sm:max-w-sm md:max-w-md lg:max-w-md mx-auto">
//           <div className="bg-white rounded-lg shadow-xl overflow-hidden ">
//             <div className="flex flex-col items-center justify-center p-6 md:p-8 lg:p-10">
//               <img src={logo} alt="Logo" className="w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 object-contain" />
//               <h2 className="text-center text-primary text-xl sm:text-2xl md:text-3xl mt-4 md:mt-6 font-semibold">Login</h2>
              
//               <form onSubmit={handleLoginSubmit} className="w-full mt-6 space-y-6">
//                 <div className="w-full">
//                   <input
//                     type="text"
//                     name="usernameOrEmail"
//                     placeholder="Username or Email"
//                     className="border-b p-3 w-full outline-none text-center"
//                     value={loginData.usernameOrEmail}
//                     onChange={handleLoginChange}
//                     required
//                   />
//                 </div>
                
//                 <div className="relative w-full">
//                   <input
//                     type={showPassword ? 'text' : 'password'}
//                     name="Password"
//                     placeholder="Password"
//                     className="border-b p-3 w-full outline-none text-center pr-10"
//                     value={loginData.Password}
//                     onChange={handleLoginChange}
//                     required
//                   />
//                   <div className="absolute inset-y-0 right-0 pr-3 flex items-center cursor-pointer">
//                     {showPassword ? (
//                       <HiOutlineEyeOff className="text-gray-500 text-xl" onClick={togglePasswordVisibility} />
//                     ) : (
//                       <HiOutlineEye className="text-gray-500 text-xl" onClick={togglePasswordVisibility} />
//                     )}
//                   </div>
//                 </div>
                
//                 <div className="pt-2">
//                   <button 
//                     type="submit" 
//                     className="bg-orange-500 hover:bg-orange-600 text-white py-3 px-4 rounded-md w-full transition duration-300 ease-in-out transform hover:scale-105"
//                   >
//                     Submit
//                   </button>
//                 </div>
                
//                 <div className="flex flex-col items-center space-y-4 mt-4">
//                   <button 
//                     type="button"
//                     onClick={() => setForgotPasswordModalOpen(true)} 
//                     className="text-gray-600 hover:text-gray-800 text-sm hover:underline transition duration-300"
//                   >
//                     Forgot Password?
//                   </button>
                  
//                   <button 
//                     type="button"
//                     onClick={() => navigate('/register')} 
//                     className="text-center text-lg font-medium text-yellow-600 hover:text-yellow-700 hover:underline transition duration-300"
//                   >
//                     For New Registration
//                   </button>
//                 </div>
//               </form>
//             </div>
//           </div>
//         </div>
//       </div>

//       {/* Forgot Password Modal */}
//       {isForgotPasswordModalOpen && (
//         <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50 p-4">
//           <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-sm">
//             <h2 className="text-orange-500 text-lg font-semibold mb-4">Forgot Password</h2>
//             <form onSubmit={handleForgotPasswordSubmit}>
//               <input
//                 type="email"
//                 placeholder="Enter your email"
//                 className="mt-2 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 text-center focus:outline-none focus:ring-orange-500 focus:border-orange-500"
//                 value={forgotPasswordEmail}
//                 onChange={handleForgotPasswordChange}
//                 required
//               />
              
//               <div className="mt-6 flex flex-col space-y-3">
//                 <button 
//                   type="submit"
//                   className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-orange-500 hover:bg-orange-600 focus:outline-none transition duration-300"
//                 >
//                   Send Reset Email
//                 </button>
                
//                 <button 
//                   type="button"
//                   onClick={() => setForgotPasswordModalOpen(false)} 
//                   className="w-full flex justify-center py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none transition duration-300"
//                 >
//                   Close
//                 </button>
//               </div>
//             </form>
//           </div>
//         </div>
//       )}

//       {/* Reset Password Modal */}
//       {isResetPasswordFormOpen && (
//         <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50 p-4">
//           <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-sm">
//             <h2 className="text-orange-500 text-lg font-semibold mb-4">Reset Password</h2>
//             <form onSubmit={handleResetPasswordSubmit} className="space-y-4">
//               <input
//                 type="text"
//                 name="token"
//                 placeholder="Reset Token"
//                 className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 text-center focus:outline-none focus:ring-orange-500 focus:border-orange-500"
//                 value={resetPasswordData.token}
//                 onChange={handleResetPasswordChange}
//                 required
//               />
              
//               <div className="relative w-full">
//                 <input
//                   type={showNewPassword ? 'text' : 'password'}
//                   name="newPassword"
//                   placeholder="New Password"
//                   className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 text-center pr-10 focus:outline-none focus:ring-orange-500 focus:border-orange-500"
//                   value={resetPasswordData.newPassword}
//                   onChange={handleResetPasswordChange}
//                   required
//                 />
//                 <div className="absolute inset-y-0 right-0 pr-3 flex items-center cursor-pointer">
//                   {showNewPassword ? (
//                     <HiOutlineEyeOff className="text-gray-500 text-xl" onClick={toggleNewPasswordVisibility} />
//                   ) : (
//                     <HiOutlineEye className="text-gray-500 text-xl" onClick={toggleNewPasswordVisibility} />
//                   )}
//                 </div>
//               </div>
              
//               <div className="mt-6 flex flex-col space-y-3">
//                 <button 
//                   type="submit"
//                   className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-orange-500 hover:bg-orange-600 focus:outline-none transition duration-300"
//                 >
//                   Reset Password
//                 </button>
                
//                 <button 
//                   type="button"
//                   onClick={() => setResetPasswordFormOpen(false)} 
//                   className="w-full flex justify-center py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none transition duration-300"
//                 >
//                   Close
//                 </button>
//               </div>
//             </form>
//           </div>
//         </div>
//       )}
      
//       <ToastContainer position="top-right" autoClose={3000} />
//     </>
//   );
// };

// export default Login;


import React, { useState } from 'react';
import axios from 'axios';
import 'tailwindcss/tailwind.css';
import logo from '../assets/image.jpg';
import img from '../assets/s2_logo_2-removebg-preview.png';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate } from 'react-router-dom';
import { HiOutlineEye, HiOutlineEyeOff } from 'react-icons/hi';


const Login = () => {
  const [loginData, setLoginData] = useState({ usernameOrEmail: '', Password: '' });
  const [forgotPasswordEmail, setForgotPasswordEmail] = useState('');
  const [resetPasswordData, setResetPasswordData] = useState({ token: '', newPassword: '' });
  const [isForgotPasswordModalOpen, setForgotPasswordModalOpen] = useState(false);
  const [isResetPasswordFormOpen, setResetPasswordFormOpen] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const navigate = useNavigate();

  const handleLoginChange = (e) => {
    setLoginData({ ...loginData, [e.target.name]: e.target.value });
  };

  const handleForgotPasswordChange = (e) => {
    setForgotPasswordEmail(e.target.value);
  };

  const handleResetPasswordChange = (e) => {
    setResetPasswordData({ ...resetPasswordData, [e.target.name]: e.target.value });
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const toggleNewPasswordVisibility = () => {
    setShowNewPassword(!showNewPassword);
  };

  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('https://newdatabackend.onrender.com/api/auth/login', loginData);
      if (response && response.data) {
        console.log('Login successful:', response.data);
        toast.success('Login successful');

        const { token, user } = response.data;

        // Save the token and user details in localStorage
        localStorage.setItem('token', token);
        localStorage.setItem('user', JSON.stringify(user)); 
        setLoginData({ usernameOrEmail: '', Password: '' });

        // Navigate to the dashboard page after successful login
        navigate('/settings');
      }
    } catch (error) {
      console.error('Error during login:', error.response?.data);
      toast.error('Login failed: ' + (error.response?.data?.msg || 'An error occurred'));
    }
  };

  const handleForgotPasswordSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('https://newdatabackend.onrender.com/api/auth/forgot-password', { Email: forgotPasswordEmail });
      if (response && response.data) {
        console.log('Password reset email sent:', response.data);
        toast.success('Password reset email sent');
        setForgotPasswordEmail('');
        setForgotPasswordModalOpen(false);
        setResetPasswordFormOpen(true);
      }
    } catch (error) {
      console.error('Error during password reset request:', error.response?.data);
      toast.error('Error: ' + (error.response?.data?.msg || 'An error occurred'));
    }
  };

  const handleResetPasswordSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('https://newdatabackend.onrender.com/api/auth/reset-password', resetPasswordData);
      if (response && response.data) {
        console.log('Password reset successful:', response.data);
        toast.success('Password reset successful');
        setResetPasswordData({ token: '', newPassword: '' });
        setResetPasswordFormOpen(false);
      }
    } catch (error) {
      console.error('Error during password reset:', error.response?.data);
      toast.error('Error: ' + (error.response?.data?.msg || 'An error occurred'));
    }
  };

  return (
    <>
      <div className="flex items-center justify-center min-h-screen bg-[#0B0B3B] p-4">
        <img src={img} alt=""className='mb-[490px]  '/>
        <div className="w-full max-w-sm sm:max-w-sm md:max-w-md lg:max-w-md mx-auto">
          <div className="bg-white rounded-lg shadow-xl overflow-hidden ">
            <div className="flex flex-col items-center justify-center p-6 md:p-8 lg:p-10">
              <img src={logo} alt="Logo" className="w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 object-contain" />
              <h2 className="text-center text-primary text-xl sm:text-2xl md:text-3xl mt-4 md:mt-6 font-semibold">Login</h2>
              
              <form onSubmit={handleLoginSubmit} className="w-full mt-6 space-y-6">
                <div className="w-full">
                  <input
                    type="text"
                    name="usernameOrEmail"
                    placeholder="Username or Email"
                    className="border-b p-3 w-full outline-none text-center"
                    value={loginData.usernameOrEmail}
                    onChange={handleLoginChange}
                    required
                  />
                </div>
                
                <div className="relative w-full">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    name="Password"
                    placeholder="Password"
                    className="border-b p-3 w-full outline-none text-center pr-10"
                    value={loginData.Password}
                    onChange={handleLoginChange}
                    required
                  />
                  <div className="absolute inset-y-0 right-0 pr-3 flex items-center cursor-pointer">
                    {showPassword ? (
                      <HiOutlineEyeOff className="text-gray-500 text-xl" onClick={togglePasswordVisibility} />
                    ) : (
                      <HiOutlineEye className="text-gray-500 text-xl" onClick={togglePasswordVisibility} />
                    )}
                  </div>
                </div>
                
                <div className="pt-2">
                  <button 
                    type="submit" 
                    className="bg-orange-500 hover:bg-orange-600 text-white py-3 px-4 rounded-md w-full transition duration-300 ease-in-out transform hover:scale-105"
                  >
                    Submit
                  </button>
                </div>
                
                <div className="flex flex-col items-center space-y-4 mt-4">
                  <button 
                    type="button"
                    onClick={() => setForgotPasswordModalOpen(true)} 
                    className="text-gray-600 hover:text-gray-800 text-sm hover:underline transition duration-300"
                  >
                    Forgot Password?
                  </button>
                  
                  <button 
                    type="button"
                    onClick={() => navigate('/register')} 
                    className="text-center text-lg font-medium text-yellow-600 hover:text-yellow-700 hover:underline transition duration-300"
                  >
                    For New Registration
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

      {/* Forgot Password Modal */}
      {isForgotPasswordModalOpen && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50 p-4">
          <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-sm">
            <h2 className="text-orange-500 text-lg font-semibold mb-4">Forgot Password</h2>
            <form onSubmit={handleForgotPasswordSubmit}>
              <input
                type="email"
                placeholder="Enter your email"
                className="mt-2 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 text-center focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                value={forgotPasswordEmail}
                onChange={handleForgotPasswordChange}
                required
              />
              
              <div className="mt-6 flex flex-col space-y-3">
                <button 
                  type="submit"
                  className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-orange-500 hover:bg-orange-600 focus:outline-none transition duration-300"
                >
                  Send Reset Email
                </button>
                
                <button 
                  type="button"
                  onClick={() => setForgotPasswordModalOpen(false)} 
                  className="w-full flex justify-center py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none transition duration-300"
                >
                  Close
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Reset Password Modal */}
      {isResetPasswordFormOpen && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50 p-4">
          <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-sm">
            <h2 className="text-orange-500 text-lg font-semibold mb-4">Reset Password</h2>
            <form onSubmit={handleResetPasswordSubmit} className="space-y-4">
              <input
                type="text"
                name="token"
                placeholder="Reset Token"
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 text-center focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                value={resetPasswordData.token}
                onChange={handleResetPasswordChange}
                required
              />
              
              <div className="relative w-full">
                <input
                  type={showNewPassword ? 'text' : 'password'}
                  name="newPassword"
                  placeholder="New Password"
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 text-center pr-10 focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                  value={resetPasswordData.newPassword}
                  onChange={handleResetPasswordChange}
                  required
                />
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center cursor-pointer">
                  {showNewPassword ? (
                    <HiOutlineEyeOff className="text-gray-500 text-xl" onClick={toggleNewPasswordVisibility} />
                  ) : (
                    <HiOutlineEye className="text-gray-500 text-xl" onClick={toggleNewPasswordVisibility} />
                  )}
                </div>
              </div>
              
              <div className="mt-6 flex flex-col space-y-3">
                <button 
                  type="submit"
                  className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-orange-500 hover:bg-orange-600 focus:outline-none transition duration-300"
                >
                  Reset Password
                </button>
                
                <button 
                  type="button"
                  onClick={() => setResetPasswordFormOpen(false)} 
                  className="w-full flex justify-center py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none transition duration-300"
                >
                  Close
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      
      <ToastContainer position="top-right" autoClose={3000} />
    </>
  );
};

export default Login;