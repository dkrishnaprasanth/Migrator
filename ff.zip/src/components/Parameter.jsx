import React, { useState } from "react";
import Sidebar from "./Sidebar";
import Topbar from "./Topbar";
import axios from "axios";
import { DndProvider } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
 
const Parameter = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [testLoading, setTestLoading] = useState(false);
  const [testResult, setTestResult] = useState(null);
  const [testError, setTestError] = useState(null);
 
 
  const handleFetchTestCaseModuleData = async () => {
    setTestLoading(true);
    setTestError(null);
    setTestResult(null);
 
    try {
      const response = await axios.get("http://localhost:5550/api/parameters/alm-setup/step1");
      setTestResult(response.data);
      toast.success(response.data.message || "ALM data fetched successfully!");
      console.log("ALM data fetched successfully:", response.data);
 
      // After successful fetch, load the fields
    //   await fetchTotalResultsA();
    } catch (err) {
      setTestError(err.message || "Failed to fetch ALM data");
      toast.error(err.message || "Failed to fetch ALM data");
      console.error("Error fetching ALM data:", err);
    } finally {
      setTestLoading(false);
    }
  };
 
  return (
    <div className="flex h-screen mt-20">
      <Sidebar />
      <Topbar />
 
      <DndProvider backend={HTML5Backend}>
        <div className="mt-10 space-y-6 ml-10">
          <div className="flex ml-[300px] mt-10">
            <div className="flex flex-col items-center space-y-4 ml-[170px]">
              <button
                onClick={handleFetchTestCaseModuleData}
                className="bg-blue-500 hover:bg-blue-700 text-white p-2 rounded text-lg w-60 h-[50px] mb-3"
              >
                {testLoading || isLoading ? "Loading..." : "Get ALM Parameter"}
              </button>
            </div>
          </div>
        </div>
 
        <ToastContainer />
      </DndProvider>
    </div>
  );
};
 
export default Parameter;
 
 
 
 
 
 