const ConfirmationDialog = () => {
  if (!showConfirmDialog) return null;
  const selectedTypes = Object.entries(selectedArtifacts)
    .filter(([_, selected]) => selected)
    .map(([type]) => type);

  // Calculate total records from confirmationData including all sub-artifacts
  const totalRecords = selectedTypes.reduce((total, type) => {
    const stats = confirmationData[type] ?? { total: 0 };
    let typeTotal = stats.total || 0;
    
    // Add sub-artifacts for testcases
    if (type === 'testcases') {
      typeTotal += (stats.folderMigratedCount || 0) + 
                  (stats.paramMigratedCount || 0) + 
                  (stats.stepMigratedCount || 0);
    }
    
    // Add sub-artifacts for testruns
    if (type === 'testruns') {
      typeTotal += (stats.testCycleCount || 0) + 
                   (stats.testSuiteCount || 0) + 
                   (stats.logCount || 0);
      // Note: testRunCount is same as total, so don't double count
    }
    
    return total + typeTotal;
  }, 0);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl sm:rounded-2xl shadow-2xl w-full max-w-[95vw] sm:max-w-2xl lg:max-w-3xl flex flex-col max-h-[90vh]">
        
        {/* Header - Fixed */}
        <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white p-6 rounded-t-2xl flex-shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-white/20 rounded-lg">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold">Confirm Migration</h3>
                <p className="text-orange-100">Please review the records to be migrated</p>
              </div>
            </div>
            <button
              onClick={() => setShowConfirmDialog(false)}
              className="p-2 hover:bg-white/20 rounded-lg transition-colors flex-shrink-0"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto">
          <div className="p-6">
            {/* Warning Box */}
            <div className="mb-6">
              <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-r-lg mb-4">
                <div className="flex items-start">
                  <AlertTriangle className="w-5 h-5 text-yellow-400 mr-3 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-yellow-800 font-medium">
                      You are about to migrate <span className="font-bold text-yellow-900">{totalRecords}</span> total records.
                    </p>
                    <p className="text-yellow-700 text-sm mt-1">
                      This action cannot be undone. Please review the details below.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Migration Details */}
            <div className="space-y-4">
              <h4 className="text-lg font-semibold text-gray-900 mb-4">Migration Details:</h4>

              {selectedTypes.map(type => {
                const config = dataTypes[type];
                const stats = confirmationData[type] || { total: 0 };
                const count = stats.total || 0;

                console.log(`Debug ${type} stats:`, stats); // Debug log

                // Calculate total including sub-components for testcases
                let totalTestCasesCount = 0;
                if (type === 'testcases') {
                  totalTestCasesCount = count + 
                    (stats.folderMigratedCount || 0) + 
                    (stats.paramMigratedCount || 0) + 
                    (stats.stepMigratedCount || 0);
                }

                // Calculate total including sub-components for testruns
                let totalTestRunsCount = 0;
                if (type === 'testruns') {
                  totalTestRunsCount = 
                    (stats.testCycleCount || 0) + 
                    (stats.testSuiteCount || 0) + 
                    (stats.testRunCount || 0) + 
                    (stats.logCount || 0);
                }

                return (
                  <div key={type} className="bg-gray-50 rounded-xl p-4 border border-gray-200">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <div className="p-2 bg-blue-100 rounded-lg flex-shrink-0">{config.icon}</div>
                        <div>
                          <h5 className="font-semibold text-gray-900">{config.title}</h5>
                          <p className="text-sm text-gray-600">Ready for migration</p>
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="text-2xl font-bold text-blue-600">
                          {type === 'testcases' ? totalTestCasesCount : 
                           type === 'testruns' ? totalTestRunsCount : count}
                        </div>
                        <div className="text-sm text-gray-500">
                          {type === 'testcases' || type === 'testruns' ? 'total items' : 'records'}
                        </div>
                      </div>
                    </div>

                    {/* Sub-artifacts for Test Design */}
                    {type === 'testcases' && (
                      <div className="mt-4 pl-4 border-l-2 border-purple-200 space-y-3">
                        <div className="text-sm text-green-700 font-medium mb-2">
                          Will also migrate the following components:
                        </div>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div className="bg-white rounded-lg p-3 border border-orange-100 shadow-sm">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-2">
                                <div className="w-2 h-2 bg-orange-500 rounded-full flex-shrink-0"></div>
                                <span className="text-sm font-medium text-gray-700">TestCase Folders</span>
                              </div>
                              <span className="text-sm font-bold text-orange-600">
                                {confirmationData[type]?.folderMigratedCount || stats.folderMigratedCount || 0}
                              </span>
                            </div>
                          </div>
                          
                          <div className="bg-white rounded-lg p-3 border border-teal-100 shadow-sm">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-2">
                                <div className="w-2 h-2 bg-teal-500 rounded-full flex-shrink-0"></div>
                                <span className="text-sm font-medium text-gray-700">Test Cases</span>
                              </div>
                              <span className="text-sm font-bold text-teal-600">
                                {count}
                              </span>
                            </div>
                          </div>
                          
                          <div className="bg-white rounded-lg p-3 border border-indigo-100 shadow-sm">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-2">
                                <div className="w-2 h-2 bg-indigo-500 rounded-full flex-shrink-0"></div>
                                <span className="text-sm font-medium text-gray-700">Parameters</span>
                              </div>
                              <span className="text-sm font-bold text-indigo-600">
                                {confirmationData[type]?.paramMigratedCount || stats.paramMigratedCount || 0}
                              </span>
                            </div>
                          </div>
                          
                          <div className="bg-white rounded-lg p-3 border border-pink-100 shadow-sm">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-2">
                                <div className="w-2 h-2 bg-pink-500 rounded-full flex-shrink-0"></div>
                                <span className="text-sm font-medium text-gray-700">TestCase Steps</span>
                              </div>
                              <span className="text-sm font-bold text-pink-600">
                                {confirmationData[type]?.stepMigratedCount || stats.stepMigratedCount || 0}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Sub-artifacts for Test Execution (testruns) */}
                    {type === 'testruns' && (
                      <div className="mt-4 pl-4 border-l-2 border-purple-200 space-y-3">
                        <div className="text-sm text-green-700 font-medium mb-2">
                          Will also migrate the following components:
                        </div>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div className="bg-white rounded-lg p-3 border border-orange-100 shadow-sm">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-2">
                                <div className="w-2 h-2 bg-orange-500 rounded-full flex-shrink-0"></div>
                                <span className="text-sm font-medium text-gray-700">Test Cycles</span>
                              </div>
                              <span className="text-sm font-bold text-orange-600">
                                {confirmationData[type]?.testCycleCount || stats.testCycleCount || 0}
                              </span>
                            </div>
                          </div>
                          
                          <div className="bg-white rounded-lg p-3 border border-teal-100 shadow-sm">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-2">
                                <div className="w-2 h-2 bg-teal-500 rounded-full flex-shrink-0"></div>
                                <span className="text-sm font-medium text-gray-700">Test Suites</span>
                              </div>
                              <span className="text-sm font-bold text-teal-600">
                                {confirmationData[type]?.testSuiteCount || stats.testSuiteCount || 0}
                              </span>
                            </div>
                          </div>
                          
                          <div className="bg-white rounded-lg p-3 border border-indigo-100 shadow-sm">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-2">
                                <div className="w-2 h-2 bg-indigo-500 rounded-full flex-shrink-0"></div>
                                <span className="text-sm font-medium text-gray-700">Test Runs</span>
                              </div>
                              <span className="text-sm font-bold text-indigo-600">
                                {confirmationData[type]?.testRunCount || stats.testRunCount || 0}
                              </span>
                            </div>
                          </div>
                          
                          <div className="bg-white rounded-lg p-3 border border-pink-100 shadow-sm">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-2">
                                <div className="w-2 h-2 bg-pink-500 rounded-full flex-shrink-0"></div>
                                <span className="text-sm font-medium text-gray-700">Test Logs</span>
                              </div>
                              <span className="text-sm font-bold text-pink-600">
                                {confirmationData[type]?.logCount || stats.logCount || 0}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Simple note for other artifacts */}
                    {type !== 'testcases' && type !== 'testruns' && (
                      <div className="mt-3 text-sm text-gray-500 italic">
                        Ready for direct migration to qTest
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Summary */}
            <div className="mt-6 p-4 bg-blue-50 rounded-xl border border-blue-200">
              <div className="flex items-center justify-between">
                <div>
                  <h5 className="font-semibold text-blue-900">Total Migration Summary</h5>
                  <p className="text-blue-700 text-sm">All selected artifacts and their sub-components will be processed</p>
                </div>
                <div className="text-right">
                  <div className="text-3xl font-bold text-blue-600">{totalRecords}</div>
                  <div className="text-sm text-blue-500">total items</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Actions - Fixed at bottom */}
        <div className="bg-gray-50 px-6 py-4 rounded-b-2xl flex flex-col sm:flex-row justify-end space-y-3 sm:space-y-0 sm:space-x-3 flex-shrink-0 border-t border-gray-200">
          <button
            onClick={() => setShowConfirmDialog(false)}
            className="px-6 py-2 border-2 border-gray-300 text-gray-700 font-semibold rounded-lg hover:bg-gray-100 hover:border-gray-400 transition-all duration-200"
          >
            Cancel
          </button>
          <button
            onClick={proceedWithMigration}
            className="px-6 py-2 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white font-bold rounded-lg shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-[1.02]"
          >
            Yes, Proceed with Migration
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmationDialog;