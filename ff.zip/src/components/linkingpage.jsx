// import React from "react";
 
// import { useState, useEffect } from "react";
// import Sidebar from "../components/Sidebar";
// import Topbar from "../components/Topbar";
// import axios from "axios";
// import { toast, ToastContainer } from "react-toastify";
// import "react-toastify/dist/ReactToastify.css";
 
// const LinkPage = () => {
//   const linkReleaseToRequirement = async () => {
//     try {
//       const res = await axios.post("http://localhost:5550/api/link-release-to-req");
//       toast.success(res.data.message || "Linked Release to Requirement successfully!");
//     } catch (err) {
//       toast.error(err.response?.data?.message || "Failed to link Release to Requirement");
//     }
//   };
 
//   const linkRequirementToTestCase = async () => {
//     try {
//       const res = await axios.post("http://localhost:5550/api/link-req-to-test");
//       toast.success(res.data.message || "Linked Requirement to Test Case successfully!");
//     } catch (err) {
//       toast.error(err.response?.data?.message || "Failed to link Requirement to Test Case");
//     }
//   };
 
//   const linkDefect = async () => {
//     try {
//       const res = await axios.post("http://localhost:5550/api/link-defects");
//       toast.success(res.data.message || "Defect linking completed successfully!");
//     } catch (err) {
//       toast.error(err.response?.data?.message || "Failed to link defects");
//     }
//   };
 
//   const RequirementAttachments = async () => {
//     try {
//       const res = await axios.post("http://localhost:5550/api/attach/RequirementAttachments");
//       toast.success(res.data.message || "Requirements Attach Successfully!");
//     } catch (err) {
//       toast.error(err.response?.data?.message || "Fail to attach");
//     }
//   };
 
//   const TestCaseAttachments = async () => {
//     try {
//       const res = await axios.post("http://localhost:5550/api/attach/TestCaseAttachments");
//       toast.success(res.data.message || "TC Attach Successfully!");
//     } catch (err) {
//       toast.error(err.response?.data?.message || "Fail to attach");
//     }
//   };
 
//   const TestCaseStepAttachments = async () => {
//     try {
//       const res = await axios.post("http://localhost:5550/api/attach/TestCaseStepAttachments");
//       toast.success(res.data.message || "TC Steps Attach Successfully!");
//     } catch (err) {
//       toast.error(err.response?.data?.message || "Fail to attach");
//     }
//   };
 
//   const DefectAttachments = async () => {
//     try {
//       const res = await axios.post("http://localhost:5550/api/attach/DefectAttachments");
//       toast.success(res.data.message || "Defects Attach Successfully!");
//     } catch (err) {
//       toast.error(err.response?.data?.message || "Fail to attach");
//     }
//   };
 
//   const TestLogAttachments = async () => {
//     try {
//       const res = await axios.post("http://localhost:5550/api/attach/TestLogAttachments");
//       toast.success(res.data.message || "TestLog Attach Successfully!");
//     } catch (err) {
//       toast.error(err.response?.data?.message || "Fail to attach");
//     }
//   };
 
//   const TestLogStepAttachments = async () => {
//     try {
//       const res = await axios.post("http://localhost:5550/api/attach/TestLogStepAttachments");
//       toast.success(res.data.message || "TestLogStep Attach Successfully!");
//     } catch (err) {
//       toast.error(err.response?.data?.message || "Fail to attach");
//     }
//   };
 
 
 
//  // Updated state and functions to fetch only current settings
//   const [almSettings, setAlmSettings] = useState({ domain: "", project: "" });
//   const [qtestSettings, setQtestSettings] = useState({ projectId: "" });
//   const [linkName, setLinkName] = useState({ linkname: "" });
 
//   const [almLoading, setAlmLoading] = useState(false);
//     const [qtestLoading, setQtestLoading] = useState(false);
 
 
//   // Updated fetchAlmSettings to get only current settings
//   const fetchAlmSettings = async () => {
//     setAlmLoading(true);
//     try {
//       const res = await axios.get("http://localhost:5550/api/settings/settings");
//       console.log("Fetched ALM Settings:", res.data);
 
//       let currentSettings = null;
 
//       // Find the current settings from the array
//       if (Array.isArray(res.data)) {
//         currentSettings = res.data.find(setting =>
//           setting.is_current === 1 ||
//           setting.is_current === true ||
//           setting.is_current === "1"
//         );
//       } else if (res.data && (res.data.is_current === 1 || res.data.is_current === true)) {
//         currentSettings = res.data;
//       }
 
//       if (currentSettings) {
//         setAlmSettings({
//           domain: currentSettings.domain || "",
//           project: currentSettings.project || "",
//         });
//       } else {
//         // No current settings found
//         setAlmSettings({ domain: "", project: "" });
//         console.log("No current ALM settings found");
//       }
//     } catch (err) {
//       console.error("ALM Fetch error:", err);
//       setStatusMessage({
//         type: "error",
//         message: "Failed to fetch ALM settings",
//       });
//       setAlmSettings({ domain: "", project: "" });
//     } finally {
//       setAlmLoading(false);
//     }
//   };
 
//   // Updated fetchQtestSettings to get only current settings
//   const fetchQtestSettings = async () => {
//     setQtestLoading(true);
//     try {
//       const res = await axios.get("http://localhost:5550/api/settings/settings");
//       console.log("Fetched qTest Settings:", res.data);
 
//       let currentSettings = null;
 
//       // Find the current settings from the array
//       if (Array.isArray(res.data)) {
//         currentSettings = res.data.find(setting =>
//           setting.is_current === 1 ||
//           setting.is_current === true ||
//           setting.is_current === "1"
//         );
//       } else if (res.data && (res.data.is_current === 1 || res.data.is_current === true)) {
//         currentSettings = res.data;
//       }
 
//       if (currentSettings) {
//         setQtestSettings({
//           projectId: currentSettings.projectId || "",
//         });
//       } else {
//         // No current settings found
//         setQtestSettings({ projectId: "" });
//         console.log("No current qTest settings found");
//       }
//     } catch (err) {
//       console.error("qTest Fetch error:", err);
//       setStatusMessage({
//         type: "error",
//         message: "Failed to fetch qTest settings",
//       });
//       setQtestSettings({ projectId: "" });
//     } finally {
//       setQtestLoading(false);
//     }
//   };
 
//   // Corrected checkNameExists function
//   const checkNameExists = async (name) => {
//     setCheckingName(true);
//     try {
//       const response = await axios.get(`http://localhost:5550/api/settings/check-name/${encodeURIComponent(name)}`);
//       setNameExists(response.data.exists);
 
//       // If you need to fetch linkname from current settings, do it here
//       const res = await axios.get("http://localhost:5550/api/settings/settings");
//       let currentSettings = null;
 
//       // Find the current settings from the array
//       if (Array.isArray(res.data)) {
//         currentSettings = res.data.find(setting =>
//           setting.is_current === 1 ||
//           setting.is_current === true ||
//           setting.is_current === "1"
//         );
//       } else if (res.data && (res.data.is_current === 1 || res.data.is_current === true)) {
//         currentSettings = res.data;
//       }
 
//       if (currentSettings) {
//         setLinkName({
//           linkname: currentSettings.linkname || currentSettings.link_name || "",
//         });
//       } else {
//         // No current settings found
//         setLinkName({ linkname: "" });
//         console.log("No current link name found");
//       }
//     } catch (err) {
//       console.error("Error checking name:", err);
//       setNameExists(false);
//       setLinkName({ linkname: "" });
//     } finally {
//       setCheckingName(false);
//     }
//   };
 
 
//   // Alternative: Combined function to fetch both settings in one call
//   const fetchCurrentSettings = async () => {
//     setAlmLoading(true);
//     setQtestLoading(true);
 
//     try {
//       const res = await axios.get("http://localhost:5550/api/settings/settings");
//       console.log("Fetched Current Settings:", res.data);
 
//       let currentSettings = null;
 
//       // Find the current settings from the array
//       if (Array.isArray(res.data)) {
//         currentSettings = res.data.find(setting =>
//           setting.is_current === 1 ||
//           setting.is_current === true ||
//           setting.is_current === "1"
//         );
//       } else if (res.data && (res.data.is_current === 1 || res.data.is_current === true)) {
//         currentSettings = res.data;
//       }
 
//       if (currentSettings) {
//         // Set both ALM and qTest settings from current configuration
//         setAlmSettings({
//           domain: currentSettings.domain || "",
//           project: currentSettings.project || "",
//         });
 
//         setQtestSettings({
//           projectId: currentSettings.projectId || "",
//         });
 
//         // Set link name
//         setLinkName({
//           linkname: currentSettings.linkname || currentSettings.link_name || "",
//         });
 
//         console.log("Current settings loaded:", currentSettings.link_name);
//       } else {
//         // No current settings found
//         setAlmSettings({ domain: "", project: "" });
//         setQtestSettings({ projectId: "" });
//         setLinkName({ linkname: "" });
 
//         setStatusMessage({
//           type: "warning",
//           message: "No current configuration found. Please set a configuration as current in Settings.",
//         });
//       }
//     } catch (err) {
//       console.error("Settings Fetch error:", err);
//       setStatusMessage({
//         type: "error",
//         message: "Failed to fetch current settings",
//       });
//       setAlmSettings({ domain: "", project: "" });
//       setQtestSettings({ projectId: "" });
//       setLinkName({ linkname: "" });
//     } finally {
//       setAlmLoading(false);
//       setQtestLoading(false);
//     }
//   };
 
//   // Usage in useEffect - choose one of these options:
 
//   // Option 1: Separate calls
//   useEffect(() => {
//     fetchAlmSettings();
//     fetchQtestSettings();
//   }, []);
 
//   // Option 2: Combined call (recommended to avoid duplicate API calls)
//   useEffect(() => {
//     fetchCurrentSettings();
//   }, []);
 
 
//   return (
//     <div>
//       <Sidebar />
//       <Topbar />
//       <ToastContainer />
 
//         <div className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl p-6 border border-white/20 mt-28 w-[1000px] ml-[440px]">
//             <h2 className="text-xl font-semibold text-gray-900 mb-4">Current Configuration</h2>
 
//             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
//               {(almSettings.domain || almSettings.project) && (
//                 <div className="bg-gradient-to-br from-blue-50 to-indigo-50 p-4 rounded-xl border border-blue-200">
//                   <h3 className="font-semibold text-blue-900 mb-2 flex items-center gap-2">
//                     <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
//                     </svg>
//                     ALM Project Information
//                   </h3>
//                   <p className="text-gray-700"><strong>Domain:</strong> {almSettings.domain}</p>
//                   <p className="text-gray-700"><strong>Project:</strong> {almSettings.project}</p>
//                 </div>
//               )}
 
//               {qtestSettings.projectId && (
//                 <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-4 rounded-xl border border-green-200">
//                   <h3 className="font-semibold text-green-900 mb-2 flex items-center gap-2">
//                     <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
//                     </svg>
//                     qTest Project Information
//                   </h3>
//                   <p className="text-gray-700"><strong>Project ID:</strong> {qtestSettings.projectId}</p>
//                 </div>
//               )}
 
//               {linkName.linkname && (
//                 <div className="bg-gradient-to-br from-purple-50 to-violet-50 p-4 rounded-xl border border-purple-200">
//                   <h3 className="font-semibold text-purple-900 mb-2 flex items-center gap-2">
//                     <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
//                     </svg>
//                     Link Information
//                   </h3>
//                   <p className="text-gray-700"><strong>Link Name:</strong> {linkName.linkname}</p>
//                 </div>
//               )}
 
//               {!almSettings.domain && !almSettings.project && !qtestSettings.projectId && (
//                 <div className="col-span-full bg-gradient-to-br from-yellow-50 to-amber-50 p-6 rounded-xl border border-yellow-200">
//                   <div className="flex items-center gap-3">
//                     <svg className="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.732-.833-2.5 0L4.732 15.5c-.77.833.192 2.5 1.732 2.5z" />
//                     </svg>
//                     <div>
//                       <h3 className="font-semibold text-yellow-900">No Current Configuration</h3>
//                       <p className="text-yellow-800">Please go to Settings and set a configuration as current.</p>
//                     </div>
//                   </div>
//                 </div>
//               )}
//             </div>
//           </div>
 
 
//       <div className="lg:mt-[90px] mt-[110px] lg:ml-[330px] space-y-8 p-4 lg:p-6">
//         <div className="text-2xl font-semibold text-gray-800">Link ALM Artifacts</div>
 
//         <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
//           <button
//             onClick={linkReleaseToRequirement}
//             className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-xl shadow-lg transition-all"
//           >
//             Link Release to Requirement
//           </button>
 
//           <button
//             onClick={linkRequirementToTestCase}
//             className="bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-6 rounded-xl shadow-lg transition-all"
//           >
//             Link Requirement to Test Case
//           </button>
 
//           <button
//             onClick={linkDefect}
//             className="bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 px-6 rounded-xl shadow-lg transition-all"
//           >
//             Link Defects
//           </button>
//         </div>
//       </div>
//       <div className="lg:mt-[90px] mt-[110px] lg:ml-[330px] space-y-8 p-4 lg:p-6">
//         <div className="text-2xl font-semibold text-gray-800">Attachments</div>
 
//         <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
//           <button
//             onClick={RequirementAttachments}
//             className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-xl shadow-lg transition-all"
//           >
//             Requirements Attachments
//           </button>
 
//           <button
//             onClick={TestCaseAttachments}
//             className="bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-6 rounded-xl shadow-lg transition-all"
//           >
//             TestCase Attachments
//           </button>
 
//            <button
//             onClick={TestCaseStepAttachments}
//             className="bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 px-6 rounded-xl shadow-lg transition-all"
//           >
//             TestCaseSteps Attachments
//           </button>
//           <button
//             onClick={TestLogAttachments}
//             className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-xl shadow-lg transition-all"
//           >
//             TestLog Attachments
//           </button>
 
//           <button
//             onClick={TestLogStepAttachments}
//             className="bg-green-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-xl shadow-lg transition-all"
//           >
//             TestLogStep Attachments
//           </button>
 
//           <button
//             onClick={DefectAttachments}
//             className="bg-purple-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-xl shadow-lg transition-all"
//           >
//             Defects Attachments
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// };
 
// export default LinkPage;
 

 
// import React from "react";
// import { useState, useEffect } from "react";
// import Sidebar from "../components/Sidebar";
// import Topbar from "../components/Topbar";
// import axios from "axios";
// import { toast, ToastContainer } from "react-toastify";
// import "react-toastify/dist/ReactToastify.css";
 
// const LinkPage = () => {
//   const linkReleaseToRequirement = async () => {
//     try {
//       const res = await axios.post("http://localhost:5550/api/link-release-to-req");
//       toast.success(res.data.message || "Linked Release to Requirement successfully!");
//     } catch (err) {
//       toast.error(err.response?.data?.message || "Failed to link Release to Requirement");
//     }
//   };
 
//   const linkRequirementToTestCase = async () => {
//     try {
//       const res = await axios.post("http://localhost:5550/api/link-req-to-test");
//       toast.success(res.data.message || "Linked Requirement to Test Case successfully!");
//     } catch (err) {
//       toast.error(err.response?.data?.message || "Failed to link Requirement to Test Case");
//     }
//   };
 
//   const linkDefect = async () => {
//     try {
//       const res = await axios.post("http://localhost:5550/api/link-defects");
//       toast.success(res.data.message || "Defect linking completed successfully!");
//     } catch (err) {
//       toast.error(err.response?.data?.message || "Failed to link defects");
//     }
//   };
 
//   const RequirementAttachments = async () => {
//     try {
//       const res = await axios.post("http://localhost:5550/api/attach/RequirementAttachments");
//       toast.success(res.data.message || "Requirements Attach Successfully!");
//     } catch (err) {
//       toast.error(err.response?.data?.message || "Fail to attach");
//     }
//   };
 
//   const TestCaseAttachments = async () => {
//     try {
//       const res = await axios.post("http://localhost:5550/api/attach/TestCaseAttachments");
//       toast.success(res.data.message || "TC Attach Successfully!");
//     } catch (err) {
//       toast.error(err.response?.data?.message || "Fail to attach");
//     }
//   };
 
//   const TestCaseStepAttachments = async () => {
//     try {
//       const res = await axios.post("http://localhost:5550/api/attach/TestCaseStepAttachments");
//       toast.success(res.data.message || "TC Steps Attach Successfully!");
//     } catch (err) {
//       toast.error(err.response?.data?.message || "Fail to attach");
//     }
//   };
 
//   const DefectAttachments = async () => {
//     try {
//       const res = await axios.post("http://localhost:5550/api/attach/DefectAttachments");
//       toast.success(res.data.message || "Defects Attach Successfully!");
//     } catch (err) {
//       toast.error(err.response?.data?.message || "Fail to attach");
//     }
//   };
 
//   const TestLogAttachments = async () => {
//     try {
//       const res = await axios.post("http://localhost:5550/api/attach/TestLogAttachments");
//       toast.success(res.data.message || "TestLog Attach Successfully!");
//     } catch (err) {
//       toast.error(err.response?.data?.message || "Fail to attach");
//     }
//   };
 
//   const TestLogStepAttachments = async () => {
//     try {
//       const res = await axios.post("http://localhost:5550/api/attach/TestLogStepAttachments");
//       toast.success(res.data.message || "TestLogStep Attach Successfully!");
//     } catch (err) {
//       toast.error(err.response?.data?.message || "Fail to attach");
//     }
//   };
 
//   // State management
//   const [almSettings, setAlmSettings] = useState({ domain: "", project: "" });
//   const [qtestSettings, setQtestSettings] = useState({ projectId: "" });
//   const [linkName, setLinkName] = useState({ linkname: "" });
//   const [almLoading, setAlmLoading] = useState(false);
//   const [qtestLoading, setQtestLoading] = useState(false);
//   const [checkingName, setCheckingName] = useState(false);
//   const [nameExists, setNameExists] = useState(false);
//   const [statusMessage, setStatusMessage] = useState(null);
 
//   // Fetch current settings
//   const fetchCurrentSettings = async () => {
//     setAlmLoading(true);
//     setQtestLoading(true);
 
//     try {
//       const res = await axios.get("http://localhost:5550/api/settings/settings");
//       console.log("Fetched Current Settings:", res.data);
 
//       let currentSettings = null;
 
//       if (Array.isArray(res.data)) {
//         currentSettings = res.data.find(setting =>
//           setting.is_current === 1 ||
//           setting.is_current === true ||
//           setting.is_current === "1"
//         );
//       } else if (res.data && (res.data.is_current === 1 || res.data.is_current === true)) {
//         currentSettings = res.data;
//       }
 
//       if (currentSettings) {
//         setAlmSettings({
//           domain: currentSettings.domain || "",
//           project: currentSettings.project || "",
//         });
 
//         setQtestSettings({
//           projectId: currentSettings.projectId || "",
//         });
 
//         setLinkName({
//           linkname: currentSettings.linkname || currentSettings.link_name || "",
//         });
 
//         console.log("Current settings loaded:", currentSettings.link_name);
//       } else {
//         setAlmSettings({ domain: "", project: "" });
//         setQtestSettings({ projectId: "" });
//         setLinkName({ linkname: "" });
 
//         setStatusMessage({
//           type: "warning",
//           message: "No current configuration found. Please set a configuration as current in Settings.",
//         });
//       }
//     } catch (err) {
//       console.error("Settings Fetch error:", err);
//       setStatusMessage({
//         type: "error",
//         message: "Failed to fetch current settings",
//       });
//       setAlmSettings({ domain: "", project: "" });
//       setQtestSettings({ projectId: "" });
//       setLinkName({ linkname: "" });
//     } finally {
//       setAlmLoading(false);
//       setQtestLoading(false);
//     }
//   };
 
//   useEffect(() => {
//     fetchCurrentSettings();
//   }, []);
 
//   return (
//     <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
//       <Sidebar />
//       <Topbar />
//       <ToastContainer position="top-right" className="mt-16" />
 
//       {/* Main Content Container */}
//       <div className="lg:ml-80 pt-20 px-4 lg:px-8 pb-8">
//         {/* Header Section */}
//         <div className="mb-8">
//           <div className="flex items-center gap-3 mb-2">
//             <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
//               <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
//               </svg>
//             </div>
//             <div>
//               <h1 className="text-3xl font-bold text-gray-900">ALM Integration Hub</h1>
//               <p className="text-gray-600">Manage artifact linking and attachments</p>
//             </div>
//           </div>
//         </div>
 
//         {/* Current Configuration Card */}
//         <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl p-8 border border-white/20 mb-8">
//           <div className="flex items-center gap-3 mb-6">
//             <div className="w-8 h-8 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-lg flex items-center justify-center">
//               <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
//                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
//               </svg>
//             </div>
//             <h2 className="text-2xl font-bold text-gray-900">Current Configuration</h2>
//           </div>
 
//           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
//             {(almSettings.domain || almSettings.project) && (
//               <div className="group bg-gradient-to-br from-blue-50 to-indigo-100 p-6 rounded-2xl border border-blue-200/50 hover:shadow-lg transition-all duration-300">
//                 <div className="flex items-center gap-3 mb-4">
//                   <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
//                     <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
//                     </svg>
//                   </div>
//                   <h3 className="font-bold text-blue-900">ALM Project</h3>
//                 </div>
//                 <div className="space-y-2">
//                   <p className="text-sm text-blue-800"><span className="font-semibold">Domain:</span> {almSettings.domain}</p>
//                   <p className="text-sm text-blue-800"><span className="font-semibold">Project:</span> {almSettings.project}</p>
//                 </div>
//               </div>
//             )}
 
//             {qtestSettings.projectId && (
//               <div className="group bg-gradient-to-br from-emerald-50 to-green-100 p-6 rounded-2xl border border-emerald-200/50 hover:shadow-lg transition-all duration-300">
//                 <div className="flex items-center gap-3 mb-4">
//                   <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
//                     <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
//                     </svg>
//                   </div>
//                   <h3 className="font-bold text-emerald-900">qTest Project</h3>
//                 </div>
//                 <div className="space-y-2">
//                   <p className="text-sm text-emerald-800"><span className="font-semibold">Project ID:</span> {qtestSettings.projectId}</p>
//                 </div>
//               </div>
//             )}
 
//             {linkName.linkname && (
//               <div className="group bg-gradient-to-br from-purple-50 to-violet-100 p-6 rounded-2xl border border-purple-200/50 hover:shadow-lg transition-all duration-300">
//                 <div className="flex items-center gap-3 mb-4">
//                   <div className="w-10 h-10 bg-purple-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
//                     <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
//                     </svg>
//                   </div>
//                   <h3 className="font-bold text-purple-900">Link Configuration</h3>
//                 </div>
//                 <div className="space-y-2">
//                   <p className="text-sm text-purple-800"><span className="font-semibold">Link Name:</span> {linkName.linkname}</p>
//                 </div>
//               </div>
//             )}
 
//             {!almSettings.domain && !almSettings.project && !qtestSettings.projectId && (
//               <div className="col-span-full bg-gradient-to-br from-amber-50 to-orange-100 p-8 rounded-2xl border border-amber-200/50">
//                 <div className="flex items-center gap-4">
//                   <div className="w-12 h-12 bg-amber-500 rounded-full flex items-center justify-center">
//                     <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.732-.833-2.5 0L4.732 15.5c-.77.833.192 2.5 1.732 2.5z" />
//                     </svg>
//                   </div>
//                   <div>
//                     <h3 className="font-bold text-amber-900 text-lg">No Current Configuration</h3>
//                     <p className="text-amber-800">Please navigate to Settings and set a configuration as current to begin.</p>
//                   </div>
//                 </div>
//               </div>
//             )}
//           </div>
//         </div>
 
//         {/* ALM Artifact Linking Section */}
//         <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl p-8 border border-white/20 mb-8">
//           <div className="flex items-center gap-3 mb-6">
//             <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
//               <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.111 16.404a5.5 5.5 0 017.778 0M12 20h.01m-7.08-7.071c3.904-3.905 10.236-3.905 14.141 0M1.394 9.393c5.857-5.857 15.355-5.857 21.213 0" />
//               </svg>
//             </div>
//             <h2 className="text-2xl font-bold text-gray-900">ALM Artifact Linking</h2>
//           </div>
 
//           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
//             <button
//               onClick={linkReleaseToRequirement}
//               className="group bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-semibold py-4 px-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
//             >
//               <div className="flex items-center gap-3">
//                 <svg className="w-5 h-5 group-hover:scale-110 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
//                 </svg>
//                 <span>Release → Requirement</span>
//               </div>
//             </button>
 
//             <button
//               onClick={linkRequirementToTestCase}
//               className="group bg-gradient-to-r from-emerald-600 to-green-700 hover:from-emerald-700 hover:to-green-800 text-white font-semibold py-4 px-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
//             >
//               <div className="flex items-center gap-3">
//                 <svg className="w-5 h-5 group-hover:scale-110 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
//                 </svg>
//                 <span>Requirement → Test Case</span>
//               </div>
//             </button>
 
//             <button
//               onClick={linkDefect}
//               className="group bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700 text-white font-semibold py-4 px-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
//             >
//               <div className="flex items-center gap-3">
//                 <svg className="w-5 h-5 group-hover:scale-110 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.732-.833-2.5 0L4.732 15.5c-.77.833.192 2.5 1.732 2.5z" />
//                 </svg>
//                 <span>Link Defects</span>
//               </div>
//             </button>
//           </div>
//         </div>
 
//         {/* Attachments Section */}
//         <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl p-8 border border-white/20">
//           <div className="flex items-center gap-3 mb-6">
//             <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg flex items-center justify-center">
//               <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
//               </svg>
//             </div>
//             <h2 className="text-2xl font-bold text-gray-900">Attachment Management</h2>
//           </div>
 
//           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
//             <button
//               onClick={RequirementAttachments}
//               className="group bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white font-semibold py-4 px-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
//             >
//               <div className="flex items-center gap-3">
//                 <svg className="w-5 h-5 group-hover:scale-110 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
//                 </svg>
//                 <span>Requirements</span>
//               </div>
//             </button>
 
//             <button
//               onClick={TestCaseAttachments}
//               className="group bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white font-semibold py-4 px-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
//             >
//               <div className="flex items-center gap-3">
//                 <svg className="w-5 h-5 group-hover:scale-110 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
//                 </svg>
//                 <span>Test Cases</span>
//               </div>
//             </button>
 
//             <button
//               onClick={TestCaseStepAttachments}
//               className="group bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700 text-white font-semibold py-4 px-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
//             >
//               <div className="flex items-center gap-3">
//                 <svg className="w-5 h-5 group-hover:scale-110 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
//                 </svg>
//                 <span>Test Case Steps</span>
//               </div>
//             </button>
 
//             <button
//               onClick={TestLogAttachments}
//               className="group bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white font-semibold py-4 px-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
//             >
//               <div className="flex items-center gap-3">
//                 <svg className="w-5 h-5 group-hover:scale-110 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
//                 </svg>
//                 <span>Test Logs</span>
//               </div>
//             </button>
 
//             <button
//               onClick={TestLogStepAttachments}
//               className="group bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white font-semibold py-4 px-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
//             >
//               <div className="flex items-center gap-3">
//                 <svg className="w-5 h-5 group-hover:scale-110 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
//                 </svg>
//                 <span>Test Log Steps</span>
//               </div>
//             </button>
 
//             <button
//               onClick={DefectAttachments}
//               className="group bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-700 hover:to-pink-700 text-white font-semibold py-4 px-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
//             >
//               <div className="flex items-center gap-3">
//                 <svg className="w-5 h-5 group-hover:scale-110 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.732-.833-2.5 0L4.732 15.5c-.77.833.192 2.5 1.732 2.5z" />
//                 </svg>
//                 <span>Defects</span>
//               </div>
//             </button>
//           </div>
//         </div>
 
//         {/* Status Message */}
//         {statusMessage && (
//           <div className={`mt-6 p-4 rounded-2xl ${
//             statusMessage.type === 'error'
//               ? 'bg-red-50 border border-red-200 text-red-800'
//               : 'bg-yellow-50 border border-yellow-200 text-yellow-800'
//           }`}>
//             <div className="flex items-center gap-3">
//               <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
//               </svg>
//               <span className="font-medium">{statusMessage.message}</span>
//             </div>
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };
 
// export default LinkPage;
 


import React from "react";
import { useState, useEffect } from "react";
import Sidebar from "../components/Sidebar";
import Topbar from "../components/Topbar";
import axios from "axios";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const LinkPage = () => {
  // Loading and status states for each button
  const [buttonStates, setButtonStates] = useState({
    linkReleaseToReq: { loading: false, status: null }, // null, 'success', 'error'
    linkReqToTest: { loading: false, status: null },
    linkDefects: { loading: false, status: null },
    requirementAttachments: { loading: false, status: null },
    testCaseAttachments: { loading: false, status: null },
    testCaseStepAttachments: { loading: false, status: null },
    defectAttachments: { loading: false, status: null },
    testLogAttachments: { loading: false, status: null },
    testLogStepAttachments: { loading: false, status: null },
  });

  const setButtonState = (buttonKey, loading, status = null) => {
    setButtonStates(prev => ({ 
      ...prev, 
      [buttonKey]: { loading, status } 
    }));
  };

  // Reset status after showing for a few seconds
  const resetButtonStatus = (buttonKey) => {
    setTimeout(() => {
      setButtonStates(prev => ({
        ...prev,
        [buttonKey]: { ...prev[buttonKey], status: null }
      }));
    }, 3000);
  };

  const linkReleaseToRequirement = async () => {
    setButtonState('linkReleaseToReq', true);
    try {
      const res = await axios.post("http://localhost:5550/api/link-release-to-req");
      toast.success(res.data.message || "Linked Release to Requirement successfully!");
      setButtonState('linkReleaseToReq', false, 'success');
      resetButtonStatus('linkReleaseToReq');
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to link Release to Requirement");
      setButtonState('linkReleaseToReq', false, 'error');
      resetButtonStatus('linkReleaseToReq');
    }
  };

  const linkRequirementToTestCase = async () => {
    setButtonState('linkReqToTest', true);
    try {
      const res = await axios.post("http://localhost:5550/api/link-req-to-test");
      toast.success(res.data.message || "Linked Requirement to Test Case successfully!");
      setButtonState('linkReqToTest', false, 'success');
      resetButtonStatus('linkReqToTest');
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to link Requirement to Test Case");
      setButtonState('linkReqToTest', false, 'error');
      resetButtonStatus('linkReqToTest');
    }
  };

  const linkDefect = async () => {
    setButtonState('linkDefects', true);
    try {
      const res = await axios.post("http://localhost:5550/api/link-defects");
      toast.success(res.data.message || "Defect linking completed successfully!");
      setButtonState('linkDefects', false, 'success');
      resetButtonStatus('linkDefects');
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to link defects");
      setButtonState('linkDefects', false, 'error');
      resetButtonStatus('linkDefects');
    }
  };

  const RequirementAttachments = async () => {
    setButtonState('requirementAttachments', true);
    try {
      const res = await axios.post("http://localhost:5550/api/attach/RequirementAttachments");
      toast.success(res.data.message || "Requirements Attach Successfully!");
      setButtonState('requirementAttachments', false, 'success');
      resetButtonStatus('requirementAttachments');
    } catch (err) {
      toast.error(err.response?.data?.message || "Fail to attach");
      setButtonState('requirementAttachments', false, 'error');
      resetButtonStatus('requirementAttachments');
    }
  };

  const TestCaseAttachments = async () => {
    setButtonState('testCaseAttachments', true);
    try {
      const res = await axios.post("http://localhost:5550/api/attach/TestCaseAttachments");
      toast.success(res.data.message || "TC Attach Successfully!");
      setButtonState('testCaseAttachments', false, 'success');
      resetButtonStatus('testCaseAttachments');
    } catch (err) {
      toast.error(err.response?.data?.message || "Fail to attach");
      setButtonState('testCaseAttachments', false, 'error');
      resetButtonStatus('testCaseAttachments');
    }
  };

  const TestCaseStepAttachments = async () => {
    setButtonState('testCaseStepAttachments', true);
    try {
      const res = await axios.post("http://localhost:5550/api/attach/TestCaseStepAttachments");
      toast.success(res.data.message || "TC Steps Attach Successfully!");
      setButtonState('testCaseStepAttachments', false, 'success');
      resetButtonStatus('testCaseStepAttachments');
    } catch (err) {
      toast.error(err.response?.data?.message || "Fail to attach");
      setButtonState('testCaseStepAttachments', false, 'error');
      resetButtonStatus('testCaseStepAttachments');
    }
  };

  const DefectAttachments = async () => {
    setButtonState('defectAttachments', true);
    try {
      const res = await axios.post("http://localhost:5550/api/attach/DefectAttachments");
      toast.success(res.data.message || "Defects Attach Successfully!");
      setButtonState('defectAttachments', false, 'success');
      resetButtonStatus('defectAttachments');
    } catch (err) {
      toast.error(err.response?.data?.message || "Fail to attach");
      setButtonState('defectAttachments', false, 'error');
      resetButtonStatus('defectAttachments');
    }
  };

  const TestLogAttachments = async () => {
    setButtonState('testLogAttachments', true);
    try {
      const res = await axios.post("http://localhost:5550/api/attach/TestLogAttachments");
      toast.success(res.data.message || "TestLog Attach Successfully!");
      setButtonState('testLogAttachments', false, 'success');
      resetButtonStatus('testLogAttachments');
    } catch (err) {
      toast.error(err.response?.data?.message || "Fail to attach");
      setButtonState('testLogAttachments', false, 'error');
      resetButtonStatus('testLogAttachments');
    }
  };

  const TestLogStepAttachments = async () => {
    setButtonState('testLogStepAttachments', true);
    try {
      const res = await axios.post("http://localhost:5550/api/attach/TestLogStepAttachments");
      toast.success(res.data.message || "TestLogStep Attach Successfully!");
      setButtonState('testLogStepAttachments', false, 'success');
      resetButtonStatus('testLogStepAttachments');
    } catch (err) {
      toast.error(err.response?.data?.message || "Fail to attach");
      setButtonState('testLogStepAttachments', false, 'error');
      resetButtonStatus('testLogStepAttachments');
    }
  };

  // Loading Spinner Component
  const LoadingSpinner = ({ size = "w-5 h-5" }) => (
    <svg className={`${size} animate-spin`} fill="none" viewBox="0 0 24 24">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
    </svg>
  );

  // Success Check Icon
  const SuccessIcon = ({ size = "w-5 h-5" }) => (
    <svg className={`${size} text-white animate-pulse`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
    </svg>
  );

  // Error X Icon
  const ErrorIcon = ({ size = "w-5 h-5" }) => (
    <svg className={`${size} text-white animate-pulse`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
    </svg>
  );

  // Action Button Component
  const ActionButton = ({ 
    onClick, 
    buttonKey,
    children, 
    gradientFrom, 
    gradientTo, 
    hoverFrom, 
    hoverTo,
    icon 
  }) => {
    const buttonState = buttonStates[buttonKey];
    const { loading, status } = buttonState;

    // Dynamic button styling based on state
    let buttonClasses = `group relative overflow-hidden font-semibold py-4 px-6 rounded-2xl shadow-lg transition-all duration-300 min-h-[60px] flex items-center justify-center `;
    
    if (loading) {
      buttonClasses += `bg-gradient-to-r ${gradientFrom} ${gradientTo} opacity-80 cursor-not-allowed`;
    } else if (status === 'success') {
      buttonClasses += `bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 hover:shadow-xl transform hover:-translate-y-1`;
    } else if (status === 'error') {
      buttonClasses += `bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 hover:shadow-xl transform hover:-translate-y-1`;
    } else {
      buttonClasses += `bg-gradient-to-r ${gradientFrom} ${gradientTo} hover:${hoverFrom} hover:${hoverTo} hover:shadow-xl transform hover:-translate-y-1`;
    }

    buttonClasses += ` text-white`;

    return (
      <button
        onClick={onClick}
        disabled={loading}
        className={buttonClasses}
      >
        <div className="flex items-center gap-3">
          {loading ? (
            <>
              <LoadingSpinner />
              <span>Processing...</span>
            </>
          ) : status === 'success' ? (
            <>
              <SuccessIcon />
              <span>Completed!</span>
            </>
          ) : status === 'error' ? (
            <>
              <ErrorIcon />
              <span>Failed!</span>
            </>
          ) : (
            <>
              <div className="group-hover:scale-110 transition-transform">
                {icon}
              </div>
              <span>{children}</span>
            </>
          )}
        </div>
        
        {/* Animated background overlay */}
        {loading && (
          <div className="absolute inset-0 bg-gradient-to-r from-white/10 to-transparent animate-pulse"></div>
        )}
        {status === 'success' && (
          <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent animate-pulse"></div>
        )}
        {status === 'error' && (
          <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent animate-pulse"></div>
        )}
      </button>
    );
  };

  // State management for settings
  const [almSettings, setAlmSettings] = useState({ domain: "", project: "" });
  const [qtestSettings, setQtestSettings] = useState({ projectId: "" });
  const [linkName, setLinkName] = useState({ linkname: "" });
  const [almLoading, setAlmLoading] = useState(false);
  const [qtestLoading, setQtestLoading] = useState(false);
  const [checkingName, setCheckingName] = useState(false);
  const [nameExists, setNameExists] = useState(false);
  const [statusMessage, setStatusMessage] = useState(null);

  // Fetch current settings
  const fetchCurrentSettings = async () => {
    setAlmLoading(true);
    setQtestLoading(true);

    try {
      const res = await axios.get("http://localhost:5550/api/settings/settings");
      console.log("Fetched Current Settings:", res.data);

      let currentSettings = null;

      if (Array.isArray(res.data)) {
        currentSettings = res.data.find(setting =>
          setting.is_current === 1 ||
          setting.is_current === true ||
          setting.is_current === "1"
        );
      } else if (res.data && (res.data.is_current === 1 || res.data.is_current === true)) {
        currentSettings = res.data;
      }

      if (currentSettings) {
        setAlmSettings({
          domain: currentSettings.domain || "",
          project: currentSettings.project || "",
        });

        setQtestSettings({
          projectId: currentSettings.projectId || "",
        });

        setLinkName({
          linkname: currentSettings.linkname || currentSettings.link_name || "",
        });

        console.log("Current settings loaded:", currentSettings.link_name);
      } else {
        setAlmSettings({ domain: "", project: "" });
        setQtestSettings({ projectId: "" });
        setLinkName({ linkname: "" });

        setStatusMessage({
          type: "warning",
          message: "No current configuration found. Please set a configuration as current in Settings.",
        });
      }
    } catch (err) {
      console.error("Settings Fetch error:", err);
      setStatusMessage({
        type: "error",
        message: "Failed to fetch current settings",
      });
      setAlmSettings({ domain: "", project: "" });
      setQtestSettings({ projectId: "" });
      setLinkName({ linkname: "" });
    } finally {
      setAlmLoading(false);
      setQtestLoading(false);
    }
  };

  useEffect(() => {
    fetchCurrentSettings();
  }, []);

  // Check if any operation is in progress
  const isAnyOperationInProgress = Object.values(buttonStates).some(state => state.loading);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      <Sidebar />
      <Topbar />
      <ToastContainer position="top-right" className="mt-16" />

      {/* Loading Overlay */}
      {isAnyOperationInProgress && (
        <div className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40 flex items-center justify-center">
          <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-8 shadow-2xl border border-white/30">
            <div className="flex flex-col items-center gap-4">
              <LoadingSpinner size="w-12 h-12" />
              <p className="text-gray-700 font-medium">Processing your request...</p>
              <p className="text-gray-500 text-sm">Please wait while we complete the operation</p>
            </div>
          </div>
        </div>
      )}

      {/* Main Content Container */}
      <div className="lg:ml-80 pt-20 px-4 lg:px-8 pb-8">
        {/* Header Section */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
              </svg>
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">ALM Integration Hub</h1>
              <p className="text-gray-600">Manage artifact linking and attachments</p>
            </div>
          </div>
        </div>

        {/* Header and Config Info Section */}
          <div className="relative pt-6 pb-3 px-4 sm:px-6 border border-slate-200/60 mb-10 bg-gradient-to-br from-slate-50 via-white to-slate-50/50 backdrop-blur-sm rounded-2xl shadow-md shadow-slate-100/50 overflow-hidden">
          {/* Background Pattern */}
          <div className="absolute inset-0 bg-gradient-to-br from-blue-50/30 via-transparent to-indigo-50/30"></div>
          <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-blue-100/20 to-indigo-100/20 rounded-full blur-3xl -translate-y-16 translate-x-16"></div>
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-gradient-to-tr from-violet-100/20 to-purple-100/20 rounded-full blur-3xl translate-y-12 -translate-x-12"></div>
          
          <div className="relative z-10">
          
            <div className="mb-3">
            <h2 className="text-lg font-semibold text-slate-900 mb-4 flex items-center gap-3">
  <div className="w-1.5 h-6 bg-gradient-to-b from-blue-500 to-indigo-600 rounded-full shadow-md" />
  <span className="tracking-wide">Active Configuration</span>
</h2>

            </div>
        
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {(almSettings.domain || almSettings.project) && (
                <div className="group relative bg-white/70 backdrop-blur-sm p-4 rounded-xl border border-blue-200/50 shadow-md hover:shadow-lg transition-all duration-300 hover:scale-[1.02] hover:border-blue-300/70">
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-50/50 to-indigo-50/30 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <div className="relative z-10">
                    <h3 className="font-semibold text-blue-900 mb-3 flex items-center gap-2">
                      <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center shadow-md">
                        <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                        </svg>
                      </div>
                      ALM Project Information
                    </h3>
                    <div className="space-y-2">
                      <p className="text-slate-700 text-sm"><span className="text-slate-500">Domain:</span> <span className="text-blue-700 font-medium">{almSettings.domain}</span></p>
                      <p className="text-slate-700 text-sm"><span className="text-slate-500">Project:</span> <span className="text-blue-700 font-medium">{almSettings.project}</span></p>
                    </div>
                  </div>
                </div>
              )}
        
              {qtestSettings.projectId && (
                <div className="group relative bg-white/70 backdrop-blur-sm p-4 rounded-xl border border-emerald-200/50 shadow-md hover:shadow-lg transition-all duration-300 hover:scale-[1.02] hover:border-emerald-300/70">
                  <div className="absolute inset-0 bg-gradient-to-br from-emerald-50/50 to-green-50/30 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <div className="relative z-10">
                    <h3 className="font-semibold text-emerald-900 mb-3 flex items-center gap-2">
                      <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-lg flex items-center justify-center shadow-md">
                        <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 003.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
                        </svg>
                      </div>
                      qTest Project Information
                    </h3>
                    <div className="space-y-2">
                      <p className="text-slate-700 text-sm"><span className="text-slate-500">Project ID:</span> <span className="text-emerald-700 font-medium">{qtestSettings.projectId}</span></p>
                    </div>
                  </div>
                </div>
              )}
        
              {linkName.linkname && (
                <div className="group relative bg-white/70 backdrop-blur-sm p-4 rounded-xl border border-violet-200/50 shadow-md hover:shadow-lg transition-all duration-300 hover:scale-[1.02] hover:border-violet-300/70">
                  <div className="absolute inset-0 bg-gradient-to-br from-violet-50/50 to-purple-50/30 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <div className="relative z-10">
                    <h3 className="font-semibold text-violet-900 mb-3 flex items-center gap-2">
                      <div className="w-8 h-8 bg-gradient-to-br from-violet-500 to-violet-600 rounded-lg flex items-center justify-center shadow-md">
                        <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                        </svg>
                      </div>
                      Link Information
                    </h3>
                    <div className="space-y-2">
                      <p className="text-slate-700 text-sm"><span className="text-slate-500">Link Name:</span> <span className="text-violet-700 font-medium">{linkName.linkname}</span></p>
                    </div>
                  </div>
                </div>
              )}
        
              {!almSettings.domain && !almSettings.project && !qtestSettings.projectId && (
                <div className="col-span-full relative bg-white/70 backdrop-blur-sm p-5 rounded-xl border border-amber-200/50 shadow-md">
                  <div className="absolute inset-0 bg-gradient-to-br from-amber-50/50 to-orange-50/30 rounded-xl"></div>
                  <div className="relative z-10 flex items-center gap-3">
                  <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center shadow-md ring-2 ring-white">
                      <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.732-.833-2.5 0L4.732 15.5c-.77.833.192 2.5 1.732 2.5z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-semibold text-amber-900 mb-1">No Current Configuration</h3>
                      <p className="text-amber-800 text-sm">Please go to Settings and set a configuration as current.</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* ALM Artifact Linking Section */}
        <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl p-8 border border-white/20 mb-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.111 16.404a5.5 5.5 0 017.778 0M12 20h.01m-7.08-7.071c3.904-3.905 10.236-3.905 14.141 0M1.394 9.393c5.857-5.857 15.355-5.857 21.213 0" />
              </svg>
            </div>
            <h2 className="text-2xl font-bold text-gray-900">ALM Artifact Linking</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <ActionButton
              onClick={linkReleaseToRequirement}
              buttonKey="linkReleaseToReq"
              gradientFrom="from-blue-600"
              gradientTo="to-blue-700"
              hoverFrom="hover:from-blue-700"
              hoverTo="hover:to-blue-800"
              icon={
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              }
            >
              Release → Requirement
            </ActionButton>

            <ActionButton
              onClick={linkRequirementToTestCase}
              buttonKey="linkReqToTest"
              gradientFrom="from-emerald-600"
              gradientTo="to-green-700"
              hoverFrom="hover:from-emerald-700"
              hoverTo="hover:to-green-800"
              icon={
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
                </svg>
              }
            >
              Requirement → Test Case
            </ActionButton>

            <ActionButton
              onClick={linkDefect}
              buttonKey="linkDefects"
              gradientFrom="from-red-600"
              gradientTo="to-pink-600"
              hoverFrom="hover:from-red-700"
              hoverTo="hover:to-pink-700"
              icon={
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.732-.833-2.5 0L4.732 15.5c-.77.833.192 2.5 1.732 2.5z" />
                </svg>
              }
            >
              Link Defects
            </ActionButton>
          </div>
        </div>

        {/* Attachments Section */}
        <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl p-8 border border-white/20">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg flex items-center justify-center">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
              </svg>
            </div>
            <h2 className="text-2xl font-bold text-gray-900">Attachment Management</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <ActionButton
              onClick={RequirementAttachments}
              buttonKey="requirementAttachments"
              gradientFrom="from-indigo-600"
              gradientTo="to-blue-600"
              hoverFrom="hover:from-indigo-700"
              hoverTo="hover:to-blue-700"
              icon={
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              }
            >
              Requirements
            </ActionButton>

            <ActionButton
              onClick={TestCaseAttachments}
              buttonKey="testCaseAttachments"
              gradientFrom="from-teal-600"
              gradientTo="to-emerald-600"
              hoverFrom="hover:from-teal-700"
              hoverTo="hover:to-emerald-700"
              icon={
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
                </svg>
              }
            >
              Test Cases
            </ActionButton>

            <ActionButton
              onClick={TestCaseStepAttachments}
              buttonKey="testCaseStepAttachments"
              gradientFrom="from-violet-600"
              gradientTo="to-purple-600"
              hoverFrom="hover:from-violet-700"
              hoverTo="hover:to-purple-700"
              icon={
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                </svg>
              }
            >
              Test Case Steps
            </ActionButton>

            <ActionButton
              onClick={TestLogAttachments}
              buttonKey="testLogAttachments"
              gradientFrom="from-cyan-600"
              gradientTo="to-blue-600"
              hoverFrom="hover:from-cyan-700"
              hoverTo="hover:to-blue-700"
              icon={
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              }
            >
              Test Logs
            </ActionButton>

            <ActionButton
              onClick={TestLogStepAttachments}
              buttonKey="testLogStepAttachments"
              gradientFrom="from-orange-600"
              gradientTo="to-red-600"
              hoverFrom="hover:from-orange-700"
              hoverTo="hover:to-red-700"
              icon={
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                </svg>
              }
            >
              Test Log Steps
            </ActionButton>

            <ActionButton
              onClick={DefectAttachments}
              buttonKey="defectAttachments"
              gradientFrom="from-rose-600"
              gradientTo="to-pink-600"
              hoverFrom="hover:from-rose-700"
              hoverTo="hover:to-pink-700"
              icon={
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.732-.833-2.5 0L4.732 15.5c-.77.833.192 2.5 1.732 2.5z" />
                </svg>
              }
            >
              Defects
            </ActionButton>
          </div>
        </div>

        {/* Status Message */}
        {statusMessage && (
          <div className={`mt-6 p-4 rounded-2xl ${
            statusMessage.type === 'error'
              ? 'bg-red-50 border border-red-200 text-red-800'
              : 'bg-yellow-50 border border-yellow-200 text-yellow-800'
          }`}>
            <div className="flex items-center gap-3">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span className="font-medium">{statusMessage.message}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default LinkPage;