import React, { useState, useEffect, useRef, useCallback } from 'react';
import axios from "axios";
import { Database, Download, Upload, CheckCircle, XCircle, AlertCircle, AlertTriangle, X,  RefreshCw, FileDown, ArrowLeftCircle } from 'lucide-react';
import Topbar from './Topbar';
import Sidebar from "./Sidebar";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Link } from 'react-router-dom';


const Migrate = () => {


  const [almSettings, setAlmSettings] = useState({ domain: "", project: "" });

  const [qtestSettings, setQtestSettings] = useState({ projectId: "" });

  const [linkName, setLinkName] = useState({ linkname: "" });



  // New state for confirmation dialog

  const [showConfirmDialog, setShowConfirmDialog] = useState(false);

  const [confirmationData, setConfirmationData] = useState({});


  //New state for dropdown 
const [selectedLink, setSelectedLink] = useState(null);
const [allLinkConfigs, setAllLinkConfigs] = useState([]);

  const alreadyFetched = useRef(false);


 // 🔽 Fetch current settings once
  useEffect(() => {
    if (!alreadyFetched.current) {
      const fetchInitialData = async () => {
        try {
          const res = await axios.get("http://localhost:5550/api/settings/settings");
          const settings = Array.isArray(res.data) ? res.data : [];
          setAllLinkConfigs(settings);

          const current = settings.find(s =>
            s.is_current === true || s.is_current === 1 || s.is_current === "1"
          );

          if (current) {
            setAlmSettings({ domain: current.domain, project: current.project });
            setQtestSettings({ projectId: current.projectId });
            setLinkName({ linkname: current.linkname || current.link_name });
          } else {
            toast.warn("No current configuration found.");
          }
        } catch (err) {
          console.error("Error fetching settings:", err);
          toast.error("Error loading configurations.");
        }
      };

      fetchInitialData();
      alreadyFetched.current = true;
    }
  }, []);

const fetchCurrentSettingsFor = async (linkname) => {
  try {
    const res = await axios.get(`http://localhost:5550/api/settings/settings/${encodeURIComponent(linkname)}`);
    const config = res.data;

    setAlmSettings({ domain: config.domain, project: config.project });
    setQtestSettings({ projectId: config.projectId });
    setLinkName({ linkname });

    toast.success(`Loaded configuration: ${linkname}`);
  } catch (err) {
    console.error("Failed to fetch selected link config:", err);
    toast.error("Error loading configuration.");
  }
};

const setLinkAsCurrent = async (linkName) => {
  try {
    await axios.put(`http://localhost:5550/api/settings/set-current/${encodeURIComponent(linkName)}`);
    console.log(`${linkName} marked as current.`);
  } catch (err) {
    console.error("Failed to set link as current:", err);
  }
};


  // Alternative: Combined function to fetch both settings in one call

  const fetchCurrentSettings = async () => {

    setAlmLoading(true);

    setQtestLoading(true);



    try {

      const res = await axios.get("http://localhost:5550/api/settings/settings");

      console.log("Fetched Current Settings:", res.data);

      let currentSettings = null;

      // Find the current settings from the array

      if (Array.isArray(res.data)) {

        currentSettings = res.data.find(setting =>

          setting.is_current === 1 ||

          setting.is_current === true ||

          setting.is_current === "1"

        );

      } else if (res.data && (res.data.is_current === 1 || res.data.is_current === true)) {

        currentSettings = res.data;

      }

      if (currentSettings) {

        // Set both ALM and qTest settings from current configuration

        setAlmSettings({

          domain: currentSettings.domain || "",

          project: currentSettings.project || "",

        });



        setQtestSettings({

          projectId: currentSettings.projectId || "",

        });



        // Set link name

        setLinkName({

          linkname: currentSettings.linkname || currentSettings.link_name || "",

        });



        console.log("Current settings loaded:", currentSettings.link_name);

      } else {

        // No current settings found

        setAlmSettings({ domain: "", project: "" });

        setQtestSettings({ projectId: "" });

        setLinkName({ linkname: "" });



        setStatusMessage({

          type: "warning",

          message: "No current configuration found. Please set a configuration as current in Settings.",

        });

      }

    } catch (err) {

      console.error("Settings Fetch error:", err);

      setStatusMessage({

        type: "error",

        message: "Failed to fetch current settings",

      });

      setAlmSettings({ domain: "", project: "" });

      setQtestSettings({ projectId: "" });

      setLinkName({ linkname: "" });

    } finally {

      setAlmLoading(false);

      setQtestLoading(false);

    }

  };

  // State for selected artifacts

  const [selectedArtifacts, setSelectedArtifacts] = useState({

    releases: false,

    requirements: false,

    defects: false,

    testcases: false,

    testruns: false

  });



  // State for custom filters/URLs

  const [customFilters, setCustomFilters] = useState({

    releases: '',

    requirements: '',

    defects: '',

    testcases: '',

    testruns: '',

    testlogs: ''  

  });



  // State for migration progress

  const [isProcessing, setIsProcessing] = useState(false);

  const [migrationResults, setMigrationResults] = useState({});

  const pollRefs = useRef({});

  const [currentOperation, setCurrentOperation] = useState('');

  const [currentlyMigratingArtifact, setCurrentlyMigratingArtifact] = useState('');

  const [migrationStarted, setMigrationStarted] = useState(false);


  // State for migration stats and status

const [migrationStats, setMigrationStats] = useState({
  releases: { total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0 },
  requirements: { total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0 },
  testcases: {
    modules: { total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0 },
    total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0,
    parameters: { total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0 },
    steps: { total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0 }
  },
  testruns: {
    total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0,
    cycle: { total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0 },
    suite: { total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0 },
    logs: { total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0 }
  },
  defects: { total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0 }
});

  const [isMigrating, setIsMigrating] = useState(false);

  const [pollingIntervals, setPollingIntervals] = useState({});

  const [insertSuccess, setInsertSuccess] = useState({});



  // Configuration for each data type

  const dataTypes = {
    releases: {
      title: 'Releases',
      icon: <Database className="w-5 h-5" />,
      fetchEndpoint: '/api/alm/releases',
      insertEndpoint: '/api/releasesupload/releases',
      customEndpoint: '/api/alm/releases/custom',
      migrationEndpoint: '/api/releasesupload/releasesupload',
      statusEndpoint: '/api/releasesupload/migration-status',
      countEndpoint: '/api/releasesupload/releases/count' 
    },
    requirements: {
      title: 'Requirements',
      icon: <Download className="w-5 h-5" />,
      fetchEndpoint: '/api/alm/requirement',
      insertEndpoint: '/api/requirementupload/requirement',
      customEndpoint: '/api/alm/requirement/custom',
      migrationEndpoint: '/api/requirementupload/requirementupload',
      statusEndpoint: '/api/requirementupload/migration-requirement-status',
      countEndpoint: '/api/requirementupload/requirement/count'     },

    testcases: {
      title: 'Test Design',
      icon: <CheckCircle className="w-5 h-5" />,
      fetchEndpoint: '/api/alm/tests',
      insertEndpoint: '/api/testcaseupload/tests',
      customEndpoint: '/api/alm/tests/custom',
      migrationEndpoint: '/api/testcaseupload/testsupload',
      statusEndpoint: '/api/testcaseupload/migrationtestcase-status',
      countEndpoint: '/api/testcaseupload/testcase/count'
    },
    testruns: {
      title: 'Test Execution',
      icon: <Upload className="w-5 h-5" />,
      fetchEndpoint: '/api/alm/testinstance',
      insertEndpoint: '/api/testinstanceupload/testinstance',
      customEndpoint: '/api/alm/testinstance/custom',
      migrationEndpoint: '/api/testinstanceupload/testrunupload',
      statusEndpoint: '/api/testinstanceupload/migrationtestinstance-status',
      countEndpoint: '/api/testinstanceupload/testruns/count'

    },
      defects: {
      title: 'Defects',
      icon: <AlertCircle className="w-5 h-5" />,
      fetchEndpoint: '/api/alm/defects',
      insertEndpoint: '/api/defectsupload/defects',
      customEndpoint: '/api/alm/defects/custom',
      migrationEndpoint: '/api/defectsupload/defectsupload',
      statusEndpoint: '/api/defectsupload/migrationdefects-status',
      countEndpoint: '/api/defectsupload/defects/count'
    }
  };

// Handle checkbox changes

  const handleArtifactSelection = (artifactType) => {

    setSelectedArtifacts(prev => ({

      ...prev,

      [artifactType]: !prev[artifactType]

    }));

  };

  const handleSelectAllArtifacts = () => {
  const allSelected = Object.keys(dataTypes).reduce((acc, key) => {
    acc[key] = true;
    return acc;
  }, {});
  setSelectedArtifacts(allSelected);
};

const handleDeselectAllArtifacts = () => {
  const noneSelected = Object.keys(dataTypes).reduce((acc, key) => {
    acc[key] = false;
    return acc;
  }, {});
  setSelectedArtifacts(noneSelected);
};

  const handleCustomFilterChange = async (artifactType, value) => {
  setCustomFilters(prev => ({
    ...prev,
    [artifactType]: value
  }));
 
  try {
    await axios.post("http://localhost:5550/api/filter/save", {
      filter: value,
      artifact_type: artifactType,
      link_name: linkName.linkname
    });
    console.log(`✅ Filter saved for ${artifactType}`);
  } catch (err) {
    console.error("❌ Failed to save filter:", err);
  }
};

 

const fetchMigrationStatus = async (artifactType) => {
  const config = dataTypes[artifactType];

  try {
    const response = await fetch(`http://localhost:5550${config.statusEndpoint}`);
    if (!response.ok) {
      console.warn(`Failed to fetch status for ${artifactType}: ${response.status}`);
      return null;
    }

    const data = await response.json();
    const rawStats = data[artifactType] || data.counts || {};

    const baseStats = {
      total: Number(rawStats?.total ?? 0),
      success: Number(rawStats?.success ?? 0),
      failed: Number(rawStats?.failed ?? 0),
      skipped: Number(rawStats?.skipped ?? 0),
      updated: Number(rawStats?.updated ?? 0),
      pending: Number(rawStats?.pending ?? 0)
    };

    // ✅ Special logic for testcases
    if (artifactType === 'testcases') {
      try {
        const [moduleRes, paramRes, stepRes] = await Promise.all([
          fetch('http://localhost:5550/api/testcasemodulefieleds/TestCaseModulesreleasesfield/status'),
          fetch('http://localhost:5550/api/parameters/alm/status'),
          fetch('http://localhost:5550/api/step-migration-status')
        ]);

        const [moduleData, paramData, stepData] = await Promise.all([
          moduleRes.ok ? moduleRes.json() : {},
          paramRes.ok ? paramRes.json() : {},
          stepRes.ok ? stepRes.json() : {}
        ]);

        const modulesStats = {
          total: Number(moduleData?.total ?? 0),
          success: Number(moduleData?.success ?? 0),
          failed: Number(moduleData?.failed ?? 0),
          skipped: Number(moduleData?.skipped ?? 0),
          updated: Number(moduleData?.updated ?? 0),
          pending: Number(moduleData?.pending ?? 0)
        };

        const parametersStats = {
          total: Number(paramData?.total ?? paramData?.migratedCount ?? 0),
          success: Number(paramData?.success ?? paramData?.migratedCount ?? 0),
          failed: Number(paramData?.failed ?? 0),
          skipped: Number(paramData?.skipped ?? 0),
          updated: Number(paramData?.updated ?? 0),
          pending: Number(paramData?.pending ?? 0)
        };

        const stepsStats = {
          total: Number(stepData?.total ?? stepData?.stepMigratedCount ?? 0),
          success: Number(stepData?.success ?? stepData?.stepMigratedCount ?? 0),
          failed: Number(stepData?.failed ?? 0),
          skipped: Number(stepData?.skipped ?? 0),
          updated: Number(stepData?.updated ?? 0),
          pending: Number(stepData?.pending ?? 0)
        };

        setMigrationStats(prev => ({
          ...prev,
          testcases: {
            total: baseStats.total,
            success: baseStats.success,
            failed: baseStats.failed,
            skipped: baseStats.skipped,
            updated: baseStats.updated,
            pending: baseStats.pending,
            modules: modulesStats,
            parameters: parametersStats,
            steps: stepsStats
          }
        }));
      } catch (e) {
        console.warn("❌ Internal testcases stats fetch failed", e);
        setMigrationStats(prev => ({
          ...prev,
          testcases: {
            ...baseStats,
            modules: { total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0 },
            parameters: { total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0 },
            steps: { total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0 }
          }
        }));
      }
    }

    // ✅ Special logic for testruns
    else if (artifactType === 'testruns') {
      try {
        const [cycleRes, suiteRes, logsRes] = await Promise.all([
          fetch('http://localhost:5550/api/status'),
          fetch('http://localhost:5550/api/testsetupload/migrationtestset-status'),
          fetch('http://localhost:5550/api/alm-testlog/status')
        ]);

        const [cycleStats, suiteStats, logsStats] = await Promise.all([
          cycleRes.ok ? cycleRes.json() : {},
          suiteRes.ok ? suiteRes.json() : {},
          logsRes.ok ? logsRes.json() : {}
        ]);

        const cycleParsed = {
          total: Number(cycleStats?.total ?? 0),
          success: Number(cycleStats?.success ?? 0),
          failed: Number(cycleStats?.failed ?? 0),
          skipped: Number(cycleStats?.skipped ?? 0),
          updated: Number(cycleStats?.updated ?? 0),
          pending: Number(cycleStats?.pending ?? 0)
        };

        const suiteParsed = {
          total: Number(suiteStats?.total ?? 0),
          success: Number(suiteStats?.success ?? 0),
          failed: Number(suiteStats?.failed ?? 0),
          skipped: Number(suiteStats?.skipped ?? 0),
          updated: Number(suiteStats?.updated ?? 0),
          pending: Number(suiteStats?.pending ?? 0)
        };

        const logsParsed = {
          total: Number(logsStats?.total ?? logsStats?.logCount ?? 0),
          success: Number(logsStats?.success ?? logsStats?.logCount ?? 0),
          failed: Number(logsStats?.failed ?? 0),
          skipped: Number(logsStats?.skipped ?? 0),
          updated: Number(logsStats?.updated ?? 0),
          pending: Number(logsStats?.pending ?? 0)
        };

        setMigrationStats(prev => ({
          ...prev,
          testruns: {
            total: baseStats.total,
            success: baseStats.success,
            failed: baseStats.failed,
            skipped: baseStats.skipped,
            updated: baseStats.updated,
            pending: baseStats.pending,
            cycle: cycleParsed,
            suite: suiteParsed,
            logs: logsParsed
          }
        }));
      } catch (e) {
        console.warn("❌ Internal testruns stats fetch failed", e);
        setMigrationStats(prev => ({
          ...prev,
          testruns: {
            ...baseStats,
            cycle: { total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0 },
            suite: { total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0 },
            logs: { total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0 }
          }
        }));
      }
    }

    // ✅ For requirement and all other artifacts
    else {
      setMigrationStats(prev => ({
        ...prev,
        [artifactType]: {
          total: baseStats.total,
          success: baseStats.success,
          failed: baseStats.failed,
          skipped: baseStats.skipped,
          updated: baseStats.updated,
          pending: baseStats.pending
        }
      }));
    }

    return baseStats;

  } catch (err) {
    console.error(`❌ Error fetching migration status for ${artifactType}:`, err);
    return null;
  }
};


useEffect(() => {
  if (!selectedArtifacts.testcases && !selectedArtifacts.testruns) return;

  const interval = setInterval(() => {
    if (selectedArtifacts.testcases) {
      fetchMigrationStatus('testcases'); 
    }
    if (selectedArtifacts.testruns) {
      fetchMigrationStatus('testruns'); 
    }
  }, 2000); // every 2 seconds

  return () => clearInterval(interval); // Cleanup on unmount
}, [selectedArtifacts.testcases, selectedArtifacts.testruns]);



// Add this new function before the migrateArtifact function
const initializeMigrationStats = (artifactType) => {
  if (artifactType === 'testcases') {
    setMigrationStats(prev => ({
      ...prev,
      testcases: {
        total: prev.testcases?.total || 0,
        success: prev.testcases?.success || 0,
        failed: prev.testcases?.failed || 0,
        pending: prev.testcases?.pending || 0,
        modules: prev.testcases?.modules || { total: 0, success: 0, failed: 0, pending: 0 },
        parameters: prev.testcases?.parameters || { total: 0, success: 0, failed: 0, pending: 0 },
        steps: prev.testcases?.steps || { total: 0, success: 0, failed: 0, pending: 0 }
      }
    }));
  } else if (artifactType === 'testruns') {
    setMigrationStats(prev => ({
      ...prev,
      testruns: {
        total: prev.testruns?.total || 0,
        success: prev.testruns?.success || 0,
        failed: prev.testruns?.failed || 0,
        pending: prev.testruns?.pending || 0,
        cycle: prev.testruns?.cycle || { total: 0, success: 0, failed: 0, pending: 0 },
        suite: prev.testruns?.suite || { total: 0, success: 0, failed: 0, pending: 0 },
        logs: prev.testruns?.logs || { total: 0, success: 0, failed: 0, pending: 0 }
      }
    }));
  }
};

const triggerAndToast = async (endpoint, label, method = 'POST') => {
  setCurrentOperation(`Migrating ${label}...`);
  const response = await fetch(`http://localhost:5550${endpoint}`, {
    method,
    headers: { 'Content-Type': 'application/json' }
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`${label} migration failed - HTTP ${response.status}: ${errorText}`);
  }

  const result = await response.json();
  toast.success(result.message || `${label} migrated successfully!`);
};

const pollUntilComplete = useCallback((artifactType) => {
  if (pollRefs.current[artifactType]) {
    console.log(`⏭️ Polling already running for ${artifactType}, skipping duplicate`);
    return;
  }

  console.log(`🚀 Starting polling for ${artifactType}`);
  pollRefs.current[artifactType] = setInterval(async () => {
    const stats = await fetchMigrationStatus(artifactType);
    if (!stats) return;

    const { total = 0, success = 0, failed = 0, skipped = 0, updated = 0 } = stats;
    console.log(`🔄 Polling ${artifactType} | Total: ${total}, Success: ${success}, Failed: ${failed}, Skipped: ${skipped}, Updated: ${updated}`);

    // ✅ Completion condition: success + failed + skipped + updated
    if ((success + failed + skipped + updated >= total) || total === 0) {
      clearInterval(pollRefs.current[artifactType]);
      delete pollRefs.current[artifactType];
      console.log(`🛑 Polling stopped for ${artifactType}`);

      // Ensure final stats are reflected in state
      setMigrationStats(prev => ({
        ...prev,
        [artifactType]: {
          ...(prev[artifactType] || {}),
          total,
          success,
          failed,
          skipped,
          updated,
          pending: Math.max(0, total - (success + failed + skipped + updated))
        }
      }));

      // ✅ This still ensures polling stops after last artifact finishes
      if (Object.keys(pollRefs.current).length === 0) {
        console.log("🎉 All artifacts completed migration!");
        setCurrentlyMigratingArtifact("");
        setIsMigrating(false);
        toast.success("All selected artifacts migrated successfully!");
      }
    }
  }, 2000);
}, [fetchMigrationStatus]);



// Updated fetchAndInsertArtifact function with proper custom filter handling
  const fetchAndInsertArtifact = async (artifactType) => {
    const config = dataTypes[artifactType];
    const customUrl = customFilters[artifactType];
 
    try {
      setCurrentOperation(`Fetching ${config.title}...`);
      let response;
 
      if (customUrl && customUrl.trim().length > 0) {
        response = await fetch(`http://localhost:5550${config.customEndpoint}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ customReleaseUrl: customUrl.trim() })
        });
        console.log(`Using custom URL for ${artifactType}:`, customUrl.trim());
      } else {
        response = await fetch(`http://localhost:5550${config.fetchEndpoint}`, {
          method: 'GET'
        });
        console.log(`Using default endpoint for ${artifactType}`);
      }
 
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP ${response.status}: ${errorText || response.statusText}`);
      }
 
      const fetchResult = await response.json();
      console.log(`${config.title} fetch result:`, fetchResult);
 
      setCurrentOperation(`Inserting ${config.title}...`);
      const insertResponse = await fetch(`http://localhost:5550${config.insertEndpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
 
      if (!insertResponse.ok) {
        const errorText = await insertResponse.text();
        throw new Error(`Insert failed - HTTP ${insertResponse.status}: ${errorText || insertResponse.statusText}`);
      }
 
      const insertResult = await insertResponse.json();
      console.log(`${config.title} insert result:`, insertResult);
 
 
      setInsertSuccess(prev => ({
        ...prev,
        [artifactType]: true
      }));
 
      return {
        success: true,
        message: `${config.title} fetched and inserted successfully`,
        details: { fetch: fetchResult, insert: insertResult }
      };
 
    } catch (error) {
      console.error(`Error processing ${config.title}:`, error);
      toast.error(`Error processing ${config.title}: ${error.message}`);
 
      return {
        success: false,
        message: `Error processing ${config.title}: ${error.message}`,
        error: error
      };
    }
  };
 
  const insertTestCaseModules = async () => {
    try {
      setCurrentOperation("Fetching & Inserting Test Case Modules...");
      const response = await fetch('http://localhost:5550/api/testcasemodulefieleds/FetchAndinAertTestCaseModules', {
        method: 'GET'
      });
 
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Test Case Modules fetch/insert failed: ${errorText}`);
      }
 
      const result = await response.json();
      toast.success(result.message || "✅ Test Case Modules fetched and inserted!");
      console.log("✅ Test Case Modules fetch/insert result:", result);
    } catch (err) {
      toast.error("❌ Failed to fetch/insert Test Case Modules");
      console.error("❌ Test Case Modules error:", err);
    }
  };
 
   const insertAlmStep1Parameters = async () => {
    try {
      setCurrentOperation("Fetching & Inserting ALM Parameters...");
      const response = await fetch('http://localhost:5550/api/parameters/insertparameters', {
        method: 'GET'
      });
 
      if (!response.ok) throw new Error(await response.text());
      const result = await response.json();
      toast.success(result.message || "✅ ALM Parameters inserted successfully");
      console.log("✅ ALM Step1 result:", result);
    } catch (err) {
      toast.error("❌ ALM Parameters insert failed");
      console.error("❌ ALM Parameters error:", err);
    }
  };
 
  const insertTestCaseSteps = async () => {
    try {
      setCurrentOperation("Fetching & Inserting Test Case Steps...");
      const response = await fetch(`http://localhost:5550/api/testdesign/insert-test-steps-and-resolve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          domain: almSettings.domain,
          project: almSettings.project
        })
      });
 
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Step Insert Failed: ${errorText}`);
      }
 
      const result = await response.json();
      toast.success(result.message || "✅ Test Case Steps fetched and inserted!");
      console.log("✅ Test Case Steps fetch/insert result:", result);
 
    } catch (err) {
      toast.error("❌ Failed to insert Test Case Steps");
      console.error("❌ Test Case Steps error:", err);
    }
  };
 
 

const insertTestLogs = async () => {
  try {
    setCurrentOperation("Fetching & Inserting Test Logs...");

    let response;
    if (customFilters.testlogs && customFilters.testlogs.trim().length > 0) {
      // ✅ Use custom fetch endpoint
      response = await fetch('http://localhost:5550/api/alm-testlog/custom', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ customReleaseUrl: customFilters.testlogs.trim() })
      });
      console.log(`Using custom Test Logs URL: ${customFilters.testlogs.trim()}`);
    } else {
      // ✅ Default fetch
      response = await fetch('http://localhost:5550/api/alm-insert-testlog', {
        method: 'GET'
      });
      console.log(`Using default Test Logs endpoint`);
    }

    if (!response.ok) throw new Error(await response.text());

    const result = await response.json();
    toast.success(result.message || "✅ Test Logs inserted");
    console.log("✅ Test Logs fetch/insert result:", result);

  } catch (err) {
    toast.error("❌ Test Logs insert failed");
    console.error("❌ Test Logs error:", err);
  }
};

 
const insertTestcyc = async () => {
    try {
      setCurrentOperation("Fetching & Inserting Test Cyc...");
      const response = await fetch('http://localhost:5550/api/insertreleaselinking-cyc', {
        method: 'GET'
      });
 
      if (!response.ok) throw new Error(await response.text());
      const result = await response.json();
      toast.success(result.message || "✅ Test testcyc inserted");
      console.log("✅ Test testcyc result:", result);
    } catch (err) {
      toast.error("❌ Test testcyc insert failed");
      console.error("❌ Test testcyc error:", err);
    }
  };
 
 
  // Handle fetch and insert process
  const handleFetchAndInsert = async () => {
    const selected = selectedArtifacts;
 
    if (Object.values(selected).every(v => !v)) {
      toast.error('Please select at least one artifact type to process.');
      return;
    }
 
    setIsProcessing(true);
    setMigrationResults({});
    setInsertSuccess({});
    const results = {};
 
    try {
      if (selected.releases) {
        results.releases = await fetchAndInsertArtifact("releases");
        setMigrationResults(prev => ({ ...prev, releases: results.releases }));
      }
 
      if (selected.requirements) {
        results.requirements = await fetchAndInsertArtifact("requirements");
        setMigrationResults(prev => ({ ...prev, requirements: results.requirements }));
      }
 
      if (selected.testcases) {
        // ✅ First: Insert Test Case Folders
        await insertTestCaseModules();
 
        // ✅Insert Test Cases
        results.testcases = await fetchAndInsertArtifact("testcases");
 
        // ✅ Then: Insert Parameters
        await insertAlmStep1Parameters();
 
        // ✅ Then: Insert Steps
        await insertTestCaseSteps();
 
        // ✅ Finally: Fetch and insert Test Cases
        await insertTestcyc ();
 
        setMigrationResults(prev => ({ ...prev, testcases: results.testcases }));
      }
 
      if (selected.testruns) {
        setCurrentOperation("Fetching & Inserting Test Suites...");
        const fetchRes = await fetch('http://localhost:5550/api/alm/testset');
        if (fetchRes.ok) {
          await fetch('http://localhost:5550/api/testsetupload/testset', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
          });
          toast.success("✅ Test Suites inserted!");
        }
 
        results.testruns = await fetchAndInsertArtifact("testruns");
        setMigrationResults(prev => ({ ...prev, testruns: results.testruns }));
       
        // ✅ Insert Test Logs
        await insertTestLogs();
 
      }
 
      if (selected.defects) {
        results.defects = await fetchAndInsertArtifact("defects");
        setMigrationResults(prev => ({ ...prev, defects: results.defects }));
      }
 
      setCurrentOperation('Fetch and Insert completed');
      toast.success('All selected artifacts have been processed successfully!');
    } catch (err) {
      toast.error("❌ Error during fetch and insert process");
      console.error(err);
    } finally {
      setIsProcessing(false);
    }
  };
 

const fetchJson = async (url, options = {}) => {

  const finalOptions = {

    method: 'POST', // ✅ Default to POST

    headers: { 'Content-Type': 'application/json' },

    body: JSON.stringify({}),

    ...options // allow overriding

  };

  const res = await fetch(url, finalOptions);

  if (!res.ok) {

    const errorText = await res.text();

    throw new Error(`❌ ${url} failed - HTTP ${res.status}: ${errorText}`);

  }

  return res.json();

};

//--------------------------

const migrateArtifact = async (artifactType) => {
  const config = dataTypes[artifactType];

  if (!insertSuccess[artifactType]) {
    toast.error(`Please run 'Fetch & Insert' for ${config.title} before migrating.`);
    return;
  }

  setCurrentlyMigratingArtifact(artifactType);
  setCurrentOperation(`Starting migration for ${config.title}...`);
  
  initializeMigrationStats(artifactType);
  
  pollUntilComplete(artifactType);

  try {
    if (artifactType === 'testcases') {
      toast.info('🚀 Migrating Test Case Folders...');
      await triggerAndToast('/api/testcasemodulefieleds/UplodeTestCaseModules', 'Test Case Folders', 'GET');

      toast.info('📦 Migrating Test Cases...');
      await triggerAndToast('/api/testcaseupload/testsupload', 'Test Cases');

      toast.info('🔄 Fetching Test Case Parameters (Step1)...');
      try {
        const response = await axios.get("http://localhost:5550/api/parameters/uploadparameters");
        console.log('📥 Parameters Fetched:', response.data);
        toast.success('✅ Test Case Parameters fetched successfully');
      await fetchMigrationStatus('testcases'); 

      } catch (err) {
        console.error('❌ Failed to fetch Test Case Parameters:', err);
        toast.error('❌ Failed to fetch Test Case Parameters');
      }

      // ✅ Run steps here ONLY if Test Design is selected and Test Execution is NOT selected
      if (selectedArtifacts['testcases'] && !selectedArtifacts['testruns']) {
        toast.info('🧩 Uploading Test Case Steps...');
        try {
          const stepData = await fetchJson('http://localhost:5550/api/upload-testcase-steps', {
            method: 'POST'
          });
          toast.success(stepData.message || '✅ Test Case Steps uploaded successfully');
await fetchMigrationStatus('testcases'); 

        } catch (err) {
          toast.error('❌ Failed to upload Test Case Steps');
          console.error('Step migration error:', err);
        }
      }

    } else if (artifactType === 'testruns') {
      
        toast.info('🧪 Migrating Test Cycles...');
      try {
        const runData = await fetchJson('http://localhost:5550/api/uploadreleaselinking-cyc');
        toast.success(runData.message || 'Test Cycles migrated successfully');
      } catch (err) {
        toast.error('❌ Failed to migrate Test Cycles');
        console.error(err);
      }

      toast.info('📡 Migrating Test Suites...');
      await triggerAndToast('/api/testsetupload/testsetupload', 'Migrating Test Suites');

      toast.info('🧪 Migrating Test Runs...');
      try {
        const runData = await fetchJson('http://localhost:5550/api/testinstanceupload/testrunupload');
        toast.success(runData.message || 'Test Runs migrated successfully');
      } catch (err) {
        toast.error('❌ Failed to migrate Test Runs');
        console.error(err);
      }

      toast.info('🧪 Migrating Test Logs...');
      try {
        const runData = await fetchJson('http://localhost:5550/api/alm-upload-testlog');
        toast.success(runData.message || 'Test Runs migrated successfully');
      } catch (err) {
        toast.error('❌ Failed to migrate Test Logs');
        console.error(err);
      }

      toast.info('🧹 Clearing Old Test Case Steps...');
      try {
        const clearRes = await fetch('http://localhost:5550/api/alm-clearteststeps');
        if (!clearRes.ok) {
          const errText = await clearRes.text();
          throw new Error(errText || 'Failed to clear test steps');
        }
        toast.success('✅ Cleared old Test Case Steps');
      } catch (err) {
        toast.error('❌ Failed to clear Test Case Steps');
        console.error('Clear Test Case Steps Error:', err);
      }

      // ✅ Run steps here ONLY if BOTH Test Design and Test Execution are selected
      if (selectedArtifacts['testcases'] && selectedArtifacts['testruns']) {
        toast.info('🧩 Uploading Test Case Steps...');
        try {
          const stepData = await fetchJson('http://localhost:5550/api/upload-testcase-steps', {
            method: 'POST'
          });
          toast.success(stepData.message || '✅ Test Case Steps uploaded successfully');
        } catch (err) {
          toast.error('❌ Failed to upload Test Case Steps');
          console.error('Step migration error:', err);
        }
      }

    } else {
      await fetchJson(`http://localhost:5550${config.migrationEndpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
    }

    await fetchMigrationStatus(artifactType);

    setMigrationResults(prev => ({
      ...prev,
      [artifactType]: {
        ...prev[artifactType],
        migrationSuccess: true,
        migrationMessage: `${config.title} migrated successfully`
      }
    }));

  } catch (err) {
    toast.error(err.message || `${config.title} migration failed`);
    console.error(`Migration error for ${config.title}:`, err);
    setMigrationResults(prev => ({
      ...prev,
      [artifactType]: {
        ...prev[artifactType],
        migrationSuccess: false,
        migrationMessage: `${config.title} migration failed: ${err.message}`
      }
    }));
  }
};

const fetchCountsForConfirmation = async () => {
  const selectedTypes = Object.entries(selectedArtifacts)
    .filter(([_, selected]) => selected)
    .map(([type]) => type);

  const counts = {};

  for (const artifactType of selectedTypes) {
    const config = dataTypes[artifactType];
    try {
      // ✅ Use countEndpoint instead of insertEndpoint
      const res = await fetch(`http://localhost:5550${config.countEndpoint}`, {
        method: "GET",
        headers: { 'Content-Type': 'application/json' }
      });

      const data = res.ok ? await res.json() : {};

      // Extract totalCount safely
      counts[artifactType] = {
        total:
          data.totalCount ??
          data.stats?.totalCount ??
          data.details?.totalProcessed ??
          0
      };

      // --- special case: testcases ---
      if (artifactType === "testcases") {
        try {
          console.log("🔍 Fetching testcases sub-artifact counts...");

          // Test Case Modules
          const modulesRes = await fetch(
            "http://localhost:5550/api/testcasemodulefieleds/testcasemodules/count",
            { method: "GET" }
          );
          const modulesData = modulesRes.ok ? await modulesRes.json() : {};

          // Parameters
          const paramsRes = await fetch(
            "http://localhost:5550/api/parameters/parameter/count",
            { method: "GET" }
          );
          const paramsData = paramsRes.ok ? await paramsRes.json() : {};

          // Steps
          const stepsRes = await fetch(
            "http://localhost:5550/api/testdesign/testcasesteps/count",
            { method: "GET" }
          );
          const stepsData = stepsRes.ok ? await stepsRes.json() : {};

          counts.testcases.folderMigratedCount =
            modulesData.totalCount ?? 0;

          counts.testcases.paramMigratedCount =
            paramsData.totalCount ?? 0;

          counts.testcases.stepMigratedCount =
            stepsData.totalCount ?? 0;

          console.log("✅ Final testcases counts:", counts.testcases);
        } catch (subErr) {
          console.warn("❌ Failed to fetch testcases sub-artifact counts:", subErr);
          counts.testcases.folderMigratedCount = 0;
          counts.testcases.paramMigratedCount = 0;
          counts.testcases.stepMigratedCount = 0;
        }
      }

      // --- special case: testruns ---
      if (artifactType === "testruns") {
        try {
          console.log("🔍 Fetching testruns sub-artifact counts...");

          const cyclesRes = await fetch("http://localhost:5550/api/testsetfolder/count");
          const cyclesData = cyclesRes.ok ? await cyclesRes.json() : {};

          const suitesRes = await fetch("http://localhost:5550/api/testsetupload/testset/count");
          const suitesData = suitesRes.ok ? await suitesRes.json() : {};

          const logsRes = await fetch("http://localhost:5550/api/testlog/count");
          const logsData = logsRes.ok ? await logsRes.json() : {};

          counts.testruns.testCycleCount = cyclesData.totalCount ?? cyclesData.total ?? 0;          counts.testruns.testSuiteCount = suitesData.totalCount ?? 0;
          counts.testruns.testRunCount = counts.testruns.total;
          counts.testruns.logCount = logsData.totalCount ?? logsData.total ?? 0;
          console.log("✅ Final testruns counts:", counts.testruns);
        } catch (subErr) {
          console.warn("❌ Failed to fetch testruns sub-artifact counts:", subErr);
          counts.testruns.testCycleCount = 0;
          counts.testruns.testSuiteCount = 0;
          counts.testruns.testRunCount = 0;
          counts.testruns.logCount = 0;
        }
      }

      console.log(`✅ Fetched counts for ${artifactType}:`, counts[artifactType]);

    } catch (err) {
      console.error(`❌ Error fetching counts for ${artifactType}:`, err);
      counts[artifactType] = { total: 0 };
    }
  }

  setConfirmationData(counts);
  console.log("🧾 Final Confirmation Data:", counts);
  return counts;
};

 

  const handleMigrateSelected = async () => {

    const selectedTypes = Object.entries(selectedArtifacts)

      .filter(([_, selected]) => selected)

      .map(([type, _]) => type);



    if (selectedTypes.length === 0) {

      toast.error('Please select at least one artifact type to migrate.');

      return;

    }

    // Check if all selected artifacts have been successfully inserted

    const notInserted = selectedTypes.filter(type => !insertSuccess[type]);

    if (notInserted.length > 0) {

      toast.error(`Please run 'Fetch & Insert' for: ${notInserted.map(type => dataTypes[type].title).join(', ')} before migrating.`);

      return;

    }

 // Fetch latest counts and show confirmation dialog
const counts = await fetchCountsForConfirmation();
console.log("✅ Fetched confirmation counts:", counts);
setShowConfirmDialog(true);
  };

  // Function to proceed with migration after confirmation
// Updated proceedWithMigration function
const proceedWithMigration = async () => {
  setShowConfirmDialog(false);
  setIsMigrating(true);
  setMigrationStarted(true); // Set flag that migration has started

  const orderedArtifacts = [
    'releases',
    'requirements',
    'testcases',
    'testruns',
    'defects'
  ];

  const anySelected = orderedArtifacts.some(type => selectedArtifacts[type]);
  if (!anySelected) {
    toast.error('Please select at least one artifact to migrate.');
    setIsMigrating(false);
    return;
  }

  for (const artifactType of orderedArtifacts) {
    if (!selectedArtifacts[artifactType]) continue;

    const title = dataTypes[artifactType]?.title || artifactType;

    try {
      // Trigger migration and polling
      await migrateArtifact(artifactType);
      pollUntilComplete(artifactType);

      // Wait for polling of this artifact to finish
      await new Promise(resolve => {
        const checkInterval = setInterval(() => {
          if (!pollRefs.current[artifactType]) {
            clearInterval(checkInterval);
            resolve();
          }
        }, 500);
      });

      toast.success(`${title} migration completed!`);
    } catch (err) {
      console.error(`⚠ Error migrating ${artifactType}:`, err);
      toast.error(`${title} migration failed: ${err.message}`);
    }
  }

  // 🔹 Final guarantee: stop spinner and show success if nothing is polling
  if (Object.keys(pollRefs.current).length === 0) {
    setIsMigrating(false);
    toast.success("All selected artifacts migrated successfully!");
  }
};

  // Handle cancel
// Updated handleCancel function
const handleCancel = () => {
  // Clear all polling intervals
  Object.values(pollingIntervals).forEach(interval => clearInterval(interval));

  setSelectedArtifacts({
    releases: false,
    requirements: false,
    defects: false,
    testcases: false,
    testruns: false
  });

  setCustomFilters({
    releases: '',
    requirements: '',
    defects: '',
    testcases: '',
    testruns: ''
  });

  setMigrationResults({});
  setInsertSuccess({});
  setCurrentOperation('');
  setPollingIntervals({});
  setMigrationStarted(false); // Reset migration started flag

  setMigrationStats({
    releases: { total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0 },
    requirements: { total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0 },
    defects: { total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0 },
    testcases: {
      total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0,
      modules:    { total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0 },
      parameters: { total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0 },
      steps:      { total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0 }
    },
    testruns: {
      total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0,
      cycle: { total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0 },
      suite: { total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0 },
      logs:  { total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0 }
    }
  });

  toast.info('All selections have been reset');
};


const ConfirmationDialog = () => {
  // Stable reference to prevent re-rendering
  const dialogData = React.useMemo(() => {
    if (!showConfirmDialog) return null;
    
    const selectedTypes = Object.entries(selectedArtifacts)
      .filter(([_, selected]) => selected)
      .map(([type]) => type);

    // Calculate total records from confirmationData including all sub-artifacts
    const totalRecords = selectedTypes.reduce((total, type) => {
      const stats = confirmationData[type] ?? { total: 0 };
      let typeTotal = stats.total || 0;
      
      // Add sub-artifacts for testcases
      if (type === 'testcases') {
        typeTotal += (stats.folderMigratedCount || 0) + 
                    (stats.paramMigratedCount || 0) + 
                    (stats.stepMigratedCount || 0);
      }
      
      // Add sub-artifacts for testruns
      if (type === 'testruns') {
        typeTotal += (stats.testCycleCount || 0) + 
                     (stats.testSuiteCount || 0) + 
                     (stats.logCount || 0);
        // Note: testRunCount is same as total, so don't double count
      }
      
      return total + typeTotal;
    }, 0);

    return { selectedTypes, totalRecords };
  }, [showConfirmDialog, selectedArtifacts, confirmationData]);

  if (!dialogData) return null;
  
  const { selectedTypes, totalRecords } = dialogData;

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
      style={{ position: 'fixed', zIndex: 9999 }} // Ensure high z-index
    >
      <div className="bg-white rounded-xl sm:rounded-2xl shadow-2xl max-w-[95vw] sm:max-w-2xl lg:max-w-3xl w-full max-h-[85vh] sm:max-h-[90vh] flex flex-col mx-2 sm:mx-4">
        {/* Header - Fixed */}
        <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white p-6 rounded-t-2xl flex-shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-white/20 rounded-lg">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold">Confirm Migration</h3>
                <p className="text-orange-100">Please review the records to be migrated</p>
              </div>
            </div>
            <button
              onClick={() => setShowConfirmDialog(false)}
              className="p-2 hover:bg-white/20 rounded-lg transition-colors flex-shrink-0"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {/* Warning Box */}
          <div className="mb-6">
            <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-r-lg mb-4">
              <div className="flex items-start">
                <AlertTriangle className="w-5 h-5 text-yellow-400 mr-3 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-yellow-800 font-medium">
                    You are about to migrate <span className="font-bold text-yellow-900">{totalRecords}</span> total records.
                  </p>
                  <p className="text-yellow-700 text-sm mt-1">
                    This action cannot be undone. Please review the details below.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Migration Details */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold text-gray-900 mb-4">Migration Details:</h4>

            {selectedTypes.map(type => {
              const config = dataTypes[type];
              const stats = confirmationData[type] || { total: 0 };
              const count = stats.total || 0;

              // Calculate total including sub-components for testcases
              let totalTestCasesCount = 0;
              if (type === 'testcases') {
                totalTestCasesCount = count + 
                  (stats.folderMigratedCount || 0) + 
                  (stats.paramMigratedCount || 0) + 
                  (stats.stepMigratedCount || 0);
              }

              // Calculate total including sub-components for testruns
              let totalTestRunsCount = 0;
              if (type === 'testruns') {
                totalTestRunsCount = 
                  (stats.testCycleCount || 0) + 
                  (stats.testSuiteCount || 0) + 
                  (stats.testRunCount || 0) + 
                  (stats.logCount || 0);
              }

              return (
                <div key={type} className="bg-gray-50 rounded-xl p-4 border border-gray-200">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-blue-100 rounded-lg flex-shrink-0">{config.icon}</div>
                      <div>
                        <h5 className="font-semibold text-gray-900">{config.title}</h5>
                        <p className="text-sm text-gray-600">Ready for migration</p>
                      </div>
                    </div>

                    <div className="text-right flex-shrink-0">
                      <div className="text-2xl font-bold text-blue-600">
                        {type === 'testcases' ? totalTestCasesCount : 
                         type === 'testruns' ? totalTestRunsCount : count}
                      </div>
                      <div className="text-sm text-gray-500">
                        {type === 'testcases' || type === 'testruns' ? 'total items' : 'records'}
                      </div>
                    </div>
                  </div>

                  {/* Sub-artifacts for Test Design */}
                  {type === 'testcases' && (
                    <div className="mt-4 pl-4 border-l-2 border-purple-200 space-y-3">
                      <div className="text-sm text-green-700 font-medium mb-2">
                        ✅ Will also migrate the following components:
                      </div>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="bg-white rounded-lg p-3 border border-orange-100 shadow-sm">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <div className="w-2 h-2 bg-orange-500 rounded-full flex-shrink-0"></div>
                              <span className="text-sm font-medium text-gray-700">TestCase Folders</span>
                            </div>
                            <span className="text-sm font-bold text-orange-600 flex-shrink-0">
                              {confirmationData[type]?.folderMigratedCount || stats.folderMigratedCount || 0}
                            </span>
                          </div>
                        </div>
                        
                        <div className="bg-white rounded-lg p-3 border border-teal-100 shadow-sm">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <div className="w-2 h-2 bg-teal-500 rounded-full flex-shrink-0"></div>
                              <span className="text-sm font-medium text-gray-700">Test Cases</span>
                            </div>
                            <span className="text-sm font-bold text-teal-600 flex-shrink-0">
                              {count}
                            </span>
                          </div>
                        </div>
                        
                        <div className="bg-white rounded-lg p-3 border border-indigo-100 shadow-sm">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <div className="w-2 h-2 bg-indigo-500 rounded-full flex-shrink-0"></div>
                              <span className="text-sm font-medium text-gray-700">Parameters</span>
                            </div>
                            <span className="text-sm font-bold text-indigo-600 flex-shrink-0">
                              {confirmationData[type]?.paramMigratedCount || stats.paramMigratedCount || 0}
                            </span>
                          </div>
                        </div>
                        
                        <div className="bg-white rounded-lg p-3 border border-pink-100 shadow-sm">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <div className="w-2 h-2 bg-pink-500 rounded-full flex-shrink-0"></div>
                              <span className="text-sm font-medium text-gray-700">TestCase Steps</span>
                            </div>
                            <span className="text-sm font-bold text-pink-600 flex-shrink-0">
                              {confirmationData[type]?.stepMigratedCount || stats.stepMigratedCount || 0}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Sub-artifacts for Test Execution (testruns) */}
                  {type === 'testruns' && (
                    <div className="mt-4 pl-4 border-l-2 border-purple-200 space-y-3">
                      <div className="text-sm text-green-700 font-medium mb-2">
                        ✅ Will also migrate the following components:
                      </div>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="bg-white rounded-lg p-3 border border-orange-100 shadow-sm">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <div className="w-2 h-2 bg-orange-500 rounded-full flex-shrink-0"></div>
                              <span className="text-sm font-medium text-gray-700">Test Cycles</span>
                            </div>
                            <span className="text-sm font-bold text-orange-600 flex-shrink-0">
                              {confirmationData[type]?.testCycleCount || stats.testCycleCount || 0}
                            </span>
                          </div>
                        </div>
                        
                        <div className="bg-white rounded-lg p-3 border border-teal-100 shadow-sm">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <div className="w-2 h-2 bg-teal-500 rounded-full flex-shrink-0"></div>
                              <span className="text-sm font-medium text-gray-700">Test Suites</span>
                            </div>
                            <span className="text-sm font-bold text-teal-600 flex-shrink-0">
                              {confirmationData[type]?.testSuiteCount || stats.testSuiteCount || 0}
                            </span>
                          </div>
                        </div>
                        
                        <div className="bg-white rounded-lg p-3 border border-indigo-100 shadow-sm">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <div className="w-2 h-2 bg-indigo-500 rounded-full flex-shrink-0"></div>
                              <span className="text-sm font-medium text-gray-700">Test Runs</span>
                            </div>
                            <span className="text-sm font-bold text-indigo-600 flex-shrink-0">
                              {confirmationData[type]?.testRunCount || stats.testRunCount || 0}
                            </span>
                          </div>
                        </div>
                        
                        <div className="bg-white rounded-lg p-3 border border-pink-100 shadow-sm">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <div className="w-2 h-2 bg-pink-500 rounded-full flex-shrink-0"></div>
                              <span className="text-sm font-medium text-gray-700">Test Logs</span>
                            </div>
                            <span className="text-sm font-bold text-pink-600 flex-shrink-0">
                              {confirmationData[type]?.logCount || stats.logCount || 0}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Simple note for other artifacts */}
                  {type !== 'testcases' && type !== 'testruns' && (
                    <div className="mt-3 text-sm text-gray-500 italic">
                      ✅ Ready for direct migration to qTest
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Summary */}
          <div className="mt-6 p-4 bg-blue-50 rounded-xl border border-blue-200">
            <div className="flex items-center justify-between">
              <div>
                <h5 className="font-semibold text-blue-900">Total Migration Summary</h5>
                <p className="text-blue-700 text-sm">All selected artifacts and their sub-components will be processed</p>
              </div>
              <div className="text-right flex-shrink-0">
                <div className="text-3xl font-bold text-blue-600">{totalRecords}</div>
                <div className="text-sm text-blue-500">total items</div>
              </div>
            </div>
          </div>
        </div>

        {/* Actions - Fixed at bottom */}
        <div className="bg-gray-50 px-6 py-4 rounded-b-2xl flex flex-col sm:flex-row justify-end space-y-3 sm:space-y-0 sm:space-x-3 flex-shrink-0">
          <button
            onClick={() => setShowConfirmDialog(false)}
            className="px-6 py-2 border-2 border-gray-300 text-gray-700 font-semibold rounded-lg hover:bg-gray-100 hover:border-gray-400 transition-all duration-200"
          >
            Cancel
          </button>
          <button
            onClick={proceedWithMigration}
            className="px-6 py-2 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white font-bold rounded-lg shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-[1.02]"
          >
            Yes, Proceed with Migration
          </button>
        </div>
      </div>
    </div>
  );
};


  // Migration Stats Display Component


const MigrationStatsDisplay = ({
  selectedArtifacts,
  migrationStats,
  isMigrating,
  currentlyMigratingArtifact,
  dataTypes,
  migrationResults
}) => {
  const selectedTypes = Object.entries(selectedArtifacts)
    .filter(([_, selected]) => selected)
    .map(([type]) => type);

  if (selectedTypes.length === 0) return null;

  const orderedTypes = ['releases', 'requirements', 'testcases', 'testruns', 'defects'];

  // Helper function to get stats array for consistent rendering
  const getStatsArray = (stats, excludeUpdated = false) => {
    const baseStats = [
      { key: 'total', label: 'Total', value: stats?.total ?? 0, icon: <Database className="w-3 h-3" />, color: 'text-gray-600', bgColor: 'bg-gray-50', borderColor: 'border-gray-200' },
      { key: 'success', label: 'Success', value: stats?.success ?? 0, icon: <CheckCircle className="w-3 h-3" />, color: 'text-green-600', bgColor: 'bg-green-50', borderColor: 'border-green-200' },
      { key: 'failed', label: 'Failed', value: stats?.failed ?? 0, icon: <XCircle className="w-3 h-3" />, color: 'text-red-600', bgColor: 'bg-red-50', borderColor: 'border-red-200' },
      { key: 'skipped', label: 'Skipped', value: stats?.skipped ?? 0, icon: <AlertCircle className="w-3 h-3" />, color: 'text-gray-600', bgColor: 'bg-gray-50', borderColor: 'border-gray-200' },
      { key: 'pending', label: 'Pending', value: stats?.pending ?? 0, icon: <AlertTriangle className="w-3 h-3" />, color: 'text-amber-600', bgColor: 'bg-amber-50', borderColor: 'border-amber-200' }
    ];

    if (!excludeUpdated) {
      baseStats.splice(4, 0, { 
        key: 'updated', 
        label: 'Updated', 
        value: stats?.updated ?? 0, 
        icon: <RefreshCw className="w-3 h-3" />, 
        color: 'text-blue-600', 
        bgColor: 'bg-blue-50', 
        borderColor: 'border-blue-200' 
      });
    }

    return baseStats;
  };

  // Responsive grid component for stats
  const StatsGrid = ({ stats, excludeUpdated = false, compact = false }) => {
    const statsArray = getStatsArray(stats, excludeUpdated);
    const iconSize = compact ? "w-3 h-3" : "w-4 h-4";
    
    return (
      <div className={`grid gap-3 ${
        statsArray.length <= 4 
          ? 'grid-cols-2 sm:grid-cols-4' 
          : statsArray.length === 5
          ? 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-5'
          : 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-6'
      }`}>
        {statsArray.map((stat) => (
          <StatCard
            key={stat.key}
            label={stat.label}
            value={stat.value}
            icon={React.cloneElement(stat.icon, { className: iconSize })}
            color={stat.color}
            bgColor={stat.bgColor}
            borderColor={stat.borderColor}
            compact={compact}
          />
        ))}
      </div>
    );
  };

  const renderSubStatCard = (artifactType, key, label, stats) => {
    const hasStats =
      (stats?.total ?? 0) > 0 ||
      (stats?.success ?? 0) > 0 ||
      (stats?.failed ?? 0) > 0 ||
      (stats?.skipped ?? 0) > 0 ||
      (stats?.updated ?? 0) > 0 ||
      (stats?.pending ?? 0) > 0;

    // Special handling for parameters and logs
    const isParametersOrLogs = key === 'parameters' || key === 'logs';

    const shouldShow =
      hasStats ||
      (isMigrating && currentlyMigratingArtifact === artifactType) ||
      (isMigrating && selectedArtifacts[artifactType]) ||
      (isParametersOrLogs && selectedArtifacts[artifactType] && isMigrating);

    if (!shouldShow) return null;

    // Keys where "Updated" should NOT be shown
    const excludeUpdated = ['modules', 'steps', 'cycle', 'logs'];

    return (
      <div key={key} className="bg-white rounded-lg border border-gray-200 p-4 shadow-sm">
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <span className="text-sm font-medium text-gray-700">{label}</span>
              {/* Show "Preparing..." indicator when migration is active but no stats yet */}
              {isMigrating && selectedArtifacts[artifactType] && !hasStats && (
                <span className="text-xs text-blue-600 font-medium animate-pulse">Preparing...</span>
              )}
            </div>
          </div>

          <StatsGrid stats={stats} excludeUpdated={excludeUpdated.includes(key)} compact={true} />
        </div>
      </div>
    );
  };

  return (
<div className="bg-gradient-to-br from-white to-gray-50 rounded-xl sm:rounded-2xl border border-gray-200 p-3 sm:p-4 lg:p-6 shadow-lg mt-4 sm:mt-6">      <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 gap-4">
        <h2 className="text-xl sm:text-2xl font-bold text-gray-800 flex items-center gap-2">
          <Database className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600" />
          Migration Statistics
        </h2>
        <div className="h-px bg-gradient-to-r from-blue-500 to-purple-500 flex-1 sm:ml-4 rounded-full"></div>
      </div>

      <div className="space-y-6">
        {orderedTypes.map((type) => {
          if (!selectedArtifacts[type]) return null;

          const stats = migrationStats[type]?.total !== undefined
            ? migrationStats[type]
            : { total: 0, success: 0, failed: 0, skipped: 0, updated: 0, pending: 0 };

          const config = dataTypes[type];
          const wasMigrated = migrationResults?.[type]?.migrationSuccess === true;

          const anyStats =
            stats.total > 0 ||
            stats.success > 0 ||
            stats.failed > 0 ||
            stats.skipped > 0 ||
            stats.updated > 0 ||
            stats.pending > 0 ||
            isMigrating ||
            wasMigrated;

          if (!anyStats && !isMigrating && currentlyMigratingArtifact !== type) return null;

          return (
            <div key={type} className="space-y-4">
              {/* Main Stats Card */}
              <div className="bg-white rounded-xl border border-gray-200 p-4 sm:p-6 shadow-sm hover:shadow-md transition-all duration-300">
                <div className="space-y-4">
                  {/* Icon & Title */}
                  <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                    <div className="flex items-center gap-4">
                      <div className="p-2 sm:p-3 bg-blue-50 rounded-lg border border-blue-200">
                        <span className="text-xl sm:text-2xl">{config.icon}</span>
                      </div>
                      <div>
                        <h3 className="text-base sm:text-lg font-semibold text-gray-800">
                          {config.title}
                        </h3>
                        {currentlyMigratingArtifact === type && (
                          <div className="flex items-center text-sm text-blue-600 gap-2 mt-1">
                            <ArrowLeftCircle className="animate-spin w-4 h-4" />
                            <span className="font-medium">Currently migrating...</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Stats Grid (non-testcases/testruns) */}
                  {type !== 'testcases' && type !== 'testruns' && (
                    <StatsGrid stats={stats} />
                  )}
                </div>
              </div>

              {/* Test Design: Testcases Internal Progress */}
              {type === 'testcases' && (
                <div className="ml-2 sm:ml-4 space-y-3">
                  <h4 className="text-sm sm:text-md font-semibold text-gray-700 flex items-center gap-2">
                    <div className="w-1 h-4 bg-blue-500 rounded-full"></div>
                    Progress of Test Design
                  </h4>
                  {renderSubStatCard('testcases', 'modules', 'Test Case Folders', migrationStats.testcases?.modules)}
                  {renderSubStatCard('testcases', 'testcases', 'Test Cases', migrationStats.testcases)}
                  {renderSubStatCard('testcases', 'parameters', 'Test Parameters', migrationStats.testcases?.parameters)}
                  {renderSubStatCard('testcases', 'steps', 'Test Steps', migrationStats.testcases?.steps)}
                </div>
              )}

              {/* Test Execution: Testruns Internal Progress */}
              {type === 'testruns' && (
                <div className="ml-2 sm:ml-4 space-y-3">
                  <h4 className="text-sm sm:text-md font-semibold text-gray-700 flex items-center gap-2">
                    <div className="w-1 h-4 bg-purple-500 rounded-full"></div>
                    Progress of Test Execution
                  </h4>
                  {renderSubStatCard('testruns', 'cycle', 'Test Cycles', migrationStats.testruns?.cycle)}
                  {renderSubStatCard('testruns', 'suite', 'Test Suites', migrationStats.testruns?.suite)}
                  {renderSubStatCard('testruns', 'testruns', 'Test Runs', migrationStats.testruns)}
                  {renderSubStatCard('testruns', 'logs', 'Test Logs', migrationStats.testruns?.logs)}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};


const StatCard = ({
  label,
  value,
  icon,
  color = "text-gray-700",
  bgColor = "bg-gray-50",
  borderColor = "border-gray-200",
  compact = false
}) => (
  <div className={`${bgColor} ${borderColor} border rounded-lg p-3 text-center hover:shadow-sm transition-shadow duration-200`}>
    <div className={`${color} flex items-center justify-center gap-1 mb-1`}>
      {icon}
      <span className={`font-medium ${compact ? 'text-xs' : 'text-xs'}`}>{label}</span>
    </div>
    <div className={`font-bold text-gray-900 ${compact ? 'text-sm' : 'text-lg'}`}>{value}</div>
  </div>
);

const pollMigrationStatus = async () => {
  const currentSelectedTypes = Object.entries(selectedArtifacts)
    .filter(([_, selected]) => selected)
    .map(([type]) => type);

  const updatedStats = {};

  for (const type of currentSelectedTypes) {
    const config = dataTypes[type];

    try {
      const response = await fetch(`http://localhost:5550${config.statusEndpoint}`);
      if (response.ok) {
        const data = await response.json();
        const stats = data.counts || data[type];

        if (type === 'testcases') {
          updatedStats[type] = {
            ...(migrationStats?.testcases || {}), // ✅ safe fallback
            total: stats?.total ?? 0,
            success: stats?.success ?? 0,
            failed: stats?.failed ?? 0,
            pending: stats?.pending ?? 0
          };
        } else if (type === 'testruns') {
          updatedStats[type] = {
            ...(migrationStats?.testruns || {}), // ✅ safe fallback
            total: stats?.total ?? 0,
            success: stats?.success ?? 0,
            failed: stats?.failed ?? 0,
            pending: stats?.pending ?? 0
          };
        } else {
          updatedStats[type] = {
            total: stats?.total ?? 0,
            success: stats?.success ?? 0,
            failed: stats?.failed ?? 0,
            pending: stats?.pending ?? 0
          };
        }
      } else {
        updatedStats[type] = {
          ...(type === 'testcases' ? (migrationStats?.testcases || {}) : {}),
          ...(type === 'testruns' ? (migrationStats?.testruns || {}) : {}),
          total: 0,
          success: 0,
          failed: 0,
          pending: 0
        };
      }
    } catch (err) {
      console.error(`Polling failed for ${type}:`, err);
      updatedStats[type] = {
        ...(type === 'testcases' ? (migrationStats?.testcases || {}) : {}),
        ...(type === 'testruns' ? (migrationStats?.testruns || {}) : {}),
        total: 0,
        success: 0,
        failed: 0,
        pending: 0
      };
    }
  }

  setMigrationStats(prev => ({
    ...prev,
    ...updatedStats
  }));
};

  // Cleanup intervals on unmount

useEffect(() => {
  return () => {
    Object.values(pollRefs.current).forEach(clearInterval);
    pollRefs.current = {};
    console.log("🧹 Cleared all polling intervals on unmount");
  };
}, []);



 return (
  <>
    {/* Sidebar */}
    <Sidebar />
    {/* Topbar */}
    <Topbar />

{!selectedLink ? (
  <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-slate-100 lg:ml-72 lg:mt-25 px-4">
    <div className="bg-white w-full max-w-md p-8 sm:p-10 rounded-3xl shadow-2xl border border-gray-100 text-center transition-all duration-300 animate-fadeIn">
      
      {/* Icon Section */}
      <div className="mb-6">
        <div className="flex justify-center mb-4">
          <div className="bg-blue-100 p-3 rounded-full shadow-inner">
            <svg className="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
        </div>
        <h1 className="text-3xl font-bold text-gray-900 tracking-tight">
          Migrate
        </h1>
        <p className="mt-2 text-gray-500 text-sm">
          Select from the available link configurations
        </p>
      </div>

      {/* Dropdown */}
      <select
  className="mt-4 w-full px-4 py-3 border border-gray-300 rounded-xl bg-white text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-200"
  onChange={(e) => {
    const chosen = e.target.value;
    if (chosen) {
      setSelectedLink(chosen);

      (async () => {
        await setLinkAsCurrent(chosen);
        fetchCurrentSettingsFor(chosen);
      })();
    }
  }}
  defaultValue=""
>
  <option value="" disabled>-- Choose Link --</option>
  {allLinkConfigs.map(config => (
    <option key={config.link_name} value={config.link_name}>
      {config.link_name}
    </option>
  ))}
</select>

    </div>
  </div>
) : (
  <>

    {/* Main Content */}
      
      <div className="min-h-screen bg-gray-50 p-2 sm:p-4 md:p-6 lg:ml-72 lg:mt-12 xl:ml-64">            <div className="w-full max-w-7xl ml-auto px-4 sm:px-6 lg:px-8">
            
                <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-200">
        <div className="mb-6">
 <div className="flex justify-end mb-4">
    <button
    onClick={() => setSelectedLink(null)}
    className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-slate-100 to-slate-200 border border-slate-300 text-slate-800 hover:from-slate-200 hover:to-slate-300 font-semibold rounded-lg shadow hover:shadow-md transition-all duration-200"
  >
    <svg
      className="w-5 h-5 mr-2 text-slate-600"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      viewBox="0 0 24 24"
    >
      <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
    </svg>
    Switch Configuration
  </button>

</div>

</div>

           {/* Header and Config Info Section */}
          <div className="relative pt-6 pb-3 px-4 sm:px-6 border border-slate-200/60 mb-10 bg-gradient-to-br from-slate-50 via-white to-slate-50/50 backdrop-blur-sm rounded-2xl shadow-md shadow-slate-100/50 overflow-hidden">
          {/* Background Pattern */}
          <div className="absolute inset-0 bg-gradient-to-br from-blue-50/30 via-transparent to-indigo-50/30"></div>
          <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-blue-100/20 to-indigo-100/20 rounded-full blur-3xl -translate-y-16 translate-x-16"></div>
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-gradient-to-tr from-violet-100/20 to-purple-100/20 rounded-full blur-3xl translate-y-12 -translate-x-12"></div>
          
          <div className="relative z-10">
            <div className="mb-4">
              <h1 className="text-2xl font-bold bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 bg-clip-text text-transparent mb-1 tracking-tight">
                Migration Dashboard
              </h1>
              <p className="text-slate-600 text-sm font-medium">Choose the artifacts you want to migrate from ALM</p>
            </div>
        
            <div className="mb-3">
            <h2 className="text-lg font-semibold text-slate-900 mb-4 flex items-center gap-3">
  <div className="w-1.5 h-6 bg-gradient-to-b from-blue-500 to-indigo-600 rounded-full shadow-md" />
  <span className="tracking-wide">Active Configuration</span>
</h2>

            </div>
        
<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-3 sm:gap-4">              {(almSettings.domain || almSettings.project) && (
                <div className="group relative bg-white/70 backdrop-blur-sm p-4 rounded-xl border border-blue-200/50 shadow-md hover:shadow-lg transition-all duration-300 hover:scale-[1.02] hover:border-blue-300/70">
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-50/50 to-indigo-50/30 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <div className="relative z-10">
                    <h3 className="font-semibold text-blue-900 mb-3 flex items-center gap-2">
                      <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center shadow-md">
                        <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                        </svg>
                      </div>
                      ALM Project Information
                    </h3>
                    <div className="space-y-2">
                      <p className="text-slate-700 text-sm"><span className="text-slate-500">Domain:</span> <span className="text-blue-700 font-medium">{almSettings.domain}</span></p>
                      <p className="text-slate-700 text-sm"><span className="text-slate-500">Project:</span> <span className="text-blue-700 font-medium">{almSettings.project}</span></p>
                    </div>
                  </div>
                </div>
              )}
        
              {qtestSettings.projectId && (
                <div className="group relative bg-white/70 backdrop-blur-sm p-4 rounded-xl border border-emerald-200/50 shadow-md hover:shadow-lg transition-all duration-300 hover:scale-[1.02] hover:border-emerald-300/70">
                  <div className="absolute inset-0 bg-gradient-to-br from-emerald-50/50 to-green-50/30 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <div className="relative z-10">
                    <h3 className="font-semibold text-emerald-900 mb-3 flex items-center gap-2">
                      <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-lg flex items-center justify-center shadow-md">
                        <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 003.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
                        </svg>
                      </div>
                      qTest Project Information
                    </h3>
                    <div className="space-y-2">
                      <p className="text-slate-700 text-sm"><span className="text-slate-500">Project ID:</span> <span className="text-emerald-700 font-medium">{qtestSettings.projectId}</span></p>
                    </div>
                  </div>
                </div>
              )}
        
              {linkName.linkname && (
                <div className="group relative bg-white/70 backdrop-blur-sm p-4 rounded-xl border border-violet-200/50 shadow-md hover:shadow-lg transition-all duration-300 hover:scale-[1.02] hover:border-violet-300/70">
                  <div className="absolute inset-0 bg-gradient-to-br from-violet-50/50 to-purple-50/30 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <div className="relative z-10">
                    <h3 className="font-semibold text-violet-900 mb-3 flex items-center gap-2">
                      <div className="w-8 h-8 bg-gradient-to-br from-violet-500 to-violet-600 rounded-lg flex items-center justify-center shadow-md">
                        <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                        </svg>
                      </div>
                      Link Information
                    </h3>
                    <div className="space-y-2">
                      <p className="text-slate-700 text-sm"><span className="text-slate-500">Link Name:</span> <span className="text-violet-700 font-medium">{linkName.linkname}</span></p>
                    </div>
                  </div>
                </div>
              )}
        
              {!almSettings.domain && !almSettings.project && !qtestSettings.projectId && (
                <div className="col-span-full relative bg-white/70 backdrop-blur-sm p-5 rounded-xl border border-amber-200/50 shadow-md">
                  <div className="absolute inset-0 bg-gradient-to-br from-amber-50/50 to-orange-50/30 rounded-xl"></div>
                  <div className="relative z-10 flex items-center gap-3">
                  <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center shadow-md ring-2 ring-white">
                      <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.732-.833-2.5 0L4.732 15.5c-.77.833.192 2.5 1.732 2.5z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-semibold text-amber-900 mb-1">No Current Configuration</h3>
                      <p className="text-amber-800 text-sm">Please go to Settings and set a configuration as current.</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
   {/* Artifact Selection Section */}
<div className="px-4 sm:px-6 mb-10">

  <h2 className="text-lg font-semibold text-slate-900 mb-4 flex items-center gap-3">
    <div className="w-1.5 h-6 bg-gradient-to-b from-blue-500 to-indigo-600 rounded-full shadow-md" />
    <span className="tracking-wide">Select Artifacts</span>
  </h2>

  <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4 gap-2">
    <p className="text-xs text-slate-500 font-medium">
      Choose the artifacts you wish to migrate to qTest
    </p>

<div className="flex items-center gap-5 text-sm font-semibold text-slate-600">
      <button
        onClick={handleSelectAllArtifacts}
        disabled={isProcessing || isMigrating}
        className="hover:text-blue-600 transition disabled:opacity-40"
      >
        Select All
      </button>
      <button
        onClick={handleDeselectAllArtifacts}
        disabled={isProcessing || isMigrating}
        className="hover:text-red-500 transition disabled:opacity-40"
      >
        Deselect All
      </button>
    </div>
  </div>

<div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-5 gap-2 sm:gap-3">    {Object.entries(dataTypes).map(([key, config]) => {
      const isSelected = selectedArtifacts[key];
      const isReady = insertSuccess[key];

      return (
        <div
          key={key}
          onClick={() => !isProcessing && !isMigrating && handleArtifactSelection(key)}
          className={`relative group cursor-pointer rounded-lg border p-3 text-center transition-all duration-150
            ${isSelected
              ? 'border-blue-500 bg-white ring-1 ring-blue-100 shadow'
              : 'border-slate-200 bg-white hover:border-slate-300 hover:shadow-sm'}
            ${isProcessing || isMigrating ? 'opacity-60 pointer-events-none' : ''}`}
        >
          {isSelected && (
            <div className="absolute top-2 right-2 w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
              <svg className="w-2.5 h-2.5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                <path d="M5 13l4 4L19 7" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
          )}

          <div className={`w-9 h-9 mx-auto rounded-md flex items-center justify-center text-lg
            ${isSelected ? 'bg-blue-100 text-blue-600' : 'bg-slate-100 text-slate-500 group-hover:bg-slate-200'}`}>
            {config.icon}
          </div>

          <div className="mt-2">
            <h4 className="text-sm font-semibold text-slate-800">{config.title}</h4>
            {isReady && (
              <p className="text-[10px] text-green-600 font-semibold mt-0.5">Ready</p>
            )}
          </div>
        </div>
      );
    })}
  </div>
</div>

{/* Custom Filters Section */}

<div className="mb-8">
  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 gap-2">
    <h3 className="text-xl sm:text-2xl font-bold text-gray-900">Custom Filters & URLs</h3>
    <div className="text-xs sm:text-sm text-gray-500">
      Optional: Specify custom ALM URLs
    </div>
  </div>

<div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg sm:rounded-xl lg:rounded-2xl p-3 sm:p-4 lg:p-6 border border-gray-200">    <div className="mb-4 p-3 sm:p-2 bg-blue-50 border-l-4 border-blue-400 rounded-r-lg">
      <p className="text-sm sm:text-base text-blue-800 font-medium">
        💡 Leave fields empty to use default URLs, or provide custom ALM URLs for specific filtering and targeted data extraction.
      </p>
    </div>

    <div className="space-y-3 sm:space-y-4">
      {/* Custom order and names for artifacts - including Test Logs in proper position */}
      {[
        { key: 'releases', config: dataTypes.releases, displayName: 'Releases' },
        { key: 'requirements', config: dataTypes.requirements, displayName: 'Requirements' },
        { key: 'testcases', config: dataTypes.testcases, displayName: 'Test Cases' },
        { key: 'testruns', config: dataTypes.testruns, displayName: 'Test Runs' },
        { 
          key: 'testlogs', 
          config: { icon: '📋' }, 
          displayName: 'Test Logs',
          isTestLogs: true 
        },
        { key: 'defects', config: dataTypes.defects, displayName: 'Defects' }
      ].map(({ key, config, displayName, isTestLogs }) => (
        <div key={key} className="group">
          <div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4">
            {/* Label - fixed width for alignment */}
            <div className="flex-shrink-0 w-full sm:w-[160px]">
              <span
                className={`inline-flex items-center px-4 py-2.5 rounded-full text-sm font-semibold transition-all duration-200 w-full sm:w-[160px] justify-center ${
                  isTestLogs 
                    ? (selectedArtifacts.testruns 
                        ? 'bg-blue-500 text-white shadow-md'
                        : 'bg-gray-400 text-white shadow-md hover:bg-gray-500 hover:shadow-lg')
                    : (selectedArtifacts[key]
                        ? 'bg-blue-500 text-white shadow-md'
                        : 'bg-gray-400 text-white shadow-md hover:bg-gray-500 hover:shadow-lg')
                }`}
              >
                <span className="mr-2">{config.icon}</span>
                <span>{displayName}</span>
              </span>
            </div>

            {/* Input field with better spacing */}
            <div className="flex-1 relative">
              <input
                type="text"
                placeholder={`Enter custom URL for ${displayName.toLowerCase()}...`}
                value={isTestLogs ? (customFilters.testlogs || '') : customFilters[key]}
                onChange={(e) => handleCustomFilterChange(isTestLogs ? 'testlogs' : key, e.target.value)}
                className="w-full px-4 py-2.5 text-sm border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all duration-200 bg-white hover:border-gray-400 placeholder-gray-500 text-gray-900"
                disabled={isProcessing || isMigrating}
              />
              {((isTestLogs && customFilters.testlogs) || (!isTestLogs && customFilters[key])) && (
                <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                </div>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  </div>
</div>
      
                  {/* Processing Status */}
        
                  {(isProcessing || isMigrating) && (
        
                    <div className="mb-8">
        
                      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border-2 border-blue-200 rounded-2xl p-6 shadow-lg">
        
                        <div className="flex items-center space-x-4">
        
                          <div className="relative">
        
                            <div className="animate-spin rounded-full h-8 w-8 border-3 border-blue-600 border-t-transparent"></div>
        
                            <div className="absolute inset-0 rounded-full h-8 w-8 border-3 border-blue-200"></div>
        
                          </div>
        
                          <div className="flex-1">
        
                            <h4 className="text-lg font-semibold text-blue-900 mb-1">
        
                              {isMigrating ? 'Migration in Progress' : 'Processing Data'}
        
                            </h4>
        
                            <p className="text-blue-700 font-medium">
        
                              {currentOperation || 'Please wait while we process your request...'}
        
                            </p>
        
                          </div>
        
                          <div className="text-blue-600">
        
                            <div className="flex space-x-1">
        
                              <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce"></div>
        
                              <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
        
                              <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
        
                            </div>
        
                          </div>
        
                        </div>
        
                      </div>
        
                    </div>
        
                  )}
        
        
        
                  {/* Migration Results */}
        
                  {Object.keys(migrationResults).length > 0 && (
        
                    <div className="mb-8">
        
                      <h4 className="text-2xl font-bold text-gray-900 mb-6">Migration Results</h4>
        
                      <div className="space-y-4">
        
                        {Object.entries(migrationResults).map(([type, result]) => (
        
                          <div key={type} className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-200">
        
                         <div className="p-4 space-y-3">
        
        
                              <div className="flex items-center space-x-3 mb-4">
        
                                <div className="p-2 rounded-lg bg-gray-100">
        
                                  {dataTypes[type].icon}
        
                                </div>
        
                                <h5 className="text-lg font-semibold text-gray-900">
        
                                  {dataTypes[type].title}
        
                                </h5>
        
                              </div>
        
        
        
                              <div className="space-y-3">
        
                                {/* Fetch & Insert Result */}
        
                                <div className={`p-2 rounded-xl border-2 transition-all duration-200 ${result.success
        
                                    ? 'bg-gradient-to-r from-green-50 to-emerald-50 border-green-200 hover:shadow-md'
        
                                    : 'bg-gradient-to-r from-red-50 to-pink-50 border-red-200 hover:shadow-md'
        
                                  }`}>
        
                                  <div className="flex items-start space-x-3">
        
                                    <div className={`p-1 rounded-full ${result.success ? 'bg-green-100' : 'bg-red-100'}`}>
        
                                      {result.success ? (
        
                                        <CheckCircle className="w-5 h-5 text-green-600" />
        
                                      ) : (
        
                                        <XCircle className="w-5 h-5 text-red-600" />
        
                                      )}
        
                                    </div>
        
                                    <div className="flex-1">
        
                                      <p className={`font-semibold ${result.success ? 'text-green-800' : 'text-red-800'
        
                                        }`}>
        
                                        Fetch & Insert Status
        
                                      </p>
        
                                      <p className={`text-sm mt-1 ${result.success ? 'text-green-700' : 'text-red-700'
        
                                        }`}>
        
                                        {result.message}
        
                                      </p>
        
                                      {!result.success && result.error && (
        
                                        <div className="mt-2 p-3 bg-red-100 rounded-lg">
        
                                          <p className="text-sm text-red-800 font-medium">Error Details:</p>
        
                                          <p className="text-sm text-red-700 mt-1">
        
                                            {result.error.message || 'Unknown error occurred'}
        
                                          </p>
        
                                        </div>
        
                                      )}
        
                                    </div>
        
                                  </div>
        
                                </div>
        
        
        
                                {/* Migration Result */}
        
                                {result.migrationMessage && (
        
                                  <div className={`p-2 rounded-xl border-2 transition-all duration-200 ${result.migrationSuccess
        
                                      ? 'bg-gradient-to-r from-purple-50 to-violet-50 border-purple-200 hover:shadow-md'
        
                                      : 'bg-gradient-to-r from-red-50 to-pink-50 border-red-200 hover:shadow-md'
        
                                    }`}>
        
                                    <div className="flex items-start space-x-3">
        
                                      <div className={`p-1 rounded-full ${result.migrationSuccess ? 'bg-purple-100' : 'bg-red-100'}`}>
        
                                        {result.migrationSuccess ? (
        
                                          <CheckCircle className="w-5 h-5 text-purple-600" />
        
                                        ) : (
        
                                          <XCircle className="w-5 h-5 text-red-600" />
        
                                        )}
        
                                      </div>
        
                                      <div className="flex-1">
        
                                        <p className={`font-semibold ${result.migrationSuccess ? 'text-purple-800' : 'text-red-800'
        
                                          }`}>
        
                                          Migration Status
        
                                        </p>
        
                                        <p className={`text-sm mt-1 ${result.migrationSuccess ? 'text-purple-700' : 'text-red-700'
        
                                          }`}>
        
                                          {result.migrationMessage}
        
                                        </p>
        
                                      </div>
        
                                    </div>
        
                                  </div>
        
                                )}
        
                              </div>
        
                            </div>
        
                          </div>
        
                        ))}
        
                      </div>
        
                    </div>
        
                  )}
        
        
        
             {/* Action Buttons */}
<div className="flex flex-col sm:flex-row lg:flex-row justify-between items-stretch sm:items-center flex-wrap gap-3 sm:gap-4 pt-4 sm:pt-6 border-t border-gray-200">        
          {/* Left group: Cancel, Fetch, Migration */}
          <div className="flex flex-col sm:flex-row gap-4">
            {/* Cancel */}
            <button
              onClick={handleCancel}
              disabled={isProcessing || isMigrating}
              className="min-w-[160px] px-6 py-3 border-2 border-gray-300 text-gray-700 font-semibold rounded-xl hover:bg-gray-50 hover:border-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
            >
              Cancel & Reset
            </button>
        
            {/* Fetch & Insert */}
            <button
              onClick={handleFetchAndInsert}
              disabled={isProcessing || isMigrating || Object.values(selectedArtifacts).every(v => !v)}
              className="min-w-[160px] px-6 py-3 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-bold rounded-xl shadow-md hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:cursor-not-allowed transition-all duration-200 flex items-center justify-center gap-2"
            >
              {isProcessing ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent"></div>
                  <span>Processing...</span>
                </>
              ) : (
                <>
                  <Database className="w-5 h-5" />
                  <span>Fetch & Insert Data</span>
                </>
              )}
            </button>
        
            {/* Migration */}
            <button
              onClick={handleMigrateSelected}
              disabled={
                isMigrating ||
                isProcessing ||
                Object.values(selectedArtifacts).every(v => !v) ||
                Object.entries(selectedArtifacts).filter(([_, selected]) => selected).some(([type]) => !insertSuccess[type])
              }
              className="min-w-[160px] px-6 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-bold rounded-xl shadow-md hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-purple-500 disabled:cursor-not-allowed transition-all duration-200 flex items-center justify-center gap-2"
            >
              {isMigrating ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent"></div>
                  <span>Migrating...</span>
                </>
              ) : (
                <>
                  <Upload className="w-5 h-5" />
                  <span>Migration</span>
                </>
              )}
            </button>
          </div>
        
      
        {/*Link & Attachments button */}
<div className="flex flex-col sm:flex-row gap-4">
  <Link
    to="/link"
    className={`min-w-[160px] px-6 py-3 bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-600 hover:to-emerald-700 text-white font-medium rounded-xl shadow-md hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-teal-500 transition-all duration-200 flex items-center justify-center gap-2 ${
      isProcessing || isMigrating ? 'pointer-events-none opacity-50' : ''
    }`}
  >
    <FileDown className="w-5 h-5" />
    <span>Link & Attachments</span>
  </Link>
</div>

        
        </div>
        
        
        
               {/* Migration Statistics */}
        
{migrationStarted && (
  <MigrationStatsDisplay
    selectedArtifacts={selectedArtifacts}
    migrationStats={migrationStats}
    isMigrating={isMigrating}
    currentlyMigratingArtifact={currentlyMigratingArtifact}
    dataTypes={dataTypes}
    migrationResults={migrationResults}
  />
)}
        
                </div>
              {/* Confirmation Dialog */}
        
                <ConfirmationDialog />
                 <ToastContainer position="top-right" autoClose={3000} />
        
              </div>
        
            </div>
      </>
    )}
  </>
);

};

export default Migrate;