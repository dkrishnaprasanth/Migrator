
// import React, { useState } from "react";
// import axios from "axios";

// export default function CsvUploader() {
//   const [file, setFile] = useState(null);
//   const [previewData, setPreviewData] = useState([]);
//   const [error, setError] = useState("");

//   const handleFileChange = (event) => {
//     const selectedFile = event.target.files[0];
//     setFile(selectedFile);
//     setError("");
//     setPreviewData([]);

//     if (selectedFile) {
//       const reader = new FileReader();
//       reader.onload = (e) => {
//         const text = e.target.result;
//         const rows = text.trim().split("\n").map((row) => row.split(","));
        
//         // Validate header
//         const headers = rows[0].map((h) => h.trim().toLowerCase());
//         if (headers[0] !== "email" || headers[1] !== "name" || headers[2] !== "qtest_email") {
//           setError("❌ Invalid CSV format. The first row must contain:email, name, qtest_email");
//           setFile(null);
//           return;
//         }

//         // Show first 5 rows for preview
//         setPreviewData(rows.slice(0, 6));
//       };
//       reader.readAsText(selectedFile);
//     }
//   };

//   const handleUpload = async () => {
//     if (!file) {
//       alert("Please select a valid CSV file first!");
//       return;
//     }

//     const formData = new FormData();
//     formData.append("csvFile", file);

//     try {
//       const response = await axios.post("http://localhost:5550/api/upload-csv", formData, {
//         headers: { "Content-Type": "multipart/form-data" },
//       });
//       alert(response.data.message);
//     } catch (error) {
//       console.error("Upload error:", error);
//       alert("Failed to upload CSV.");
//     }
//   };

//   return (
//     <div className="flex flex-col items-center p-6">
//       <h1 className="text-2xl font-bold mb-4">CSV File Upload</h1>
//       <input type="file" accept=".csv" onChange={handleFileChange} className="mb-4 border p-2 rounded" />

//       {error && <p className="text-red-500 mb-4">{error}</p>}

//       {previewData.length > 0 && (
//         <div className="mb-4 border rounded-lg shadow p-4 w-full max-w-xl">
//           <h2 className="font-semibold mb-2">📋 Preview:</h2>
//           <table className="table-auto w-full border-collapse border border-gray-300">
//             <thead>
//               <tr>
//                 {previewData[0].map((header, index) => (
//                   <th key={index} className="border border-gray-300 px-2 py-1 bg-gray-100">
//                     {header}
//                   </th>
//                 ))}
//               </tr>
//             </thead>
//             <tbody>
//               {previewData.slice(1).map((row, rowIndex) => (
//                 <tr key={rowIndex}>
//                   {row.map((cell, colIndex) => (
//                     <td key={colIndex} className="border border-gray-300 px-2 py-1">
//                       {cell}
//                     </td>
//                   ))}
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//           <p className="text-sm text-gray-500 mt-2">Showing first {previewData.length - 1} rows</p>
//         </div>
//       )}

//       <button
//         onClick={handleUpload}
//         disabled={!file || error}
//         className={`px-4 py-2 rounded-lg shadow text-white ${
//           !file || error ? "bg-gray-400 cursor-not-allowed" : "bg-blue-500 hover:bg-blue-600"
//         }`}
//       >
//         Upload
//       </button>
//     </div>
//   );
// }






// import React, { useState } from "react";
// import axios from "axios";
// import { DndProvider } from "react-dnd";
// import { Upload, FileText, AlertCircle, CheckCircle2 } from "lucide-react";
// import { HTML5Backend } from "react-dnd-html5-backend";
// import Topbar from "./Topbar";
// import Sidebar from "./Sidebar";
 
// export default function CsvUploader() {
//   const [file, setFile] = useState(null);
//   const [previewData, setPreviewData] = useState([]);
//   const [error, setError] = useState("");
//   const [success, setSuccess] = useState("");
 
 
//   const handleFileChange = (event) => {
//     const selectedFile = event.target.files[0];
//     setFile(selectedFile);
//     setError("");
//     setSuccess("");
//     setPreviewData([]);
 
//     if (selectedFile) {
//       const reader = new FileReader();
//       reader.onload = (e) => {
//         const text = e.target.result;
//         const rows = text.trim().split("\n").map((row) => row.split(","));
 
//         // Validate header
//         const headers = rows[0].map((h) => h.trim().toLowerCase());
//         if (
//           headers[0] !== "email" ||
//           headers[1] !== "name" ||
//           headers[2] !== "qtest_email"
//         ) {
//           setError(
//             "❌ Invalid CSV format. The first row must contain: email, name, qtest_email"
//           );
//           setFile(null);
//           return;
//         }
 
//         // Show first 5 rows for preview
//         setPreviewData(rows.slice(0, 6));
//       };
//       reader.readAsText(selectedFile);
//     }
//   };
 
//   const handleUpload = async () => {
//     if (!file) {
//       setError("Please select a valid CSV file first!");
//       return;
//     }
 
//     const formData = new FormData();
//     formData.append("csvFile", file);
 
//     try {
//       const response = await axios.post(
//         "http://localhost:5550/api/upload-csv",
//         formData,
//         {
//           headers: { "Content-Type": "multipart/form-data" },
//         }
//       );
//       setSuccess(response.data.message || "✅ File uploaded successfully!");
//       setError("");
//     } catch (err) {
//       console.error("Upload error:", err);
//       setError("❌ Failed to upload CSV.");
//       setSuccess("");
//     }
//   };
 
//   return (
// <div>
 
//      {/* Sidebar */}
//        <Sidebar/>
//        {/* Topbar */}
//        <Topbar />
 
//   <DndProvider backend={HTML5Backend}>
//    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-6">
//       <div className="w-full max-w-2xl bg-white rounded-2xl shadow-lg p-6 space-y-6">
//         <h1 className="text-2xl font-bold text-center text-gray-800">
//           <Upload className="inline w-6 h-6 mr-2 text-blue-600" />
//           CSV File Upload
//         </h1>
 
//         {/* File input */}
//         <div className="flex flex-col items-center">
//           <input
//             type="file"
//             accept=".csv"
//             onChange={handleFileChange}
//             className="hidden"
//             id="csvInput"
//           />
//           <label
//             htmlFor="csvInput"
//             className="cursor-pointer flex items-center gap-2 bg-blue-50 border border-dashed border-blue-400 text-blue-600 px-6 py-3 rounded-lg hover:bg-blue-100 transition"
//           >
//             <FileText className="w-5 h-5" />
//             {file ? file.name : "Choose a CSV file"}
//           </label>
//         </div>
 
//         {/* Error & Success messages */}
//         {error && (
//           <p className="flex items-center gap-2 text-red-600 bg-red-50 p-3 rounded-lg text-sm">
//             <AlertCircle className="w-5 h-5" /> {error}
//           </p>
//         )}
//         {success && (
//           <p className="flex items-center gap-2 text-green-600 bg-green-50 p-3 rounded-lg text-sm">
//             <CheckCircle2 className="w-5 h-5" /> {success}
//           </p>
//         )}
 
//         {/* Preview Table */}
//         {previewData.length > 0 && (
//           <div className="border rounded-lg shadow-sm overflow-hidden">
//             <h2 className="font-semibold text-gray-700 px-4 py-2 bg-gray-100 border-b">
//               📋 Preview
//             </h2>
//             <div className="overflow-x-auto">
//               <table className="table-auto w-full text-sm border-collapse">
//                 <thead>
//                   <tr>
//                     {previewData[0].map((header, index) => (
//                       <th
//                         key={index}
//                         className="border border-gray-300 px-3 py-2 bg-gray-50 text-gray-700"
//                       >
//                         {header}
//                       </th>
//                     ))}
//                   </tr>
//                 </thead>
//                 <tbody>
//                   {previewData.slice(1).map((row, rowIndex) => (
//                     <tr key={rowIndex} className="hover:bg-gray-50">
//                       {row.map((cell, colIndex) => (
//                         <td
//                           key={colIndex}
//                           className="border border-gray-300 px-3 py-2 text-gray-600"
//                         >
//                           {cell}
//                         </td>
//                       ))}
//                     </tr>
//                   ))}
//                 </tbody>
//               </table>
//             </div>
//             <p className="text-xs text-gray-500 px-4 py-2">
//               Showing first {previewData.length - 1} rows
//             </p>
//           </div>
//         )}
 
//         {/* Upload button */}
//         <div className="flex justify-center">
//           <button
//             onClick={handleUpload}
//             disabled={!file || error}
//             className={`px-6 py-2 rounded-lg shadow font-medium text-white transition ${
//               !file || error
//                 ? "bg-gray-400 cursor-not-allowed"
//                 : "bg-blue-600 hover:bg-blue-700"
//             }`}
//           >
//             Upload
//           </button>
//         </div>
//       </div>
//     </div>
//   </DndProvider>
// </div>
   
   
//   );
// }



 
import React, { useState, useRef } from "react";
import axios from "axios";
import { DndProvider } from "react-dnd";
import { Upload, FileText, AlertCircle, CheckCircle2 } from "lucide-react";
import { HTML5Backend } from "react-dnd-html5-backend";
import Topbar from "./Topbar";
import Sidebar from "./Sidebar";
 
export default function CsvUploader() {
  const [file, setFile] = useState(null);
  const [previewData, setPreviewData] = useState([]);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [uploaded, setUploaded] = useState(false); // ✅ track upload status
  const fileInputRef = useRef(null);
 
  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];
    setFile(selectedFile);
    setError("");
    setSuccess("");
    setPreviewData([]);
    setUploaded(false); // ✅ allow upload again when new file chosen
 
    if (selectedFile) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target.result;
        const rows = text.trim().split("\n").map((row) => row.split(","));
 
        // Validate header
        const headers = rows[0].map((h) => h.trim().toLowerCase());
        if (
          headers[0] !== "email" ||
          headers[1] !== "name" ||
          headers[2] !== "qtest_email"
        ) {
          setError(
            "❌ Invalid CSV format. The first row must contain: email, name, qtest_email"
          );
          setFile(null);
          return;
        }
 
        // Show first 5 rows for preview
        setPreviewData(rows.slice(0, 6));
      };
      reader.readAsText(selectedFile);
    }
  };
 
  const handleUpload = async () => {
    if (!file || uploaded) return; // ✅ prevent multiple uploads
 
    const formData = new FormData();
    formData.append("csvFile", file);
 
    try {
      const response = await axios.post(
        "http://localhost:5550/api/upload-csv",
        formData,
        {
          headers: { "Content-Type": "multipart/form-data" },
        }
      );
      setSuccess(response.data.message || "✅ File uploaded successfully!");
      setError("");
      setUploaded(true); // ✅ mark as uploaded
    } catch (err) {
      console.error("Upload error:", err);
      setError("❌ Failed to upload CSV.");
      setSuccess("");
    }
  };
 
  return (
    <div>
      <Sidebar />
      <Topbar />
 
      <DndProvider backend={HTML5Backend}>
        <div className="min-h-screen flex items-center justify-center bg-gray-50 p-6">
          <div className="w-full max-w-2xl bg-white rounded-2xl shadow-lg p-6 space-y-6">
            <h1 className="text-2xl font-bold text-center text-gray-800">
              <Upload className="inline w-6 h-6 mr-2 text-blue-600" />
              CSV File Upload
            </h1>
 
            {/* File input */}
            <div className="flex flex-col items-center">
              <input
                type="file"
                accept=".csv"
                ref={fileInputRef}
                onChange={handleFileChange}
                className="hidden"
                id="csvInput"
              />
              <label
                htmlFor="csvInput"
                className="cursor-pointer flex items-center gap-2 bg-blue-50 border border-dashed border-blue-400 text-blue-600 px-6 py-3 rounded-lg hover:bg-blue-100 transition"
              >
                <FileText className="w-5 h-5" />
                {file ? file.name : "Choose a CSV file"}
              </label>
            </div>
 
            {/* Error & Success messages */}
            {error && (
              <p className="flex items-center gap-2 text-red-600 bg-red-50 p-3 rounded-lg text-sm">
                <AlertCircle className="w-5 h-5" /> {error}
              </p>
            )}
            {success && (
              <p className="flex items-center gap-2 text-green-600 bg-green-50 p-3 rounded-lg text-sm">
                <CheckCircle2 className="w-5 h-5" /> {success}
              </p>
            )}
 
            {/* Preview Table */}
            {previewData.length > 0 && (
              <div className="border rounded-lg shadow-sm overflow-hidden">
                <h2 className="font-semibold text-gray-700 px-4 py-2 bg-gray-100 border-b">
                  📋 Preview
                </h2>
                <div className="overflow-x-auto">
                  <table className="table-auto w-full text-sm border-collapse">
                    <thead>
                      <tr>
                        {previewData[0].map((header, index) => (
                          <th
                            key={index}
                            className="border border-gray-300 px-3 py-2 bg-gray-50 text-gray-700"
                          >
                            {header}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {previewData.slice(1).map((row, rowIndex) => (
                        <tr key={rowIndex} className="hover:bg-gray-50">
                          {row.map((cell, colIndex) => (
                            <td
                              key={colIndex}
                              className="border border-gray-300 px-3 py-2 text-gray-600"
                            >
                              {cell}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <p className="text-xs text-gray-500 px-4 py-2">
                  Showing first {previewData.length - 1} rows
                </p>
              </div>
            )}
 
            {/* Upload button */}
            <div className="flex justify-center">
              <button
                onClick={handleUpload}
                disabled={!file || error || uploaded} // ✅ disable if uploaded
                className={`px-6 py-2 rounded-lg shadow font-medium text-white transition ${
                  !file || error || uploaded
                    ? "bg-gray-400 cursor-not-allowed"
                    : "bg-blue-600 hover:bg-blue-700"
                }`}
              >
                {uploaded ? "Uploaded" : "Upload"}
              </button>
            </div>
          </div>
        </div>
      </DndProvider>
    </div>
  );
}
 