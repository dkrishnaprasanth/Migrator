import React, { useState } from "react";
import { HiSearch, HiOutlineBell, HiOutlineViewGrid } from "react-icons/hi";
import { FiSettings, FiKey } from "react-icons/fi";
import { Link } from "react-router-dom";
import logo from "../assets/image.jpg";
    import { FiLink } from "react-icons/fi"; // make sure to import
const Topbar = () => {
  const [notifications] = useState(3);
 
  return (
    <div className="fixed top-0 left-0 w-full z-50 bg-white/80 backdrop-blur border-b border-gray-200 shadow-md">
      <div className="max-w-screen-2xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16">
        {/* Logo Section */}
        <div className="flex items-center space-x-3">
          <div className="relative w-12 h-12 rounded-xl overflow-hidden shadow-md hover:scale-105 transition-transform duration-300">
            <img
              src={logo}
              alt="Logo"
              className="object-cover w-full h-full"
            />
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white rounded-full animate-pulse"></span>
          </div>
          <div className="hidden sm:block">
            <h1 className="text-lg sm:text-xl font-semibold text-gray-800 leading-tight">
              Migrate to Modernize
            </h1>
            <p className="text-xs text-gray-500">Efficiency in migration</p>
          </div>
        </div>
 
        {/* Action Buttons */}
        <div className="flex items-center space-x-2">
          {/* Search - Mobile only */}
          <button className="md:hidden p-2 rounded-xl hover:bg-gray-100 transition duration-200">
            <HiSearch className="w-5 h-5 text-gray-600" />
          </button>
 
          {/* Grid View */}
          <button className="p-2 rounded-xl hover:bg-gray-100 transition duration-200">
            <HiOutlineViewGrid className="w-5 h-5 text-gray-600" />
          </button>
 
          {/* Notifications
          <button className="relative p-2 rounded-xl hover:bg-gray-100 transition duration-200">
            <HiOutlineBell className="w-5 h-5 text-gray-600" />
            {notifications > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 text-[10px] bg-red-500 text-white rounded-full flex items-center justify-center animate-bounce">
                {notifications}
              </span>
            )} */}
          {/* </button> */}
 
          {/* Settings */}
          <button className="p-2 rounded-xl hover:bg-gray-100 transition duration-200 group">
            <FiSettings className="w-5 h-5 text-gray-600 group-hover:rotate-90 transition-transform duration-300" />
          </button>
 
          {/* Credentials Button */}
       

<Link to="/settings">
  <button className="hidden md:flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-medium shadow-md hover:shadow-lg transition-all duration-200">
    <FiLink className="w-4 h-4" />
    <span className="text-sm">Endpoints</span>
  </button>
</Link>

        </div>
      </div>
    </div>
  );
};
 
export default Topbar;