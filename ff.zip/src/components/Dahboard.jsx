
import React, { useState } from "react";
import Sidebar from "./Sidebar";
import Topbar from "./Topbar";


const Dahboard = () => {
 
  return (
    <div className="flex h-screen mt-20">
 
        {/* Sidebar */}
      <Sidebar/>
        {/* Topbar */}
        <Topbar />
    
      </div>
    
  );
};

export default Dahboard;

