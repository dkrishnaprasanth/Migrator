import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Register from "./components/Register";
import DataTable from "./components/DataTable";
import DashboardDefects from "./components/DashboardDefects";
import SettingsPage from "./components/SettingsPage";
import Dahboard from "./components/Dahboard";
import Parameter from "./components/Parameter";
import ExecutionTestInstance from "./components/ExecutionTestInstance";
import ApproveTestCase from "./components/ApproveTestCase";
import Releases from "./components/Releases";
import Requirement from "./components/Requirement";
import TestCase from "./components/TestCase";
import Testshould from "./components/Testshould";
import LinkPage from "./components/linkingpage";
import Migrate from "./components/Migrate";
import Reporting from "./components/Reporting";
import Login from "./components/Login";

import Users from "./components/Users";

function App() {
  return (

    <Router>
      <Routes>

        {/* login and register */}
        <Route path="/" element={<Login />} />
        <Route path="/register" element={<Register />} />

        {/* Test Plan */}
        <Route path="/release" element={<Releases />} />

        {/* Requirements */}
        <Route path="/requirement" element={<Requirement />} />

         {/* Test Design */}
        <Route path="/test-case" element={<TestCase />} />

         {/* Test Execution */}
        <Route path="/test-run" element={<ExecutionTestInstance />} />
        <Route path="/test-suite" element={<Testshould />} />

        {/* defects */}
        <Route path="/dashboarddefects" element={<DashboardDefects />} />

        {/* Migrate */}
        <Route path="/migrate" element={<Migrate />} />

        {/* Reporting */}
        <Route path="/reporting" element={<Reporting />} />

        {/* Approve Test Case */}
        <Route path="/approvetestcase" element={<ApproveTestCase />} />
        
        {/* SettingsPage */}
        <Route path="/settings" element={<SettingsPage />} />

        {/* Parameter */}
        <Route path="/parameter" element={<Parameter />} />

        {/*linkpage  */}
        <Route path="/link" element={<LinkPage />} />

        <Route path="/dashboard" element={<Dahboard />} />
        <Route path="/datatable" element={<DataTable/>} />

        <Route path="/users" element={<Users/>} />
      </Routes>
    </Router>
  );
}

export default App;

